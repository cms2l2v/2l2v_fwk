
#include <string>
#include <vector>

#include "TROOT.h"
#include "TStyle.h"
#include "TFile.h"
#include "TDirectory.h"
#include "TChain.h"
#include "TObject.h"
#include "TCanvas.h"
#include "TMath.h"
#include "TLegend.h"
#include "TGraph.h"
#include "TH1.h"
#include "TH2.h"
#include "TH3.h"
#include "TTree.h"
#include "TF1.h"
#include "TCutG.h"
#include "TGraphErrors.h"
#include "TGraphAsymmErrors.h"
#include "TMultiGraph.h"
#include "TPaveText.h"


TH1D* readHistoFromDatFile(string filePath, string name){
  FILE* pFile = fopen(filePath.c_str(), "r");
  if(!pFile){printf("File can not be open:\n%s\n", filePath.c_str()); return NULL;}

  //read file line by line
  char line[4096]; int lc=0;
  char title[2048];  
  float xmin=0, xmax=0, xwidth=0;
  int Nbins=0;  TH1D* histo=NULL;
  while(true){
     if(! fgets(line, 4096, pFile))break;
     if(lc==1){
        sscanf(line, "title: %s\n", title);
     }else if(lc==3){
        sscanf(line, "partition: %f %f %f %i\n", &xmin, &xmax, &xwidth, &Nbins);
        histo = new TH1D((name).c_str(), title, Nbins, xmin, xmax);
     }else if(lc>=5 && lc<5+Nbins){
         int bin=0, chi2=0;  double val=0, err=0;
         sscanf(line, "%i %lf %lf %i\n", &bin, &val, &err, &chi2);
         histo->SetBinContent(bin, val);
         histo->SetBinError(bin, err);
     }else if(lc==5+Nbins){
         break; //if you want to read more than one histo in the file, some special treatment must be done here
     }
     lc++;
  }//end parsing the file
  fclose(pFile);
  return histo;
}


TH1D* readHistoFromRootFile(string filePath, string name){
   TH1D* toReturn = NULL;
   int NHisto=0;
   for(int i=0;i<35;i++){
     char buffer[1024]; sprintf(buffer, "%s/gg2VV_%i_histo.root", filePath.c_str(), i);
     TFile* file = TFile::Open(buffer, "Read");
     if(!file || file->IsZombie() || !file->IsOpen() || file->TestBit(TFile::kRecovered) ){/*printf("File %s does not exist\n", buffer);*/ continue; }
     TH1D* tempHisto = (TH1D*)file->Get("mZZ");  
     if(!tempHisto){/*printf("File %s does not exist\n", buffer);*/ continue; }
     if(toReturn==NULL){toReturn = (TH1D*)tempHisto->Clone(name.c_str()); toReturn->SetDirectory(0);}else{toReturn->Add(tempHisto);}
     NHisto++;
     file->Close();
   }
   if(toReturn){toReturn->Scale(1.0/NHisto);}
   return toReturn;
}

void histoToWeightFile()
{
  //style options
  gStyle->SetCanvasBorderMode(0);
  gStyle->SetCanvasColor(kWhite);
  gStyle->SetFrameBorderMode(0);
  gStyle->SetFrameBorderSize(1);
  gStyle->SetFrameFillColor(0);
  gStyle->SetFrameFillStyle(0);
  gStyle->SetFrameLineColor(1);
  gStyle->SetFrameLineStyle(1);
  gStyle->SetFrameLineWidth(1);
  gStyle->SetOptFit(1);
  gStyle->SetFitFormat("5.4g");
  gStyle->SetFuncColor(2);
  gStyle->SetOptFile(0);
  //gStyle->SetOptStat(0);
  gStyle->SetOptStat("mr");
  gStyle->SetStatColor(kWhite);
  gStyle->SetStatFont(42);
  gStyle->SetStatFontSize(0.04);
  gStyle->SetStatTextColor(1);
  gStyle->SetStatFormat("6.4g");
  gStyle->SetStatBorderSize(1);
  gStyle->SetStatH(0.1);
  gStyle->SetStatW(0.2);
  gStyle->SetPadTopMargin(0.05);
  gStyle->SetPadBottomMargin(0.13);
  gStyle->SetPadLeftMargin(0.16);
  gStyle->SetPadRightMargin(0.02);
  gStyle->SetOptTitle(0);
  gStyle->SetTitleFont(42);
  gStyle->SetTitleColor(1);
  gStyle->SetTitleTextColor(1);
  gStyle->SetTitleFillColor(10);
  gStyle->SetTitleFontSize(0.05);
  gStyle->SetAxisColor(1, "XYZ");
  gStyle->SetStripDecimals(kTRUE);
  gStyle->SetTickLength(0.03, "XYZ");
  gStyle->SetNdivisions(510, "XYZ");
  gStyle->SetPadTickX(1);  // To get tick marks on the opposite side of the frame
  gStyle->SetPadTickY(1);
  gStyle->SetEndErrorSize(2);
  gStyle->SetErrorX(0.);
  gStyle->SetMarkerStyle(20); 
  gROOT->ForceStyle();
  gStyle->SetPadTopMargin   (0.06);
  gStyle->SetPadBottomMargin(0.12);
  gStyle->SetPadRightMargin (0.06);
  gStyle->SetPadLeftMargin  (0.14);
  gStyle->SetTitleSize(0.04, "XYZ");
  gStyle->SetTitleXOffset(1.1);
  gStyle->SetTitleYOffset(1.45);
  gStyle->SetPalette(1);
  gStyle->SetNdivisions(505);

  //Build the kFractor from Passarino values.   These kFactors are used only for mH>=400GeV. (also build fake kFactors = 1 formH<400GeV) 
  double kFactorUnity_x[] = {211, 999}; 
  double kFactorUnity_y[] = {1.0, 1.0};
  TGraph* kFactorUnity = new TGraph(sizeof(kFactorUnity_x)/sizeof(double), kFactorUnity_x, kFactorUnity_y);
  double kFactorPassarino_x[] = {211, 213, 215, 217, 219, 221, 223, 225, 227, 229, 231, 233, 235, 237, 239, 241, 243, 245, 247, 249, 251, 253, 255, 257, 259, 261, 263, 265, 267, 269, 271, 273, 275, 277, 279, 281, 283, 285, 287, 289, 291, 293, 295, 297, 299, 301, 303, 305, 307, 309, 311, 313, 315, 317, 319, 321, 323, 325, 327, 329, 331, 333, 335, 337, 339, 341, 343, 345, 347, 349, 351, 353, 355, 357, 359, 361, 363, 365, 367, 369, 371, 373, 375, 377, 379, 381, 383, 385, 387, 389, 391, 393, 395, 397, 399, 401, 403, 405, 407, 409, 411, 413, 415, 417, 419, 421, 423, 425, 427, 429, 431, 433, 435, 437, 439, 441, 443, 445, 447, 449, 451, 453, 455, 457, 459, 461, 463, 465, 467, 469, 471, 473, 475, 477, 479, 481, 483, 485, 487, 489, 491, 493, 495, 497, 499, 501, 503, 505, 507, 509, 511, 513, 515, 517, 519, 521, 523, 525, 527, 529, 531, 533, 535, 537, 539, 541, 543, 545, 547, 549, 551, 553, 555, 557, 559, 561, 563, 565, 567, 569, 571, 573, 575, 577, 579, 581, 583, 585, 587, 589, 591, 593, 595, 597, 599, 601, 603, 605, 607, 609, 611, 613, 615, 617, 619, 621, 623, 625, 627, 629, 631, 633, 635, 637, 639, 641, 643, 645, 647, 649, 651, 653, 655, 657, 659, 661, 663, 665, 667, 669, 671, 673, 675, 677, 679, 681, 683, 685, 687, 689, 691, 693, 695, 697, 699, 701, 703, 705, 707, 709, 711, 713, 715, 717, 719, 721, 723, 725, 727, 729, 731, 733, 735, 737, 739, 741, 743, 745, 747, 749, 751, 753, 755, 757, 759, 761, 763, 765, 767, 769, 771, 773, 775, 777, 779, 781, 783, 785, 787, 789, 791, 793, 795, 797, 799, 801, 803, 805, 807, 809, 811, 813, 815, 817, 819, 821, 823, 825, 827, 829, 831, 833, 835, 837, 839, 841, 843, 845, 847, 849, 851, 853, 855, 857, 859, 861, 863, 865, 867, 869, 871, 873, 875, 877, 879, 881, 883, 885, 887, 889, 891, 893, 895, 897, 899, 901, 903, 905, 907, 909, 911, 913, 915, 917, 919, 921, 923, 925, 927, 929, 931, 933, 935, 937, 939, 941, 943, 945, 947, 949, 951, 953, 955, 957, 959, 961, 963, 965, 967, 969, 971, 973, 975, 977, 979, 981, 983, 985, 987, 989, 991, 993, 995, 997, 999};
  double kFactorPassarino_y[] = {1.9891, 1.9913, 1.9934, 1.995, 1.9964, 1.9976, 1.9985, 1.9995, 1.9999, 2.0006, 2.0011, 2.0015, 2.002, 2.0026, 2.0034, 2.0046, 2.0058, 2.0069, 2.0075, 2.0078, 2.0072, 2.0061, 2.0047, 2.0033, 2.0021, 2.0015, 2.0012, 2.0016, 2.0023, 2.0034, 2.0049, 2.0066, 2.0082, 2.0095, 2.0101, 2.0101, 2.0095, 2.0088, 2.0082, 2.008, 2.0087, 2.0101, 2.0118, 2.0135, 2.015, 2.0159, 2.016, 2.0159, 2.0151, 2.0147, 2.014, 2.0135, 2.013, 2.0127, 2.0124, 2.0122, 2.0119, 2.0115, 2.0107, 2.0093, 2.0071, 2.0043, 2.0009, 1.997, 1.9927, 1.9878, 1.982, 1.9726, 1.9611, 1.959, 1.9595, 1.9616, 1.9651, 1.9691, 1.9733, 1.9783, 1.9824, 1.9853, 1.9876, 1.9898, 1.9924, 1.9955, 1.9991, 2.0028, 2.0067, 2.0104, 2.0137, 2.0171, 2.0202, 2.0231, 2.026, 2.0286, 2.0312, 2.0337, 2.0363, 2.0392, 2.0421, 2.0451, 2.0479, 2.0507, 2.0532, 2.0556, 2.058, 2.0604, 2.0629, 2.0659, 2.0689, 2.0719, 2.0749, 2.0775, 2.0795, 2.0813, 2.0827, 2.0844, 2.0867, 2.0895, 2.093, 2.0968, 2.1007, 2.1043, 2.1074, 2.1099, 2.1117, 2.1131, 2.1139, 2.1143, 2.1144, 2.1142, 2.1141, 2.1142, 2.1146, 2.1154, 2.1165, 2.1182, 2.1202, 2.1228, 2.1258, 2.1286, 2.1316, 2.134, 2.1358, 2.1373, 2.1383, 2.1391, 2.1401, 2.1414, 2.1431, 2.1451, 2.1475, 2.1501, 2.1529, 2.1559, 2.1589, 2.1617, 2.1643, 2.1667, 2.1687, 2.1703, 2.1716, 2.1725, 2.1732, 2.1735, 2.1738, 2.174, 2.1742, 2.1748, 2.1755, 2.1764, 2.1775, 2.1788, 2.1801, 2.1817, 2.1835, 2.1853, 2.1872, 2.1895, 2.1917, 2.1937, 2.1958, 2.1975, 2.1991, 2.2003, 2.2012, 2.2022, 2.2034, 2.2046, 2.2059, 2.2074, 2.2089, 2.2108, 2.2124, 2.2141, 2.216, 2.2178, 2.2197, 2.2218, 2.2242, 2.2264, 2.2285, 2.2304, 2.232, 2.2334, 2.2346, 2.2357, 2.2368, 2.2379, 2.2392, 2.2406, 2.2421, 2.2438, 2.2453, 2.2469, 2.2485, 2.2503, 2.2521, 2.254, 2.2561, 2.258, 2.26, 2.2616, 2.2629, 2.2639, 2.2648, 2.2658, 2.267, 2.2687, 2.2707, 2.2731, 2.2754, 2.2775, 2.2795, 2.281, 2.2823, 2.2833, 2.2844, 2.2854, 2.2866, 2.2879, 2.2894, 2.2912, 2.2933, 2.2957, 2.2981, 2.3007, 2.3031, 2.3053, 2.3072, 2.3089, 2.3104, 2.3119, 2.3133, 2.3147, 2.3162, 2.3178, 2.3197, 2.3219, 2.3242, 2.3266, 2.329, 2.3312, 2.333, 2.3347, 2.3362, 2.3377, 2.3394, 2.3414, 2.3438, 2.3463, 2.3488, 2.3513, 2.3533, 2.3549, 2.3565, 2.358, 2.3596, 2.3615, 2.3637, 2.3659, 2.3682, 2.3705, 2.3728, 2.3748, 2.3768, 2.3788, 2.381, 2.3835, 2.386, 2.3887, 2.3914, 2.394, 2.3963, 2.3985, 2.4005, 2.4025, 2.4043, 2.4064, 2.4086, 2.4108, 2.4132, 2.4157, 2.4184, 2.4212, 2.4239, 2.4262, 2.4278, 2.4287, 2.4294, 2.4298, 2.4309, 2.4333, 2.4373, 2.4429, 2.4491, 2.4548, 2.4595, 2.462, 2.4628, 2.4623, 2.4617, 2.4617, 2.4632, 2.4664, 2.4707, 2.4755, 2.4804, 2.4848, 2.4885, 2.4918, 2.4947, 2.4975, 2.5002, 2.5031, 2.5059, 2.5085, 2.5107, 2.5126, 2.5141, 2.5159, 2.5182, 2.5215, 2.5258, 2.5314, 2.5373, 2.5429, 2.5475, 2.5505, 2.552, 2.5525, 2.553, 2.5538, 2.556, 2.5593, 2.5636, 2.5683, 2.573, 2.5775, 2.5815, 2.585, 2.5884, 2.5915, 2.5947, 2.598, 2.601, 2.604, 2.6066, 2.6087, 2.6108, 2.6128, 2.6153, 2.6182, 2.6219, 2.6266, 2.6317, 2.6371, 2.6425, 2.6477, 2.6521, 2.6565, 2.6606, 2.6648, 2.6688, 2.6726, 2.6765, 2.6805, 2.684, 2.6876, 2.6908, 2.6939, 2.697, 2.7001, 2.7032, 2.7065, 2.7099, 2.7134, 2.7134};
  TGraph* kFactorPassarino = new TGraph(sizeof(kFactorPassarino_x)/sizeof(double), kFactorPassarino_x, kFactorPassarino_y);



  double mHlist [] = {200, 250, 300, 350, 400, 450, 500, 550, 600, 650, 700, 750, 800, 850, 900, 950, 1000};
  double CPlist [] = {0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0};

//  double mHlist [] = {750};
//  double CPlist [] = {0.8};


//  double mHlist [] = {200};
//  double CPlist [] = {1.0};

  TFile* OutputFile = new TFile("Weights.root", "RECREATE");
  for(unsigned int mHi = 0; mHi<sizeof(mHlist)/sizeof(double); mHi++){
  for(unsigned int CPi = 0; CPi<sizeof(CPlist)/sizeof(double); CPi++){
     double mH = mHlist[mHi];
     double CP = CPlist[CPi];

     char dirName  [1024]; sprintf(dirName  , "%i_%3.1f_%3.1f", (int)mH, CP, 0.0);
////To run on histo.dat files
//     char path_B   [1024]; sprintf(path_B   , "../gg2VV_P0/gg2VV/results/%i_0_%3.1f/gg2VV.dat", (int)mH, CP);
//     char path_S   [1024]; sprintf(path_S   , "../gg2VV_P1/gg2VV/results/%i_1_%3.1f/gg2VV.dat", (int)mH, CP);
//     char path_SBI [1024]; sprintf(path_SBI , "../gg2VV_P2/gg2VV/results/%i_2_%3.1f/gg2VV.dat", (int)mH, CP);
//     char path_Sm  [1024]; sprintf(path_Sm  , "../gg2VV_P1/gg2VV/results/%i_1_%3.1f/gg2VV.dat", (int)mH, 1.0);
//     char path_SmBI[1024]; sprintf(path_SmBI, "../gg2VV_P2/gg2VV/results/%i_2_%3.1f/gg2VV.dat", (int)mH, 1.0);

////To run on histo.root files
     char path_B   [1024]; sprintf(path_B   , "../testGG2VV_JianSelection/gg2VV/results/%i_0_%3.1f/", (int)200, 1.0);
     char path_S   [1024]; sprintf(path_S   , "../testGG2VV_JianSelection/gg2VV/results/%i_1_%3.1f/", (int)mH, CP);
     char path_SBI [1024]; sprintf(path_SBI , "../testGG2VV_JianSelection/gg2VV/results/%i_2_%3.1f/", (int)mH, CP);
     char path_Sm  [1024]; sprintf(path_Sm  , "../testGG2VV_JianSelection/gg2VV/results/%i_1_%3.1f/", (int)mH, 1.0);
     char path_SmBI[1024]; sprintf(path_SmBI, "../testGG2VV_JianSelection/gg2VV/results/%i_2_%3.1f/", (int)mH, 1.0);

     //init kFactors
     TGraph* kFactor = (mH<400 ? kFactorUnity : kFactorPassarino);

     //get the background (=ZZ continum)
     TH1D* hB = readHistoFromRootFile(path_B, "B"); if(!hB){printf("Background sample missing for mH=%f C'=%f\n", mH, CP); continue;}
          
     /////////////////////////////////// TAKE CARE OF THE SIGNAL  
     //get the pure signal sample
     TH1D* hS = readHistoFromRootFile(path_S, "S"); if(!hS){printf("Signal sample missing for mH=%f C'=%f\n", mH, CP); continue;}


     //get the signal + background + interference sample
     TH1D* hSBI = readHistoFromRootFile(path_SBI, "SBI"); if(!hSBI){printf("SBI sample missing for mH=%f C'=%f\n", mH, CP); continue;}

     //scale the pure signal sample to NNLO (multiply by kFactors)
     TH1D* hS_nnlo  = (TH1D*)hS->Clone("hS_nnlo");
     for(int x=1;x<=hS_nnlo->GetNbinsX();x++){ hS_nnlo->SetBinContent(x, hS_nnlo->GetBinContent(x) * kFactor->Eval(hS_nnlo->GetXaxis()->GetBinCenter(x)) ); }

     //get the pure interference signal and scale it to NNLO (multiply by sqrt(kFactors)
     TH1D* hI_nnlo  = (TH1D*)hSBI->Clone("hI_nnlo");   hI_nnlo->Add(hB, -1);  hI_nnlo->Add(hS, -1);     
     TH1D* hIup_nnlo  = (TH1D*)hI_nnlo->Clone("hIup_nnlo");
     TH1D* hIdn_nnlo  = (TH1D*)hI_nnlo->Clone("hIdn_nnlo");
     for(int x=1;x<=hI_nnlo->GetNbinsX();x++){ hI_nnlo  ->SetBinContent(x, hI_nnlo->GetBinContent(x)   * sqrt(kFactor->Eval(hI_nnlo->GetXaxis()->GetBinCenter(x))) ); }
     for(int x=1;x<=hI_nnlo->GetNbinsX();x++){ hIup_nnlo->SetBinContent(x, hIup_nnlo->GetBinContent(x) *     (kFactor->Eval(hI_nnlo->GetXaxis()->GetBinCenter(x))) ); }
     for(int x=1;x<=hI_nnlo->GetNbinsX();x++){ hIdn_nnlo->SetBinContent(x, hIdn_nnlo->GetBinContent(x) * 1 ); }

     //Built a sampe of Signal+Interferance but without the background
     TH1D* hSI_nnlo   = (TH1D*)hS_nnlo->Clone("hSI_nnlo"  );  hSI_nnlo  ->Add(hI_nnlo  , 1);
     TH1D* hSIup_nnlo = (TH1D*)hS_nnlo->Clone("hSIup_nnlo");  hSIup_nnlo->Add(hIup_nnlo, 1);
     TH1D* hSIdn_nnlo = (TH1D*)hS_nnlo->Clone("hSIdn_nnlo");  hSIdn_nnlo->Add(hIdn_nnlo, 1);

     /////////////////////////////////// TAKE CARE OF THE STANDARD MODEL CASE     
     //get the pure signal sample for the case of a standard model like higgs (C'=1 BRNew=0)
     TH1D* hSm = readHistoFromRootFile(path_Sm, "Ssm"); if(!hSm){printf("SM sample missing for mH=%f C'=%f\n", mH, CP); continue;}

     //get the signal + background + interference sample for the standard model like case (C'=1 BRNew=0)
     TH1D* hSmBI = readHistoFromRootFile(path_SmBI, "SBIsm"); if(!hSmBI){printf("SM SBI sample missing for mH=%f C'=%f\n", mH, CP); continue;}

     //scale the pure signal sample to NNLO (multiply by kFactors)
     TH1D* hSm_nnlo  = (TH1D*)hS->Clone("hSm_nnlo");
     for(int x=1;x<=hSm_nnlo->GetNbinsX();x++){ hSm_nnlo->SetBinContent(x, hSm_nnlo->GetBinContent(x) * kFactor->Eval(hSm_nnlo->GetXaxis()->GetBinCenter(x)) );  }

     //get the pure interference signal and scale it to NNLO (multiply by sqrt(kFactors)
     TH1D* hIm_nnlo  = (TH1D*)hSmBI->Clone("hIm_nnlo");   hIm_nnlo->Add(hB, -1);  hIm_nnlo->Add(hSm, -1);
     for(int x=1;x<=hIm_nnlo->GetNbinsX();x++){ hIm_nnlo->SetBinContent(x, hIm_nnlo->GetBinContent(x) * sqrt(kFactor->Eval(hIm_nnlo->GetXaxis()->GetBinCenter(x))) );  }

     //Built a sampe of Signal+Interferance but without the background
     TH1D* hSIm_nnlo = (TH1D*)hSm_nnlo->Clone("hSIm_nnlo");  hSIm_nnlo->Add(hIm_nnlo, 1);

     /////////////////////////////////// COMPUTE THE WEIGHTS TO BE APPLIED
 
     //compute rebin factor
     double RMS = hS->GetRMS();
     int RebinFactor = 1; while((hS->GetBinWidth(1)*RebinFactor) < RMS/ 8.0){RebinFactor*=2;}

    //compute weights with respect to C'=1 SI shape --> make life easier
//    TH1D* weightsHDenominator = (TH1D*)hSIm_nnlo->Clone("weightsHDenominator");    
    TH1D* weightsHDenominator = (TH1D*)hSm->Clone("weightsHDenominator");    weightsHDenominator->Rebin(RebinFactor);
    TH1D* weightsH   = mH>=400?(TH1D*)hSI_nnlo  ->Clone("weightsH")  : (TH1D*)hS_nnlo->Clone("weightsH");   weightsH  ->Rebin(RebinFactor);  weightsH->  Divide(weightsHDenominator);
    TH1D* weightsHup = mH>=400?(TH1D*)hSIup_nnlo->Clone("weightsHup"): (TH1D*)hS_nnlo->Clone("weightsHup"); weightsHup->Rebin(RebinFactor);  weightsHup->Divide(weightsHDenominator);  
    TH1D* weightsHdn = mH>=400?(TH1D*)hSIdn_nnlo->Clone("weightsHdn"): (TH1D*)hS_nnlo->Clone("weightsHdn"); weightsHdn->Rebin(RebinFactor);  weightsHdn->Divide(weightsHDenominator);  
    for(int x=1;x<=weightsH->GetNbinsX();x++){ weightsH  ->SetBinContent(x, std::max(0.0,weightsH  ->GetBinContent(x))  );   weightsH  ->SetBinError(x, 0.0  );} //truncate to positive values
    for(int x=1;x<=weightsH->GetNbinsX();x++){ weightsHup->SetBinContent(x, std::max(0.0,weightsHup->GetBinContent(x))  );   weightsHup->SetBinError(x, 0.0  );} //truncate to positive values
    for(int x=1;x<=weightsH->GetNbinsX();x++){ weightsHdn->SetBinContent(x, std::max(0.0,weightsHdn->GetBinContent(x))  );   weightsHdn->SetBinError(x, 0.0  );} //truncate to positive values

    for(int x=1;x<=weightsH->GetNbinsX();x++){ if(fabs(weightsH->GetXaxis()->GetBinCenter(x) - mH)>3*RMS){ weightsH  ->SetBinContent(x, 0.0  );   weightsH  ->SetBinError(x, 0.0  );}} //truncate to 3sigma
    for(int x=1;x<=weightsH->GetNbinsX();x++){ if(fabs(weightsH->GetXaxis()->GetBinCenter(x) - mH)>3*RMS){ weightsHup->SetBinContent(x, 0.0  );   weightsHup->SetBinError(x, 0.0  );}} //truncate to 3sigma
    for(int x=1;x<=weightsH->GetNbinsX();x++){ if(fabs(weightsH->GetXaxis()->GetBinCenter(x) - mH)>3*RMS){ weightsHdn->SetBinContent(x, 0.0  );   weightsHdn->SetBinError(x, 0.0  );}} //truncate to 3sigma

     /////////////////////////////////// ALL DONE, SAVE TO FILE

     OutputFile->cd();
     TDirectory* dir = OutputFile->mkdir(dirName, dirName);
     dir->cd();
     kFactor->Write("kFactors");
     hB->Write("mH_B");
     hS->Write("mH_S_NR");
     hSBI->Write("mH_SBI_NR");
     hS_nnlo->Write("mH_S_NR_nnlo");
     hI_nnlo->Write("mH_I_NR_nnlo");
     hIup_nnlo->Write("mH_I_NR_nnlo_up");
     hIdn_nnlo->Write("mH_I_NR_nnlo_down");
     hSI_nnlo->Write("mH_SI_NR_nnlo");
     hSIup_nnlo->Write("mH_SI_NR_nnlo_up");
     hSIdn_nnlo->Write("mH_SI_NR_nnlo_down");

     hSm->Write("mH_S_SM");
     hSmBI->Write("mH_SBI_SM");
     hSm_nnlo->Write("mH_S_SM_nnlo");
     hIm_nnlo->Write("mH_I_SM_nnlo");
     hSIm_nnlo->Write("mH_SI_SM_nnlo");
     weightsH->Write("weights");
     weightsHup->Write("weights_up");
     weightsHdn->Write("weights_down");


/*

//      if(mH==1000.0 && CP==0.5){
      TCanvas* c = new TCanvas("c", "c",600,600);
      TH1F* framework = new TH1F("Graph","Graph",10,100,1500);
      framework->SetStats(false);
      framework->SetTitle("");
      framework->GetXaxis()->SetTitle("Higgs boson mass [GeV]");
      framework->GetYaxis()->SetTitleOffset(1.70);
      framework->GetYaxis()->SetTitle("#entries");
      framework->GetYaxis()->SetRangeUser(1E-7,1E1);
      c->SetLogy(true);

      hSBI->Rebin(10);  hB->Rebin(10);
      hSBI->Add(hB, -1); hSBI->Draw("E1 same");

//      hB->Rebin(2);  hB->SetLineColor(1); hB->SetLineWidth(2);   hB->Draw("E3 same");
//      hS->Rebin(2);  hS->SetLineColor(2);   hS->SetLineWidth(4); hS->Draw("E3 same");  
//      hSBI->Rebin(1);  hSBI->SetLineColor(4);  hSBI->SetLineWidth(2);   hSBI->Draw("E1 same");
//      }
*/    
  }}

  OutputFile->Close();



}











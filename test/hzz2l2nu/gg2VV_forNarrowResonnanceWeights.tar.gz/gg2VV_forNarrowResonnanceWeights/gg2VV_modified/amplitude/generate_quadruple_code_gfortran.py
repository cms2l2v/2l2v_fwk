# IMPORTANT:
# direct and indirect interfaces with C/C++ double variables:
# function/subroutine arguments AND common block variables:
# variables need to be declared real*8 by hand to prevent
# conversion to real*16 by quadruple compiler option
# in all affected Fortran files
# diagnostics(filepath) provides helpful information if enabled below

from string import upper, lower, strip, find, join, split, rstrip
from re import sub, search, I
from os import listdir, mkdir, getcwd, environ
import subprocess
from os.path import dirname, exists, isfile, isdir
from sys import exit

def intrinsicsFilter(s):
    # correct order is important when substrings of function names
    # match other function names!
    intrinsics = [("dble", "dble"),
                  ("dimag", "aimag"),
                  ("dconjg", "dconjg"),
                  ("dcmplx", "dcmplx"),
                  ("cdlog", "log"),
                  ("zlog", "log"),
                  ("dlog10", "log10"),
                  ("dlog", "log"),
                  ("cdexp", "exp"),
                  ("zexp", "exp"),
                  ("dexp", "exp"),
                  ("cdsqrt", "sqrt"),
                  ("zsqrt", "sqrt"),
                  ("dsqrt", "sqrt"),
                  ("cdabs", "abs"),
                  ("zabs", "abs"),
                  ("dabs", "abs")]
    # assuming no trigonometric functions
    for pair in intrinsics:
        double, quad = pair
        s = sub(lower(double)+" *\(", lower(quad)+"(", s)
        s = sub(upper(double)+" *\(", lower(quad)+"(", s)
    return s

def createQuadDir(quad_dir):
    if exists(quad_dir):
        print "WARNING: quadruple directory exists:"
        print quad_dir
        print "no modifications"
        print
        return 1
    else:
        mkdir(quad_dir, 0755)
        return 0

def getFilepathList(double_dir):
    process = subprocess.Popen("cd "+double_dir+"; find . -name \"*\"", shell=True, executable="/bin/bash", stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    stdout, stderr = process.communicate()
    assert stderr == ""
    rawList = split(stdout, "\n")
    processedList = []
    # remove leading "./", e.g. in "./box_coeff/massive/pp/cpp83.f"
    for filepath in rawList:
        filepath = strip(filepath)
        if filepath in ["", "."]:
            continue
        assert filepath[-1] != "~"     # no emacs backup files
        assert filepath[:2] == "./"
        processedList.append(filepath[2:])
    return processedList

def removeFortranComments(fileString):
    lineList = split(fileString, "\n")
    newLineList = []
    for line in lineList:
        if len(line) > 0 and (lower(line[0]) in ["c","*"] or line[0] == "#"):   # comment line or preprocessor directive
            continue
        index = find(line, "!")    # comment part
        if index > -1:
            line = line[:index]
        if strip(line) == "":   # empty line
            continue
        newLineList.append(line)
    return join(newLineList, "\n")

def concatenateFortranContinuationLines(fileString):
    lineList = split(fileString, "\n")
    newlineList = []
    newline = ""
    for line in lineList:
        line = rstrip(line)
        if newline == "":
            newline = line
        elif line[0] != "\t" and len(line) >= 6 and line[:5] == 5*" " and line[5] != " ":
            newline += (" " + strip(line[6:]))
        else:
            newlineList.append(newline)
            newline = line
    newlineList.append(newline)
    return join(newlineList, "\n")

def processFortranCode(fileString):
    return concatenateFortranContinuationLines(removeFortranComments(fileString))

def diagnostics(filepath):
    substring = "quadruple/"
    assert find(filepath, substring) > -1
    shortfilepath = filepath[(find(filepath, substring)+len(substring)):]
    fileString = open(filepath).read()
    fileString = lower(processFortranCode(fileString))
    fixed_size_declarations = ["real*4", "real*8", "complex*8", "complex*16"]
    for str in fixed_size_declarations:
        if find(fileString, str) > -1:
            print "warning: fixed-size f77 declaration  ", str, "  in", shortfilepath
    f90decl = ["real(4)", "real(kind=4)", "real(8)", "real(kind=8)",
                   "complex(4)", "complex(kind=4)", "complex(8)", "complex(kind=8)"]
    for str in f90decl:
        if find(fileString, str) > -1:
            print "warning: fixed-size f90 declaration  ", str, "  in", shortfilepath
    fixed_low_prec_intrinsics = ["dfloat", "dprod", "floati", "float", "[^dq]real", "floatj", "floatk", "sngl", "snglq"]
    for str in fixed_low_prec_intrinsics:
        if search(str+" *\(", fileString, I) is not None:
            print "warning: fixed-low-prec. intrinsic  ", str, "  in", shortfilepath

def processAmpSubDir(ampsubdirpath):
    print "processing", ampsubdirpath
    double_dir = ampsubdirpath+"/double"
    quad_dir = ampsubdirpath+"/quadruple"
    assert exists(double_dir)
    errorcode = createQuadDir(quad_dir)
    if errorcode == 1: return
    
    filepathList = getFilepathList(double_dir)
    
    # create quad directories
    for filepath in filepathList:
        if isdir(double_dir+"/"+filepath):
            mkdir(quad_dir+"/"+filepath)
    
    # write intrinsics filtered files to quad dir
    for filepath in filepathList:
        double_filepath = double_dir+"/"+filepath
        if isfile(double_filepath): 
            quad_filepath = quad_dir+"/"+filepath
            quadFileString = intrinsicsFilter(open(double_filepath).read())
            open(quad_filepath, 'w').write(quadFileString)
            if True: diagnostics(quad_filepath)
    
# main starts --------------------------------------------------------------

topdir = environ["TOPDIR"]
ampdir = topdir + "/amplitude"
ampsubdirs = ["", "/formcalc"]
for subdir in ampsubdirs:
    processAmpSubDir(ampdir+subdir)


#COMMON INTERFACES *********************************************************
#
#init_looptools_
#
#FORMCALC C/FORTRAN INTERFACES ************************************************
#
#vecsetwrapper_
#squaredme_
#init_formcalc_

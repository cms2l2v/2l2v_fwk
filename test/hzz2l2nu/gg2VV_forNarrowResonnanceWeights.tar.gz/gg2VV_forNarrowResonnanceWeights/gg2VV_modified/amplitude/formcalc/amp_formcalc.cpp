#include <iostream>

#include "amp_formcalc.h"
#include "assert_looptools_initialized.h"
#include "clooptools.h"
#include "settings.h"
#include "utilities.h"

#include "tinymass.inc"

AmpSqrFormcalc::AmpSqrFormcalc(unsigned int selection)
  : AmpSqr(selection)
{}

extern "C"
{
  void init_formcalc_(const double* mW, const double* wW, const double* mZ, const double* wZ, const double* mH, const double* wH, const double* nk_tiny_lepton_mass, const double* nk_tiny_quark_mass, const double* mb, const double* mt, const double* gfermi, const double* alpha, const double* CKM_lambda, const double* CKM_A, const double* CKM_rho_bar, const double* CKM_eta_bar, const int* nk_continuum_in, const int* nk_higgs_in, const double* nk_hggcoupfac_in, const double* nk_hwwcoupfac_in, const double* nk_hzzcoupfac_in);
}


void AmpSqrFormcalc::initialize()
{
  const double huge_fermion_mass = 1.e5;

  double used_light_quark_mass = 0.;     // initialize
  double used_bottom_quark_mass = 0.;
  double used_top_quark_mass = 0.;

  if ((selection() == AmpSqr::MASSLESSBOX + AmpSqr::HIGGSSIGNAL) || (selection() == AmpSqr::MASSIVEBOX + AmpSqr::HIGGSSIGNAL)) {
    fatal_error("AmpSqrFormcalc::initialize: amplitude selection not implemented");
  }
  else if (selection() == AmpSqr::MASSLESSBOX) {
    used_light_quark_mass = AmpSqrFormcalc::tiny_fermion_mass;
    used_bottom_quark_mass = huge_fermion_mass;
    used_top_quark_mass = huge_fermion_mass;
  }
  else if (selection() == AmpSqr::MASSIVEBOX) {
    used_light_quark_mass = huge_fermion_mass;
    used_bottom_quark_mass = SMP::mb;
    used_top_quark_mass = SMP::mt;
  }
  else {
    used_light_quark_mass = AmpSqrFormcalc::tiny_fermion_mass;
    used_bottom_quark_mass = SMP::mb;
    used_top_quark_mass = SMP::mt;
  }

  int nk_continuum_in = 0;
  int nk_higgs_in = 0;
  
  if (AmpSqr::includesOnlySignal(selection())) {
    nk_continuum_in = 0;
    nk_higgs_in = 1;
  }
  else if (AmpSqr::includesOnlyBackground(selection())) {
    nk_continuum_in = 1;
    nk_higgs_in = 0;
  }
  else if (AmpSqr::includesSignalAndBackground(selection())) {
    nk_continuum_in = 1;
    nk_higgs_in = 1;
  }
  else {
    fatal_error("AmpSqrFormcalc::initialize: invalid selection");
  }

  init_formcalc_(&SMP::mW, &SMP::wW, &SMP::mZ, &SMP::wZ, &SMP::mH, &SMP::wH, &AmpSqrFormcalc::tiny_fermion_mass, &used_light_quark_mass, &used_bottom_quark_mass, &used_top_quark_mass, &SMP::gfermi, &SMP::alpha, &SMP::CKM_lambda, &SMP::CKM_A, &SMP::CKM_rho_bar, &SMP::CKM_eta_bar, &nk_continuum_in, &nk_higgs_in, &BSM::HggCouplingRescalingFactor, &BSM::HWWCouplingRescalingFactor, &BSM::HZZCouplingRescalingFactor);

  assert_looptools_initialized_();
}

namespace
{
extern "C"
{
  void vecsetwrapper_(const int* i, const double* mass, const double* px, const double* py, const double* pz);
}

inline void setvector(int& i, const double& mass, const ConstValue<FourMomentum>& p)
{
  const double px = p().px();
  const double py = p().py();
  const double pz = p().pz();
  vecsetwrapper_(&i, &mass, &px, &py, &pz);
}
}     // unnamed namespace

extern "C"
{
  void squaredme_(double result[], const int* helicities, const int* flags);   // FormCalc5
  //void squaredme_(double result[], const Int64* helicities, const int* flags);   // FormCalc7
}

const double AmpSqrFormcalc::ampSqr(const PhaseSpace& ps)
{
  //  1     2         3           4          5           6         
  // --------------------------------------------------------------
  // WW2l2v:
  // {V[5], V[5]} -> {-F[2, {1}], F[1, {1}], -F[1, {2}], F[2, {2}]}
  //  g     g         e+          nu_e       {nu_bar}_mu mu-       
  // --------------------------------------------------------------
  // ZAZA2l2l:
  // {V[5], V[5]} -> {-F[2, {1}], F[2, {1}], -F[2, {2}], F[2, {2}]}
  //  g     g         e+          e-         mu+         mu-       
  // --------------------------------------------------------------
  // ZAZ_2l2v:
  // {V[5], V[5]} -> {-F[2, {1}], F[2, {1}], -F[1, {2}], F[1, {2}]}
  //  g     g         e+          e-         {nu_bar}_mu nu_mu     
  // --------------------------------------------------------------
  // ZAZA4l:
  // {V[5], V[5]} -> {-F[2, {1}], F[2, {1}], -F[2, {1}], F[2, {1}]}
  //  g     g         e+          e-         e+          e-        
  // --------------------------------------------------------------
  // WWZAZ_2l2v (2l2v_sameflav_full):
  // {V[5], V[5]} -> {-F[2, {1}], F[1, {1}], -F[1, {1}], F[2, {1}]}
  //  g     g         e+          nu_e       {nu_bar}_e  e-        

  int i;
  double zero_mass = 0.;
  i = 1; setvector(i, zero_mass, ps.i);
  i = 2; setvector(i, zero_mass, ps.i_);
  i = 3; setvector(i, AmpSqrFormcalc::tiny_fermion_mass, ps.aa);
  i = 4; setvector(i, AmpSqrFormcalc::tiny_fermion_mass, ps.ap);
  i = 5; setvector(i, AmpSqrFormcalc::tiny_fermion_mass, ps.pa);
  i = 6; setvector(i, AmpSqrFormcalc::tiny_fermion_mass, ps.pp);

  // 3: final state antiparticle from intermediate antiparticle decay (aa)
  // 4: final state particle from intermediate antiparticle decay (ap)
  // 5: final state antiparticle from intermediate particle decay (pa)
  // 6: final state particle from intermediate particle decay (pp)

  clearcache();     // clooptools.h: flush LoopTools results caches

  double result[2];
  // =============================================================================
  /*
  FormCalc5 convention for polarisations: see page 39
  p_1(3 bits) p_2(3 bits) ... p_n(3 bits), where each 3 bits =
  right circular,longitudinal,left-circular:
  p_1 -> [(+)(L)(-)]_binary = [(+)*4+(L)*2+(-)*1]_decimal
  octal number [C/C++ convention: left-most digit "0"]: one digit per particle:
  (-) = 1, (+) = 4, (L) = 2, transverse = 5, unpolarized = 7
  particle 1 to n correspond to digits of octal number from left to right
  */

#if defined PROCMACRO_WWZAZ_2l2v
  const int helicities = 0555145;    // ttt-+t (gg -> all -> l~ v v~ l)
#elif defined PROCMACRO_WW2l2v
  const int helicities = 0554141;    // tt+-+- (gg -> WW -> l~ v v~ l only)
#elif defined PROCMACRO_ZAZ_2l2v
  const int helicities = 0555541;    // tttt+- (gg -> ZAZA -> l~ l v~ v)
#else
  const int helicities = 0555555;    // tttttt (gg -> ZAZA -> l~ l l~ l)
#endif
  // =============================================================================
  /*
  FormCalc7 convention for polarisations: see pages 44 and 45
  p_1(5 bits) p_2(5 bits) ... p_n(5 bits), where each 5 bits =
  +(spin 2 or 3/2),+(spin 1 or 1/2),longitud.,-(spin 1 or 1/2),-(spin 2 or 3/2);
  use Python to convert from binary to decimal:
  >>> 0b010100101001000000100100000010
  346294530
  >>> 0b010100101001010010100101001010
  346368330
  use bin(decimal_number) to convert to binary:
  >>> bin(346368330)
  '0b10100101001010010100101001010'
  */

#if defined PROCMACRO_WW2l2v
  //const Int64 helicities = 346294530;    // tt+-+- (gg -> WW -> l~ v v~ l only)
#endif
  // =============================================================================
  const int flags = 1 + 2;  // both (reset and loop) set: 2**0 + 2**1
  
  squaredme_(result, &helicities, &flags);

  //std::cout << result[0] << " " << result[1] << std::endl;

  result[1] *= 1./4;      // gluon pol. average
  result[1] *= 1./64;     // color average

#ifdef PROCMACRO_ZAZA4l
  result[1] *= 1./4;      // symmetry factor 1/(2!2!)
#endif

  return result[1];       // g_s := 1
}

void AmpSqrFormcalc::writeImplementation(ostream& os) const
{
  os << "Formcalc";
}

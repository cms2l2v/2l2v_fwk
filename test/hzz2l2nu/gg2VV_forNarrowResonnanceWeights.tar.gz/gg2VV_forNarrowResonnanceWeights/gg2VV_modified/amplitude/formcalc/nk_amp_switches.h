	integer  nk_continuum, nk_higgs, nk_barscheme
	common /nk_amp_switches/ nk_continuum, nk_higgs, nk_barscheme

	double precision nk_hggcoupfac, nk_hwwcoupfac, nk_hzzcoupfac
	common /nk_amp_bsm/ nk_hggcoupfac, nk_hwwcoupfac, nk_hzzcoupfac

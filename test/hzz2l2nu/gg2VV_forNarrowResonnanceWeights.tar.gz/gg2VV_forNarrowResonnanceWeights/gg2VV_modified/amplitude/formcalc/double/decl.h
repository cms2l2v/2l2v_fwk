* decl.h
* these declarations are included "everywhere"
* this file is part of FormCalc
* last modified 4 Mar 08 th


#include "model.h"
#include "util.h"
#include "looptools.h"
#include "renconst.h"
#include "user.h"


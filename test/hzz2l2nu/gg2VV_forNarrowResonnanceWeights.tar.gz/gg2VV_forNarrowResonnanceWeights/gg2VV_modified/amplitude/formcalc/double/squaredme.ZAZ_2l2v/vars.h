#include "decl.h"

	double precision S, T, T14, T15, U, T24, T25, S34, S35, S45
	common /kinvars/ S, T, T14, T15, U, T24, T25, S34, S35, S45

	integer Hel(6)
	common /kinvars/ Hel

	double complex F11, F12, F5, F7, F9, F24, F86, F13, F14, F31
	double complex F87, F10, F8, F70, F25, F4, F1054, F1057, F1058
	double complex F1059, F1060, F1074, F893, F896, F897, F898
	double complex F899, F921, F1042, F966, F967, F1045, F1000
	double complex F1046, F877, F1047, F1001, F1048, F880, F881
	double complex F1067, F882, F883, F908, F979, F980, F1017
	double complex F1018, F912, F911, F910, F909, F1073, F920
	double complex F1066, F907, Pair6, Pair85, Pair26, Pair30
	double complex Pair27, Pair28, Pair29, Eps941, Eps962, Eps963
	double complex Eps884, Eps964, Eps965, Eps885, Eps996, Eps997
	double complex Eps931, Eps998, Eps999, Eps932, Abb1068
	double complex Abb1075, Abb1055, Abb1076, Abb15, Abb1043
	double complex Abb1069, Abb1070, Abb1077, Abb16, Abb17, Abb878
	double complex Abb894, Abb18, Abb913, Abb922, Abb914, Abb923
	double complex Abb915, Abb916, Abb924, Abb972, Abb985, Abb973
	double complex Abb986, Abb917, Abb925, Abb926, Abb974, Abb975
	double complex Abb976, Abb977, Abb987, Abb988, Abb989, Abb990
	double complex Abb1091, Abb900, Abb901, Abb949, Abb981, Abb982
	double complex Abb983, Abb984, Abb944, Abb951, Abb1087, Abb886
	double complex Abb887, Abb942, Abb968, Abb969, Abb970, Abb971
	double complex Abb945, Abb952, Abb946, Abb953, Abb71, Abb72
	double complex Abb45, Abb46, Abb88, Abb89, Abb73, Abb74
	double complex Abb1061, Abb1062, Abb80, Abb1002, Abb1021
	double complex Abb50, Abb81, Abb1049, Abb1050, Abb51, Abb1005
	double complex Abb1022, Abb90, Abb91, Abb92, Abb93, Abb888
	double complex Abb889, Abb902, Abb903, Abb1006, Abb1023
	double complex Abb1007, Abb1024, Abb94, Abb54, Abb95, Abb55
	double complex Abb96, Abb97, Abb98, Abb99, Abb100, Abb58
	double complex Abb101, Abb59, Abb102, Abb103, Abb104, Abb105
	double complex Abb75, Abb76, Abb47, Abb48, Abb106, Abb107
	double complex Abb77, Abb78, Abb1078, Abb19, Abb144, Abb145
	double complex Abb1071, Abb20, Abb82, Abb83, Abb108, Abb150
	double complex Abb109, Abb151, Abb918, Abb927, Abb1063
	double complex Abb1064, Abb1008, Abb1027, Abb110, Abb1051
	double complex Abb1052, Abb1011, Abb1028, Abb152, Abb153
	double complex Abb154, Abb188, Abb189, Abb890, Abb891, Abb904
	double complex Abb905, Abb111, Abb155, Abb1012, Abb1029
	double complex Abb1013, Abb1030, Abb938, Abb1019, Abb1020
	double complex Abb933, Abb1003, Abb1004, Abb52, Abb32, Abb33
	double complex Abb53, Abb161, Abb162, Abb119, Abb120, Abb121
	double complex Abb122, Abb56, Abb34, Abb35, Abb57, Abb166
	double complex Abb167, Abb239, Abb123, Abb240, Abb124, Abb60
	double complex Abb36, Abb37, Abb61, Abb168, Abb169, Abb241
	double complex Abb125, Abb242, Abb126, Abb62, Abb38, Abb39
	double complex Abb63, Abb163, Abb164, Abb127, Abb128, Abb129
	double complex Abb130, Abb64, Abb40, Abb41, Abb65, Abb170
	double complex Abb171, Abb243, Abb131, Abb244, Abb132, Abb66
	double complex Abb42, Abb43, Abb67, Abb172, Abb173, Abb245
	double complex Abb133, Abb246, Abb134, Abb939, Abb1025
	double complex Abb1026, Abb934, Abb1009, Abb1010, Abb1092
	double complex Abb112, Abb135, Abb136, Abb1088, Abb113, Abb137
	double complex Abb138, Abb191, Abb177, Abb192, Abb178, Abb947
	double complex Abb954, Abb114, Abb193, Abb194, Abb115, Abb139
	double complex Abb140, Abb291, Abb195, Abb292, Abb196, Abb116
	double complex Abb197, Abb198, Abb117, Abb141, Abb142, Abb293
	double complex Abb199, Abb294, Abb200, Opt1892, Opt1893
	double complex Opt1894, Opt1895, Opt1896, Opt1897, Opt1898
	double complex Opt1899, Opt1900, Opt1901, Opt1902, Opt1903
	double complex Opt1904, Opt1905, Opt1906, Opt1907, Opt1908
	double complex Opt1909, Opt1910, Opt1911, Opt1912, Opt1913
	double complex Opt1914, Opt1915, Opt1916, Opt1917, Opt1918
	double complex Opt1919, Opt1920, Opt1921, Opt1922, Opt1923
	double complex Opt1924, Opt1925, Opt1926, Opt1927, Opt1928
	double complex Opt1929, Opt1930, Opt1931, Opt1932, Opt1933
	double complex Opt1934, Opt1935, Opt1936, Opt1937, Opt1938
	double complex Opt1939, Opt1940, Opt1941, Opt1942, Opt1943
	double complex Opt1944, Opt1945, Opt1946, Opt1947, Opt1948
	double complex Opt1949, Opt1950, Opt1951, Opt1952, Opt1953
	double complex Opt1954, Opt1955, Opt1956, Opt1957, Opt1958
	double complex Opt1959, Opt1960, Opt1961, Opt1962, Opt1963
	double complex Opt1964, Opt1965, Opt1966, Opt1967, Opt1968
	double complex Opt1969, Opt1970, Opt1971, Opt1972, Opt1973
	double complex Opt1974, Opt1975, Opt1976, Opt1977, Opt1978
	double complex Opt1979, Opt1980, AbbSum249, AbbSum660
	double complex AbbSum659, AbbSum661, AbbSum662, AbbSum238
	double complex AbbSum813, AbbSum778, AbbSum527, AbbSum528
	double complex AbbSum355, AbbSum569, AbbSum693, AbbSum570
	double complex AbbSum694, AbbSum811, AbbSum358, AbbSum777
	double complex AbbSum605, AbbSum845, AbbSum1086, AbbSum606
	double complex AbbSum846, AbbSum1090, AbbSum1102, AbbSum824
	double complex AbbSum789, AbbSum770, AbbSum820, AbbSum773
	double complex AbbSum810, AbbSum727, AbbSum699, AbbSum728
	double complex AbbSum700, AbbSum339, AbbSum1100, AbbSum819
	double complex AbbSum771, AbbSum809, AbbSum823, AbbSum787
	double complex AbbSum769, AbbSum352, AbbSum745, AbbSum746
	double complex AbbSum411, AbbSum413, AbbSum837, AbbSum834
	double complex AbbSum474, AbbSum473, AbbSum451, AbbSum447
	double complex AbbSum448, AbbSum452, AbbSum664, AbbSum434
	double complex AbbSum663, AbbSum433, AbbSum701, AbbSum829
	double complex AbbSum702, AbbSum832, AbbSum935, AbbSum940
	double complex AbbSum957, AbbSum943, AbbSum958, AbbSum950
	double complex AbbSum532, AbbSum534, AbbSum581, AbbSum725
	double complex AbbSum579, AbbSum723, AbbSum457, AbbSum458
	double complex AbbSum803, AbbSum804, AbbSum406, AbbSum408
	double complex AbbSum404, AbbSum816, AbbSum405, AbbSum403
	double complex AbbSum407, AbbSum815, AbbSum741, AbbSum742
	double complex AbbSum730, AbbSum836, AbbSum729, AbbSum833
	double complex AbbSum490, AbbSum632, AbbSum489, AbbSum629
	double complex AbbSum563, AbbSum559, AbbSum571, AbbSum572
	double complex AbbSum560, AbbSum564, AbbSum930, AbbSum519
	double complex AbbSum762, AbbSum937, AbbSum517, AbbSum761
	double complex AbbSum622, AbbSum827, AbbSum625, AbbSum830
	double complex AbbSum1095, AbbSum1096, AbbSum298, AbbSum299
	double complex AbbSum223, AbbSum250, AbbSum315, AbbSum377
	double complex AbbSum360, AbbSum703, AbbSum268, AbbSum705
	double complex AbbSum387, AbbSum1056, AbbSum332, AbbSum318
	double complex AbbSum1044, AbbSum381, AbbSum356, AbbSum376
	double complex AbbSum383, AbbSum365, AbbSum354, AbbSum724
	double complex AbbSum726, AbbSum342, AbbSum518, AbbSum520
	double complex AbbSum49, AbbSum633, AbbSum831, AbbSum630
	double complex AbbSum828, AbbSum624, AbbSum621, AbbSum183
	double complex AbbSum432, AbbSum431, AbbSum480, AbbSum418
	double complex AbbSum479, AbbSum417, AbbSum463, AbbSum669
	double complex AbbSum465, AbbSum670, AbbSum879, AbbSum895
	double complex AbbSum300, AbbSum203, AbbSum835, AbbSum1081
	double complex AbbSum319, AbbSum838, AbbSum1084, AbbSum644
	double complex AbbSum1033, AbbSum1032, AbbSum1036, AbbSum1035
	double complex AbbSum646, AbbSum561, AbbSum557, AbbSum226
	double complex AbbSum640, AbbSum637, AbbSum521, AbbSum523
	double complex AbbSum592, AbbSum678, AbbSum589, AbbSum675
	double complex AbbSum676, AbbSum590, AbbSum679, AbbSum593
	double complex AbbSum255, AbbSum330, AbbSum165, AbbSum522
	double complex AbbSum524, AbbSum464, AbbSum466, AbbSum373
	double complex AbbSum529, AbbSum22, AbbSum21, AbbSum23
	double complex AbbSum379, AbbSum530, AbbSum704, AbbSum340
	double complex AbbSum706, AbbSum409, AbbSum410, AbbSum333
	double complex AbbSum577, AbbSum574, AbbSum216, AbbSum279
	double complex AbbSum614, AbbSum536, AbbSum416, AbbSum613
	double complex AbbSum535, AbbSum415, AbbSum645, AbbSum734
	double complex AbbSum739, AbbSum512, AbbSum643, AbbSum731
	double complex AbbSum737, AbbSum509, AbbSum251, AbbSum583
	double complex AbbSum749, AbbSum747, AbbSum585, AbbSum750
	double complex AbbSum748, AbbSum218, AbbSum349, AbbSum995
	double complex AbbSum276, AbbSum1016, AbbSum475, AbbSum738
	double complex AbbSum477, AbbSum740, AbbSum450, AbbSum446
	double complex AbbSum708, AbbSum707, AbbSum665, AbbSum467
	double complex AbbSum667, AbbSum468, AbbSum441, AbbSum553
	double complex AbbSum795, AbbSum443, AbbSum555, AbbSum796
	double complex AbbSum948, AbbSum955, AbbSum562, AbbSum558
	double complex AbbSum320, AbbSum715, AbbSum716, AbbSum584
	double complex AbbSum567, AbbSum586, AbbSum568, AbbSum721
	double complex AbbSum722, AbbSum331, AbbSum649, AbbSum505
	double complex AbbSum507, AbbSum219, AbbSum650, AbbSum506
	double complex AbbSum508, AbbSum476, AbbSum461, AbbSum478
	double complex AbbSum462, AbbSum280, AbbSum275, AbbSum860
	double complex AbbSum859, AbbSum186, AbbSum79, AbbSum176
	double complex AbbSum303, AbbSum495, AbbSum435, AbbSum419
	double complex AbbSum498, AbbSum438, AbbSum422, AbbSum587
	double complex AbbSum588, AbbSum792, AbbSum502, AbbSum791
	double complex AbbSum501, AbbSum805, AbbSum806, AbbSum287
	double complex AbbSum449, AbbSum456, AbbSum445, AbbSum455
	double complex AbbSum548, AbbSum538, AbbSum551, AbbSum541
	double complex AbbSum666, AbbSum668, AbbSum1089, AbbSum1093
	double complex AbbSum717, AbbSum718, AbbSum615, AbbSum616
	double complex AbbSum808, AbbSum807, AbbSum414, AbbSum412
	double complex AbbSum533, AbbSum531, AbbSum573, AbbSum713
	double complex AbbSum709, AbbSum576, AbbSum714, AbbSum711
	double complex AbbSum862, AbbSum861, AbbSum767, AbbSum841
	double complex AbbSum768, AbbSum842, AbbSum732, AbbSum510
	double complex AbbSum627, AbbSum735, AbbSum513, AbbSum628
	double complex AbbSum636, AbbSum756, AbbSum635, AbbSum755
	double complex AbbSum1107, AbbSum1082, AbbSum623, AbbSum626
	double complex AbbSum631, AbbSum634, AbbSum657, AbbSum655
	double complex AbbSum283, AbbSum220, AbbSum260, AbbSum306
	double complex AbbSum307, AbbSum261, AbbSum428, AbbSum471
	double complex AbbSum546, AbbSum426, AbbSum469, AbbSum544
	double complex AbbSum691, AbbSum689, AbbSum1080, AbbSum491
	double complex AbbSum482, AbbSum994, AbbSum493, AbbSum1083
	double complex AbbSum485, AbbSum638, AbbSum1110, AbbSum1034
	double complex AbbSum641, AbbSum1037, AbbSum673, AbbSum600
	double complex AbbSum840, AbbSum671, AbbSum597, AbbSum839
	double complex AbbSum221, AbbSum503, AbbSum504, AbbSum179
	double complex AbbSum224, AbbSum653, AbbSum656, AbbSum710
	double complex AbbSum743, AbbSum697, AbbSum695, AbbSum654
	double complex AbbSum658, AbbSum712, AbbSum744, AbbSum698
	double complex AbbSum696, AbbSum321, AbbSum591, AbbSum677
	double complex AbbSum594, AbbSum680, AbbSum470, AbbSum459
	double complex AbbSum44, AbbSum472, AbbSum460, AbbSum253
	double complex AbbSum227, AbbSum69, AbbSum286, AbbSum334
	double complex AbbSum337, AbbSum213, AbbSum580, AbbSum257
	double complex AbbSum582, AbbSum344, AbbSum343, AbbSum484
	double complex AbbSum686, AbbSum481, AbbSum683, AbbSum547
	double complex AbbSum550, AbbSum1015, AbbSum515, AbbSum516
	double complex AbbSum184, AbbSum338, AbbSum1111, AbbSum760
	double complex AbbSum766, AbbSum794, AbbSum759, AbbSum765
	double complex AbbSum793, AbbSum1112, AbbSum863, AbbSum436
	double complex AbbSum598, AbbSum864, AbbSum439, AbbSum601
	double complex AbbSum1106, AbbSum929, AbbSum936, AbbSum1108
	double complex AbbSum857, AbbSum858, AbbSum1113, AbbSum1109
	double complex AbbSum1085, AbbSum651, AbbSum652, AbbSum322
	double complex AbbSum301, AbbSum180, AbbSum892, AbbSum681
	double complex AbbSum851, AbbSum595, AbbSum682, AbbSum906
	double complex AbbSum158, AbbSum852, AbbSum236, AbbSum369
	double complex AbbSum596, AbbSum1014, AbbSum442, AbbSum425
	double complex AbbSum956, AbbSum959, AbbSum444, AbbSum427
	double complex AbbSum784, AbbSum776, AbbSum783, AbbSum775
	double complex AbbSum1094, AbbSum554, AbbSum543, AbbSum556
	double complex AbbSum545, AbbSum511, AbbSum525, AbbSum733
	double complex AbbSum514, AbbSum526, AbbSum736, AbbSum565
	double complex AbbSum575, AbbSum566, AbbSum578, AbbSum843
	double complex AbbSum844, AbbSum782, AbbSum781, AbbSum801
	double complex AbbSum802, AbbSum326, AbbSum258, AbbSum248
	double complex AbbSum329, AbbSum289, AbbSum211, AbbSum212
	double complex AbbSum185, AbbSum175, AbbSum394, AbbSum206
	double complex AbbSum149, AbbSum84, AbbSum259, AbbSum430
	double complex AbbSum367, AbbSum429, AbbSum209, AbbSum374
	double complex AbbSum1097, AbbSum234, AbbSum229, AbbSum763
	double complex AbbSum764, AbbSum780, AbbSum758, AbbSum454
	double complex AbbSum779, AbbSum757, AbbSum453, AbbSum1104
	double complex AbbSum797, AbbSum785, AbbSum798, AbbSum786
	double complex AbbSum302, AbbSum327, AbbSum272, AbbSum672
	double complex AbbSum539, AbbSum549, AbbSum608, AbbSum639
	double complex AbbSum492, AbbSum437, AbbSum421, AbbSum674
	double complex AbbSum542, AbbSum552, AbbSum610, AbbSum642
	double complex AbbSum494, AbbSum440, AbbSum424, AbbSum375
	double complex AbbSum68, AbbSum225, AbbSum252, AbbSum325
	double complex AbbSum323, AbbSum395, AbbSum607, AbbSum353
	double complex AbbSum609, AbbSum385, AbbSum1031, AbbSum335
	double complex AbbSum214, AbbSum278, AbbSum282, AbbSum347
	double complex AbbSum1038, AbbSum1072, AbbSum853, AbbSum1105
	double complex AbbSum854, AbbSum919, AbbSum928, AbbSum992
	double complex AbbSum277, AbbSum281, AbbSum619, AbbSum483
	double complex AbbSum647, AbbSum617, AbbSum599, AbbSum620
	double complex AbbSum486, AbbSum648, AbbSum618, AbbSum602
	double complex AbbSum296, AbbSum147, AbbSum181, AbbSum232
	double complex AbbSum1079, AbbSum1039, AbbSum540, AbbSum856
	double complex AbbSum537, AbbSum855, AbbSum812, AbbSum420
	double complex AbbSum993, AbbSum814, AbbSum423, AbbSum685
	double complex AbbSum497, AbbSum688, AbbSum500, AbbSum313
	double complex AbbSum753, AbbSum751, AbbSum204, AbbSum754
	double complex AbbSum752, AbbSum190, AbbSum690, AbbSum284
	double complex AbbSum692, AbbSum304, AbbSum264, AbbSum1101
	double complex AbbSum1053, AbbSum799, AbbSum800, AbbSum1065
	double complex AbbSum960, AbbSum961, AbbSum488, AbbSum872
	double complex AbbSum604, AbbSum874, AbbSum774, AbbSum499
	double complex AbbSum487, AbbSum871, AbbSum603, AbbSum873
	double complex AbbSum772, AbbSum496, AbbSum788, AbbSum790
	double complex AbbSum210, AbbSum295, AbbSum297, AbbSum324
	double complex AbbSum341, AbbSum317, AbbSum316, AbbSum262
	double complex AbbSum308, AbbSum719, AbbSum720, AbbSum182
	double complex AbbSum174, AbbSum256, AbbSum187, AbbSum310
	double complex AbbSum233, AbbSum217, AbbSum351, AbbSum368
	double complex AbbSum396, AbbSum156, AbbSum265, AbbSum611
	double complex AbbSum612, AbbSum866, AbbSum865, AbbSum978
	double complex AbbSum393, AbbSum1103, AbbSum991, AbbSum850
	double complex AbbSum849, AbbSum1114, AbbSum1115, AbbSum290
	double complex AbbSum309, AbbSum390, AbbSum263, AbbSum159
	double complex AbbSum146, AbbSum687, AbbSum684, AbbSum363
	double complex AbbSum359, AbbSum1098, AbbSum237, AbbSum231
	double complex AbbSum876, AbbSum875, AbbSum215, AbbSum222
	double complex AbbSum336, AbbSum247, AbbSum254, AbbSum386
	double complex AbbSum362, AbbSum867, AbbSum868, AbbSum372
	double complex AbbSum1099, AbbSum1040, AbbSum869, AbbSum847
	double complex AbbSum870, AbbSum848, AbbSum148, AbbSum821
	double complex AbbSum817, AbbSum822, AbbSum818, AbbSum825
	double complex AbbSum826, AbbSum1041, AbbSum350, AbbSum361
	double complex AbbSum348, AbbSum160, AbbSum370, AbbSum364
	double complex AbbSum305, AbbSum230, AbbSum235, AbbSum270
	double complex AbbSum285, AbbSum205, AbbSum157, AbbSum143
	double complex AbbSum269, AbbSum391, AbbSum274, AbbSum201
	double complex AbbSum288, AbbSum273, AbbSum266, AbbSum228
	double complex AbbSum392, AbbSum378, AbbSum118, AbbSum312
	double complex AbbSum208, AbbSum346, AbbSum345, AbbSum314
	double complex AbbSum371, AbbSum202, AbbSum400, AbbSum267
	double complex AbbSum401, AbbSum357, AbbSum207, AbbSum366
	double complex AbbSum328, AbbSum271, AbbSum397, AbbSum389
	double complex AbbSum311, AbbSum402, AbbSum398, AbbSum399
	double complex AbbSum388, AbbSum382, AbbSum380, AbbSum384
	double complex Opt1981, Sub1424, Sub1398, Sub1332, Sub1175
	double complex Sub1172, Sub1161, Sub1140, Sub1137, Sub1143
	double complex Sub1126, Sub1123, Sub1799, Sub1800, Sub1752
	double complex Sub1753, Sub1655, Sub1656, Sub1499, Sub1500
	double complex Sub1491, Sub1492, Sub1472, Sub1473, Sub1466
	double complex Sub1467, Sub1464, Sub1465, Sub1468, Sub1469
	double complex Sub1454, Sub1455, Sub1446, Sub1447, Sub1862
	double complex Sub1592, Sub1810, Sub1786, Sub1742, Sub1618
	double complex Sub1558, Sub1707, Sub1658, Sub1682, Sub1605
	double complex Sub1598, Sub1815, Sub1792, Sub1747, Sub1623
	double complex Sub1563, Sub1714, Sub1663, Sub1687, Sub1610
	double complex Sub1360, Sub1340, Sub1595, Sub1672, Sub1601
	double complex Sub1677, Sub1547, Sub1552, Sub1559, Sub1564
	double complex Sub1593, Sub1599, Sub1607, Sub1612, Sub1619
	double complex Sub1624, Sub1659, Sub1664, Sub1670, Sub1675
	double complex Sub1683, Sub1688, Sub1708, Sub1715, Sub1721
	double complex Sub1725, Sub1744, Sub1749, Sub1787, Sub1793
	double complex Sub1811, Sub1816, Sub1847, Sub1885, Sub1850
	double complex Sub1867, Sub1832, Sub1830, Sub1796, Sub1510
	double complex Sub1494, Sub1502, Sub1449, Sub1457, Sub1820
	double complex Sub1767, Sub1758, Sub1513, Sub1497, Sub1505
	double complex Sub1452, Sub1460, Sub1823, Sub1770, Sub1762
	double complex Sub1235, Sub1453, Sub1450, Sub1461, Sub1458
	double complex Sub1498, Sub1495, Sub1506, Sub1503, Sub1514
	double complex Sub1511, Sub1554, Sub1549, Sub1566, Sub1561
	double complex Sub1602, Sub1596, Sub1614, Sub1609, Sub1626
	double complex Sub1621, Sub1666, Sub1661, Sub1678, Sub1673
	double complex Sub1690, Sub1685, Sub1717, Sub1710, Sub1797
	double complex Sub1798, Sub1727, Sub1723, Sub1751, Sub1746
	double complex Sub1763, Sub1759, Sub1771, Sub1768, Sub1795
	double complex Sub1789, Sub1806, Sub1803, Sub1818, Sub1813
	double complex Sub1824, Sub1821, Sub1441, Sub1703, Sub1443
	double complex Sub1476, Sub1712, Sub1480, Sub1633, Sub1637
	double complex Sub1874, Sub1875, Sub1849, Sub1409, Sub1406
	double complex Sub1412, Sub1399, Sub1394, Sub1381, Sub1378
	double complex Sub1385, Sub1367, Sub1242, Sub1348, Sub1344
	double complex Sub1351, Sub1336, Sub1331, Sub1317, Sub1314
	double complex Sub1321, Sub1300, Sub1297, Sub1303, Sub1290
	double complex Sub1286, Sub1274, Sub1271, Sub1277, Sub1256
	double complex Sub1253, Sub1259, Sub1223, Sub1220, Sub1226
	double complex Sub1206, Sub1203, Sub1209, Sub1187, Sub1184
	double complex Sub1190, Sub1179, Sub1825, Sub1826, Sub1701
	double complex Sub1432, Sub1772, Sub1773, Sub1778, Sub1779
	double complex Sub1754, Sub1755, Sub1740, Sub1741, Sub1734
	double complex Sub1735, Sub1728, Sub1567, Sub1729, Sub1568
	double complex Sub1691, Sub1692, Sub1697, Sub1698, Sub1667
	double complex Sub1668, Sub1653, Sub1654, Sub1645, Sub1646
	double complex Sub1641, Sub1642, Sub1649, Sub1650, Sub1632
	double complex Sub1634, Sub1603, Sub1604, Sub1589, Sub1590
	double complex Sub1585, Sub1586, Sub1575, Sub1576, Sub1532
	double complex Sub1531, Sub1538, Sub1537, Sub1525, Sub1526
	double complex Sub1519, Sub1520, Sub1507, Sub1508, Sub1509
	double complex Sub1448, Sub1456, Sub1801, Sub1512, Sub1451
	double complex Sub1459, Sub1804, Sub1382, Sub1345, Sub1337
	double complex Sub1318, Sub1322, Sub1287, Sub1260, Sub1844
	double complex Sub1884, Sub1400, Sub1333, Sub1819, Sub1628
	double complex Sub1582, Sub1474, Sub1627, Sub1462, Sub1757
	double complex Sub1822, Sub1630, Sub1584, Sub1475, Sub1629
	double complex Sub1463, Sub1761, Sub1479, Sub1483, Sub1486
	double complex Sub1489, Sub1855, Sub1889, Sub1837, Sub1834
	double complex Sub1851, Sub1840, Sub1881, Sub1880, Sub1882
	double complex Sub1843, Sub1883, Sub1802, Sub1805, Sub1835
	double complex Sub1836, Sub1116, Sub1117, Sub1121, Sub1122
	double complex Sub1118, Sub1119, Sub1838, Sub1839, Sub1124
	double complex Sub1125, Sub1127, Sub1128, Sub1129, Sub1130
	double complex Sub1841, Sub1842, Sub1131, Sub1132, Sub1133
	double complex Sub1134, Sub1135, Sub1136, Sub1846, Sub1848
	double complex Sub1138, Sub1139, Sub1141, Sub1142, Sub1144
	double complex Sub1145, Sub1146, Sub1147, Sub1148, Sub1149
	double complex Sub1150, Sub1151, Sub1852, Sub1853, Sub1152
	double complex Sub1153, Sub1154, Sub1155, Sub1156, Sub1157
	double complex Sub1159, Sub1160, Sub1162, Sub1163, Sub1164
	double complex Sub1165, Sub1166, Sub1167, Sub1168, Sub1169
	double complex Sub1170, Sub1171, Sub1173, Sub1174, Sub1177
	double complex Sub1178, Sub1180, Sub1181, Sub1185, Sub1186
	double complex Sub1188, Sub1189, Sub1191, Sub1192, Sub1195
	double complex Sub1196, Sub1197, Sub1198, Sub1201, Sub1202
	double complex Sub1204, Sub1205, Sub1207, Sub1208, Sub1210
	double complex Sub1211, Sub1214, Sub1215, Sub1218, Sub1219
	double complex Sub1221, Sub1222, Sub1224, Sub1225, Sub1227
	double complex Sub1228, Sub1229, Sub1230, Sub1233, Sub1234
	double complex Sub1237, Sub1238, Sub1240, Sub1241, Sub1243
	double complex Sub1244, Sub1245, Sub1246, Sub1247, Sub1248
	double complex Sub1251, Sub1252, Sub1254, Sub1255, Sub1257
	double complex Sub1258, Sub1261, Sub1262, Sub1263, Sub1264
	double complex Sub1265, Sub1266, Sub1267, Sub1268, Sub1269
	double complex Sub1270, Sub1272, Sub1273, Sub1275, Sub1276
	double complex Sub1278, Sub1279, Sub1280, Sub1281, Sub1284
	double complex Sub1285, Sub1288, Sub1289, Sub1292, Sub1293
	double complex Sub1295, Sub1296, Sub1298, Sub1299, Sub1301
	double complex Sub1302, Sub1304, Sub1305, Sub1306, Sub1307
	double complex Sub1308, Sub1309, Sub1310, Sub1311, Sub1312
	double complex Sub1313, Sub1315, Sub1316, Sub1319, Sub1320
	double complex Sub1323, Sub1324, Sub1325, Sub1326, Sub1327
	double complex Sub1328, Sub1329, Sub1330, Sub1334, Sub1335
	double complex Sub1338, Sub1339, Sub1342, Sub1343, Sub1346
	double complex Sub1347, Sub1349, Sub1350, Sub1352, Sub1353
	double complex Sub1354, Sub1355, Sub1358, Sub1359, Sub1362
	double complex Sub1363, Sub1365, Sub1366, Sub1368, Sub1369
	double complex Sub1372, Sub1373, Sub1376, Sub1377, Sub1379
	double complex Sub1380, Sub1383, Sub1384, Sub1386, Sub1387
	double complex Sub1388, Sub1389, Sub1392, Sub1393, Sub1396
	double complex Sub1397, Sub1401, Sub1402, Sub1404, Sub1405
	double complex Sub1407, Sub1408, Sub1410, Sub1411, Sub1413
	double complex Sub1414, Sub1415, Sub1416, Sub1419, Sub1420
	double complex Sub1422, Sub1423, Sub1425, Sub1426, Sub1428
	double complex Sub1429, Sub1430, Sub1431, Sub1433, Sub1434
	double complex Sub1435, Sub1436, Sub1437, Sub1438, Sub1782
	double complex Sub1440, Sub1790, Sub1442, Sub1631, Sub1636
	double complex Sub1702, Sub1444, Sub1711, Sub1445, Sub1542
	double complex Sub1541, Sub1873, Sub1427, Sub1421, Sub1403
	double complex Sub1364, Sub1239, Sub1236, Sub1361, Sub1341
	double complex Sub1294, Sub1807, Sub1808, Sub1783, Sub1784
	double complex Sub1764, Sub1765, Sub1718, Sub1555, Sub1719
	double complex Sub1556, Sub1543, Sub1704, Sub1544, Sub1705
	double complex Sub1679, Sub1680, Sub1615, Sub1616, Sub1858
	double complex Sub1856, Sub1861, Sub1870, Sub1868, Sub1546
	double complex Sub1551, Sub1470, Sub1827, Sub1774, Sub1730
	double complex Sub1699, Sub1635, Sub1587, Sub1569, Sub1484
	double complex Sub1477, Sub1501, Sub1493, Sub1527, Sub1533
	double complex Sub1780, Sub1521, Sub1539, Sub1471, Sub1828
	double complex Sub1775, Sub1731, Sub1700, Sub1638, Sub1588
	double complex Sub1570, Sub1487, Sub1481, Sub1504, Sub1496
	double complex Sub1528, Sub1534, Sub1781, Sub1522, Sub1540
	double complex Sub1756, Sub1760, Sub1876, Sub1831, Sub1490
	double complex Sub1120, Sub1485, Sub1478, Sub1488, Sub1482
	double complex Sub1395, Sub1291, Sub1872, Sub1859, Sub1857
	double complex Sub1860, Sub1871, Sub1869, Sub1671, Sub1594
	double complex Sub1676, Sub1600, Sub1158, Sub1864, Sub1863
	double complex Sub1766, Sub1651, Sub1577, Sub1591, Sub1669
	double complex Sub1647, Sub1643, Sub1812, Sub1736, Sub1693
	double complex Sub1809, Sub1743, Sub1606, Sub1581, Sub1788
	double complex Sub1722, Sub1560, Sub1709, Sub1684, Sub1548
	double complex Sub1620, Sub1720, Sub1557, Sub1681, Sub1545
	double complex Sub1617, Sub1660, Sub1657, Sub1769, Sub1652
	double complex Sub1578, Sub1597, Sub1674, Sub1648, Sub1644
	double complex Sub1817, Sub1737, Sub1694, Sub1814, Sub1748
	double complex Sub1611, Sub1583, Sub1794, Sub1726, Sub1565
	double complex Sub1716, Sub1689, Sub1553, Sub1625, Sub1724
	double complex Sub1562, Sub1686, Sub1550, Sub1622, Sub1665
	double complex Sub1662, Sub1193, Sub1194, Sub1212, Sub1213
	double complex Sub1199, Sub1200, Sub1216, Sub1217, Sub1370
	double complex Sub1371, Sub1249, Sub1250, Sub1374, Sub1375
	double complex Sub1282, Sub1283, Sub1390, Sub1391, Sub1356
	double complex Sub1357, Sub1417, Sub1418, Sub1865, Sub1877
	double complex Sub1176, Sub1879, Sub1887, Sub1732, Sub1738
	double complex Sub1573, Sub1535, Sub1529, Sub1515, Sub1523
	double complex Sub1517, Sub1639, Sub1776, Sub1695, Sub1579
	double complex Sub1571, Sub1733, Sub1739, Sub1574, Sub1536
	double complex Sub1530, Sub1516, Sub1524, Sub1518, Sub1640
	double complex Sub1777, Sub1696, Sub1580, Sub1572, Sub1854
	double complex Sub1866, Sub1888, Sub1833, Sub1182, Sub1183
	double complex Sub1231, Sub1232, Sub1745, Sub1608, Sub1750
	double complex Sub1613, Sub1878, Sub1785, Sub1706, Sub1791
	double complex Sub1713, Sub1439, Sub1829, Sub1845, Sub1886
	common /abbrev/ F11, F12, F5, F7, F9, F24, F86, F13, F14, F31
	common /abbrev/ F87, F10, F8, F70, F25, F4, F1054, F1057
	common /abbrev/ F1058, F1059, F1060, F1074, F893, F896, F897
	common /abbrev/ F898, F899, F921, F1042, F966, F967, F1045
	common /abbrev/ F1000, F1046, F877, F1047, F1001, F1048, F880
	common /abbrev/ F881, F1067, F882, F883, F908, F979, F980
	common /abbrev/ F1017, F1018, F912, F911, F910, F909, F1073
	common /abbrev/ F920, F1066, F907, Pair6, Pair85, Pair26
	common /abbrev/ Pair30, Pair27, Pair28, Pair29, Eps941, Eps962
	common /abbrev/ Eps963, Eps884, Eps964, Eps965, Eps885, Eps996
	common /abbrev/ Eps997, Eps931, Eps998, Eps999, Eps932
	common /abbrev/ Abb1068, Abb1075, Abb1055, Abb1076, Abb15
	common /abbrev/ Abb1043, Abb1069, Abb1070, Abb1077, Abb16
	common /abbrev/ Abb17, Abb878, Abb894, Abb18, Abb913, Abb922
	common /abbrev/ Abb914, Abb923, Abb915, Abb916, Abb924, Abb972
	common /abbrev/ Abb985, Abb973, Abb986, Abb917, Abb925, Abb926
	common /abbrev/ Abb974, Abb975, Abb976, Abb977, Abb987, Abb988
	common /abbrev/ Abb989, Abb990, Abb1091, Abb900, Abb901
	common /abbrev/ Abb949, Abb981, Abb982, Abb983, Abb984, Abb944
	common /abbrev/ Abb951, Abb1087, Abb886, Abb887, Abb942
	common /abbrev/ Abb968, Abb969, Abb970, Abb971, Abb945, Abb952
	common /abbrev/ Abb946, Abb953, Abb71, Abb72, Abb45, Abb46
	common /abbrev/ Abb88, Abb89, Abb73, Abb74, Abb1061, Abb1062
	common /abbrev/ Abb80, Abb1002, Abb1021, Abb50, Abb81, Abb1049
	common /abbrev/ Abb1050, Abb51, Abb1005, Abb1022, Abb90, Abb91
	common /abbrev/ Abb92, Abb93, Abb888, Abb889, Abb902, Abb903
	common /abbrev/ Abb1006, Abb1023, Abb1007, Abb1024, Abb94
	common /abbrev/ Abb54, Abb95, Abb55, Abb96, Abb97, Abb98
	common /abbrev/ Abb99, Abb100, Abb58, Abb101, Abb59, Abb102
	common /abbrev/ Abb103, Abb104, Abb105, Abb75, Abb76, Abb47
	common /abbrev/ Abb48, Abb106, Abb107, Abb77, Abb78, Abb1078
	common /abbrev/ Abb19, Abb144, Abb145, Abb1071, Abb20, Abb82
	common /abbrev/ Abb83, Abb108, Abb150, Abb109, Abb151, Abb918
	common /abbrev/ Abb927, Abb1063, Abb1064, Abb1008, Abb1027
	common /abbrev/ Abb110, Abb1051, Abb1052, Abb1011, Abb1028
	common /abbrev/ Abb152, Abb153, Abb154, Abb188, Abb189, Abb890
	common /abbrev/ Abb891, Abb904, Abb905, Abb111, Abb155
	common /abbrev/ Abb1012, Abb1029, Abb1013, Abb1030, Abb938
	common /abbrev/ Abb1019, Abb1020, Abb933, Abb1003, Abb1004
	common /abbrev/ Abb52, Abb32, Abb33, Abb53, Abb161, Abb162
	common /abbrev/ Abb119, Abb120, Abb121, Abb122, Abb56, Abb34
	common /abbrev/ Abb35, Abb57, Abb166, Abb167, Abb239, Abb123
	common /abbrev/ Abb240, Abb124, Abb60, Abb36, Abb37, Abb61
	common /abbrev/ Abb168, Abb169, Abb241, Abb125, Abb242, Abb126
	common /abbrev/ Abb62, Abb38, Abb39, Abb63, Abb163, Abb164
	common /abbrev/ Abb127, Abb128, Abb129, Abb130, Abb64, Abb40
	common /abbrev/ Abb41, Abb65, Abb170, Abb171, Abb243, Abb131
	common /abbrev/ Abb244, Abb132, Abb66, Abb42, Abb43, Abb67
	common /abbrev/ Abb172, Abb173, Abb245, Abb133, Abb246, Abb134
	common /abbrev/ Abb939, Abb1025, Abb1026, Abb934, Abb1009
	common /abbrev/ Abb1010, Abb1092, Abb112, Abb135, Abb136
	common /abbrev/ Abb1088, Abb113, Abb137, Abb138, Abb191
	common /abbrev/ Abb177, Abb192, Abb178, Abb947, Abb954, Abb114
	common /abbrev/ Abb193, Abb194, Abb115, Abb139, Abb140, Abb291
	common /abbrev/ Abb195, Abb292, Abb196, Abb116, Abb197, Abb198
	common /abbrev/ Abb117, Abb141, Abb142, Abb293, Abb199, Abb294
	common /abbrev/ Abb200, Opt1892, Opt1893, Opt1894, Opt1895
	common /abbrev/ Opt1896, Opt1897, Opt1898, Opt1899, Opt1900
	common /abbrev/ Opt1901, Opt1902, Opt1903, Opt1904, Opt1905
	common /abbrev/ Opt1906, Opt1907, Opt1908, Opt1909, Opt1910
	common /abbrev/ Opt1911, Opt1912, Opt1913, Opt1914, Opt1915
	common /abbrev/ Opt1916, Opt1917, Opt1918, Opt1919, Opt1920
	common /abbrev/ Opt1921, Opt1922, Opt1923, Opt1924, Opt1925
	common /abbrev/ Opt1926, Opt1927, Opt1928, Opt1929, Opt1930
	common /abbrev/ Opt1931, Opt1932, Opt1933, Opt1934, Opt1935
	common /abbrev/ Opt1936, Opt1937, Opt1938, Opt1939, Opt1940
	common /abbrev/ Opt1941, Opt1942, Opt1943, Opt1944, Opt1945
	common /abbrev/ Opt1946, Opt1947, Opt1948, Opt1949, Opt1950
	common /abbrev/ Opt1951, Opt1952, Opt1953, Opt1954, Opt1955
	common /abbrev/ Opt1956, Opt1957, Opt1958, Opt1959, Opt1960
	common /abbrev/ Opt1961, Opt1962, Opt1963, Opt1964, Opt1965
	common /abbrev/ Opt1966, Opt1967, Opt1968, Opt1969, Opt1970
	common /abbrev/ Opt1971, Opt1972, Opt1973, Opt1974, Opt1975
	common /abbrev/ Opt1976, Opt1977, Opt1978, Opt1979, Opt1980
	common /abbrev/ AbbSum249, AbbSum660, AbbSum659, AbbSum661
	common /abbrev/ AbbSum662, AbbSum238, AbbSum813, AbbSum778
	common /abbrev/ AbbSum527, AbbSum528, AbbSum355, AbbSum569
	common /abbrev/ AbbSum693, AbbSum570, AbbSum694, AbbSum811
	common /abbrev/ AbbSum358, AbbSum777, AbbSum605, AbbSum845
	common /abbrev/ AbbSum1086, AbbSum606, AbbSum846, AbbSum1090
	common /abbrev/ AbbSum1102, AbbSum824, AbbSum789, AbbSum770
	common /abbrev/ AbbSum820, AbbSum773, AbbSum810, AbbSum727
	common /abbrev/ AbbSum699, AbbSum728, AbbSum700, AbbSum339
	common /abbrev/ AbbSum1100, AbbSum819, AbbSum771, AbbSum809
	common /abbrev/ AbbSum823, AbbSum787, AbbSum769, AbbSum352
	common /abbrev/ AbbSum745, AbbSum746, AbbSum411, AbbSum413
	common /abbrev/ AbbSum837, AbbSum834, AbbSum474, AbbSum473
	common /abbrev/ AbbSum451, AbbSum447, AbbSum448, AbbSum452
	common /abbrev/ AbbSum664, AbbSum434, AbbSum663, AbbSum433
	common /abbrev/ AbbSum701, AbbSum829, AbbSum702, AbbSum832
	common /abbrev/ AbbSum935, AbbSum940, AbbSum957, AbbSum943
	common /abbrev/ AbbSum958, AbbSum950, AbbSum532, AbbSum534
	common /abbrev/ AbbSum581, AbbSum725, AbbSum579, AbbSum723
	common /abbrev/ AbbSum457, AbbSum458, AbbSum803, AbbSum804
	common /abbrev/ AbbSum406, AbbSum408, AbbSum404, AbbSum816
	common /abbrev/ AbbSum405, AbbSum403, AbbSum407, AbbSum815
	common /abbrev/ AbbSum741, AbbSum742, AbbSum730, AbbSum836
	common /abbrev/ AbbSum729, AbbSum833, AbbSum490, AbbSum632
	common /abbrev/ AbbSum489, AbbSum629, AbbSum563, AbbSum559
	common /abbrev/ AbbSum571, AbbSum572, AbbSum560, AbbSum564
	common /abbrev/ AbbSum930, AbbSum519, AbbSum762, AbbSum937
	common /abbrev/ AbbSum517, AbbSum761, AbbSum622, AbbSum827
	common /abbrev/ AbbSum625, AbbSum830, AbbSum1095, AbbSum1096
	common /abbrev/ AbbSum298, AbbSum299, AbbSum223, AbbSum250
	common /abbrev/ AbbSum315, AbbSum377, AbbSum360, AbbSum703
	common /abbrev/ AbbSum268, AbbSum705, AbbSum387, AbbSum1056
	common /abbrev/ AbbSum332, AbbSum318, AbbSum1044, AbbSum381
	common /abbrev/ AbbSum356, AbbSum376, AbbSum383, AbbSum365
	common /abbrev/ AbbSum354, AbbSum724, AbbSum726, AbbSum342
	common /abbrev/ AbbSum518, AbbSum520, AbbSum49, AbbSum633
	common /abbrev/ AbbSum831, AbbSum630, AbbSum828, AbbSum624
	common /abbrev/ AbbSum621, AbbSum183, AbbSum432, AbbSum431
	common /abbrev/ AbbSum480, AbbSum418, AbbSum479, AbbSum417
	common /abbrev/ AbbSum463, AbbSum669, AbbSum465, AbbSum670
	common /abbrev/ AbbSum879, AbbSum895, AbbSum300, AbbSum203
	common /abbrev/ AbbSum835, AbbSum1081, AbbSum319, AbbSum838
	common /abbrev/ AbbSum1084, AbbSum644, AbbSum1033, AbbSum1032
	common /abbrev/ AbbSum1036, AbbSum1035, AbbSum646, AbbSum561
	common /abbrev/ AbbSum557, AbbSum226, AbbSum640, AbbSum637
	common /abbrev/ AbbSum521, AbbSum523, AbbSum592, AbbSum678
	common /abbrev/ AbbSum589, AbbSum675, AbbSum676, AbbSum590
	common /abbrev/ AbbSum679, AbbSum593, AbbSum255, AbbSum330
	common /abbrev/ AbbSum165, AbbSum522, AbbSum524, AbbSum464
	common /abbrev/ AbbSum466, AbbSum373, AbbSum529, AbbSum22
	common /abbrev/ AbbSum21, AbbSum23, AbbSum379, AbbSum530
	common /abbrev/ AbbSum704, AbbSum340, AbbSum706, AbbSum409
	common /abbrev/ AbbSum410, AbbSum333, AbbSum577, AbbSum574
	common /abbrev/ AbbSum216, AbbSum279, AbbSum614, AbbSum536
	common /abbrev/ AbbSum416, AbbSum613, AbbSum535, AbbSum415
	common /abbrev/ AbbSum645, AbbSum734, AbbSum739, AbbSum512
	common /abbrev/ AbbSum643, AbbSum731, AbbSum737, AbbSum509
	common /abbrev/ AbbSum251, AbbSum583, AbbSum749, AbbSum747
	common /abbrev/ AbbSum585, AbbSum750, AbbSum748, AbbSum218
	common /abbrev/ AbbSum349, AbbSum995, AbbSum276, AbbSum1016
	common /abbrev/ AbbSum475, AbbSum738, AbbSum477, AbbSum740
	common /abbrev/ AbbSum450, AbbSum446, AbbSum708, AbbSum707
	common /abbrev/ AbbSum665, AbbSum467, AbbSum667, AbbSum468
	common /abbrev/ AbbSum441, AbbSum553, AbbSum795, AbbSum443
	common /abbrev/ AbbSum555, AbbSum796, AbbSum948, AbbSum955
	common /abbrev/ AbbSum562, AbbSum558, AbbSum320, AbbSum715
	common /abbrev/ AbbSum716, AbbSum584, AbbSum567, AbbSum586
	common /abbrev/ AbbSum568, AbbSum721, AbbSum722, AbbSum331
	common /abbrev/ AbbSum649, AbbSum505, AbbSum507, AbbSum219
	common /abbrev/ AbbSum650, AbbSum506, AbbSum508, AbbSum476
	common /abbrev/ AbbSum461, AbbSum478, AbbSum462, AbbSum280
	common /abbrev/ AbbSum275, AbbSum860, AbbSum859, AbbSum186
	common /abbrev/ AbbSum79, AbbSum176, AbbSum303, AbbSum495
	common /abbrev/ AbbSum435, AbbSum419, AbbSum498, AbbSum438
	common /abbrev/ AbbSum422, AbbSum587, AbbSum588, AbbSum792
	common /abbrev/ AbbSum502, AbbSum791, AbbSum501, AbbSum805
	common /abbrev/ AbbSum806, AbbSum287, AbbSum449, AbbSum456
	common /abbrev/ AbbSum445, AbbSum455, AbbSum548, AbbSum538
	common /abbrev/ AbbSum551, AbbSum541, AbbSum666, AbbSum668
	common /abbrev/ AbbSum1089, AbbSum1093, AbbSum717, AbbSum718
	common /abbrev/ AbbSum615, AbbSum616, AbbSum808, AbbSum807
	common /abbrev/ AbbSum414, AbbSum412, AbbSum533, AbbSum531
	common /abbrev/ AbbSum573, AbbSum713, AbbSum709, AbbSum576
	common /abbrev/ AbbSum714, AbbSum711, AbbSum862, AbbSum861
	common /abbrev/ AbbSum767, AbbSum841, AbbSum768, AbbSum842
	common /abbrev/ AbbSum732, AbbSum510, AbbSum627, AbbSum735
	common /abbrev/ AbbSum513, AbbSum628, AbbSum636, AbbSum756
	common /abbrev/ AbbSum635, AbbSum755, AbbSum1107, AbbSum1082
	common /abbrev/ AbbSum623, AbbSum626, AbbSum631, AbbSum634
	common /abbrev/ AbbSum657, AbbSum655, AbbSum283, AbbSum220
	common /abbrev/ AbbSum260, AbbSum306, AbbSum307, AbbSum261
	common /abbrev/ AbbSum428, AbbSum471, AbbSum546, AbbSum426
	common /abbrev/ AbbSum469, AbbSum544, AbbSum691, AbbSum689
	common /abbrev/ AbbSum1080, AbbSum491, AbbSum482, AbbSum994
	common /abbrev/ AbbSum493, AbbSum1083, AbbSum485, AbbSum638
	common /abbrev/ AbbSum1110, AbbSum1034, AbbSum641, AbbSum1037
	common /abbrev/ AbbSum673, AbbSum600, AbbSum840, AbbSum671
	common /abbrev/ AbbSum597, AbbSum839, AbbSum221, AbbSum503
	common /abbrev/ AbbSum504, AbbSum179, AbbSum224, AbbSum653
	common /abbrev/ AbbSum656, AbbSum710, AbbSum743, AbbSum697
	common /abbrev/ AbbSum695, AbbSum654, AbbSum658, AbbSum712
	common /abbrev/ AbbSum744, AbbSum698, AbbSum696, AbbSum321
	common /abbrev/ AbbSum591, AbbSum677, AbbSum594, AbbSum680
	common /abbrev/ AbbSum470, AbbSum459, AbbSum44, AbbSum472
	common /abbrev/ AbbSum460, AbbSum253, AbbSum227, AbbSum69
	common /abbrev/ AbbSum286, AbbSum334, AbbSum337, AbbSum213
	common /abbrev/ AbbSum580, AbbSum257, AbbSum582, AbbSum344
	common /abbrev/ AbbSum343, AbbSum484, AbbSum686, AbbSum481
	common /abbrev/ AbbSum683, AbbSum547, AbbSum550, AbbSum1015
	common /abbrev/ AbbSum515, AbbSum516, AbbSum184, AbbSum338
	common /abbrev/ AbbSum1111, AbbSum760, AbbSum766, AbbSum794
	common /abbrev/ AbbSum759, AbbSum765, AbbSum793, AbbSum1112
	common /abbrev/ AbbSum863, AbbSum436, AbbSum598, AbbSum864
	common /abbrev/ AbbSum439, AbbSum601, AbbSum1106, AbbSum929
	common /abbrev/ AbbSum936, AbbSum1108, AbbSum857, AbbSum858
	common /abbrev/ AbbSum1113, AbbSum1109, AbbSum1085, AbbSum651
	common /abbrev/ AbbSum652, AbbSum322, AbbSum301, AbbSum180
	common /abbrev/ AbbSum892, AbbSum681, AbbSum851, AbbSum595
	common /abbrev/ AbbSum682, AbbSum906, AbbSum158, AbbSum852
	common /abbrev/ AbbSum236, AbbSum369, AbbSum596, AbbSum1014
	common /abbrev/ AbbSum442, AbbSum425, AbbSum956, AbbSum959
	common /abbrev/ AbbSum444, AbbSum427, AbbSum784, AbbSum776
	common /abbrev/ AbbSum783, AbbSum775, AbbSum1094, AbbSum554
	common /abbrev/ AbbSum543, AbbSum556, AbbSum545, AbbSum511
	common /abbrev/ AbbSum525, AbbSum733, AbbSum514, AbbSum526
	common /abbrev/ AbbSum736, AbbSum565, AbbSum575, AbbSum566
	common /abbrev/ AbbSum578, AbbSum843, AbbSum844, AbbSum782
	common /abbrev/ AbbSum781, AbbSum801, AbbSum802, AbbSum326
	common /abbrev/ AbbSum258, AbbSum248, AbbSum329, AbbSum289
	common /abbrev/ AbbSum211, AbbSum212, AbbSum185, AbbSum175
	common /abbrev/ AbbSum394, AbbSum206, AbbSum149, AbbSum84
	common /abbrev/ AbbSum259, AbbSum430, AbbSum367, AbbSum429
	common /abbrev/ AbbSum209, AbbSum374, AbbSum1097, AbbSum234
	common /abbrev/ AbbSum229, AbbSum763, AbbSum764, AbbSum780
	common /abbrev/ AbbSum758, AbbSum454, AbbSum779, AbbSum757
	common /abbrev/ AbbSum453, AbbSum1104, AbbSum797, AbbSum785
	common /abbrev/ AbbSum798, AbbSum786, AbbSum302, AbbSum327
	common /abbrev/ AbbSum272, AbbSum672, AbbSum539, AbbSum549
	common /abbrev/ AbbSum608, AbbSum639, AbbSum492, AbbSum437
	common /abbrev/ AbbSum421, AbbSum674, AbbSum542, AbbSum552
	common /abbrev/ AbbSum610, AbbSum642, AbbSum494, AbbSum440
	common /abbrev/ AbbSum424, AbbSum375, AbbSum68, AbbSum225
	common /abbrev/ AbbSum252, AbbSum325, AbbSum323, AbbSum395
	common /abbrev/ AbbSum607, AbbSum353, AbbSum609, AbbSum385
	common /abbrev/ AbbSum1031, AbbSum335, AbbSum214, AbbSum278
	common /abbrev/ AbbSum282, AbbSum347, AbbSum1038, AbbSum1072
	common /abbrev/ AbbSum853, AbbSum1105, AbbSum854, AbbSum919
	common /abbrev/ AbbSum928, AbbSum992, AbbSum277, AbbSum281
	common /abbrev/ AbbSum619, AbbSum483, AbbSum647, AbbSum617
	common /abbrev/ AbbSum599, AbbSum620, AbbSum486, AbbSum648
	common /abbrev/ AbbSum618, AbbSum602, AbbSum296, AbbSum147
	common /abbrev/ AbbSum181, AbbSum232, AbbSum1079, AbbSum1039
	common /abbrev/ AbbSum540, AbbSum856, AbbSum537, AbbSum855
	common /abbrev/ AbbSum812, AbbSum420, AbbSum993, AbbSum814
	common /abbrev/ AbbSum423, AbbSum685, AbbSum497, AbbSum688
	common /abbrev/ AbbSum500, AbbSum313, AbbSum753, AbbSum751
	common /abbrev/ AbbSum204, AbbSum754, AbbSum752, AbbSum190
	common /abbrev/ AbbSum690, AbbSum284, AbbSum692, AbbSum304
	common /abbrev/ AbbSum264, AbbSum1101, AbbSum1053, AbbSum799
	common /abbrev/ AbbSum800, AbbSum1065, AbbSum960, AbbSum961
	common /abbrev/ AbbSum488, AbbSum872, AbbSum604, AbbSum874
	common /abbrev/ AbbSum774, AbbSum499, AbbSum487, AbbSum871
	common /abbrev/ AbbSum603, AbbSum873, AbbSum772, AbbSum496
	common /abbrev/ AbbSum788, AbbSum790, AbbSum210, AbbSum295
	common /abbrev/ AbbSum297, AbbSum324, AbbSum341, AbbSum317
	common /abbrev/ AbbSum316, AbbSum262, AbbSum308, AbbSum719
	common /abbrev/ AbbSum720, AbbSum182, AbbSum174, AbbSum256
	common /abbrev/ AbbSum187, AbbSum310, AbbSum233, AbbSum217
	common /abbrev/ AbbSum351, AbbSum368, AbbSum396, AbbSum156
	common /abbrev/ AbbSum265, AbbSum611, AbbSum612, AbbSum866
	common /abbrev/ AbbSum865, AbbSum978, AbbSum393, AbbSum1103
	common /abbrev/ AbbSum991, AbbSum850, AbbSum849, AbbSum1114
	common /abbrev/ AbbSum1115, AbbSum290, AbbSum309, AbbSum390
	common /abbrev/ AbbSum263, AbbSum159, AbbSum146, AbbSum687
	common /abbrev/ AbbSum684, AbbSum363, AbbSum359, AbbSum1098
	common /abbrev/ AbbSum237, AbbSum231, AbbSum876, AbbSum875
	common /abbrev/ AbbSum215, AbbSum222, AbbSum336, AbbSum247
	common /abbrev/ AbbSum254, AbbSum386, AbbSum362, AbbSum867
	common /abbrev/ AbbSum868, AbbSum372, AbbSum1099, AbbSum1040
	common /abbrev/ AbbSum869, AbbSum847, AbbSum870, AbbSum848
	common /abbrev/ AbbSum148, AbbSum821, AbbSum817, AbbSum822
	common /abbrev/ AbbSum818, AbbSum825, AbbSum826, AbbSum1041
	common /abbrev/ AbbSum350, AbbSum361, AbbSum348, AbbSum160
	common /abbrev/ AbbSum370, AbbSum364, AbbSum305, AbbSum230
	common /abbrev/ AbbSum235, AbbSum270, AbbSum285, AbbSum205
	common /abbrev/ AbbSum157, AbbSum143, AbbSum269, AbbSum391
	common /abbrev/ AbbSum274, AbbSum201, AbbSum288, AbbSum273
	common /abbrev/ AbbSum266, AbbSum228, AbbSum392, AbbSum378
	common /abbrev/ AbbSum118, AbbSum312, AbbSum208, AbbSum346
	common /abbrev/ AbbSum345, AbbSum314, AbbSum371, AbbSum202
	common /abbrev/ AbbSum400, AbbSum267, AbbSum401, AbbSum357
	common /abbrev/ AbbSum207, AbbSum366, AbbSum328, AbbSum271
	common /abbrev/ AbbSum397, AbbSum389, AbbSum311, AbbSum402
	common /abbrev/ AbbSum398, AbbSum399, AbbSum388, AbbSum382
	common /abbrev/ AbbSum380, AbbSum384, Opt1981, Sub1424
	common /abbrev/ Sub1398, Sub1332, Sub1175, Sub1172, Sub1161
	common /abbrev/ Sub1140, Sub1137, Sub1143, Sub1126, Sub1123
	common /abbrev/ Sub1799, Sub1800, Sub1752, Sub1753, Sub1655
	common /abbrev/ Sub1656, Sub1499, Sub1500, Sub1491, Sub1492
	common /abbrev/ Sub1472, Sub1473, Sub1466, Sub1467, Sub1464
	common /abbrev/ Sub1465, Sub1468, Sub1469, Sub1454, Sub1455
	common /abbrev/ Sub1446, Sub1447, Sub1862, Sub1592, Sub1810
	common /abbrev/ Sub1786, Sub1742, Sub1618, Sub1558, Sub1707
	common /abbrev/ Sub1658, Sub1682, Sub1605, Sub1598, Sub1815
	common /abbrev/ Sub1792, Sub1747, Sub1623, Sub1563, Sub1714
	common /abbrev/ Sub1663, Sub1687, Sub1610, Sub1360, Sub1340
	common /abbrev/ Sub1595, Sub1672, Sub1601, Sub1677, Sub1547
	common /abbrev/ Sub1552, Sub1559, Sub1564, Sub1593, Sub1599
	common /abbrev/ Sub1607, Sub1612, Sub1619, Sub1624, Sub1659
	common /abbrev/ Sub1664, Sub1670, Sub1675, Sub1683, Sub1688
	common /abbrev/ Sub1708, Sub1715, Sub1721, Sub1725, Sub1744
	common /abbrev/ Sub1749, Sub1787, Sub1793, Sub1811, Sub1816
	common /abbrev/ Sub1847, Sub1885, Sub1850, Sub1867, Sub1832
	common /abbrev/ Sub1830, Sub1796, Sub1510, Sub1494, Sub1502
	common /abbrev/ Sub1449, Sub1457, Sub1820, Sub1767, Sub1758
	common /abbrev/ Sub1513, Sub1497, Sub1505, Sub1452, Sub1460
	common /abbrev/ Sub1823, Sub1770, Sub1762, Sub1235, Sub1453
	common /abbrev/ Sub1450, Sub1461, Sub1458, Sub1498, Sub1495
	common /abbrev/ Sub1506, Sub1503, Sub1514, Sub1511, Sub1554
	common /abbrev/ Sub1549, Sub1566, Sub1561, Sub1602, Sub1596
	common /abbrev/ Sub1614, Sub1609, Sub1626, Sub1621, Sub1666
	common /abbrev/ Sub1661, Sub1678, Sub1673, Sub1690, Sub1685
	common /abbrev/ Sub1717, Sub1710, Sub1797, Sub1798, Sub1727
	common /abbrev/ Sub1723, Sub1751, Sub1746, Sub1763, Sub1759
	common /abbrev/ Sub1771, Sub1768, Sub1795, Sub1789, Sub1806
	common /abbrev/ Sub1803, Sub1818, Sub1813, Sub1824, Sub1821
	common /abbrev/ Sub1441, Sub1703, Sub1443, Sub1476, Sub1712
	common /abbrev/ Sub1480, Sub1633, Sub1637, Sub1874, Sub1875
	common /abbrev/ Sub1849, Sub1409, Sub1406, Sub1412, Sub1399
	common /abbrev/ Sub1394, Sub1381, Sub1378, Sub1385, Sub1367
	common /abbrev/ Sub1242, Sub1348, Sub1344, Sub1351, Sub1336
	common /abbrev/ Sub1331, Sub1317, Sub1314, Sub1321, Sub1300
	common /abbrev/ Sub1297, Sub1303, Sub1290, Sub1286, Sub1274
	common /abbrev/ Sub1271, Sub1277, Sub1256, Sub1253, Sub1259
	common /abbrev/ Sub1223, Sub1220, Sub1226, Sub1206, Sub1203
	common /abbrev/ Sub1209, Sub1187, Sub1184, Sub1190, Sub1179
	common /abbrev/ Sub1825, Sub1826, Sub1701, Sub1432, Sub1772
	common /abbrev/ Sub1773, Sub1778, Sub1779, Sub1754, Sub1755
	common /abbrev/ Sub1740, Sub1741, Sub1734, Sub1735, Sub1728
	common /abbrev/ Sub1567, Sub1729, Sub1568, Sub1691, Sub1692
	common /abbrev/ Sub1697, Sub1698, Sub1667, Sub1668, Sub1653
	common /abbrev/ Sub1654, Sub1645, Sub1646, Sub1641, Sub1642
	common /abbrev/ Sub1649, Sub1650, Sub1632, Sub1634, Sub1603
	common /abbrev/ Sub1604, Sub1589, Sub1590, Sub1585, Sub1586
	common /abbrev/ Sub1575, Sub1576, Sub1532, Sub1531, Sub1538
	common /abbrev/ Sub1537, Sub1525, Sub1526, Sub1519, Sub1520
	common /abbrev/ Sub1507, Sub1508, Sub1509, Sub1448, Sub1456
	common /abbrev/ Sub1801, Sub1512, Sub1451, Sub1459, Sub1804
	common /abbrev/ Sub1382, Sub1345, Sub1337, Sub1318, Sub1322
	common /abbrev/ Sub1287, Sub1260, Sub1844, Sub1884, Sub1400
	common /abbrev/ Sub1333, Sub1819, Sub1628, Sub1582, Sub1474
	common /abbrev/ Sub1627, Sub1462, Sub1757, Sub1822, Sub1630
	common /abbrev/ Sub1584, Sub1475, Sub1629, Sub1463, Sub1761
	common /abbrev/ Sub1479, Sub1483, Sub1486, Sub1489, Sub1855
	common /abbrev/ Sub1889, Sub1837, Sub1834, Sub1851, Sub1840
	common /abbrev/ Sub1881, Sub1880, Sub1882, Sub1843, Sub1883
	common /abbrev/ Sub1802, Sub1805, Sub1835, Sub1836, Sub1116
	common /abbrev/ Sub1117, Sub1121, Sub1122, Sub1118, Sub1119
	common /abbrev/ Sub1838, Sub1839, Sub1124, Sub1125, Sub1127
	common /abbrev/ Sub1128, Sub1129, Sub1130, Sub1841, Sub1842
	common /abbrev/ Sub1131, Sub1132, Sub1133, Sub1134, Sub1135
	common /abbrev/ Sub1136, Sub1846, Sub1848, Sub1138, Sub1139
	common /abbrev/ Sub1141, Sub1142, Sub1144, Sub1145, Sub1146
	common /abbrev/ Sub1147, Sub1148, Sub1149, Sub1150, Sub1151
	common /abbrev/ Sub1852, Sub1853, Sub1152, Sub1153, Sub1154
	common /abbrev/ Sub1155, Sub1156, Sub1157, Sub1159, Sub1160
	common /abbrev/ Sub1162, Sub1163, Sub1164, Sub1165, Sub1166
	common /abbrev/ Sub1167, Sub1168, Sub1169, Sub1170, Sub1171
	common /abbrev/ Sub1173, Sub1174, Sub1177, Sub1178, Sub1180
	common /abbrev/ Sub1181, Sub1185, Sub1186, Sub1188, Sub1189
	common /abbrev/ Sub1191, Sub1192, Sub1195, Sub1196, Sub1197
	common /abbrev/ Sub1198, Sub1201, Sub1202, Sub1204, Sub1205
	common /abbrev/ Sub1207, Sub1208, Sub1210, Sub1211, Sub1214
	common /abbrev/ Sub1215, Sub1218, Sub1219, Sub1221, Sub1222
	common /abbrev/ Sub1224, Sub1225, Sub1227, Sub1228, Sub1229
	common /abbrev/ Sub1230, Sub1233, Sub1234, Sub1237, Sub1238
	common /abbrev/ Sub1240, Sub1241, Sub1243, Sub1244, Sub1245
	common /abbrev/ Sub1246, Sub1247, Sub1248, Sub1251, Sub1252
	common /abbrev/ Sub1254, Sub1255, Sub1257, Sub1258, Sub1261
	common /abbrev/ Sub1262, Sub1263, Sub1264, Sub1265, Sub1266
	common /abbrev/ Sub1267, Sub1268, Sub1269, Sub1270, Sub1272
	common /abbrev/ Sub1273, Sub1275, Sub1276, Sub1278, Sub1279
	common /abbrev/ Sub1280, Sub1281, Sub1284, Sub1285, Sub1288
	common /abbrev/ Sub1289, Sub1292, Sub1293, Sub1295, Sub1296
	common /abbrev/ Sub1298, Sub1299, Sub1301, Sub1302, Sub1304
	common /abbrev/ Sub1305, Sub1306, Sub1307, Sub1308, Sub1309
	common /abbrev/ Sub1310, Sub1311, Sub1312, Sub1313, Sub1315
	common /abbrev/ Sub1316, Sub1319, Sub1320, Sub1323, Sub1324
	common /abbrev/ Sub1325, Sub1326, Sub1327, Sub1328, Sub1329
	common /abbrev/ Sub1330, Sub1334, Sub1335, Sub1338, Sub1339
	common /abbrev/ Sub1342, Sub1343, Sub1346, Sub1347, Sub1349
	common /abbrev/ Sub1350, Sub1352, Sub1353, Sub1354, Sub1355
	common /abbrev/ Sub1358, Sub1359, Sub1362, Sub1363, Sub1365
	common /abbrev/ Sub1366, Sub1368, Sub1369, Sub1372, Sub1373
	common /abbrev/ Sub1376, Sub1377, Sub1379, Sub1380, Sub1383
	common /abbrev/ Sub1384, Sub1386, Sub1387, Sub1388, Sub1389
	common /abbrev/ Sub1392, Sub1393, Sub1396, Sub1397, Sub1401
	common /abbrev/ Sub1402, Sub1404, Sub1405, Sub1407, Sub1408
	common /abbrev/ Sub1410, Sub1411, Sub1413, Sub1414, Sub1415
	common /abbrev/ Sub1416, Sub1419, Sub1420, Sub1422, Sub1423
	common /abbrev/ Sub1425, Sub1426, Sub1428, Sub1429, Sub1430
	common /abbrev/ Sub1431, Sub1433, Sub1434, Sub1435, Sub1436
	common /abbrev/ Sub1437, Sub1438, Sub1782, Sub1440, Sub1790
	common /abbrev/ Sub1442, Sub1631, Sub1636, Sub1702, Sub1444
	common /abbrev/ Sub1711, Sub1445, Sub1542, Sub1541, Sub1873
	common /abbrev/ Sub1427, Sub1421, Sub1403, Sub1364, Sub1239
	common /abbrev/ Sub1236, Sub1361, Sub1341, Sub1294, Sub1807
	common /abbrev/ Sub1808, Sub1783, Sub1784, Sub1764, Sub1765
	common /abbrev/ Sub1718, Sub1555, Sub1719, Sub1556, Sub1543
	common /abbrev/ Sub1704, Sub1544, Sub1705, Sub1679, Sub1680
	common /abbrev/ Sub1615, Sub1616, Sub1858, Sub1856, Sub1861
	common /abbrev/ Sub1870, Sub1868, Sub1546, Sub1551, Sub1470
	common /abbrev/ Sub1827, Sub1774, Sub1730, Sub1699, Sub1635
	common /abbrev/ Sub1587, Sub1569, Sub1484, Sub1477, Sub1501
	common /abbrev/ Sub1493, Sub1527, Sub1533, Sub1780, Sub1521
	common /abbrev/ Sub1539, Sub1471, Sub1828, Sub1775, Sub1731
	common /abbrev/ Sub1700, Sub1638, Sub1588, Sub1570, Sub1487
	common /abbrev/ Sub1481, Sub1504, Sub1496, Sub1528, Sub1534
	common /abbrev/ Sub1781, Sub1522, Sub1540, Sub1756, Sub1760
	common /abbrev/ Sub1876, Sub1831, Sub1490, Sub1120, Sub1485
	common /abbrev/ Sub1478, Sub1488, Sub1482, Sub1395, Sub1291
	common /abbrev/ Sub1872, Sub1859, Sub1857, Sub1860, Sub1871
	common /abbrev/ Sub1869, Sub1671, Sub1594, Sub1676, Sub1600
	common /abbrev/ Sub1158, Sub1864, Sub1863, Sub1766, Sub1651
	common /abbrev/ Sub1577, Sub1591, Sub1669, Sub1647, Sub1643
	common /abbrev/ Sub1812, Sub1736, Sub1693, Sub1809, Sub1743
	common /abbrev/ Sub1606, Sub1581, Sub1788, Sub1722, Sub1560
	common /abbrev/ Sub1709, Sub1684, Sub1548, Sub1620, Sub1720
	common /abbrev/ Sub1557, Sub1681, Sub1545, Sub1617, Sub1660
	common /abbrev/ Sub1657, Sub1769, Sub1652, Sub1578, Sub1597
	common /abbrev/ Sub1674, Sub1648, Sub1644, Sub1817, Sub1737
	common /abbrev/ Sub1694, Sub1814, Sub1748, Sub1611, Sub1583
	common /abbrev/ Sub1794, Sub1726, Sub1565, Sub1716, Sub1689
	common /abbrev/ Sub1553, Sub1625, Sub1724, Sub1562, Sub1686
	common /abbrev/ Sub1550, Sub1622, Sub1665, Sub1662, Sub1193
	common /abbrev/ Sub1194, Sub1212, Sub1213, Sub1199, Sub1200
	common /abbrev/ Sub1216, Sub1217, Sub1370, Sub1371, Sub1249
	common /abbrev/ Sub1250, Sub1374, Sub1375, Sub1282, Sub1283
	common /abbrev/ Sub1390, Sub1391, Sub1356, Sub1357, Sub1417
	common /abbrev/ Sub1418, Sub1865, Sub1877, Sub1176, Sub1879
	common /abbrev/ Sub1887, Sub1732, Sub1738, Sub1573, Sub1535
	common /abbrev/ Sub1529, Sub1515, Sub1523, Sub1517, Sub1639
	common /abbrev/ Sub1776, Sub1695, Sub1579, Sub1571, Sub1733
	common /abbrev/ Sub1739, Sub1574, Sub1536, Sub1530, Sub1516
	common /abbrev/ Sub1524, Sub1518, Sub1640, Sub1777, Sub1696
	common /abbrev/ Sub1580, Sub1572, Sub1854, Sub1866, Sub1888
	common /abbrev/ Sub1833, Sub1182, Sub1183, Sub1231, Sub1232
	common /abbrev/ Sub1745, Sub1608, Sub1750, Sub1613, Sub1878
	common /abbrev/ Sub1785, Sub1706, Sub1791, Sub1713, Sub1439
	common /abbrev/ Sub1829, Sub1845, Sub1886

	integer iint1, iint2, iint3, iint4, iint5, iint6, iint7, iint8
	integer iint9, iint10, iint11, iint12, iint13, iint14, iint15
	integer iint16, iint17, iint18, iint19, iint20, iint21, iint22
	integer iint23, iint24, iint25, iint26, iint27, iint28, iint29
	integer iint30, iint31, iint32, iint33, iint34, iint35, iint36
	integer iint37, iint38, iint39, iint40, iint41, iint42, iint43
	integer iint44, iint45, iint46, iint47, iint48, iint49, iint50
	integer iint51, iint52, iint53, iint54, iint55, iint56, iint57
	integer iint58, iint59, iint60, iint61, iint62, iint63, iint64
	integer iint65, iint66
	common /loopint/ iint1, iint2, iint3, iint4, iint5, iint6
	common /loopint/ iint7, iint8, iint9, iint10, iint11, iint12
	common /loopint/ iint13, iint14, iint15, iint16, iint17
	common /loopint/ iint18, iint19, iint20, iint21, iint22
	common /loopint/ iint23, iint24, iint25, iint26, iint27
	common /loopint/ iint28, iint29, iint30, iint31, iint32
	common /loopint/ iint33, iint34, iint35, iint36, iint37
	common /loopint/ iint38, iint39, iint40, iint41, iint42
	common /loopint/ iint43, iint44, iint45, iint46, iint47
	common /loopint/ iint48, iint49, iint50, iint51, iint52
	common /loopint/ iint53, iint54, iint55, iint56, iint57
	common /loopint/ iint58, iint59, iint60, iint61, iint62
	common /loopint/ iint63, iint64, iint65, iint66

	double complex MatSUN(3,3), Cloop(3)
	common /formfactors/ MatSUN, Cloop


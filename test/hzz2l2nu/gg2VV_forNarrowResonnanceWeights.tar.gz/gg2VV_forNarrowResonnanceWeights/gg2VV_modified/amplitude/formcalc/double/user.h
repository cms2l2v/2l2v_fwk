* user.h
* here is the right place to add user definitions
* this file is part of FormCalc
* last modified 30 Apr 08 th


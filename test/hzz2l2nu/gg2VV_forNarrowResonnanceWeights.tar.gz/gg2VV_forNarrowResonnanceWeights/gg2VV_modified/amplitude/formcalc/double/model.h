* model.h
* common blocks for the model parameters
* this file is part of FormCalc
* last modified 19 May 08 th


	double precision pi, degree, sqrt2

	parameter (pi = 3.1415926535897932384626433832795029D0)
	parameter (degree = pi/180D0)
	parameter (sqrt2 = 1.4142135623730950488016887242096981D0)

	double complex bogus, cI

	parameter (bogus = (-1D123, -2D123))
*	  some weird number likely to noticeably distort the final result;
*	  used for initializing arrays to check that all components
*	  have been calculated

	parameter (cI = (0D0, 1D0))

* SM parameters

      double precision MZ, MZ2, MW, MW2, CW, CW2, SW2
      double precision GF, Alfa, Alfa2, AlfaMZ, AlfasMZ
      double precision ME, ME2, MM, MM2, ML, ML2
      double precision MU, MU2, MC, MC2, MT, MT2
      double precision MD, MD2, MS, MS2, MB, MB2, MBatMB

      common /sm_para/ MZ, MZ2, MW, MW2, CW, CW2, SW2
      common /sm_para/ GF, Alfa, Alfa2, AlfaMZ, AlfasMZ
      common /sm_para/ ME, ME2, MM, MM2, ML, ML2
      common /sm_para/ MU, MU2, MC, MC2, MT, MT2
      common /sm_para/ MD, MD2, MS, MS2, MB, MB2, MBatMB

      double precision Mf(4,3), Mf2(4,3)
      double precision MH, MH2
      double precision EL, GS, Alfas, Alfas2, AlfasMT, SW

      common /sm_para/ Mf, Mf2
      common /sm_para/ MH, MH2
      common /sm_para/ EL, GS, Alfas, Alfas2, AlfasMT, SW

C     widths (not part of FormCalc):
      double precision nk_W_width, nk_Z_width, nk_H_width
      common /sm_para/ nk_W_width, nk_Z_width, nk_H_width

#include "decl.h"

	double precision S, T, T14, T15, U, T24, T25, S34, S35, S45
	common /kinvars/ S, T, T14, T15, U, T24, T25, S34, S35, S45

	integer Hel(6)
	common /kinvars/ Hel

	double complex F11, F6, F13, F21, F35, F14, F7, F36, F22, F200
	double complex F4, F5, F127, F255, F125, F126, F359, F1040
	double complex F274, F96, F117, F1043, F1044, F322, F1045
	double complex F1046, F1057, F154, F254, F153, F589, F164
	double complex F348, F1099, F1056, Pair12, Pair37, Pair23
	double complex Pair27, Pair70, Pair24, Pair25, Pair26, Pair55
	double complex Eps165, Eps94, Eps95, Eps1047, Eps228, Eps229
	double complex Eps1048, Eps92, Eps93, Eps1063, Eps347, Eps483
	double complex Eps484, Eps1064, Abb15, Abb155, Abb275, Abb128
	double complex Abb256, Abb257, Abb156, Abb258, Abb276, Abb305
	double complex Abb1041, Abb1058, Abb1100, Abb8, Abb381, Abb129
	double complex Abb9, Abb323, Abb689, Abb690, Abb230, Abb231
	double complex Abb232, Abb233, Abb234, Abb97, Abb98, Abb485
	double complex Abb486, Abb295, Abb235, Abb236, Abb166, Abb167
	double complex Abb876, Abb691, Abb692, Abb877, Abb878, Abb168
	double complex Abb296, Abb297, Abb169, Abb170, Abb1069
	double complex Abb1049, Abb1050, Abb315, Abb379, Abb380
	double complex Abb261, Abb262, Abb1104, Abb99, Abb100, Abb298
	double complex Abb299, Abb324, Abb130, Abb325, Abb131, Abb118
	double complex Abb157, Abb1059, Abb16, Abb326, Abb201, Abb237
	double complex Abb81, Abb171, Abb74, Abb119, Abb277, Abb45
	double complex Abb120, Abb101, Abb300, Abb84, Abb438, Abb238
	double complex Abb132, Abb239, Abb549, Abb1051, Abb1052
	double complex Abb133, Abb585, Abb382, Abb59, Abb85, Abb86
	double complex Abb439, Abb242, Abb64, Abb243, Abb461, Abb134
	double complex Abb360, Abb906, Abb590, Abb204, Abb60, Abb350
	double complex Abb87, Abb88, Abb440, Abb246, Abb65, Abb247
	double complex Abb462, Abb135, Abb361, Abb907, Abb591, Abb205
	double complex Abb61, Abb353, Abb89, Abb202, Abb250, Abb82
	double complex Abb172, Abb75, Abb121, Abb278, Abb46, Abb122
	double complex Abb105, Abb301, Abb362, Abb718, Abb136, Abb173
	double complex Abb76, Abb1053, Abb1054, Abb184, Abb327, Abb137
	double complex Abb158, Abb302, Abb303, Abb328, Abb159, Abb139
	double complex Abb383, Abb160, Abb263, Abb329, Abb161, Abb1065
	double complex Abb240, Abb241, Abb407, Abb28, Abb630, Abb102
	double complex Abb398, Abb103, Abb48, Abb520, Abb349, Abb244
	double complex Abb245, Abb210, Abb29, Abb211, Abb104, Abb212
	double complex Abb38, Abb49, Abb351, Abb352, Abb248, Abb249
	double complex Abb213, Abb30, Abb214, Abb403, Abb215, Abb39
	double complex Abb50, Abb354, Abb408, Abb31, Abb631, Abb106
	double complex Abb399, Abb107, Abb51, Abb521, Abb216, Abb32
	double complex Abb217, Abb108, Abb355, Abb40, Abb52, Abb356
	double complex Abb218, Abb33, Abb219, Abb404, Abb400, Abb41
	double complex Abb53, Abb357, Abb1066, Abb1077, Abb1078
	double complex Abb522, Abb109, Abb730, Abb174, Abb110, Abb175
	double complex Abb1070, Abb138, Abb523, Abb416, Abb176, Abb487
	double complex Abb177, Abb111, Abb42, Abb67, Abb417, Abb418
	double complex Abb178, Abb488, Abb511, Abb112, Abb43, Abb68
	double complex Abb419, Abb56, Abb113, Abb840, Abb179, Abb57
	double complex Abb114, Abb841, Abb180, Abb632, Abb181, Abb862
	double complex Abb182, Abb653, Abb441, Abb251, Abb654, Abb420
	double complex Abb71, Abb655, Abb421, Abb72, Opt1658, Opt1659
	double complex Opt1660, Opt1661, Opt1662, Opt1663, Opt1664
	double complex Opt1665, Opt1666, Opt1667, Opt1668, Opt1669
	double complex Opt1670, Opt1671, Opt1672, Opt1673, Opt1674
	double complex Opt1675, Opt1676, Opt1677, Opt1678, Opt1679
	double complex Opt1680, Opt1681, Opt1682, Opt1683, Opt1684
	double complex Opt1685, Opt1686, Opt1687, Opt1688, Opt1689
	double complex Opt1690, Opt1691, Opt1692, Opt1693, Opt1694
	double complex Opt1695, Opt1696, Opt1697, Opt1698, Opt1699
	double complex Opt1700, Opt1701, Opt1702, Opt1703, Opt1704
	double complex Opt1705, Opt1706, Opt1707, Opt1708, Opt1709
	double complex Opt1710, Opt1711, Opt1712, Opt1713, Opt1714
	double complex Opt1715, Opt1716, Opt1717, Opt1718, Opt1719
	double complex Opt1720, Opt1721, Opt1722, Opt1723, Opt1724
	double complex Opt1725, Opt1726, Opt1727, Opt1728, Opt1729
	double complex Opt1730, Opt1731, Opt1732, Opt1733, Opt1734
	double complex Opt1735, Opt1736, Opt1737, Opt1738, Opt1739
	double complex Opt1740, Opt1741, Opt1742, Opt1743, Opt1744
	double complex Opt1745, Opt1746, Opt1747, Opt1748, Opt1749
	double complex Opt1750, Opt1751, Opt1752, Opt1753, Opt1754
	double complex Opt1755, Opt1756, Opt1757, Opt1758, Opt1759
	double complex Opt1760, Opt1761, Opt1762, Opt1763, Opt1764
	double complex Opt1765, Opt1766, Opt1767, Opt1768, Opt1769
	double complex Opt1770, Opt1771, Opt1772, Opt1773, Opt1774
	double complex Opt1775, Opt1776, Opt1777, Opt1778, Opt1779
	double complex Opt1780, Opt1781, Opt1782, Opt1783, Opt1784
	double complex Opt1785, Opt1786, Opt1787, Opt1788, Opt1789
	double complex Opt1790, Opt1791, Opt1792, Opt1793, Opt1794
	double complex Opt1795, Opt1796, Opt1797, Opt1798, AbbSum1067
	double complex AbbSum429, AbbSum548, AbbSum860, AbbSum859
	double complex AbbSum856, AbbSum756, AbbSum758, AbbSum852
	double complex AbbSum782, AbbSum854, AbbSum1082, AbbSum333
	double complex AbbSum367, AbbSum587, AbbSum599, AbbSum392
	double complex AbbSum321, AbbSum902, AbbSum850, AbbSum871
	double complex AbbSum873, AbbSum1073, AbbSum1068, AbbSum537
	double complex AbbSum47, AbbSum826, AbbSum450, AbbSum868
	double complex AbbSum546, AbbSum853, AbbSum66, AbbSum508
	double complex AbbSum574, AbbSum497, AbbSum564, AbbSum680
	double complex AbbSum649, AbbSum1030, AbbSum891, AbbSum19
	double complex AbbSum377, AbbSum376, AbbSum547, AbbSum757
	double complex AbbSum543, AbbSum880, AbbSum963, AbbSum579
	double complex AbbSum10, AbbSum340, AbbSum288, AbbSum986
	double complex AbbSum888, AbbSum271, AbbSum970, AbbSum889
	double complex AbbSum318, AbbSum378, AbbSum389, AbbSum390
	double complex AbbSum923, AbbSum372, AbbSum933, AbbSum272
	double complex AbbSum967, AbbSum628, AbbSum716, AbbSum797
	double complex AbbSum789, AbbSum1062, AbbSum191, AbbSum940
	double complex AbbSum869, AbbSum577, AbbSum583, AbbSum1083
	double complex AbbSum538, AbbSum471, AbbSum867, AbbSum225
	double complex AbbSum774, AbbSum652, AbbSum576, AbbSum679
	double complex AbbSum629, AbbSum331, AbbSum1023, AbbSum17
	double complex AbbSum958, AbbSum764, AbbSum763, AbbSum760
	double complex AbbSum551, AbbSum545, AbbSum542, AbbSum928
	double complex AbbSum839, AbbSum518, AbbSum874, AbbSum1001
	double complex AbbSum1002, AbbSum951, AbbSum972, AbbSum365
	double complex AbbSum966, AbbSum596, AbbSum391, AbbSum332
	double complex AbbSum1027, AbbSum20, AbbSum960, AbbSum616
	double complex AbbSum617, AbbSum309, AbbSum310, AbbSum338
	double complex AbbSum339, AbbSum956, AbbSum820, AbbSum366
	double complex AbbSum553, AbbSum1028, AbbSum480, AbbSum146
	double complex AbbSum498, AbbSum1024, AbbSum186, AbbSum311
	double complex AbbSum196, AbbSum458, AbbSum953, AbbSum954
	double complex AbbSum1032, AbbSum1031, AbbSum287, AbbSum597
	double complex AbbSum598, AbbSum312, AbbSum313, AbbSum341
	double complex AbbSum342, AbbSum984, AbbSum282, AbbSum985
	double complex AbbSum265, AbbSum974, AbbSum266, AbbSum91
	double complex AbbSum947, AbbSum989, AbbSum289, AbbSum226
	double complex AbbSum988, AbbSum990, AbbSum1034, AbbSum991
	double complex AbbSum267, AbbSum116, AbbSum997, AbbSum281
	double complex AbbSum949, AbbSum717, AbbSum724, AbbSum872
	double complex AbbSum1093, AbbSum1092, AbbSum544, AbbSum712
	double complex AbbSum206, AbbSum406, AbbSum411, AbbSum207
	double complex AbbSum977, AbbSum550, AbbSum832, AbbSum661
	double complex AbbSum582, AbbSum430, AbbSum895, AbbSum894
	double complex AbbSum671, AbbSum831, AbbSum641, AbbSum638
	double complex AbbSum759, AbbSum755, AbbSum857, AbbSum858
	double complex AbbSum703, AbbSum647, AbbSum796, AbbSum482
	double complex AbbSum83, AbbSum1081, AbbSum644, AbbSum838
	double complex AbbSum517, AbbSum375, AbbSum999, AbbSum962
	double complex AbbSum1000, AbbSum622, AbbSum396, AbbSum1026
	double complex AbbSum1029, AbbSum18, AbbSum584, AbbSum1097
	double complex AbbSum913, AbbSum983, AbbSum995, AbbSum1020
	double complex AbbSum606, AbbSum981, AbbSum610, AbbSum608
	double complex AbbSum911, AbbSum386, AbbSum624, AbbSum397
	double complex AbbSum996, AbbSum1018, AbbSum387, AbbSum1022
	double complex AbbSum969, AbbSum611, AbbSum388, AbbSum1042
	double complex AbbSum280, AbbSum870, AbbSum723, AbbSum721
	double complex AbbSum224, AbbSum762, AbbSum761, AbbSum685
	double complex AbbSum675, AbbSum890, AbbSum529, AbbSum533
	double complex AbbSum320, AbbSum528, AbbSum881, AbbSum837
	double complex AbbSum834, AbbSum851, AbbSum855, AbbSum900
	double complex AbbSum768, AbbSum556, AbbSum514, AbbSum515
	double complex AbbSum781, AbbSum846, AbbSum843, AbbSum727
	double complex AbbSum414, AbbSum875, AbbSum34, AbbSum513
	double complex AbbSum44, AbbSum825, AbbSum711, AbbSum835
	double complex AbbSum54, AbbSum801, AbbSum802, AbbSum793
	double complex AbbSum794, AbbSum636, AbbSum669, AbbSum581
	double complex AbbSum575, AbbSum884, AbbSum634, AbbSum192
	double complex AbbSum702, AbbSum815, AbbSum435, AbbSum433
	double complex AbbSum650, AbbSum494, AbbSum1090, AbbSum688
	double complex AbbSum728, AbbSum700, AbbSum519, AbbSum733
	double complex AbbSum745, AbbSum845, AbbSum864, AbbSum701
	double complex AbbSum373, AbbSum374, AbbSum904, AbbSum908
	double complex AbbSum1071, AbbSum516, AbbSum836, AbbSum779
	double complex AbbSum780, AbbSum787, AbbSum788, AbbSum253
	double complex AbbSum883, AbbSum227, AbbSum273, AbbSum720
	double complex AbbSum726, AbbSum939, AbbSum678, AbbSum222
	double complex AbbSum879, AbbSum527, AbbSum736, AbbSum526
	double complex AbbSum729, AbbSum861, AbbSum722, AbbSum905
	double complex AbbSum752, AbbSum1011, AbbSum509, AbbSum627
	double complex AbbSum829, AbbSum405, AbbSum848, AbbSum828
	double complex AbbSum507, AbbSum58, AbbSum63, AbbSum751
	double complex AbbSum78, AbbSum69, AbbSum73, AbbSum79
	double complex AbbSum541, AbbSum540, AbbSum432, AbbSum470
	double complex AbbSum163, AbbSum561, AbbSum813, AbbSum605
	double complex AbbSum208, AbbSum978, AbbSum777, AbbSum778
	double complex AbbSum785, AbbSum786, AbbSum1080, AbbSum428
	double complex AbbSum415, AbbSum424, AbbSum766, AbbSum750
	double complex AbbSum738, AbbSum646, AbbSum910, AbbSum909
	double complex AbbSum209, AbbSum753, AbbSum847, AbbSum824
	double complex AbbSum635, AbbSum62, AbbSum676, AbbSum677
	double complex AbbSum1105, AbbSum1010, AbbSum814, AbbSum898
	double complex AbbSum886, AbbSum887, AbbSum899, AbbSum294
	double complex AbbSum221, AbbSum844, AbbSum799, AbbSum791
	double complex AbbSum800, AbbSum792, AbbSum737, AbbSum732
	double complex AbbSum735, AbbSum739, AbbSum744, AbbSum90
	double complex AbbSum1085, AbbSum573, AbbSum686, AbbSum687
	double complex AbbSum1111, AbbSum1103, AbbSum1084, AbbSum563
	double complex AbbSum535, AbbSum536, AbbSum930, AbbSum865
	double complex AbbSum749, AbbSum866, AbbSum603, AbbSum946
	double complex AbbSum943, AbbSum1094, AbbSum1112, AbbSum80
	double complex AbbSum77, AbbSum944, AbbSum531, AbbSum190
	double complex AbbSum532, AbbSum1102, AbbSum1089, AbbSum842
	double complex AbbSum772, AbbSum427, AbbSum423, AbbSum460
	double complex AbbSum426, AbbSum773, AbbSum769, AbbSum743
	double complex AbbSum748, AbbSum812, AbbSum804, AbbSum449
	double complex AbbSum510, AbbSum401, AbbSum626, AbbSum539
	double complex AbbSum827, AbbSum512, AbbSum1113, AbbSum506
	double complex AbbSum1079, AbbSum290, AbbSum643, AbbSum640
	double complex AbbSum496, AbbSum929, AbbSum742, AbbSum697
	double complex AbbSum698, AbbSum696, AbbSum466, AbbSum708
	double complex AbbSum709, AbbSum445, AbbSum410, AbbSum413
	double complex AbbSum917, AbbSum604, AbbSum525, AbbSum942
	double complex AbbSum668, AbbSum667, AbbSum833, AbbSum268
	double complex AbbSum319, AbbSum188, AbbSum931, AbbSum1076
	double complex AbbSum1110, AbbSum1061, AbbSum863, AbbSum707
	double complex AbbSum370, AbbSum371, AbbSum662, AbbSum124
	double complex AbbSum437, AbbSum448, AbbSum849, AbbSum1072
	double complex AbbSum1106, AbbSum941, AbbSum572, AbbSum660
	double complex AbbSum659, AbbSum1091, AbbSum562, AbbSum710
	double complex AbbSum932, AbbSum1055, AbbSum765, AbbSum469
	double complex AbbSum741, AbbSum476, AbbSum770, AbbSum455
	double complex AbbSum142, AbbSum938, AbbSum369, AbbSum945
	double complex AbbSum625, AbbSum402, AbbSum976, AbbSum937
	double complex AbbSum747, AbbSum925, AbbSum220, AbbSum524
	double complex AbbSum830, AbbSum343, AbbSum314, AbbSum495
	double complex AbbSum795, AbbSum803, AbbSum1009, AbbSum699
	double complex AbbSum936, AbbSum1012, AbbSum1109, AbbSum915
	double complex AbbSum198, AbbSum916, AbbSum926, AbbSum771
	double complex AbbSum896, AbbSum648, AbbSum1095, AbbSum980
	double complex AbbSum975, AbbSum434, AbbSum1101, AbbSum784
	double complex AbbSum203, AbbSum223, AbbSum364, AbbSum979
	double complex AbbSum811, AbbSum505, AbbSum446, AbbSum447
	double complex AbbSum150, AbbSum456, AbbSum457, AbbSum790
	double complex AbbSum798, AbbSum412, AbbSum783, AbbSum775
	double complex AbbSum642, AbbSum269, AbbSum270, AbbSum291
	double complex AbbSum292, AbbSum776, AbbSum1060, AbbSum1088
	double complex AbbSum363, AbbSum385, AbbSum713, AbbSum715
	double complex AbbSum714, AbbSum645, AbbSum431, AbbSum569
	double complex AbbSum502, AbbSum558, AbbSum490, AbbSum1075
	double complex AbbSum595, AbbSum914, AbbSum821, AbbSum822
	double complex AbbSum823, AbbSum147, AbbSum123, AbbSum684
	double complex AbbSum493, AbbSum674, AbbSum593, AbbSum393
	double complex AbbSum767, AbbSum725, AbbSum534, AbbSum734
	double complex AbbSum885, AbbSum193, AbbSum162, AbbSum615
	double complex AbbSum809, AbbSum810, AbbSum395, AbbSum1004
	double complex AbbSum613, AbbSum594, AbbSum409, AbbSum882
	double complex AbbSum639, AbbSum897, AbbSum1098, AbbSum1108
	double complex AbbSum492, AbbSum912, AbbSum1005, AbbSum683
	double complex AbbSum927, AbbSum151, AbbSum143, AbbSum368
	double complex AbbSum673, AbbSum609, AbbSum570, AbbSum559
	double complex AbbSum503, AbbSum491, AbbSum719, AbbSum731
	double complex AbbSum478, AbbSum468, AbbSum1086, AbbSum1074
	double complex AbbSum464, AbbSum465, AbbSum924, AbbSum152
	double complex AbbSum666, AbbSum922, AbbSum658, AbbSum754
	double complex AbbSum306, AbbSum307, AbbSum335, AbbSum336
	double complex AbbSum284, AbbSum500, AbbSum185, AbbSum187
	double complex AbbSum479, AbbSum504, AbbSum552, AbbSum566
	double complex AbbSum555, AbbSum567, AbbSum554, AbbSum565
	double complex AbbSum474, AbbSum475, AbbSum681, AbbSum670
	double complex AbbSum614, AbbSum530, AbbSum285, AbbSum443
	double complex AbbSum453, AbbSum971, AbbSum477, AbbSum467
	double complex AbbSum451, AbbSum436, AbbSum197, AbbSum144
	double complex AbbSum199, AbbSum560, AbbSum623, AbbSum279
	double complex AbbSum571, AbbSum973, AbbSum259, AbbSum1087
	double complex AbbSum293, AbbSum189, AbbSum619, AbbSum444
	double complex AbbSum601, AbbSum620, AbbSum665, AbbSum934
	double complex AbbSum657, AbbSum602, AbbSum260, AbbSum919
	double complex AbbSum316, AbbSum317, AbbSum1114, AbbSum481
	double complex AbbSum921, AbbSum454, AbbSum618, AbbSum1014
	double complex AbbSum1107, AbbSum344, AbbSum345, AbbSum1013
	double complex AbbSum264, AbbSum935, AbbSum195, AbbSum706
	double complex AbbSum694, AbbSum1008, AbbSum499, AbbSum286
	double complex AbbSum578, AbbSum472, AbbSum600, AbbSum459
	double complex AbbSum141, AbbSum140, AbbSum145, AbbSum425
	double complex AbbSum637, AbbSum746, AbbSum1006, AbbSum1003
	double complex AbbSum1007, AbbSum695, AbbSum337, AbbSum580
	double complex AbbSum705, AbbSum115, AbbSum1096, AbbSum149
	double complex AbbSum148, AbbSum308, AbbSum672, AbbSum682
	double complex AbbSum663, AbbSum422, AbbSum633, AbbSum920
	double complex AbbSum1036, AbbSum918, AbbSum808, AbbSum901
	double complex AbbSum651, AbbSum664, AbbSum740, AbbSum903
	double complex AbbSum1037, AbbSum817, AbbSum807, AbbSum819
	double complex AbbSum704, AbbSum586, AbbSum1035, AbbSum964
	double complex AbbSum693, AbbSum194, AbbSum568, AbbSum557
	double complex AbbSum892, AbbSum806, AbbSum588, AbbSum961
	double complex AbbSum183, AbbSum893, AbbSum965, AbbSum968
	double complex AbbSum818, AbbSum452, AbbSum442, AbbSum656
	double complex AbbSum330, AbbSum358, AbbSum1033, AbbSum346
	double complex AbbSum394, AbbSum473, AbbSum384, AbbSum463
	double complex AbbSum816, AbbSum805, AbbSum955, AbbSum952
	double complex AbbSum957, AbbSum950, AbbSum959, AbbSum1039
	double complex AbbSum948, AbbSum304, AbbSum334, AbbSum1016
	double complex AbbSum992, AbbSum1038, AbbSum993, AbbSum998
	double complex AbbSum1015, AbbSum994, AbbSum489, AbbSum501
	double complex AbbSum621, AbbSum1017, AbbSum987, AbbSum607
	double complex AbbSum982, AbbSum1019, AbbSum252, AbbSum592
	double complex AbbSum283, AbbSum612, AbbSum1025, AbbSum1021
	double complex Opt1799, Opt1800, Opt1801, Opt1802, Opt1803
	double complex Opt1804, Opt1805, Opt1806, Opt1807, Sub1161
	double complex Sub1158, Sub1124, Sub1120, Sub1646, Sub1637
	double complex Sub1650, Sub1642, Sub1654, Sub1603, Sub1604
	double complex Sub1598, Sub1597, Sub1501, Sub1503, Sub1488
	double complex Sub1486, Sub1487, Sub1479, Sub1480, Sub1481
	double complex Sub1449, Sub1451, Sub1447, Sub1415, Sub1411
	double complex Sub1375, Sub1349, Sub1345, Sub1357, Sub1353
	double complex Sub1335, Sub1316, Sub1252, Sub1256, Sub1254
	double complex Sub1239, Sub1237, Sub1200, Sub1198, Sub1205
	double complex Sub1202, Sub1189, Sub1186, Sub1390, Sub1532
	double complex Sub1209, Sub1127, Sub1123, Sub1134, Sub1131
	double complex Sub1142, Sub1138, Sub1216, Sub1212, Sub1223
	double complex Sub1220, Sub1232, Sub1228, Sub1286, Sub1284
	double complex Sub1293, Sub1291, Sub1301, Sub1298, Sub1352
	double complex Sub1348, Sub1360, Sub1356, Sub1369, Sub1365
	double complex Sub1410, Sub1407, Sub1418, Sub1414, Sub1426
	double complex Sub1422, Sub1453, Sub1450, Sub1457, Sub1455
	double complex Sub1470, Sub1464, Sub1492, Sub1485, Sub1523
	double complex Sub1519, Sub1531, Sub1527, Sub1540, Sub1536
	double complex Sub1567, Sub1563, Sub1578, Sub1573, Sub1588
	double complex Sub1584, Sub1596, Sub1592, Sub1608, Sub1602
	double complex Sub1614, Sub1611, Sub1139, Sub1135, Sub1645
	double complex Sub1634, Sub1649, Sub1648, Sub1593, Sub1589
	double complex Sub1575, Sub1574, Sub1570, Sub1568, Sub1544
	double complex Sub1541, Sub1546, Sub1553, Sub1551, Sub1520
	double complex Sub1516, Sub1528, Sub1524, Sub1510, Sub1471
	double complex Sub1475, Sub1489, Sub1482, Sub1617, Sub1465
	double complex Sub1458, Sub1430, Sub1427, Sub1437, Sub1434
	double complex Sub1442, Sub1439, Sub1423, Sub1419, Sub1621
	double complex Sub1495, Sub1392, Sub1399, Sub1377, Sub1493
	double complex Sub1619, Sub1331, Sub1340, Sub1325, Sub1306
	double complex Sub1309, Sub1281, Sub1295, Sub1299, Sub1294
	double complex Sub1268, Sub1272, Sub1270, Sub1276, Sub1274
	double complex Sub1250, Sub1260, Sub1258, Sub1235, Sub1243
	double complex Sub1213, Sub1229, Sub1226, Sub1179, Sub1176
	double complex Sub1559, Sub1361, Sub1440, Sub1579, Sub1297
	double complex Sub1387, Sub1428, Sub1472, Sub1476, Sub1305
	double complex Sub1115, Sub1116, Sub1628, Sub1629, Sub1117
	double complex Sub1119, Sub1630, Sub1631, Sub1632, Sub1633
	double complex Sub1143, Sub1144, Sub1145, Sub1146, Sub1147
	double complex Sub1148, Sub1635, Sub1636, Sub1151, Sub1153
	double complex Sub1155, Sub1157, Sub1160, Sub1163, Sub1164
	double complex Sub1165, Sub1166, Sub1167, Sub1168, Sub1169
	double complex Sub1638, Sub1639, Sub1170, Sub1171, Sub1172
	double complex Sub1173, Sub1174, Sub1175, Sub1178, Sub1181
	double complex Sub1183, Sub1185, Sub1188, Sub1191, Sub1192
	double complex Sub1193, Sub1194, Sub1195, Sub1196, Sub1197
	double complex Sub1234, Sub1236, Sub1238, Sub1240, Sub1242
	double complex Sub1244, Sub1251, Sub1253, Sub1255, Sub1257
	double complex Sub1259, Sub1261, Sub1267, Sub1269, Sub1271
	double complex Sub1273, Sub1275, Sub1277, Sub1303, Sub1304
	double complex Sub1307, Sub1308, Sub1310, Sub1311, Sub1317
	double complex Sub1319, Sub1321, Sub1322, Sub1324, Sub1326
	double complex Sub1332, Sub1334, Sub1336, Sub1337, Sub1339
	double complex Sub1341, Sub1370, Sub1372, Sub1374, Sub1376
	double complex Sub1379, Sub1381, Sub1388, Sub1391, Sub1394
	double complex Sub1396, Sub1398, Sub1401, Sub1429, Sub1432
	double complex Sub1435, Sub1438, Sub1441, Sub1443, Sub1473
	double complex Sub1474, Sub1477, Sub1478, Sub1494, Sub1496
	double complex Sub1500, Sub1502, Sub1505, Sub1507, Sub1509
	double complex Sub1512, Sub1542, Sub1545, Sub1548, Sub1550
	double complex Sub1552, Sub1554, Sub1616, Sub1618, Sub1620
	double complex Sub1622, Sub1152, Sub1150, Sub1156, Sub1154
	double complex Sub1644, Sub1641, Sub1653, Sub1605, Sub1599
	double complex Sub1560, Sub1585, Sub1580, Sub1537, Sub1533
	double complex Sub1506, Sub1466, Sub1459, Sub1615, Sub1389
	double complex Sub1386, Sub1371, Sub1373, Sub1380, Sub1362
	double complex Sub1318, Sub1320, Sub1323, Sub1288, Sub1266
	double complex Sub1241, Sub1208, Sub1207, Sub1224, Sub1128
	double complex Sub1287, Sub1126, Sub1504, Sub1431, Sub1122
	double complex Sub1225, Sub1137, Sub1141, Sub1215, Sub1231
	double complex Sub1378, Sub1133, Sub1130, Sub1564, Sub1549
	double complex Sub1395, Sub1366, Sub1333, Sub1338, Sub1302
	double complex Sub1211, Sub1121, Sub1227, Sub1136, Sub1140
	double complex Sub1214, Sub1125, Sub1433, Sub1547, Sub1393
	double complex Sub1180, Sub1177, Sub1296, Sub1300, Sub1149
	double complex Sub1217, Sub1511, Sub1201, Sub1132, Sub1129
	double complex Sub1448, Sub1452, Sub1467, Sub1461, Sub1210
	double complex Sub1184, Sub1182, Sub1118, Sub1230, Sub1199
	double complex Sub1436, Sub1558, Sub1400, Sub1460, Sub1247
	double complex Sub1248, Sub1249, Sub1263, Sub1265, Sub1278
	double complex Sub1280, Sub1313, Sub1314, Sub1315, Sub1328
	double complex Sub1329, Sub1330, Sub1342, Sub1343, Sub1344
	double complex Sub1383, Sub1384, Sub1385, Sub1402, Sub1403
	double complex Sub1404, Sub1444, Sub1445, Sub1446, Sub1497
	double complex Sub1499, Sub1513, Sub1515, Sub1555, Sub1557
	double complex Sub1623, Sub1624, Sub1222, Sub1219, Sub1543
	double complex Sub1162, Sub1159, Sub1607, Sub1601, Sub1206
	double complex Sub1203, Sub1569, Sub1613, Sub1610, Sub1454
	double complex Sub1456, Sub1221, Sub1218, Sub1600, Sub1606
	double complex Sub1187, Sub1491, Sub1484, Sub1290, Sub1190
	double complex Sub1627, Sub1204, Sub1652, Sub1612, Sub1590
	double complex Sub1594, Sub1539, Sub1535, Sub1346, Sub1354
	double complex Sub1517, Sub1350, Sub1358, Sub1521, Sub1351
	double complex Sub1347, Sub1359, Sub1355, Sub1526, Sub1530
	double complex Sub1409, Sub1406, Sub1640, Sub1647, Sub1643
	double complex Sub1651, Sub1655, Sub1581, Sub1508, Sub1397
	double complex Sub1609, Sub1525, Sub1490, Sub1405, Sub1529
	double complex Sub1408, Sub1522, Sub1518, Sub1283, Sub1417
	double complex Sub1413, Sub1538, Sub1412, Sub1416, Sub1595
	double complex Sub1591, Sub1425, Sub1421, Sub1368, Sub1364
	double complex Sub1289, Sub1292, Sub1245, Sub1246, Sub1264
	double complex Sub1279, Sub1312, Sub1498, Sub1327, Sub1514
	double complex Sub1382, Sub1556, Sub1625, Sub1483, Sub1534
	double complex Sub1424, Sub1367, Sub1566, Sub1562, Sub1420
	double complex Sub1363, Sub1282, Sub1285, Sub1577, Sub1572
	double complex Sub1469, Sub1463, Sub1565, Sub1561, Sub1587
	double complex Sub1583, Sub1233, Sub1262, Sub1576, Sub1571
	double complex Sub1468, Sub1462, Sub1582, Sub1586, Sub1626
	common /abbrev/ F11, F6, F13, F21, F35, F14, F7, F36, F22
	common /abbrev/ F200, F4, F5, F127, F255, F125, F126, F359
	common /abbrev/ F1040, F274, F96, F117, F1043, F1044, F322
	common /abbrev/ F1045, F1046, F1057, F154, F254, F153, F589
	common /abbrev/ F164, F348, F1099, F1056, Pair12, Pair37
	common /abbrev/ Pair23, Pair27, Pair70, Pair24, Pair25, Pair26
	common /abbrev/ Pair55, Eps165, Eps94, Eps95, Eps1047, Eps228
	common /abbrev/ Eps229, Eps1048, Eps92, Eps93, Eps1063, Eps347
	common /abbrev/ Eps483, Eps484, Eps1064, Abb15, Abb155, Abb275
	common /abbrev/ Abb128, Abb256, Abb257, Abb156, Abb258, Abb276
	common /abbrev/ Abb305, Abb1041, Abb1058, Abb1100, Abb8
	common /abbrev/ Abb381, Abb129, Abb9, Abb323, Abb689, Abb690
	common /abbrev/ Abb230, Abb231, Abb232, Abb233, Abb234, Abb97
	common /abbrev/ Abb98, Abb485, Abb486, Abb295, Abb235, Abb236
	common /abbrev/ Abb166, Abb167, Abb876, Abb691, Abb692, Abb877
	common /abbrev/ Abb878, Abb168, Abb296, Abb297, Abb169, Abb170
	common /abbrev/ Abb1069, Abb1049, Abb1050, Abb315, Abb379
	common /abbrev/ Abb380, Abb261, Abb262, Abb1104, Abb99, Abb100
	common /abbrev/ Abb298, Abb299, Abb324, Abb130, Abb325, Abb131
	common /abbrev/ Abb118, Abb157, Abb1059, Abb16, Abb326, Abb201
	common /abbrev/ Abb237, Abb81, Abb171, Abb74, Abb119, Abb277
	common /abbrev/ Abb45, Abb120, Abb101, Abb300, Abb84, Abb438
	common /abbrev/ Abb238, Abb132, Abb239, Abb549, Abb1051
	common /abbrev/ Abb1052, Abb133, Abb585, Abb382, Abb59, Abb85
	common /abbrev/ Abb86, Abb439, Abb242, Abb64, Abb243, Abb461
	common /abbrev/ Abb134, Abb360, Abb906, Abb590, Abb204, Abb60
	common /abbrev/ Abb350, Abb87, Abb88, Abb440, Abb246, Abb65
	common /abbrev/ Abb247, Abb462, Abb135, Abb361, Abb907, Abb591
	common /abbrev/ Abb205, Abb61, Abb353, Abb89, Abb202, Abb250
	common /abbrev/ Abb82, Abb172, Abb75, Abb121, Abb278, Abb46
	common /abbrev/ Abb122, Abb105, Abb301, Abb362, Abb718, Abb136
	common /abbrev/ Abb173, Abb76, Abb1053, Abb1054, Abb184
	common /abbrev/ Abb327, Abb137, Abb158, Abb302, Abb303, Abb328
	common /abbrev/ Abb159, Abb139, Abb383, Abb160, Abb263, Abb329
	common /abbrev/ Abb161, Abb1065, Abb240, Abb241, Abb407, Abb28
	common /abbrev/ Abb630, Abb102, Abb398, Abb103, Abb48, Abb520
	common /abbrev/ Abb349, Abb244, Abb245, Abb210, Abb29, Abb211
	common /abbrev/ Abb104, Abb212, Abb38, Abb49, Abb351, Abb352
	common /abbrev/ Abb248, Abb249, Abb213, Abb30, Abb214, Abb403
	common /abbrev/ Abb215, Abb39, Abb50, Abb354, Abb408, Abb31
	common /abbrev/ Abb631, Abb106, Abb399, Abb107, Abb51, Abb521
	common /abbrev/ Abb216, Abb32, Abb217, Abb108, Abb355, Abb40
	common /abbrev/ Abb52, Abb356, Abb218, Abb33, Abb219, Abb404
	common /abbrev/ Abb400, Abb41, Abb53, Abb357, Abb1066, Abb1077
	common /abbrev/ Abb1078, Abb522, Abb109, Abb730, Abb174
	common /abbrev/ Abb110, Abb175, Abb1070, Abb138, Abb523
	common /abbrev/ Abb416, Abb176, Abb487, Abb177, Abb111, Abb42
	common /abbrev/ Abb67, Abb417, Abb418, Abb178, Abb488, Abb511
	common /abbrev/ Abb112, Abb43, Abb68, Abb419, Abb56, Abb113
	common /abbrev/ Abb840, Abb179, Abb57, Abb114, Abb841, Abb180
	common /abbrev/ Abb632, Abb181, Abb862, Abb182, Abb653, Abb441
	common /abbrev/ Abb251, Abb654, Abb420, Abb71, Abb655, Abb421
	common /abbrev/ Abb72, Opt1658, Opt1659, Opt1660, Opt1661
	common /abbrev/ Opt1662, Opt1663, Opt1664, Opt1665, Opt1666
	common /abbrev/ Opt1667, Opt1668, Opt1669, Opt1670, Opt1671
	common /abbrev/ Opt1672, Opt1673, Opt1674, Opt1675, Opt1676
	common /abbrev/ Opt1677, Opt1678, Opt1679, Opt1680, Opt1681
	common /abbrev/ Opt1682, Opt1683, Opt1684, Opt1685, Opt1686
	common /abbrev/ Opt1687, Opt1688, Opt1689, Opt1690, Opt1691
	common /abbrev/ Opt1692, Opt1693, Opt1694, Opt1695, Opt1696
	common /abbrev/ Opt1697, Opt1698, Opt1699, Opt1700, Opt1701
	common /abbrev/ Opt1702, Opt1703, Opt1704, Opt1705, Opt1706
	common /abbrev/ Opt1707, Opt1708, Opt1709, Opt1710, Opt1711
	common /abbrev/ Opt1712, Opt1713, Opt1714, Opt1715, Opt1716
	common /abbrev/ Opt1717, Opt1718, Opt1719, Opt1720, Opt1721
	common /abbrev/ Opt1722, Opt1723, Opt1724, Opt1725, Opt1726
	common /abbrev/ Opt1727, Opt1728, Opt1729, Opt1730, Opt1731
	common /abbrev/ Opt1732, Opt1733, Opt1734, Opt1735, Opt1736
	common /abbrev/ Opt1737, Opt1738, Opt1739, Opt1740, Opt1741
	common /abbrev/ Opt1742, Opt1743, Opt1744, Opt1745, Opt1746
	common /abbrev/ Opt1747, Opt1748, Opt1749, Opt1750, Opt1751
	common /abbrev/ Opt1752, Opt1753, Opt1754, Opt1755, Opt1756
	common /abbrev/ Opt1757, Opt1758, Opt1759, Opt1760, Opt1761
	common /abbrev/ Opt1762, Opt1763, Opt1764, Opt1765, Opt1766
	common /abbrev/ Opt1767, Opt1768, Opt1769, Opt1770, Opt1771
	common /abbrev/ Opt1772, Opt1773, Opt1774, Opt1775, Opt1776
	common /abbrev/ Opt1777, Opt1778, Opt1779, Opt1780, Opt1781
	common /abbrev/ Opt1782, Opt1783, Opt1784, Opt1785, Opt1786
	common /abbrev/ Opt1787, Opt1788, Opt1789, Opt1790, Opt1791
	common /abbrev/ Opt1792, Opt1793, Opt1794, Opt1795, Opt1796
	common /abbrev/ Opt1797, Opt1798, AbbSum1067, AbbSum429
	common /abbrev/ AbbSum548, AbbSum860, AbbSum859, AbbSum856
	common /abbrev/ AbbSum756, AbbSum758, AbbSum852, AbbSum782
	common /abbrev/ AbbSum854, AbbSum1082, AbbSum333, AbbSum367
	common /abbrev/ AbbSum587, AbbSum599, AbbSum392, AbbSum321
	common /abbrev/ AbbSum902, AbbSum850, AbbSum871, AbbSum873
	common /abbrev/ AbbSum1073, AbbSum1068, AbbSum537, AbbSum47
	common /abbrev/ AbbSum826, AbbSum450, AbbSum868, AbbSum546
	common /abbrev/ AbbSum853, AbbSum66, AbbSum508, AbbSum574
	common /abbrev/ AbbSum497, AbbSum564, AbbSum680, AbbSum649
	common /abbrev/ AbbSum1030, AbbSum891, AbbSum19, AbbSum377
	common /abbrev/ AbbSum376, AbbSum547, AbbSum757, AbbSum543
	common /abbrev/ AbbSum880, AbbSum963, AbbSum579, AbbSum10
	common /abbrev/ AbbSum340, AbbSum288, AbbSum986, AbbSum888
	common /abbrev/ AbbSum271, AbbSum970, AbbSum889, AbbSum318
	common /abbrev/ AbbSum378, AbbSum389, AbbSum390, AbbSum923
	common /abbrev/ AbbSum372, AbbSum933, AbbSum272, AbbSum967
	common /abbrev/ AbbSum628, AbbSum716, AbbSum797, AbbSum789
	common /abbrev/ AbbSum1062, AbbSum191, AbbSum940, AbbSum869
	common /abbrev/ AbbSum577, AbbSum583, AbbSum1083, AbbSum538
	common /abbrev/ AbbSum471, AbbSum867, AbbSum225, AbbSum774
	common /abbrev/ AbbSum652, AbbSum576, AbbSum679, AbbSum629
	common /abbrev/ AbbSum331, AbbSum1023, AbbSum17, AbbSum958
	common /abbrev/ AbbSum764, AbbSum763, AbbSum760, AbbSum551
	common /abbrev/ AbbSum545, AbbSum542, AbbSum928, AbbSum839
	common /abbrev/ AbbSum518, AbbSum874, AbbSum1001, AbbSum1002
	common /abbrev/ AbbSum951, AbbSum972, AbbSum365, AbbSum966
	common /abbrev/ AbbSum596, AbbSum391, AbbSum332, AbbSum1027
	common /abbrev/ AbbSum20, AbbSum960, AbbSum616, AbbSum617
	common /abbrev/ AbbSum309, AbbSum310, AbbSum338, AbbSum339
	common /abbrev/ AbbSum956, AbbSum820, AbbSum366, AbbSum553
	common /abbrev/ AbbSum1028, AbbSum480, AbbSum146, AbbSum498
	common /abbrev/ AbbSum1024, AbbSum186, AbbSum311, AbbSum196
	common /abbrev/ AbbSum458, AbbSum953, AbbSum954, AbbSum1032
	common /abbrev/ AbbSum1031, AbbSum287, AbbSum597, AbbSum598
	common /abbrev/ AbbSum312, AbbSum313, AbbSum341, AbbSum342
	common /abbrev/ AbbSum984, AbbSum282, AbbSum985, AbbSum265
	common /abbrev/ AbbSum974, AbbSum266, AbbSum91, AbbSum947
	common /abbrev/ AbbSum989, AbbSum289, AbbSum226, AbbSum988
	common /abbrev/ AbbSum990, AbbSum1034, AbbSum991, AbbSum267
	common /abbrev/ AbbSum116, AbbSum997, AbbSum281, AbbSum949
	common /abbrev/ AbbSum717, AbbSum724, AbbSum872, AbbSum1093
	common /abbrev/ AbbSum1092, AbbSum544, AbbSum712, AbbSum206
	common /abbrev/ AbbSum406, AbbSum411, AbbSum207, AbbSum977
	common /abbrev/ AbbSum550, AbbSum832, AbbSum661, AbbSum582
	common /abbrev/ AbbSum430, AbbSum895, AbbSum894, AbbSum671
	common /abbrev/ AbbSum831, AbbSum641, AbbSum638, AbbSum759
	common /abbrev/ AbbSum755, AbbSum857, AbbSum858, AbbSum703
	common /abbrev/ AbbSum647, AbbSum796, AbbSum482, AbbSum83
	common /abbrev/ AbbSum1081, AbbSum644, AbbSum838, AbbSum517
	common /abbrev/ AbbSum375, AbbSum999, AbbSum962, AbbSum1000
	common /abbrev/ AbbSum622, AbbSum396, AbbSum1026, AbbSum1029
	common /abbrev/ AbbSum18, AbbSum584, AbbSum1097, AbbSum913
	common /abbrev/ AbbSum983, AbbSum995, AbbSum1020, AbbSum606
	common /abbrev/ AbbSum981, AbbSum610, AbbSum608, AbbSum911
	common /abbrev/ AbbSum386, AbbSum624, AbbSum397, AbbSum996
	common /abbrev/ AbbSum1018, AbbSum387, AbbSum1022, AbbSum969
	common /abbrev/ AbbSum611, AbbSum388, AbbSum1042, AbbSum280
	common /abbrev/ AbbSum870, AbbSum723, AbbSum721, AbbSum224
	common /abbrev/ AbbSum762, AbbSum761, AbbSum685, AbbSum675
	common /abbrev/ AbbSum890, AbbSum529, AbbSum533, AbbSum320
	common /abbrev/ AbbSum528, AbbSum881, AbbSum837, AbbSum834
	common /abbrev/ AbbSum851, AbbSum855, AbbSum900, AbbSum768
	common /abbrev/ AbbSum556, AbbSum514, AbbSum515, AbbSum781
	common /abbrev/ AbbSum846, AbbSum843, AbbSum727, AbbSum414
	common /abbrev/ AbbSum875, AbbSum34, AbbSum513, AbbSum44
	common /abbrev/ AbbSum825, AbbSum711, AbbSum835, AbbSum54
	common /abbrev/ AbbSum801, AbbSum802, AbbSum793, AbbSum794
	common /abbrev/ AbbSum636, AbbSum669, AbbSum581, AbbSum575
	common /abbrev/ AbbSum884, AbbSum634, AbbSum192, AbbSum702
	common /abbrev/ AbbSum815, AbbSum435, AbbSum433, AbbSum650
	common /abbrev/ AbbSum494, AbbSum1090, AbbSum688, AbbSum728
	common /abbrev/ AbbSum700, AbbSum519, AbbSum733, AbbSum745
	common /abbrev/ AbbSum845, AbbSum864, AbbSum701, AbbSum373
	common /abbrev/ AbbSum374, AbbSum904, AbbSum908, AbbSum1071
	common /abbrev/ AbbSum516, AbbSum836, AbbSum779, AbbSum780
	common /abbrev/ AbbSum787, AbbSum788, AbbSum253, AbbSum883
	common /abbrev/ AbbSum227, AbbSum273, AbbSum720, AbbSum726
	common /abbrev/ AbbSum939, AbbSum678, AbbSum222, AbbSum879
	common /abbrev/ AbbSum527, AbbSum736, AbbSum526, AbbSum729
	common /abbrev/ AbbSum861, AbbSum722, AbbSum905, AbbSum752
	common /abbrev/ AbbSum1011, AbbSum509, AbbSum627, AbbSum829
	common /abbrev/ AbbSum405, AbbSum848, AbbSum828, AbbSum507
	common /abbrev/ AbbSum58, AbbSum63, AbbSum751, AbbSum78
	common /abbrev/ AbbSum69, AbbSum73, AbbSum79, AbbSum541
	common /abbrev/ AbbSum540, AbbSum432, AbbSum470, AbbSum163
	common /abbrev/ AbbSum561, AbbSum813, AbbSum605, AbbSum208
	common /abbrev/ AbbSum978, AbbSum777, AbbSum778, AbbSum785
	common /abbrev/ AbbSum786, AbbSum1080, AbbSum428, AbbSum415
	common /abbrev/ AbbSum424, AbbSum766, AbbSum750, AbbSum738
	common /abbrev/ AbbSum646, AbbSum910, AbbSum909, AbbSum209
	common /abbrev/ AbbSum753, AbbSum847, AbbSum824, AbbSum635
	common /abbrev/ AbbSum62, AbbSum676, AbbSum677, AbbSum1105
	common /abbrev/ AbbSum1010, AbbSum814, AbbSum898, AbbSum886
	common /abbrev/ AbbSum887, AbbSum899, AbbSum294, AbbSum221
	common /abbrev/ AbbSum844, AbbSum799, AbbSum791, AbbSum800
	common /abbrev/ AbbSum792, AbbSum737, AbbSum732, AbbSum735
	common /abbrev/ AbbSum739, AbbSum744, AbbSum90, AbbSum1085
	common /abbrev/ AbbSum573, AbbSum686, AbbSum687, AbbSum1111
	common /abbrev/ AbbSum1103, AbbSum1084, AbbSum563, AbbSum535
	common /abbrev/ AbbSum536, AbbSum930, AbbSum865, AbbSum749
	common /abbrev/ AbbSum866, AbbSum603, AbbSum946, AbbSum943
	common /abbrev/ AbbSum1094, AbbSum1112, AbbSum80, AbbSum77
	common /abbrev/ AbbSum944, AbbSum531, AbbSum190, AbbSum532
	common /abbrev/ AbbSum1102, AbbSum1089, AbbSum842, AbbSum772
	common /abbrev/ AbbSum427, AbbSum423, AbbSum460, AbbSum426
	common /abbrev/ AbbSum773, AbbSum769, AbbSum743, AbbSum748
	common /abbrev/ AbbSum812, AbbSum804, AbbSum449, AbbSum510
	common /abbrev/ AbbSum401, AbbSum626, AbbSum539, AbbSum827
	common /abbrev/ AbbSum512, AbbSum1113, AbbSum506, AbbSum1079
	common /abbrev/ AbbSum290, AbbSum643, AbbSum640, AbbSum496
	common /abbrev/ AbbSum929, AbbSum742, AbbSum697, AbbSum698
	common /abbrev/ AbbSum696, AbbSum466, AbbSum708, AbbSum709
	common /abbrev/ AbbSum445, AbbSum410, AbbSum413, AbbSum917
	common /abbrev/ AbbSum604, AbbSum525, AbbSum942, AbbSum668
	common /abbrev/ AbbSum667, AbbSum833, AbbSum268, AbbSum319
	common /abbrev/ AbbSum188, AbbSum931, AbbSum1076, AbbSum1110
	common /abbrev/ AbbSum1061, AbbSum863, AbbSum707, AbbSum370
	common /abbrev/ AbbSum371, AbbSum662, AbbSum124, AbbSum437
	common /abbrev/ AbbSum448, AbbSum849, AbbSum1072, AbbSum1106
	common /abbrev/ AbbSum941, AbbSum572, AbbSum660, AbbSum659
	common /abbrev/ AbbSum1091, AbbSum562, AbbSum710, AbbSum932
	common /abbrev/ AbbSum1055, AbbSum765, AbbSum469, AbbSum741
	common /abbrev/ AbbSum476, AbbSum770, AbbSum455, AbbSum142
	common /abbrev/ AbbSum938, AbbSum369, AbbSum945, AbbSum625
	common /abbrev/ AbbSum402, AbbSum976, AbbSum937, AbbSum747
	common /abbrev/ AbbSum925, AbbSum220, AbbSum524, AbbSum830
	common /abbrev/ AbbSum343, AbbSum314, AbbSum495, AbbSum795
	common /abbrev/ AbbSum803, AbbSum1009, AbbSum699, AbbSum936
	common /abbrev/ AbbSum1012, AbbSum1109, AbbSum915, AbbSum198
	common /abbrev/ AbbSum916, AbbSum926, AbbSum771, AbbSum896
	common /abbrev/ AbbSum648, AbbSum1095, AbbSum980, AbbSum975
	common /abbrev/ AbbSum434, AbbSum1101, AbbSum784, AbbSum203
	common /abbrev/ AbbSum223, AbbSum364, AbbSum979, AbbSum811
	common /abbrev/ AbbSum505, AbbSum446, AbbSum447, AbbSum150
	common /abbrev/ AbbSum456, AbbSum457, AbbSum790, AbbSum798
	common /abbrev/ AbbSum412, AbbSum783, AbbSum775, AbbSum642
	common /abbrev/ AbbSum269, AbbSum270, AbbSum291, AbbSum292
	common /abbrev/ AbbSum776, AbbSum1060, AbbSum1088, AbbSum363
	common /abbrev/ AbbSum385, AbbSum713, AbbSum715, AbbSum714
	common /abbrev/ AbbSum645, AbbSum431, AbbSum569, AbbSum502
	common /abbrev/ AbbSum558, AbbSum490, AbbSum1075, AbbSum595
	common /abbrev/ AbbSum914, AbbSum821, AbbSum822, AbbSum823
	common /abbrev/ AbbSum147, AbbSum123, AbbSum684, AbbSum493
	common /abbrev/ AbbSum674, AbbSum593, AbbSum393, AbbSum767
	common /abbrev/ AbbSum725, AbbSum534, AbbSum734, AbbSum885
	common /abbrev/ AbbSum193, AbbSum162, AbbSum615, AbbSum809
	common /abbrev/ AbbSum810, AbbSum395, AbbSum1004, AbbSum613
	common /abbrev/ AbbSum594, AbbSum409, AbbSum882, AbbSum639
	common /abbrev/ AbbSum897, AbbSum1098, AbbSum1108, AbbSum492
	common /abbrev/ AbbSum912, AbbSum1005, AbbSum683, AbbSum927
	common /abbrev/ AbbSum151, AbbSum143, AbbSum368, AbbSum673
	common /abbrev/ AbbSum609, AbbSum570, AbbSum559, AbbSum503
	common /abbrev/ AbbSum491, AbbSum719, AbbSum731, AbbSum478
	common /abbrev/ AbbSum468, AbbSum1086, AbbSum1074, AbbSum464
	common /abbrev/ AbbSum465, AbbSum924, AbbSum152, AbbSum666
	common /abbrev/ AbbSum922, AbbSum658, AbbSum754, AbbSum306
	common /abbrev/ AbbSum307, AbbSum335, AbbSum336, AbbSum284
	common /abbrev/ AbbSum500, AbbSum185, AbbSum187, AbbSum479
	common /abbrev/ AbbSum504, AbbSum552, AbbSum566, AbbSum555
	common /abbrev/ AbbSum567, AbbSum554, AbbSum565, AbbSum474
	common /abbrev/ AbbSum475, AbbSum681, AbbSum670, AbbSum614
	common /abbrev/ AbbSum530, AbbSum285, AbbSum443, AbbSum453
	common /abbrev/ AbbSum971, AbbSum477, AbbSum467, AbbSum451
	common /abbrev/ AbbSum436, AbbSum197, AbbSum144, AbbSum199
	common /abbrev/ AbbSum560, AbbSum623, AbbSum279, AbbSum571
	common /abbrev/ AbbSum973, AbbSum259, AbbSum1087, AbbSum293
	common /abbrev/ AbbSum189, AbbSum619, AbbSum444, AbbSum601
	common /abbrev/ AbbSum620, AbbSum665, AbbSum934, AbbSum657
	common /abbrev/ AbbSum602, AbbSum260, AbbSum919, AbbSum316
	common /abbrev/ AbbSum317, AbbSum1114, AbbSum481, AbbSum921
	common /abbrev/ AbbSum454, AbbSum618, AbbSum1014, AbbSum1107
	common /abbrev/ AbbSum344, AbbSum345, AbbSum1013, AbbSum264
	common /abbrev/ AbbSum935, AbbSum195, AbbSum706, AbbSum694
	common /abbrev/ AbbSum1008, AbbSum499, AbbSum286, AbbSum578
	common /abbrev/ AbbSum472, AbbSum600, AbbSum459, AbbSum141
	common /abbrev/ AbbSum140, AbbSum145, AbbSum425, AbbSum637
	common /abbrev/ AbbSum746, AbbSum1006, AbbSum1003, AbbSum1007
	common /abbrev/ AbbSum695, AbbSum337, AbbSum580, AbbSum705
	common /abbrev/ AbbSum115, AbbSum1096, AbbSum149, AbbSum148
	common /abbrev/ AbbSum308, AbbSum672, AbbSum682, AbbSum663
	common /abbrev/ AbbSum422, AbbSum633, AbbSum920, AbbSum1036
	common /abbrev/ AbbSum918, AbbSum808, AbbSum901, AbbSum651
	common /abbrev/ AbbSum664, AbbSum740, AbbSum903, AbbSum1037
	common /abbrev/ AbbSum817, AbbSum807, AbbSum819, AbbSum704
	common /abbrev/ AbbSum586, AbbSum1035, AbbSum964, AbbSum693
	common /abbrev/ AbbSum194, AbbSum568, AbbSum557, AbbSum892
	common /abbrev/ AbbSum806, AbbSum588, AbbSum961, AbbSum183
	common /abbrev/ AbbSum893, AbbSum965, AbbSum968, AbbSum818
	common /abbrev/ AbbSum452, AbbSum442, AbbSum656, AbbSum330
	common /abbrev/ AbbSum358, AbbSum1033, AbbSum346, AbbSum394
	common /abbrev/ AbbSum473, AbbSum384, AbbSum463, AbbSum816
	common /abbrev/ AbbSum805, AbbSum955, AbbSum952, AbbSum957
	common /abbrev/ AbbSum950, AbbSum959, AbbSum1039, AbbSum948
	common /abbrev/ AbbSum304, AbbSum334, AbbSum1016, AbbSum992
	common /abbrev/ AbbSum1038, AbbSum993, AbbSum998, AbbSum1015
	common /abbrev/ AbbSum994, AbbSum489, AbbSum501, AbbSum621
	common /abbrev/ AbbSum1017, AbbSum987, AbbSum607, AbbSum982
	common /abbrev/ AbbSum1019, AbbSum252, AbbSum592, AbbSum283
	common /abbrev/ AbbSum612, AbbSum1025, AbbSum1021, Opt1799
	common /abbrev/ Opt1800, Opt1801, Opt1802, Opt1803, Opt1804
	common /abbrev/ Opt1805, Opt1806, Opt1807, Sub1161, Sub1158
	common /abbrev/ Sub1124, Sub1120, Sub1646, Sub1637, Sub1650
	common /abbrev/ Sub1642, Sub1654, Sub1603, Sub1604, Sub1598
	common /abbrev/ Sub1597, Sub1501, Sub1503, Sub1488, Sub1486
	common /abbrev/ Sub1487, Sub1479, Sub1480, Sub1481, Sub1449
	common /abbrev/ Sub1451, Sub1447, Sub1415, Sub1411, Sub1375
	common /abbrev/ Sub1349, Sub1345, Sub1357, Sub1353, Sub1335
	common /abbrev/ Sub1316, Sub1252, Sub1256, Sub1254, Sub1239
	common /abbrev/ Sub1237, Sub1200, Sub1198, Sub1205, Sub1202
	common /abbrev/ Sub1189, Sub1186, Sub1390, Sub1532, Sub1209
	common /abbrev/ Sub1127, Sub1123, Sub1134, Sub1131, Sub1142
	common /abbrev/ Sub1138, Sub1216, Sub1212, Sub1223, Sub1220
	common /abbrev/ Sub1232, Sub1228, Sub1286, Sub1284, Sub1293
	common /abbrev/ Sub1291, Sub1301, Sub1298, Sub1352, Sub1348
	common /abbrev/ Sub1360, Sub1356, Sub1369, Sub1365, Sub1410
	common /abbrev/ Sub1407, Sub1418, Sub1414, Sub1426, Sub1422
	common /abbrev/ Sub1453, Sub1450, Sub1457, Sub1455, Sub1470
	common /abbrev/ Sub1464, Sub1492, Sub1485, Sub1523, Sub1519
	common /abbrev/ Sub1531, Sub1527, Sub1540, Sub1536, Sub1567
	common /abbrev/ Sub1563, Sub1578, Sub1573, Sub1588, Sub1584
	common /abbrev/ Sub1596, Sub1592, Sub1608, Sub1602, Sub1614
	common /abbrev/ Sub1611, Sub1139, Sub1135, Sub1645, Sub1634
	common /abbrev/ Sub1649, Sub1648, Sub1593, Sub1589, Sub1575
	common /abbrev/ Sub1574, Sub1570, Sub1568, Sub1544, Sub1541
	common /abbrev/ Sub1546, Sub1553, Sub1551, Sub1520, Sub1516
	common /abbrev/ Sub1528, Sub1524, Sub1510, Sub1471, Sub1475
	common /abbrev/ Sub1489, Sub1482, Sub1617, Sub1465, Sub1458
	common /abbrev/ Sub1430, Sub1427, Sub1437, Sub1434, Sub1442
	common /abbrev/ Sub1439, Sub1423, Sub1419, Sub1621, Sub1495
	common /abbrev/ Sub1392, Sub1399, Sub1377, Sub1493, Sub1619
	common /abbrev/ Sub1331, Sub1340, Sub1325, Sub1306, Sub1309
	common /abbrev/ Sub1281, Sub1295, Sub1299, Sub1294, Sub1268
	common /abbrev/ Sub1272, Sub1270, Sub1276, Sub1274, Sub1250
	common /abbrev/ Sub1260, Sub1258, Sub1235, Sub1243, Sub1213
	common /abbrev/ Sub1229, Sub1226, Sub1179, Sub1176, Sub1559
	common /abbrev/ Sub1361, Sub1440, Sub1579, Sub1297, Sub1387
	common /abbrev/ Sub1428, Sub1472, Sub1476, Sub1305, Sub1115
	common /abbrev/ Sub1116, Sub1628, Sub1629, Sub1117, Sub1119
	common /abbrev/ Sub1630, Sub1631, Sub1632, Sub1633, Sub1143
	common /abbrev/ Sub1144, Sub1145, Sub1146, Sub1147, Sub1148
	common /abbrev/ Sub1635, Sub1636, Sub1151, Sub1153, Sub1155
	common /abbrev/ Sub1157, Sub1160, Sub1163, Sub1164, Sub1165
	common /abbrev/ Sub1166, Sub1167, Sub1168, Sub1169, Sub1638
	common /abbrev/ Sub1639, Sub1170, Sub1171, Sub1172, Sub1173
	common /abbrev/ Sub1174, Sub1175, Sub1178, Sub1181, Sub1183
	common /abbrev/ Sub1185, Sub1188, Sub1191, Sub1192, Sub1193
	common /abbrev/ Sub1194, Sub1195, Sub1196, Sub1197, Sub1234
	common /abbrev/ Sub1236, Sub1238, Sub1240, Sub1242, Sub1244
	common /abbrev/ Sub1251, Sub1253, Sub1255, Sub1257, Sub1259
	common /abbrev/ Sub1261, Sub1267, Sub1269, Sub1271, Sub1273
	common /abbrev/ Sub1275, Sub1277, Sub1303, Sub1304, Sub1307
	common /abbrev/ Sub1308, Sub1310, Sub1311, Sub1317, Sub1319
	common /abbrev/ Sub1321, Sub1322, Sub1324, Sub1326, Sub1332
	common /abbrev/ Sub1334, Sub1336, Sub1337, Sub1339, Sub1341
	common /abbrev/ Sub1370, Sub1372, Sub1374, Sub1376, Sub1379
	common /abbrev/ Sub1381, Sub1388, Sub1391, Sub1394, Sub1396
	common /abbrev/ Sub1398, Sub1401, Sub1429, Sub1432, Sub1435
	common /abbrev/ Sub1438, Sub1441, Sub1443, Sub1473, Sub1474
	common /abbrev/ Sub1477, Sub1478, Sub1494, Sub1496, Sub1500
	common /abbrev/ Sub1502, Sub1505, Sub1507, Sub1509, Sub1512
	common /abbrev/ Sub1542, Sub1545, Sub1548, Sub1550, Sub1552
	common /abbrev/ Sub1554, Sub1616, Sub1618, Sub1620, Sub1622
	common /abbrev/ Sub1152, Sub1150, Sub1156, Sub1154, Sub1644
	common /abbrev/ Sub1641, Sub1653, Sub1605, Sub1599, Sub1560
	common /abbrev/ Sub1585, Sub1580, Sub1537, Sub1533, Sub1506
	common /abbrev/ Sub1466, Sub1459, Sub1615, Sub1389, Sub1386
	common /abbrev/ Sub1371, Sub1373, Sub1380, Sub1362, Sub1318
	common /abbrev/ Sub1320, Sub1323, Sub1288, Sub1266, Sub1241
	common /abbrev/ Sub1208, Sub1207, Sub1224, Sub1128, Sub1287
	common /abbrev/ Sub1126, Sub1504, Sub1431, Sub1122, Sub1225
	common /abbrev/ Sub1137, Sub1141, Sub1215, Sub1231, Sub1378
	common /abbrev/ Sub1133, Sub1130, Sub1564, Sub1549, Sub1395
	common /abbrev/ Sub1366, Sub1333, Sub1338, Sub1302, Sub1211
	common /abbrev/ Sub1121, Sub1227, Sub1136, Sub1140, Sub1214
	common /abbrev/ Sub1125, Sub1433, Sub1547, Sub1393, Sub1180
	common /abbrev/ Sub1177, Sub1296, Sub1300, Sub1149, Sub1217
	common /abbrev/ Sub1511, Sub1201, Sub1132, Sub1129, Sub1448
	common /abbrev/ Sub1452, Sub1467, Sub1461, Sub1210, Sub1184
	common /abbrev/ Sub1182, Sub1118, Sub1230, Sub1199, Sub1436
	common /abbrev/ Sub1558, Sub1400, Sub1460, Sub1247, Sub1248
	common /abbrev/ Sub1249, Sub1263, Sub1265, Sub1278, Sub1280
	common /abbrev/ Sub1313, Sub1314, Sub1315, Sub1328, Sub1329
	common /abbrev/ Sub1330, Sub1342, Sub1343, Sub1344, Sub1383
	common /abbrev/ Sub1384, Sub1385, Sub1402, Sub1403, Sub1404
	common /abbrev/ Sub1444, Sub1445, Sub1446, Sub1497, Sub1499
	common /abbrev/ Sub1513, Sub1515, Sub1555, Sub1557, Sub1623
	common /abbrev/ Sub1624, Sub1222, Sub1219, Sub1543, Sub1162
	common /abbrev/ Sub1159, Sub1607, Sub1601, Sub1206, Sub1203
	common /abbrev/ Sub1569, Sub1613, Sub1610, Sub1454, Sub1456
	common /abbrev/ Sub1221, Sub1218, Sub1600, Sub1606, Sub1187
	common /abbrev/ Sub1491, Sub1484, Sub1290, Sub1190, Sub1627
	common /abbrev/ Sub1204, Sub1652, Sub1612, Sub1590, Sub1594
	common /abbrev/ Sub1539, Sub1535, Sub1346, Sub1354, Sub1517
	common /abbrev/ Sub1350, Sub1358, Sub1521, Sub1351, Sub1347
	common /abbrev/ Sub1359, Sub1355, Sub1526, Sub1530, Sub1409
	common /abbrev/ Sub1406, Sub1640, Sub1647, Sub1643, Sub1651
	common /abbrev/ Sub1655, Sub1581, Sub1508, Sub1397, Sub1609
	common /abbrev/ Sub1525, Sub1490, Sub1405, Sub1529, Sub1408
	common /abbrev/ Sub1522, Sub1518, Sub1283, Sub1417, Sub1413
	common /abbrev/ Sub1538, Sub1412, Sub1416, Sub1595, Sub1591
	common /abbrev/ Sub1425, Sub1421, Sub1368, Sub1364, Sub1289
	common /abbrev/ Sub1292, Sub1245, Sub1246, Sub1264, Sub1279
	common /abbrev/ Sub1312, Sub1498, Sub1327, Sub1514, Sub1382
	common /abbrev/ Sub1556, Sub1625, Sub1483, Sub1534, Sub1424
	common /abbrev/ Sub1367, Sub1566, Sub1562, Sub1420, Sub1363
	common /abbrev/ Sub1282, Sub1285, Sub1577, Sub1572, Sub1469
	common /abbrev/ Sub1463, Sub1565, Sub1561, Sub1587, Sub1583
	common /abbrev/ Sub1233, Sub1262, Sub1576, Sub1571, Sub1468
	common /abbrev/ Sub1462, Sub1582, Sub1586, Sub1626

	integer iint1, iint2, iint3, iint4, iint5, iint6, iint7, iint8
	integer iint9, iint10, iint11, iint12, iint13, iint14, iint15
	integer iint16, iint17, iint18, iint19, iint20, iint21, iint22
	integer iint23, iint24, iint25, iint26, iint27, iint28, iint29
	integer iint30, iint31, iint32, iint33, iint34, iint35, iint36
	integer iint37, iint38, iint39, iint40, iint41, iint42, iint43
	integer iint44, iint45, iint46, iint47, iint48, iint49, iint50
	integer iint51, iint52, iint53, iint54, iint55, iint56, iint57
	integer iint58, iint59, iint60
	common /loopint/ iint1, iint2, iint3, iint4, iint5, iint6
	common /loopint/ iint7, iint8, iint9, iint10, iint11, iint12
	common /loopint/ iint13, iint14, iint15, iint16, iint17
	common /loopint/ iint18, iint19, iint20, iint21, iint22
	common /loopint/ iint23, iint24, iint25, iint26, iint27
	common /loopint/ iint28, iint29, iint30, iint31, iint32
	common /loopint/ iint33, iint34, iint35, iint36, iint37
	common /loopint/ iint38, iint39, iint40, iint41, iint42
	common /loopint/ iint43, iint44, iint45, iint46, iint47
	common /loopint/ iint48, iint49, iint50, iint51, iint52
	common /loopint/ iint53, iint54, iint55, iint56, iint57
	common /loopint/ iint58, iint59, iint60

	double complex MatSUN(3,3), Cloop(3)
	common /formfactors/ MatSUN, Cloop


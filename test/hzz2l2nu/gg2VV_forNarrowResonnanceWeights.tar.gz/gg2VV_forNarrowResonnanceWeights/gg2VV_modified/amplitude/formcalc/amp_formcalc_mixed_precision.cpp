#include <iostream>
using std::cout;
#include <iomanip>
using std::endl;
using std::setprecision;

#include "amp_formcalc.h"
#include "settings.h"
#include "utilities.h"
#include "rng.h"
#include "stablepoint.h"

#include "tinymass.inc"

AmpSqrFormcalc::AmpSqrFormcalc(unsigned int selection)
  : AmpSqr(selection)
{}

extern "C"
{
  void assert_looptools_initialized_();     // from amplitude/double/assert_looptools_initialized.h
  void clearcache_();     // in libooptools.a
  void init_formcalc_(const double* mW, const double* wW, const double* mZ, const double* wZ, const double* mH, const double* wH, const double* nk_tiny_lepton_mass, const double* nk_tiny_quark_mass, const double* mb, const double* mt, const double* gfermi, const double* alpha, const double* CKM_lambda, const double* CKM_A, const double* CKM_rho_bar, const double* CKM_eta_bar, const int* nk_continuum_in, const int* nk_higgs_in, const double* nk_hggcoupfac_in, const double* nk_hwwcoupfac_in, const double* nk_hzzcoupfac_in);

  void assert_looptools_initialized_quad_();
  void clearcache_quad_();
  void init_formcalc_quad_(const double* mW, const double* wW, const double* mZ, const double* wZ, const double* mH, const double* wH, const double* nk_tiny_lepton_mass, const double* nk_tiny_quark_mass, const double* mb, const double* mt, const double* gfermi, const double* alpha, const double* CKM_lambda, const double* CKM_A, const double* CKM_rho_bar, const double* CKM_eta_bar, const int* nk_continuum_in, const int* nk_higgs_in, const double* nk_hggcoupfac_in, const double* nk_hwwcoupfac_in, const double* nk_hzzcoupfac_in);
}

void AmpSqrFormcalc::initialize()
{
  const double huge_fermion_mass = 1.e5;

  double used_light_quark_mass = 0.;     // initialize
  double used_bottom_quark_mass = 0.;
  double used_top_quark_mass = 0.;

  if ((selection() == MASSLESSBOX + HIGGSSIGNAL) || (selection() == MASSIVEBOX + HIGGSSIGNAL)) {
    fatal_error("AmpSqrFormcalc::initialize: amplitude selection not implemented");
  }
  else if (selection() == MASSLESSBOX) {
    used_light_quark_mass = AmpSqrFormcalc::tiny_fermion_mass;
    used_bottom_quark_mass = huge_fermion_mass;
    used_top_quark_mass = huge_fermion_mass;
  }
  else if (selection() == MASSIVEBOX) {
    used_light_quark_mass = huge_fermion_mass;
    used_bottom_quark_mass = SMP::mb;
    used_top_quark_mass = SMP::mt;
  }
  else {
    used_light_quark_mass = AmpSqrFormcalc::tiny_fermion_mass;
    used_bottom_quark_mass = SMP::mb;
    used_top_quark_mass = SMP::mt;
  }

  int nk_continuum_in = 0;
  int nk_higgs_in = 0;
  
  if (includesOnlySignal(selection())) {
    nk_continuum_in = 0;
    nk_higgs_in = 1;
  }
  else if (includesOnlyBackground(selection())) {
    nk_continuum_in = 1;
    nk_higgs_in = 0;
  }
  else if (includesSignalAndBackground(selection())) {
    nk_continuum_in = 1;
    nk_higgs_in = 1;
  }
  else {
    fatal_error("AmpSqrFormcalc::initialize: invalid selection");
  }

  init_formcalc_(&SMP::mW, &SMP::wW, &SMP::mZ, &SMP::wZ, &SMP::mH, &SMP::wH, &AmpSqrFormcalc::tiny_fermion_mass, &used_light_quark_mass, &used_bottom_quark_mass, &used_top_quark_mass, &SMP::gfermi, &SMP::alpha, &SMP::CKM_lambda, &SMP::CKM_A, &SMP::CKM_rho_bar, &SMP::CKM_eta_bar, &nk_continuum_in, &nk_higgs_in, &BSM::HggCouplingRescalingFactor, &BSM::HWWCouplingRescalingFactor, &BSM::HZZCouplingRescalingFactor);

  assert_looptools_initialized_();

  init_formcalc_quad_(&SMP::mW, &SMP::wW, &SMP::mZ, &SMP::wZ, &SMP::mH, &SMP::wH, &AmpSqrFormcalc::tiny_fermion_mass, &used_light_quark_mass, &used_bottom_quark_mass, &used_top_quark_mass, &SMP::gfermi, &SMP::alpha, &SMP::CKM_lambda, &SMP::CKM_A, &SMP::CKM_rho_bar, &SMP::CKM_eta_bar, &nk_continuum_in, &nk_higgs_in, &BSM::HggCouplingRescalingFactor, &BSM::HWWCouplingRescalingFactor, &BSM::HZZCouplingRescalingFactor);

  assert_looptools_initialized_quad_();
}

extern "C"
{
  void vecsetwrapper_(const int* i, const double* mass, const double* px, const double* py, const double* pz);

  void vecsetwrapper_quad_(const int* i, const double* mass, const double* px, const double* py, const double* pz);
}

namespace
{
inline void setvector(int& i, const double& mass, const ConstValue<FourMomentum>& p, const bool useQuadPrec)
{
  const double px = p().px();
  const double py = p().py();
  const double pz = p().pz();

  if (useQuadPrec) {
    vecsetwrapper_quad_(&i, &mass, &px, &py, &pz);
  }
  else {
    vecsetwrapper_(&i, &mass, &px, &py, &pz);
  }
}
}     // unnamed namespace

extern "C"
{
  void squaredme_(double result[], const int* helicities, const int* flags);   // FormCalc5
  //void squaredme_(double result[], const Int64* helicities, const int* flags);   // FormCalc7

  void squaredme_quad_(double result[], const int* helicities, const int* flags);   // FormCalc5
  //void squaredme_quad_(double result[], const Int64* helicities, const int* flags);   // FormCalc7
}

namespace
{
const double ampsqr_core(const PhaseSpace& ps, const bool useQuadPrec)
{
  //  1     2         3           4          5           6         
  // --------------------------------------------------------------
  // WW2l2v:
  // {V[5], V[5]} -> {-F[2, {1}], F[1, {1}], -F[1, {2}], F[2, {2}]}
  //  g     g         e+          nu_e       {nu_bar}_mu mu-       
  // --------------------------------------------------------------
  // ZAZA2l2l:
  // {V[5], V[5]} -> {-F[2, {1}], F[2, {1}], -F[2, {2}], F[2, {2}]}
  //  g     g         e+          e-         mu+         mu-       
  // --------------------------------------------------------------
  // ZAZ_2l2v:
  // {V[5], V[5]} -> {-F[2, {1}], F[2, {1}], -F[1, {2}], F[1, {2}]}
  //  g     g         e+          e-         {nu_bar}_mu nu_mu     
  // --------------------------------------------------------------
  // ZAZA4l:
  // {V[5], V[5]} -> {-F[2, {1}], F[2, {1}], -F[2, {1}], F[2, {1}]}
  //  g     g         e+          e-         e+          e-        
  // --------------------------------------------------------------
  // WWZAZ_2l2v (2l2v_sameflav_fullamp):
  // {V[5], V[5]} -> {-F[2, {1}], F[1, {1}], -F[1, {1}], F[2, {1}]}
  //  g     g         e+          nu_e       {nu_bar}_e  e-        

  int i;
  double zero_mass = 0.;
  i = 1; setvector(i, zero_mass, ps.i, useQuadPrec);
  i = 2; setvector(i, zero_mass, ps.i_, useQuadPrec);
  i = 3; setvector(i, AmpSqrFormcalc::tiny_fermion_mass, ps.aa, useQuadPrec);
  i = 4; setvector(i, AmpSqrFormcalc::tiny_fermion_mass, ps.ap, useQuadPrec);
  i = 5; setvector(i, AmpSqrFormcalc::tiny_fermion_mass, ps.pa, useQuadPrec);
  i = 6; setvector(i, AmpSqrFormcalc::tiny_fermion_mass, ps.pp, useQuadPrec);

  // 3: final state antiparticle from intermediate antiparticle decay (aa)
  // 4: final state particle from intermediate antiparticle decay (ap)
  // 5: final state antiparticle from intermediate particle decay (pa)
  // 6: final state particle from intermediate particle decay (pp)

  (useQuadPrec) ? clearcache_quad_() : clearcache_();     // flush LoopTools results caches

  //{V[5], V[5]} -> {-F[2, {1}], F[2, {1}], -F[2, {2}], F[2, {2}]
  // 1    2          3           4          5          6 
  // g    g          e+          e-         mu+        mu-

  double result[2];
  // =============================================================================
  /*
  FormCalc5 convention for polarisations: see page 39
  p_1(3 bits) p_2(3 bits) ... p_n(3 bits), where each 3 bits =
  right circular,longitudinal,left-circular:
  p_1 -> [(+)(L)(-)]_binary = [(+)*4+(L)*2+(-)*1]_decimal
  octal number [C/C++ convention: left-most digit "0"]: one digit per particle:
  (-) = 1, (+) = 4, (L) = 2, transverse = 5, unpolarized = 7
  particle 1 to n correspond to digits of octal number from left to right
  */

#if defined PROCMACRO_WWZAZ_2l2v
  const int helicities = 0555145;    // ttt-+t (gg -> all -> l~ v v~ l)
#elif defined PROCMACRO_WW2l2v
  const int helicities = 0554141;    // tt+-+- (gg -> WW -> l~ v v~ l only)
#elif defined PROCMACRO_ZAZ_2l2v
  const int helicities = 0555541;    // tttt+- (gg -> ZAZA -> l~ l v~ v)
#else
  const int helicities = 0555555;    // tttttt (gg -> ZAZA -> l~ l l~ l)
#endif
  // =============================================================================
  /*
  FormCalc7 convention for polarisations: see pages 44 and 45
  p_1(5 bits) p_2(5 bits) ... p_n(5 bits), where each 5 bits =
  +(spin 2 or 3/2),+(spin 1 or 1/2),longitud.,-(spin 1 or 1/2),-(spin 2 or 3/2);
  use Python to convert from binary to decimal:
  >>> 0b010100101001000000100100000010
  346294530
  >>> 0b010100101001010010100101001010
  346368330
  use bin(decimal_number) to convert to binary:
  >>> bin(346368330)
  '0b10100101001010010100101001010'
  */

#if defined PROCMACRO_WW2l2v
  //const Int64 helicities = 346294530;    // tt+-+- (gg -> WW -> l~ v v~ l only)
#endif
  // =============================================================================
  const int flags = 1 + 2;  // both (reset and loop) set: 2**0 + 2**1
  
  if (useQuadPrec) {
    squaredme_quad_(result, &helicities, &flags);
  }
  else {
    squaredme_(result, &helicities, &flags);
  }

  //std::cout << result[0] << " " << result[1] << std::endl;

  result[1] *= 1./4;      // gluon pol. average
  result[1] *= 1./64;     // color average

#ifdef PROCMACRO_ZAZA4l
  result[1] *= 1./4;      // symmetry factor 1/(2!2!)
#endif

  return result[1];       // g_s := 1
}

struct DPSufficientTestsResults
{
  const bool dpIsSufficient;
  const double dpResult;
  DPSufficientTestsResults(const bool dpIsSufficient, const double dpResult);
};

DPSufficientTestsResults::DPSufficientTestsResults(const bool dpIsSufficient_, const double dpResult_)
  : dpIsSufficient(dpIsSufficient_), dpResult(dpResult_)
{}

const DPSufficientTestsResults double_precision_sufficient_tests(const PhaseSpace& ps)
{
  double rel_deviation_1 = 0.;
  double rel_deviation_2 = 0.;
  double rel_deviation_3 = 0.;
  bool double_estimated_sufficient = true;
  double res = 0.;
  if (amplitude_selection == AmpSqr::HIGGSSIGNAL) {
    double_estimated_sufficient = true;   // no instabilities
    res = ampsqr_core(ps, false);
  }
  else {
    // assess formcalc continuum amplitude stability in quad prec
    // check 1st criterion
    const PhaseSpace ps_boosted = boost(ps, FourVector(1., 0., 0., 0.001+0.1*randomNumberGenerator->uniformInZeroOne()));
    res = ampsqr_core(ps, false);
    const double res_boosted = ampsqr_core(ps_boosted, false);
    rel_deviation_1 = fabs(res-res_boosted)/min(res, res_boosted);
    if (rel_deviation_1 > 1.e-4) {
      double_estimated_sufficient = false;
    }
    if (double_estimated_sufficient) {
      // check 2nd criterion
      const PhaseSpace ps_boosted2 = boost(ps, FourVector(1., 0., 0., 0.001+0.1*randomNumberGenerator->uniformInZeroOne()), true);   // reverse
      const double res_boosted2 = ampsqr_core(ps_boosted2, false);
      rel_deviation_2 = max(fabs(res-res_boosted2), fabs(res_boosted-res_boosted2))/min(res, res_boosted, res_boosted2);
      if (rel_deviation_2 > 1.e-4) {
	double_estimated_sufficient = false;
      }
    }
    if (double_estimated_sufficient) {
      // check 3rd criterion
      const PhaseSpace ps_single = map_to_float(ps);
      const double res_single = ampsqr_core(ps_single, false);
      rel_deviation_3 = fabs(res-res_single)/res;
      if (rel_deviation_3 > 1.) {
	double_estimated_sufficient = false;
      }
    }
  }
  return DPSufficientTestsResults(double_estimated_sufficient, res);
}
}     // unnamed namespace

const double AmpSqrFormcalc::ampSqr(const PhaseSpace& ps)
{
#if defined PROCMACRO_WWZAZ_2l2v
  double result = 0.;
  bool dp_sufficient = false;
  if (double_precision_sufficient(ps)) {   // stablepoint.cpp
    const DPSufficientTestsResults dpstr = double_precision_sufficient_tests(ps);   // unnamed namespace above
    if (dpstr.dpIsSufficient) {
      result = dpstr.dpResult;
      dp_sufficient = true;
    }
  }
  if (!dp_sufficient && quadruple_precision_sufficient(ps)) {   // stablepoint.cpp
    result = ampsqr_core(ps, true);
  }
  return result;
#else
  double result = 0.;
  if (double_precision_sufficient(ps)) {   // stablepoint.cpp
    result = ampsqr_core(ps, false);
  }
  else if (quadruple_precision_sufficient(ps)) {   // stablepoint.cpp
    result = ampsqr_core(ps, true);
  }
  else {
    result = 0.;
  }
  return result;
#endif
}

void AmpSqrFormcalc::writeImplementation(ostream& os) const
{
  os << "Formcalc";
}

#ifndef INIT_BARSCHEME_H
#define INIT_BARSCHEME_H

extern "C"
{
  void init_barscheme_(const int* nk_barscheme_in);
}

#endif     /* INIT_BARSCHEME_H */

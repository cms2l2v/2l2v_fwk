#ifndef STABLEPOINT_H
#define STABLEPOINT_H

#include "phasespace.h"

const bool double_precision_sufficient(const PhaseSpace& ps);

const bool quadruple_precision_sufficient(const PhaseSpace& ps);

#endif     /* STABLEPOINT_H */

#ifndef AMP_FORMCALC_H
#define AMP_FORMCALC_H

#include "amp.h"
#include "phasespace.h"

class AmpSqrFormcalc : public AmpSqr
{
public:
  static const double tiny_fermion_mass;
  AmpSqrFormcalc(unsigned int selection);
  void initialize();
  const double ampSqr(const PhaseSpace& ps);
  void writeImplementation(ostream& os) const;
};

#endif     /* AMP_FORMCALC_H */

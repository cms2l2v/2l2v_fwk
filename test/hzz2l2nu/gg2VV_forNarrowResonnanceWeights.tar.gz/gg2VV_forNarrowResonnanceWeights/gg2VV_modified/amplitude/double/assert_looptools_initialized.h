#ifndef ASSERT_LOOPTOOLS_INITIALIZED_H
#define ASSERT_LOOPTOOLS_INITIALIZED_H

extern "C"
{
  void assert_looptools_initialized_();
}

#endif     /* ASSERT_LOOPTOOLS_INITIALIZED_H */

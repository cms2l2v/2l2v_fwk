from string import *
from os import environ, chdir
from os.path import isfile, isdir
import subprocess
from sys import exit

backslash = "\\"

def command_to_suffix_defined_extern_of_file(in_path, out_path):
    # append "quad_" to all defined, external symbols of file (incl. common blocks)
    assert isfile(in_path)
    return "objcopy `nm --extern-only --defined-only --format=posix "+in_path+" | grep -v : | sed 's/\(.*_\.*\).*/"+backslash+"1/' | sort -u | sed 's/\(.*_\)\(\.*\)/--redefine-sym &="+backslash+"1quad_"+backslash+"2/' | tr '\n' ' '` "+in_path+" "+out_path

def command_to_suffix_undefined_extern_resolved_by_looptools(file_path, looptools_libdir):
    # append "quad_" to undefined, external symbols that are resolved by LoopTools
    assert isfile(file_path)
    assert isdir(looptools_libdir)
    looptools_file = looptools_libdir+"/libooptools-quad.a"
    assert isfile(looptools_file)
    return "objcopy `nm --extern-only --defined-only --format=posix "+looptools_file+" | grep -v : | grep -v '_ C ' | grep -v '_ D ' | sed 's/\(.*_\.*\).*/"+backslash+"1/' | sort -u | sed 's/\(.*_\)\(\.*\)/--redefine-sym &="+backslash+"1quad_"+backslash+"2/' | tr '\n' ' '` "+file_path

def exec_command(command):
    process = subprocess.Popen(command, shell=True, executable="/bin/bash", stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    stdout, stderr = process.communicate()
    return (stdout, stderr)

def exec_command_without_output(command):
    stdout, stderr = exec_command(command)
    assert stdout == stderr == ""

def exec_command_with_output(command):
    stdout, stderr = exec_command(command)
    assert stderr == ""
    return stdout

def get_looptools_libdir():
    default = ""
    if environ.has_key("LIB_TOPDIR"):
        long_bit = strip(exec_command_with_output("getconf LONG_BIT"))
        assert long_bit in ["32", "64"]
        if long_bit == "32":
            lib_str = "lib"
        elif long_bit == "64":
            lib_str = "lib64"
        default_dir = environ["LIB_TOPDIR"] + "/gcc/LoopTools/" + lib_str 
        default = " ["+default_dir+"]"
    looptools_libdir = strip(raw_input("LoopTools library directory"+default+":\n"))
    if looptools_libdir == "":
        looptools_libdir = default_dir
    assert isdir(looptools_libdir)
    return looptools_libdir

looptools_libdir = get_looptools_libdir()

if not environ.has_key("TOPDIR"):
    print "error: environment variable TOPDIR not set"
    exit(1)
topdir = environ["TOPDIR"]

# generate libooptools-quad-suffix.a

chdir(looptools_libdir)
exec_command_without_output(command_to_suffix_defined_extern_of_file("libooptools-quad.a", "libooptools-quad-suffix.a"))

# generate $(TOPDIR)/amplitude/libamp_quadruple_suffix.a

chdir(topdir+"/amplitude")
exec_command_without_output(command_to_suffix_defined_extern_of_file("libamp_quadruple.a", "libamp_quadruple_suffix.a"))
exec_command_without_output(command_to_suffix_undefined_extern_resolved_by_looptools("libamp_quadruple_suffix.a", looptools_libdir))

# generate $(TOPDIR)/amplitude/formcalc/libampformcalc_quadruple_suffix.a

chdir(topdir+"/amplitude/formcalc")
exec_command_without_output(command_to_suffix_defined_extern_of_file("libampformcalc_quadruple.a", "libampformcalc_quadruple_suffix.a"))
exec_command_without_output(command_to_suffix_undefined_extern_resolved_by_looptools("libampformcalc_quadruple_suffix.a", looptools_libdir))

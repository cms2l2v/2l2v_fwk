#ifndef AMP_H
#define AMP_H

#include "phasespace.h"

#include <iostream>
using std::ostream;

class AmpSqr
{
public:
  static const unsigned int MASSLESSBOX;
  static const unsigned int MASSIVEBOX;
  static const unsigned int HIGGSSIGNAL;
  static const unsigned int CONTINUUMBACKGROUND;

  static const bool includesSignal(const unsigned int selection);
  static const bool includesBackground(const unsigned int selection);
  static const bool includesOnlySignal(const unsigned int selection);
  static const bool includesOnlyBackground(const unsigned int selection);
  static const bool includesSignalAndBackground(const unsigned int selection);

  const unsigned int selection() const;
  void writeSelection(ostream& os) const;
  
  AmpSqr(unsigned int selection);
  virtual void initialize() = 0;
  virtual const double ampSqr(const PhaseSpace& ps) = 0;
  virtual void writeImplementation(ostream& os) const = 0;
  virtual ~AmpSqr() {}
  void setSelection(unsigned int selection){_selection = selection;}  //MODIFIED BY LOIC QUERTENMONT

private:  
  unsigned int _selection;  //MODIFIED BY LOIC QUERTENMONT
};

inline const bool AmpSqr::includesSignal(const unsigned int selection)
{ return selection & HIGGSSIGNAL; }

inline const bool AmpSqr::includesBackground(const unsigned int selection)
{ return selection & (MASSLESSBOX | MASSIVEBOX); }

inline const bool AmpSqr::includesOnlySignal(const unsigned int selection)
{ return includesSignal(selection) && !includesBackground(selection); }

inline const bool AmpSqr::includesOnlyBackground(const unsigned int selection)
{ return includesBackground(selection) && !includesSignal(selection); }

inline const bool AmpSqr::includesSignalAndBackground(const unsigned int selection)
{ return includesBackground(selection) && includesSignal(selection); }

inline const unsigned int AmpSqr::selection() const { return _selection; }

#endif     /* AMP_H */

#include "amp.h"

const unsigned int AmpSqr::MASSLESSBOX = 1;
const unsigned int AmpSqr::MASSIVEBOX = 2;
const unsigned int AmpSqr::HIGGSSIGNAL = 4;
const unsigned int AmpSqr::CONTINUUMBACKGROUND = AmpSqr::MASSLESSBOX + AmpSqr::MASSIVEBOX;

void AmpSqr::writeSelection(ostream& os) const
{
  assert(_selection != 0);
  bool addPlus = false;
  if (_selection & HIGGSSIGNAL) {
    os << "Higgs";
    addPlus = true;
  }
  // continuum:
  if ((_selection & MASSLESSBOX) && (_selection & MASSIVEBOX)) {
    if (addPlus) {
      os << " + ";
    }
    os << "Continuum";
  }
  else if (_selection & MASSLESSBOX) {
    if (addPlus) {
      os << " + ";
    }
    os << "Continuum (massless box)";
  }
  else if (_selection & MASSIVEBOX) {
      if (addPlus) {
	os << " + ";
      }
      os << "Continuum (massive box)";
  }
}

AmpSqr::AmpSqr(const unsigned int selection)
  : _selection(selection)
{}

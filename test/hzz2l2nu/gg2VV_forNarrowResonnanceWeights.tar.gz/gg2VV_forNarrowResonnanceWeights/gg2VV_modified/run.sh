cd /afs/cern.ch/work/q/querten/public/HZZ2l2v_onCondor/CMSSW_5_3_11/src/UserCode/llvv_fwk/test/hzz2l2nu/DEBUG_NR/run_GG2VV_grid/rundir/1000_0_0.1/
. ./ENV.sh
cd gg2VV
jam clean
jam gg2VV
jam gg2VV
./gg2VV
echo "\n\n\nReplace settings.cpp to increase number of events and recompile\n\n\n"
mv settingsRun2.cpp settings.cpp
rm settings.o
jam gg2VV
jam gg2VV




#ifndef MAXEVENTWEIGHTESTIMATE_H
#define MAXEVENTWEIGHTESTIMATE_H

// for omnicomp parallelized computation (generateEvents = false)

#include "geometry.h"

namespace MaxEventWeightEstimate
{
extern double value;

inline void addEstimateValue(const double maxEventWeightEstimate)
{ value = max(maxEventWeightEstimate, value); }  
}

#endif  /* MAXEVENTWEIGHTESTIMATE_H */

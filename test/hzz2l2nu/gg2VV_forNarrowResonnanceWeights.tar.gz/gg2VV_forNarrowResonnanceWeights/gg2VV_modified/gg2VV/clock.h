#ifndef CLOCK_H
#define CLOCK_H

#include <sys/time.h>   // gettimeofday(): approx. 1 microsecond resolution

#include <iostream>
using std::ostream;

class Clock     // measures CPU time
{
public:
  void start();
  void stop();
  const double getTimeMilliseconds() const;
  void writeTime(ostream& os) const;
private:
  timeval _start;
  timeval _end;
  double _time_milliseconds;
};

inline const double Clock::getTimeMilliseconds() const { return _time_milliseconds; }

#endif     /* CLOCK_H */

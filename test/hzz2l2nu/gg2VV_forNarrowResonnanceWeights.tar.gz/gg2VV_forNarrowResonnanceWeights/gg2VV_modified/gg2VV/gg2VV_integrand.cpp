#include <typeinfo>
using std::bad_cast;
#include <cmath>
using std::fabs;
#include <iostream>
using std::ostream;
using std::cout;
using std::cerr;
#include <fstream>
using std::ofstream;
#include <iomanip>
using std::endl;
using std::setprecision;
using std::setw;
using std::fixed;
#include <ios>
using std::ios_base;
#include <string>
using std::string;
#include <cassert>
/* assert macro */

#include "gg2VV_integrand.h"
#include "settings.h"
#include "scales.h"
#include "pdf.h"
#include "amp.h"
#include "rng.h"
#include "utilities.h"
#include "amp_formcalc.h"
#include "events.h"
#include "detector.h"
#include "maxeventweightestimate.h"

IntegrandWithHistos::IntegrandWithHistos()
  : _histoSuite(0)
{}

void IntegrandWithHistos::attachOmniHistoSuite(HepSource::OmniHistoSuite *const omniHistoSuite)
{
  try {
    _histoSuite = dynamic_cast<HistoSuite*>(omniHistoSuite);
  }
  catch (bad_cast) {
    fatal_error("IntegrandWithHistos::attachOmniHistoSuite(OmniHistoSuite *const): arg not of type HistoSuite*");
  }
}

void IntegrandWithHistos::createAndAttachEmptyOmniHistoSuite()
{
  attachOmniHistoSuite(new HistoSuite());
}

// helpers ------------------------------------------------------

namespace
{
  const bool isInSection(const PhaseSpace& ps, const int section, const double mV, const double wV)
{
#if defined PROCMACRO_ZAZA2l2l || defined PROCMACRO_ZAZA4l
  const double higgsDeviation = fabs(ps.E_partonCMS() - SMP::mH)/SMP::wH;
  bool resHiggs = (nonresonantHiggsOnly) ? false : (higgsDeviation < compositePhaseSpaceParameter);
  

  const bool belowThreshold = ps.E_partonCMS() < contSingleResVUpperBound;

  const double lowerThreshold = max(SMP::mH + SMP::wH * compositePhaseSpaceParameter, 140.);
  const bool aboveThreshold = lowerThreshold < ps.E_partonCMS();

  if (amplitude_selection == AmpSqr::HIGGSSIGNAL && SMP::mH < contSingleResVUpperBound) {
    assert(lowerThreshold < contSingleResVUpperBound);
    if (section == Mapping::RESONANTHIGGS) {
      return !aboveThreshold;
    }
    else if (section == Mapping::NONRESONANTHIGGSBELOW) {
      return aboveThreshold && belowThreshold;
    }
    else if (section == Mapping::NONRESONANTHIGGSABOVE) {
      return !belowThreshold;
    }
    else {
      fatal_error("unknown mapping:", section);
    }
  }
  else {
    if (section == Mapping::RESONANTHIGGS) {
      return resHiggs;
    }
    else if (section == Mapping::NONRESONANTHIGGSBELOW) {
      return !resHiggs && belowThreshold;
    }
    else if (section == Mapping::NONRESONANTHIGGSABOVE) {
      return !resHiggs && !belowThreshold;
    }
    else {
      fatal_error("unknown mapping:", section);
    }
  }  
#else
  if (SMP::mH >= 2*mV) {
    const double higgsDeviation = fabs(ps.E_partonCMS() - SMP::mH)/SMP::wH;
    const bool resHiggs = higgsDeviation < compositePhaseSpaceParameter;
    if (section == Mapping::RESONANTHIGGS) {
      return resHiggs;
    }
    else if (section == Mapping::NONRESONANTHIGGS) {
      return !resHiggs;
    }
    else {
      fatal_error("unknown mapping:", section);
    }
  }
  else {
    static const double invHiggsMassCut =
      max(2 * mV - 4 * wV,
        SMP::mH + SMP::wH * compositePhaseSpaceParameter);
    const bool isBelowCut = ps.E_partonCMS() < invHiggsMassCut;
    if (section == Mapping::RESONANTHIGGS) {
      return isBelowCut;
    }
    else if (section == Mapping::NONRESONANTHIGGS) {
      return !isBelowCut;
    }
    else {
      fatal_error("unknown mapping:", section);
    }
  }
#endif

  return false;
}

const double initStateProb(const PhaseSpace& truePS, const double factorizationScale)
{
  static Pdf pdf(Pdf::PROTON);
  pdf(truePS.x(), factorizationScale);
  const double isp = pdf.g();
  pdf(truePS.x_(), factorizationScale);
  const double isp_ = pdf.g();
  return isp * isp_;
}
}     // unnamed namespace

// --------------------------------------------------------------

void GG2VV_Integrand::operator()(const vector<double>& x, const vector<int>& k,
                                const double& weight, const vector<double>& aux,
                                vector<double>& f)
{
  if (const bool recordPhaseSpacePoints = false) {
    static bool displayedWarning = false;
    if (!displayedWarning) {
      cout << endl;
      cout << "******************************************************" << endl;
      cout << "        WARNING: recordPhaseSpacePoints = true        " << endl;
      cout << "******************************************************" << endl;
      displayedWarning = true;
    }
    static int numberOfRecordedPoints = 0;
    PhaseSpace ps;
#if defined PROCMACRO_WWZAZ_2l2v
    assert(false);
#else
    //Mapping::higgsResonant(x, ps);
    Mapping::continuum(x, ps);
#endif
    bool isSuitablePoint = ps.weight() > 0.0;
    isSuitablePoint = isSuitablePoint && 30. < ps.a().pt();
    //isSuitablePoint = isSuitablePoint && fabs(ps.a().m() - SMP::mV) < 2*SMP::wV;
    isSuitablePoint = isSuitablePoint && 10. < ps.p().m() && ps.p().m() < 15.;
    //isSuitablePoint = isSuitablePoint && fabs(ps.p().m() - SMP::mV) < 2*SMP::wV;
    isSuitablePoint = isSuitablePoint && 40. < ps.a().m() && ps.a().m() < 60.;
    //isSuitablePoint = isSuitablePoint && 340. < ps.E_partonCMS() && ps.E_partonCMS() < 350.;
    if (isSuitablePoint) {
      ++numberOfRecordedPoints;
      cout << endl;
      cout << "Phase space configuration " << numberOfRecordedPoints << ":" << endl << endl;
      ps.print(cout);
      cout << endl;
      cout << "C++ code:" << endl;
      cout << "*****************************************************************" << endl;
      ps.printCode(cout);
      cout << "*****************************************************************" << endl;
    }
    if (numberOfRecordedPoints == 1) {
      terminate();     // stop GG2VV
    }
  }
  
  PhaseSpace truePS;
  bool isValidConfig = false;
#if defined PROCMACRO_WWZAZ_2l2v
  if ((numberOfPsMappings == 2 && type() == Mapping::WW) || (numberOfPsMappings == 4 && (type() == Mapping::RESONANTHIGGS+2*Mapping::WW || type() == Mapping::NONRESONANTHIGGS+2*Mapping::WW))) {
    if (AmpSqr::includesOnlyBackground(ampSqr.selection()) || nonresonantHiggsOnly) {
      Mapping::continuum_WW(x, truePS);
      isValidConfig = truePS.weight() > 0.0;
    }
    else if (resonantHiggsOnly || applyingHiggsNWA) {
      Mapping::higgsResonant_WW(x, truePS);
      isValidConfig = truePS.weight() > 0.0;
    }
    else {
      int sec = -1;
      if (numberOfPsMappings == 4 && type() == Mapping::RESONANTHIGGS+2*Mapping::WW) {
	Mapping::higgsResonant_WW(x, truePS);
	sec = Mapping::RESONANTHIGGS;
      }
      else if (numberOfPsMappings == 4 && type() == Mapping::NONRESONANTHIGGS+2*Mapping::WW) {
	Mapping::continuum_WW(x, truePS);
	sec = Mapping::NONRESONANTHIGGS;
      }
      else {
	fatal_error("unknown mapping:", type());
      }
      isValidConfig = truePS.weight() > 0.0 && isInSection(truePS, sec, SMP::mW, SMP::wW);
    }
  }
  else if ((numberOfPsMappings == 2 && type() == Mapping::ZZ) || (numberOfPsMappings == 4 && (type() == Mapping::RESONANTHIGGS+2*Mapping::ZZ || type() == Mapping::NONRESONANTHIGGS+2*Mapping::ZZ))) {
    if (AmpSqr::includesOnlyBackground(ampSqr.selection()) || nonresonantHiggsOnly) {
      Mapping::continuum_ZZ(x, truePS);
      isValidConfig = truePS.weight() > 0.0;
    }
    else if (resonantHiggsOnly || applyingHiggsNWA) {
      Mapping::higgsResonant_ZZ(x, truePS);
      isValidConfig = truePS.weight() > 0.0;
    }
    else {
      int sec = -1;
      if (numberOfPsMappings == 4 && type() == Mapping::RESONANTHIGGS+2*Mapping::ZZ) {
	Mapping::higgsResonant_ZZ(x, truePS);
	sec = Mapping::RESONANTHIGGS;
      }
      else if (numberOfPsMappings == 4 && type() == Mapping::NONRESONANTHIGGS+2*Mapping::ZZ) {
	Mapping::continuum_ZZ(x, truePS);
	sec = Mapping::NONRESONANTHIGGS;
      }
      else {
	fatal_error("unknown mapping:", type());
      }
      isValidConfig = truePS.weight() > 0.0 && isInSection(truePS, sec, SMP::mZ, SMP::wZ);
    }
  }
  else {
    fatal_error("error in mapping selection");
  }
#elif defined PROCMACRO_ZAZA2l2l || defined PROCMACRO_ZAZA4l
  if (AmpSqr::includesOnlyBackground(ampSqr.selection()) || resonantVVcontOnly) {
    Mapping::continuum(x, truePS);
    isValidConfig = truePS.weight() > 0.0;
  }
  else if (resonantHiggsOnly || applyingHiggsNWA) {
    Mapping::higgsResonant(x, truePS);
    isValidConfig = truePS.weight() > 0.0;
  }
  else if (nonresonantHiggsOnly) {
    if (type() == Mapping::NONRESONANTHIGGSBELOW) {
      Mapping::contSingleResV(x, truePS);
    }
    else if (type() == Mapping::NONRESONANTHIGGSABOVE) {
      Mapping::continuum(x, truePS);
    }
    else {
      fatal_error("unknown mapping:", type());
    }
    isValidConfig = truePS.weight() > 0.0 && isInSection(truePS, type(), SMP::mV, SMP::wV);
  }
  else {
    if (type() == Mapping::RESONANTHIGGS) {
      Mapping::higgsResonant(x, truePS);
    }
    else if (type() == Mapping::NONRESONANTHIGGSBELOW) {
      Mapping::contSingleResV(x, truePS);
    }
    else if (type() == Mapping::NONRESONANTHIGGSABOVE) {
      Mapping::continuum(x, truePS);
    }
    else {
      fatal_error("unknown mapping:", type());
    }
    isValidConfig = truePS.weight() > 0.0 && isInSection(truePS, type(), SMP::mV, SMP::wV);
  }
#else
  if (AmpSqr::includesOnlyBackground(ampSqr.selection()) || nonresonantHiggsOnly) {
    Mapping::continuum(x, truePS);
    isValidConfig = truePS.weight() > 0.0;
  }
  else if (resonantHiggsOnly || applyingHiggsNWA) {
    Mapping::higgsResonant(x, truePS);
    isValidConfig = truePS.weight() > 0.0;
  }
  else {
    if (type() == Mapping::RESONANTHIGGS) {
      Mapping::higgsResonant(x, truePS);
    }
    else if (type() == Mapping::NONRESONANTHIGGS) {
      Mapping::continuum(x, truePS);
    }
    else {
      fatal_error("unknown mapping:", type());
    }
    isValidConfig = truePS.weight() > 0.0 && isInSection(truePS, type(), SMP::mV, SMP::wV);
  }
#endif

  /*
  // for unweightEvents == true testing
  static Int64 counter = 0;
  static double sumEvtWeights = 0.;
  static int numberEvents = 0;
  static double sumExcessEvtWeight = 0.;
  counter += 1;
  */

  const PhaseSpace& measuredPS = truePS;     // perfect detector
  //PhaseSpace emptyPS;
  //const PhaseSpace measuredPS = (isValidConfig) ? detector_LHC(truePS) : emptyPS;

  vector<double>& dsigma = f;
  assert(generateEvents || dsigma.size() == scales_ptr_vector.size() + 4 || _calculatePDFError);
  if (isValidConfig && selection.includes(measuredPS, truePS)) {
    const double fbPerGeV2 = 3.893796623e11;
    double commonFactors = fbPerGeV2;
    commonFactors *= truePS.weight();   // dPS
    commonFactors *= ampSqr.ampSqr(truePS);   // |M|^2 with g_s := 1
    if (applyingHiggsNWA) {
	commonFactors *= 0.5*SMP::mH*SMP::wH;
    }
#if !defined PROCMACRO_WWZAZ_2l2v
    if (applyingNWA) {
	commonFactors *= pow2(0.5*SMP::mV*SMP::wV);     // 2 resonances
    }
#endif

    if (!generateEvents) {
      assert(scale_variation_factor > 1);
      const double svf = scale_variation_factor;
      scales_ptr_vector.at(0)->operator()(truePS, svf, svf);
      const double dsigma_0 = commonFactors*initStateProb(truePS, scales_ptr_vector[0]->factorizationScale())*scales_ptr_vector[0]->strongCouplingFactor();   // correct g_s := 1;
      dsigma[scales_ptr_vector.size()] = dsigma_0;
      scales_ptr_vector[0]->operator()(truePS, 1./svf, 1./svf);
      const double dsigma_1 = commonFactors*initStateProb(truePS, scales_ptr_vector[0]->factorizationScale())*scales_ptr_vector[0]->strongCouplingFactor();
      dsigma[scales_ptr_vector.size()+1] = dsigma_1;
      scales_ptr_vector[0]->operator()(truePS, svf, 1./svf);
      const double dsigma_2 = commonFactors*initStateProb(truePS, scales_ptr_vector[0]->factorizationScale())*scales_ptr_vector[0]->strongCouplingFactor();
      dsigma[scales_ptr_vector.size()+2] = dsigma_2;
      scales_ptr_vector[0]->operator()(truePS, 1./svf, svf);
      const double dsigma_3 = commonFactors*initStateProb(truePS, scales_ptr_vector[0]->factorizationScale())*scales_ptr_vector[0]->strongCouplingFactor();
      dsigma[scales_ptr_vector.size()+3] = dsigma_3;
    }
    for (int i_s = 0; i_s < scales_ptr_vector.size(); ++i_s) {
      Scales& scales = (*scales_ptr_vector[i_s]);
      scales(truePS);
      const double moreFactors = commonFactors*scales.strongCouplingFactor();
      dsigma[i_s] = moreFactors*initStateProb(truePS, scales.factorizationScale());
      if (_calculatePDFError && i_s == 0) {
	static const int maxMemberNumber = Pdf::getMaxMemberNumber();
	static const int offset = scales_ptr_vector.size() + 4;
	assert(dsigma.size() == offset + maxMemberNumber);
	for (int i_p = 0; i_p < maxMemberNumber; ++i_p) {
	  Pdf::setMemberNumber(1+i_p);
	  dsigma[offset+i_p] = moreFactors*initStateProb(truePS, scales.factorizationScale());
	}
	Pdf::setMemberNumber(0);
      }
    }

    if (_histoSuite) {
      _histoSuite->fill(truePS, measuredPS, dsigma[0], weight, type());
    }

    if (!(generateEvents && PartialEventSet::generatingEvents)) {
      const double thisEventWeight = dsigma[0]*weight;
      MaxEventWeightEstimate::addEstimateValue(thisEventWeight);
    }
    
    if (generateEvents && PartialEventSet::generatingEvents) {
      const double eventWeight = dsigma[0]*weight;
#if defined PROCMACRO_ZAZA2l2l || defined PROCMACRO_ZAZA4l
      int section = -1;
      if (numberOfPsMappings == 1) {
	section = 0;
      }
      else if (numberOfPsMappings == 2) {
	if (type() == Mapping::NONRESONANTHIGGSBELOW || type() == Mapping::RESONANTHIGGS) {
	  section = 0;
	}
	else if (type() == Mapping::NONRESONANTHIGGSABOVE) {
	  section = 1;
	}
	else {
	  fatal_error("unknown mapping:", type());
	}
      }
      else if (numberOfPsMappings == 3) {
	if (type() == Mapping::RESONANTHIGGS) {
	  section = 0;
	}
	else if (type() == Mapping::NONRESONANTHIGGSBELOW) {
	  section = 1;
	}
	else if (type() == Mapping::NONRESONANTHIGGSABOVE) {
	  section = 2;
	}
	else {
	  fatal_error("unknown mapping:", type());
	}
      }
      else {
	fatal_error("unknown numberOfPsMappings:", numberOfPsMappings);
      }
#else
      const int section = type();
#endif
      if (eventWeight > 0.) {
	const int& numberOfEvents = _partialEventSetVector[section].numberOfEvents;
	double& maxEventWeight = _partialEventSetVector[section].maxEventWeight;
	int& eventCounter = _partialEventSetVector[section].eventCounter;
	static Int64 shotsCounter = -1;     // for unweighting efficiency
	static Int64 excessCounter = -1;     // for excess weight criterion
	static double maxExcessWeight = -1.;
	if (unweightEvents) {
	  if (_partialEventSetVector[section].maxEventWeight == 0.) {     // first pass
	    shotsCounter = 0;
	    excessCounter = 0;
	    maxExcessWeight = 0.;
	  }
	  assert(shotsCounter >= 0);
	  ++shotsCounter;
	  const double& maxEventWeightEstimate = _partialEventSetVector[section].maxEventWeightEstimate;
	  if (eventWeight > maxEventWeightEstimate * randomNumberGenerator->uniformInZeroOne()) {
	    if (eventWeight < maxEventWeightEstimate) {
	      _partialEventSetVector[section].eventInfoVector.push_back(EventInfo(1., scales_ptr_vector.at(0)->factorizationScale(), scales_ptr_vector.at(0)->renormalizationScale(), truePS));
	      maxEventWeight = max(maxEventWeight, eventWeight);
	      ++eventCounter;
	    }
	    else {
	      maxExcessWeight = max(maxExcessWeight, eventWeight);
	      ++excessCounter;
	    }
	  }
	}
	else {
	  _partialEventSetVector[section].eventInfoVector.push_back(EventInfo(eventWeight, scales_ptr_vector.at(0)->factorizationScale(), scales_ptr_vector.at(0)->renormalizationScale(), truePS));
	  maxEventWeight = max(maxEventWeight, eventWeight);
	  ++eventCounter;
	}
	assert(eventCounter <= numberOfEvents);
	if (numberOfEvents >= 20 && eventCounter%(int(numberOfEvents/20.)) == 0)
	  printProgress(float(eventCounter)/numberOfEvents);
	if (eventCounter == numberOfEvents) {
	  printProgress(1.);
	  PartialEventSet::abortLoop = true;
	  if (unweightEvents) {
	    cout << endl << "Unweighting efficiency for section " << section << ": ";
	    cout << fixed << setprecision(2) << setw(5) << numberOfEvents/float(shotsCounter) * 100 << "%" << endl;
	    cout << excessCounter << " excess events (" << excessCounter/float(numberOfEvents) * 100 << "%), max excess event weight/max event weight estimate = ";
	    cout << setprecision(3) << maxExcessWeight/_partialEventSetVector[section].maxEventWeightEstimate << endl;
	    cout << setprecision(16);     // reset setprecision to default
	    cout.setf(ios_base::fmtflags(0), ios_base::floatfield);   // reset fixed to default
	  }
	}
      }
      else if (eventWeight < 0.) {
	static bool printWarning = true;
	if (printWarning) {
	  cerr << "WARNING: event with negative event weight occurred (PDF?) and has been discarded (recommended: check that negative contribution to cross section is negligible)" << endl;
	  printWarning = false;
	}
      }
    }
  }
  else {
    for (int i = 0; i < dsigma.size(); ++i) {
      dsigma[i] = 0.;  
    }
  }
}

// --------------------------------------------------------------

namespace HepSource
{
Integrand *const Integrand::make(const Type type)
{
  Integrand* integrand = 0;
  integrand = new GG2VV_Integrand();
  integrand->_type = type;
  return integrand;
}
}     // HepSource

#!/usr/bin/env python

import urllib
import string
import os
import sys
import glob

NEventsPreRun = 5000 #set to zero if the initialization has already been run and you just want to do more stat
mHlist = [200, 250, 300, 350, 400, 450, 500, 550, 600, 650, 700, 750, 800, 850, 900, 950, 1000]
Plist  = [0,1,2]
CPlist = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0]

NEventsPreRun = 10000
#mHlist = [1000]
#CPlist = [0.5]

NEventsPerRun = 100000
NRuns = 25
FirstRun = 0;

for P in Plist:
   for mH in mHlist:
      for CP in CPlist:
            JobName = str(mH) + '_' + str(P) + '_' + str(CP)
            if(P==0 and not (mH==200 and CP==1.0)):
               for R in range(FirstRun,NRuns):
                  os.system('rm results/'+JobName+'/gg2VV_'+str(R) + '_histo.root'
               continue
           
            rmcommand = ''
            haddcommand = 'hadd -f results/'+JobName+'/histo.root ' 
            if(os.path.isfile(os.getcwd()+'/results/'+JobName+'/histo.root') ):
               haddcommand += 'results/'+JobName+'/histo.root ' 
            for R in range(FirstRun,NRuns):
               if(os.path.isfile(os.getcwd()+'/results/'+JobName+'/gg2VV_'+str(R) + '_histo.root') ): 
                  haddcommand += 'results/'+JobName+'/gg2VV_'+str(R)+'_histo.root '
                  rmcommand += 'rm -f results/'+JobName+'/gg2VV_'+str(R)+'_histo.root; '
                  rmcommand += 'ln -s results/'+JobName+'/histo.root results/'+JobName+'/gg2VV_'+str(R)+'_histo.rootDeleted ;'
            os.system(haddcommand)
            os.system(rmcommand)

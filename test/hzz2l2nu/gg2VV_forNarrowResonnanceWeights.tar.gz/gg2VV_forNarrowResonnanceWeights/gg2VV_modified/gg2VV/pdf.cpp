#include <vector>
using std::vector;
#include <cmath>
using std::sqrt;
#include <cassert>
/* assert macro */
#include <iostream>
using std::ostream;
using std::cout;
#include <iomanip>
using std::endl;
using std::setprecision;

#include "pdf.h"
#include "utilities.h"
#include "geometry.h"
#include "small_powers.h"

const int Pdf::T_ = -6 + 6;
const int Pdf::B_ = -5 + 6;
const int Pdf::C_ = -4 + 6;
const int Pdf::S_ = -3 + 6;
const int Pdf::U_ = -2 + 6;
const int Pdf::D_ = -1 + 6;
const int Pdf::G = 0 + 6;
const int Pdf::D = 1 + 6;
const int Pdf::U = 2 + 6;
const int Pdf::S = 3 + 6;
const int Pdf::C = 4 + 6;
const int Pdf::B = 5 + 6;
const int Pdf::T = 6 + 6;

// LHAPDF Fortran function declarations:
extern "C"
{
void initpdfset_(const char* filepath, unsigned int filepathLength);
void numberpdf_(int* maxMemberNumber);
void initpdf_(const int* memberNumber);
void evolvepdf_(const double* x,  const double* Q, double xpdf[]);
}

void Pdf::initialize()
{
  initpdfset_(_pathToLhapdfInputFile.c_str(), _pathToLhapdfInputFile.length());
  setMemberNumber(0);     // default: "best fit" PDF
}

const int Pdf::getMaxMemberNumber()
{
  int maxMemberNumber = 0;
  numberpdf_(&maxMemberNumber);
  return maxMemberNumber;
}

void Pdf::setMemberNumber(const int memberNumber)
{
  initpdf_(&memberNumber);
}

const string Pdf::pdfsetName()
{
  const string& pdfpath = _pathToLhapdfInputFile;
  const int startpos = pdfpath.rfind("/")+1;
  return string(pdfpath, startpos, pdfpath.length()-startpos);
}

Pdf::Pdf(const Type type)
  : _type(type)
{}

Pdf::Pdf(const Pdf& pdf)
  : _type(pdf._type)
{}

Pdf::ThreeGen::ThreeGen(const double first_, const double second_, const double third_)
  : first(first_), second(second_), third(third_)
{}

Pdf::ThreeGen::ThreeGen()
  : first(0.), second(0.), third(0.)
{}

void Pdf::operator()(const double x, const double factorizationScale)
{
  static double xpdf[13];     // proton content
  evolvepdf_(&x, &factorizationScale, xpdf);

  _g = xpdf[G]/x;
  switch (_type) {
  case PROTON:
    _u = ThreeGen(xpdf[U]/x, xpdf[C]/x, xpdf[T]/x);
    _u_ = ThreeGen(xpdf[U_]/x, xpdf[C_]/x, xpdf[T_]/x);
    _d = ThreeGen(xpdf[D]/x, xpdf[S]/x, xpdf[B]/x);
    _d_ = ThreeGen(xpdf[D_]/x, xpdf[S_]/x, xpdf[B_]/x);
    break;
  case ANTIPROTON:
    _u = ThreeGen(xpdf[U_]/x, xpdf[C_]/x, xpdf[T_]/x);
    _u_ = ThreeGen(xpdf[U]/x, xpdf[C]/x, xpdf[T]/x);
    _d = ThreeGen(xpdf[D_]/x, xpdf[S_]/x, xpdf[B_]/x);
    _d_ = ThreeGen(xpdf[D]/x, xpdf[S]/x, xpdf[B]/x);
    break;
  default:
    fatal_error("Pdf: invalid type: ", _type);
  }
}

// ---------------------------------------------------------------------

const AsymmetricError getErrorForPDFHepdataMethod(const double centralValue, const vector<double>& noncentralValues)
{
  const int N = noncentralValues.size();
  assert(N%2 == 0);
  const int n = N/2;
  vector<double> plusValues;
  vector<double> minusValues;
  // member=1: f_1^(+), member=2: f_1^(-), member=3: f_2^(+), ...
  int i = 0;
  while (i < N) {
    plusValues.push_back(noncentralValues[i]);
    ++i;
    minusValues.push_back(noncentralValues[i]);
    ++i;
  }
  assert(plusValues.size() == n);
  assert(minusValues.size() == n);
  double delta_plus_square = 0.;
  double delta_minus_square = 0.;
  for (int j = 0; j < n; ++j) {
    const double plusValue = plusValues[j];
    const double minusValue = minusValues[j];
    delta_plus_square += pow2(max(plusValue-centralValue, minusValue-centralValue, 0.));
    delta_minus_square += pow2(max(centralValue-plusValue, centralValue-minusValue, 0.));
  }
  AsymmetricError error;
  error.plus = sqrt(delta_plus_square);
  error.minus = sqrt(delta_minus_square);
  return error;
}

// ---------------------------------------------------------------------

const CentralValueAndErrorForEnsemble getResultsForPDFMonteCarloMethod(const vector<double>& noncentralValues)
{
  const int N = noncentralValues.size();
  double sum = 0.;
  double sumSqr = 0.;
  for (int i = 0; i < N; ++i) {
    sum += noncentralValues[i];
    sumSqr += pow2(noncentralValues[i]);
  }
  CentralValueAndErrorForEnsemble result;
  assert(N > 1);
  result.centralValue = sum/double(N);
  result.error = sqrt(N/(N-1.)*(sumSqr/double(N) - pow2(result.centralValue)));
  return result;
}

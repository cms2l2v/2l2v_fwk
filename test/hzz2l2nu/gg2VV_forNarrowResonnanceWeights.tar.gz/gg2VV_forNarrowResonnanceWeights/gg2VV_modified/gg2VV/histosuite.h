#ifndef HISTOSUITE_H
#define HISTOSUITE_H

#include "omnihistosuite.h"
#include "histo.h"
#include "phasespace.h"

#include <vector>

class HistoSuite : public HepSource::OmniHistoSuite
{
public:
  HistoSuite();
  void fill(const PhaseSpace& truePS, const PhaseSpace& measuredPS,
            const double dsigma, const double weight, const int type);
  void print(ostream& os);     // output for human readers
  static void printVerbatim(ostream& os, const string& s);    // headers, comments etc.
  HistoSuite& operator+=(const HistoSuite& partial);
  void updateEstimatesWithPartialEstimates();
  // OmniHistoSuite interface:
  void updatePartialEstimates(const Int64 numberOfShots);
  void toStream(ostream& os);
  HistoSuite *const cloneEmpty() const;
  void fromStream(istream& is);
  HistoSuite& operator+=(const OmniHistoSuite& partial);
  ~HistoSuite();
private:
  const int continuumMappingDim;
  const int higgsResonantMappingDim;
  const int numberOfNamedHistograms();
  
  typedef Histo* PHisto;
  typedef vector<PHisto> PHistoList;
  typedef PHisto& RPHisto;

  PHistoList list;

  // histograms ===================================================

  RPHisto m4l;
  RPHisto ma;
  RPHisto ma2;
  RPHisto mp;
  RPHisto mp2;

  RPHisto etal;
  RPHisto ptl;
  RPHisto ptmiss;
  RPHisto ptlmax;
  RPHisto ptlmin;
  RPHisto mll;
  RPHisto absdeletall;
  RPHisto abscosthetallsys;
  RPHisto costhetall;
  RPHisto absdelphill;
};

#endif     /* HISTOSUITE_H */

#ifndef PHASESPACE_H
#define PHASESPACE_H

#include <vector>
using std::vector;
#include <iostream>
using std::ostream;

#include "constvalue.h"
#include "geometry.h"

struct PhaseSpace 
{
  static ConstValue<double> E_CMS;  // root_s
  ConstValue<double> E_partonCMS;   // root_shat

  ConstValue<FourMomentum> i;    // incoming parton from hadron 1 (p)
  ConstValue<double> x;          // Bjorken x (momentum fraction)
  ConstValue<FourMomentum> i_;   // incoming parton from hadron 2 (p~ or p)
  ConstValue<double> x_;

  ConstValue<FourMomentum> aa;   // antiparticle from intermediate antiparticle
  ConstValue<FourMomentum> ap;   // particle from intermediate antiparticle
  ConstValue<FourMomentum> pa;   // antiparticle from intermediate particle
  ConstValue<FourMomentum> pp;   // particle from intermediate particle
  ConstValue<FourMomentum> a;    // intermediate state (antiparticle): a = aa + ap
  ConstValue<FourMomentum> p;    // intermediate state (particle): p = pa + pp

  ConstValue<FourMomentum> a2;    // intermediate state: a2 := aa + pp
  ConstValue<FourMomentum> p2;    // intermediate state: p2 := pa + ap

  // for PROCMACRO_WWZAZ_2l2v:
  // a2 = a in ZAZ_2l2v
  // p2 = p in ZAZ_2l2v

  //  i     i_        aa          ap         pa          pp
  // ---------------------------------------------------------
  // WW2l2v:
  //  g     g         e+          nu_e       {nu_bar}_mu mu-       
  // ---------------------------------------------------------
  // ZAZA2l2l:
  //  g     g         e+          e-         mu+         mu-       
  // ---------------------------------------------------------
  // ZAZ_2l2v:
  //  g     g         e+          e-         {nu_bar}_mu nu_mu     
  // ---------------------------------------------------------
  // ZAZA4l:
  //  g     g         e+          e-         e+          e-        
  // ---------------------------------------------------------
  // WWZAZ_2l2v (2l2v_sameflav_fullamp):
  //  g     g         e+          nu_e       {nu_bar}_e  e-        
  // ---------------------------------------------------------
  // WWlvqq:
  //  g     g         e+          nu_e       u_bar       d       
  // ---------------------------------------------------------
  // WWqqlv:
  //  g     g         d_bar       u          {nu_bar}_e  e-

  ConstValue<double> weight;              // weight of sampled phase space point

  void check() const;   // check phase space consistency
  void print(ostream& os) const;          // print phase space configuration
  void printCode(ostream& os) const;      // print C++ code to create PhaseSpace object

  ConstValue< vector<double> > randomNumber;     // histos to check mapping quality

  PhaseSpace();
};

const PhaseSpace boost(const PhaseSpace& ps, const FourVector& r, const bool reverse_r = false);

inline const PhaseSpace boostToCMS(const PhaseSpace& ps)
{
  const FourMomentum in(ps.i() + ps.i_());
  return boost(ps, in, true);
}

const PhaseSpace map_to_float(const PhaseSpace& ps);

void checkAndCompletePhaseSpace(PhaseSpace& ps);

void completePhaseSpace(PhaseSpace& ps);

namespace Mapping
{
enum Type { RESONANTHIGGS, NONRESONANTHIGGS, NONRESONANTHIGGSBELOW, NONRESONANTHIGGSABOVE };
void continuum(const vector<double>& randomNumber, PhaseSpace& ps);
void contSingleResV(const vector<double>& randomNumber, PhaseSpace& ps);
void higgsResonant(const vector<double>& randomNumber, PhaseSpace& ps);

#if defined PROCMACRO_WWZAZ_2l2v
enum VVType { WW, ZZ };
void continuum_WW(const vector<double>& randomNumber, PhaseSpace& ps);
void higgsResonant_WW(const vector<double>& randomNumber, PhaseSpace& ps);
void continuum_ZZ(const vector<double>& randomNumber, PhaseSpace& ps);
void higgsResonant_ZZ(const vector<double>& randomNumber, PhaseSpace& ps);
#endif

const bool minInvMassPhotonPropCutsPassed(const PhaseSpace& truePS);
}

#endif  /* PHASESPACE_H */

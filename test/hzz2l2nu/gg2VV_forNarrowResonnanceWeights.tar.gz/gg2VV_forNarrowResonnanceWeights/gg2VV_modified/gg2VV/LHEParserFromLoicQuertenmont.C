#include <string>
#include <vector>
#include "TLorentzVector.h"
#include "TH1.h"
#include "TFile.h"

TH1D* readHistoFromDatFile(string filePath, string name){
  FILE* pFile = fopen(filePath.c_str(), "r");
  if(!pFile){printf("File can not be open:\n%s\n", filePath.c_str()); return NULL;}

  //read file line by line
  char line[4096];
  TH1D* histo = new TH1D(name.c_str(), "mZZ", 4000, 0, 4000);
  std::vector<TLorentzVector> Lep;
  double weight=0;  bool ProcessEvent = false;  int EventLine=0;   double xsection=0;
  while(true){
     if(! fgets(line, 4096, pFile))break;

     //printf("%i %s", ProcessEvent?1:0, line);
     string strLine = string(line);
     if(strLine.find("<init>")==0){
        if(! fgets(line, 4096, pFile))break; //read one more line --> skip^it
        if(! fgets(line, 4096, pFile))break; //read xsection line
           sscanf(line, "%lf", &xsection);
     }
     if(strLine.find("<event>")==0){
        Lep.clear();
        weight=0;    
        ProcessEvent = true;   EventLine=0;
     }else if(strLine.find("</event>")==0){
        histo->Fill((Lep[0]+Lep[1]+Lep[2]+Lep[3]).M(), weight);
        ProcessEvent = false;
     }else if(ProcessEvent){
        EventLine++;
        int Id; int UnusedInt;
        double Px, Py, Pz, E;
        sscanf(line, "%d", &Id);        
        if(EventLine==1){ //read event weight from the first line entry within the event
           sscanf(line, "%d %d %lf", &Id, &UnusedInt, &weight);                    
        }else if(abs(Id)>=11 && abs(Id)<=16){
           sscanf(line, "%d %d %d %d %d %d %lf %lf %lf %lf", &Id, &UnusedInt, &UnusedInt, &UnusedInt, &UnusedInt, &UnusedInt, &Px, &Py, &Pz, &E); 
           Lep.push_back(TLorentzVector(Px, Py, Pz, E));
        }
     }
  }//end parsing the file
  fclose(pFile);

  //scale to xsection
  histo->Scale(xsection / histo->Integral());
  return histo;
}

void LHEParserFromLoicQuertenmont(string InFilePath="", string OutFilePath="out.root")
{
     if(InFilePath == "")return;
     TFile* OutputFile = new TFile(OutFilePath.c_str(), "RECREATE");
     TH1D* mZZ = readHistoFromDatFile(InFilePath, "mZZ");
     mZZ->Write();
     OutputFile->Close();
}











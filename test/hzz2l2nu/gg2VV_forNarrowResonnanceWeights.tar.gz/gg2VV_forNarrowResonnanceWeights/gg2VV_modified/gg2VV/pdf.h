#ifndef PDF_H
#define PDF_H

#include <string>
using std::string;

class Pdf
{
public:
  enum Type { PROTON, ANTIPROTON };
  Pdf(const Type type);
  Pdf(const Pdf& pdf);
  struct ThreeGen 
  {
    double first;
    double second;
    double third;
    ThreeGen(const double first, const double second, const double third);
    ThreeGen();
  };

  void operator()(const double x, const double factorizationScale);

  const double g() const;
  const ThreeGen u() const;
  const ThreeGen u_() const;
  const ThreeGen d() const;
  const ThreeGen d_() const;

  static void initialize();
  static const int getMaxMemberNumber();
  static void setMemberNumber(const int memberNumber);
  static const string pdfsetName();
private:
  const Type _type;

  double _g;
  ThreeGen _u;
  ThreeGen _u_;
  ThreeGen _d;
  ThreeGen _d_;

  // implementation: LHAPDFv2
  static const int T_;
  static const int B_;
  static const int C_;
  static const int S_;
  static const int U_;
  static const int D_;
  static const int G;
  static const int D;
  static const int U;
  static const int S;
  static const int C;
  static const int B;
  static const int T;
  static const string _pathToLhapdfInputFile;     // defined in settings.cpp
};

inline const double Pdf::g() const { return _g; }
inline const Pdf::ThreeGen Pdf::u() const { return _u; }
inline const Pdf::ThreeGen Pdf::u_() const { return _u_; }
inline const Pdf::ThreeGen Pdf::d() const { return _d; }
inline const Pdf::ThreeGen Pdf::d_() const { return _d_; }

inline const double operator*(const Pdf::ThreeGen& tg1, const Pdf::ThreeGen& tg2)
{
  return tg1.first * tg2.first + tg1.second * tg2.second + tg1.third * tg2.third;
}

inline const double operator*(const Pdf::ThreeGen& tg, const double d)
{
  return (tg.first + tg.second + tg.third) * d;
}

inline const double operator*(const double d, const Pdf::ThreeGen& tg)
{
  return tg * d;
}

// ---------------------------------------------------------------------

struct AsymmetricError
{
  double plus;
  double minus;
};

const AsymmetricError getErrorForPDFHepdataMethod(const double centralValue, const vector<double>& noncentralValues);

struct CentralValueAndErrorForEnsemble
{
  double centralValue;
  double error;
};

const CentralValueAndErrorForEnsemble getResultsForPDFMonteCarloMethod(const vector<double>& noncentralValues);

#endif  /* PDF_H */

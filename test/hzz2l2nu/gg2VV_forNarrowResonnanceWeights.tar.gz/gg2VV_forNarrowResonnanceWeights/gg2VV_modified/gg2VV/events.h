#ifndef EVENTS_H
#define EVENTS_H

#include <iostream>
using std::ostream;
#include <string>
using std::string;

#include "phasespace.h"

const bool writeEvent(ostream& os, const double weight,
		      const double factorizationScale, 
		      const double renormalizationScale, 
		      const PhaseSpace& truePS);

void writeEventFile(const string eventsFilename);

struct EventInfo
{
  double weight;
  double factorizationScale;
  double renormalizationScale;
  PhaseSpace truePS;
  EventInfo(const double weight, const double factorizationScale, const double renormalizationScale, const PhaseSpace truePS);
};

struct PartialEventSet
{
  PartialEventSet();

  vector<EventInfo> eventInfoVector;

  int numberOfEvents;
  int eventCounter;
  double xsecValEstimate;
  double xsecErrEstimate;
  double maxEventWeight;
  double maxEventWeightEstimate;
  
  static bool generatingEvents;
  static bool abortLoop;
};

void setNumberOfEventsForSections(const int totNumberOfEvents, vector<PartialEventSet>& partialEventSetVector);

void printProgress(const double fraction);

extern vector<PartialEventSet> _partialEventSetVector;

#endif     /* EVENTS_H */

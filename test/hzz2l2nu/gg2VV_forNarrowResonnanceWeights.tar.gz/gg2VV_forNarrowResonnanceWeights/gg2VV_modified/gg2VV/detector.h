#ifndef DETECTOR_H
#define DETECTOR_H

#include "phasespace.h"

const FourVector resolveChargedLepton(const FourMomentum& fm);
const FourVector resolveHadron(const FourMomentum& fm);
const FourVector resolveMissmom(const FourMomentum& fm_miss);

const PhaseSpace detector_LHC(const PhaseSpace& truePS);

#endif  /* DETECTOR_H */

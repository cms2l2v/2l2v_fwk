#include <iostream>
using std::cout;
using std::ostream;
#include <fstream>
using std::ofstream;
#include <iomanip>
using std::endl;
using std::setprecision;
using std::setw;
using std::fixed;
#include <ios>
using std::ios_base;
#include <string>
using std::string;
#include <cmath>

#include "events.h"
#include "givemass.h"
#include "settings.h"
#include "rng.h"
#include "utilities.h"
#include "pdf.h"

namespace
{
const PhaseSpace giveLeptonsMass(const PhaseSpace& ps, const string& aa_flavor, const string& ap_flavor, const string& pa_flavor, const string& pp_flavor, bool& hasSucceeded)

{
  hasSucceeded = true;
  static Givemass gm;
  PhaseSpace ps_lept_mass;
  ps_lept_mass.i.set(ps.i());
  ps_lept_mass.i_.set(ps.i_());

#if defined PROCMACRO_WW2l2v || defined PROCMACRO_WWZAZ_2l2v
  if (pp_flavor == "13 ") {     // muon decay mode
    gm(ps.pp(), SMP::mmuon, ps.pa(), 0.);
    if (!gm.isAllowed()) {
      hasSucceeded = false;
      return PhaseSpace();
    }
    ps_lept_mass.pp.set(gm.p1());
    ps_lept_mass.pa.set(gm.p2());
  }
  else if (pp_flavor == "15 ") {     // tau decay mode
    gm(ps.pp(), SMP::mtau, ps.pa(), 0.);
    if (!gm.isAllowed()) {
      hasSucceeded = false;
      return PhaseSpace();
    }
    ps_lept_mass.pp.set(gm.p1());
    ps_lept_mass.pa.set(gm.p2());
  }
  else {
    if (ps.pp().m2() < 0.) {
      ps_lept_mass.pp.set(getRepairNegativeMass(ps.pp()));
    }
    else {
      ps_lept_mass.pp.set(ps.pp());
    }

    if (ps.pa().m2() < 0.) {
      ps_lept_mass.pa.set(getRepairNegativeMass(ps.pa()));
    }
    else {
      ps_lept_mass.pa.set(ps.pa());
    }
  }

  if (aa_flavor == "-13 ") {     // muon decay mode
    gm(ps.aa(), SMP::mmuon, ps.ap(), 0.);
    if (!gm.isAllowed()) {
      hasSucceeded = false;
      return PhaseSpace();
    }
    ps_lept_mass.aa.set(gm.p1());
    ps_lept_mass.ap.set(gm.p2());
  }
  else if (aa_flavor == "-15 ") {     // tau decay mode
    gm(ps.aa(), SMP::mtau, ps.ap(), 0.);
    if (!gm.isAllowed()) {
      hasSucceeded = false;
      return PhaseSpace();
    }
    ps_lept_mass.aa.set(gm.p1());
    ps_lept_mass.ap.set(gm.p2());
  }
  else {
    if (ps.aa().m2() < 0.) {
      ps_lept_mass.aa.set(getRepairNegativeMass(ps.aa()));
    }
    else {
      ps_lept_mass.aa.set(ps.aa());
    }

    if (ps.ap().m2() < 0.) {
      ps_lept_mass.ap.set(getRepairNegativeMass(ps.ap()));
    }
    else {
      ps_lept_mass.ap.set(ps.ap());
    }
  }
#elif defined PROCMACRO_ZAZ_2l2v
  if (ap_flavor == "13 ") {
    gm(ps.aa(), SMP::mmuon, ps.ap(), SMP::mmuon);
    if (!gm.isAllowed()) {
      hasSucceeded = false;
      return PhaseSpace();
    }
    ps_lept_mass.aa.set(gm.p1());
    ps_lept_mass.ap.set(gm.p2());
  }
  else if (ap_flavor == "15 ") {
    gm(ps.aa(), SMP::mtau, ps.ap(), SMP::mtau);
    if (!gm.isAllowed()) {
      hasSucceeded = false;
      return PhaseSpace();
    }
    ps_lept_mass.aa.set(gm.p1());
    ps_lept_mass.ap.set(gm.p2());
  }
  else {
    if (ps.aa().m2() < 0.) {
      ps_lept_mass.aa.set(getRepairNegativeMass(ps.aa()));
    }
    else {
      ps_lept_mass.aa.set(ps.aa());
    }

    if (ps.ap().m2() < 0.) {
      ps_lept_mass.ap.set(getRepairNegativeMass(ps.ap()));
    }
    else {
      ps_lept_mass.ap.set(ps.ap());
    }
  }

  if (ps.pa().m2() < 0.) {
    ps_lept_mass.pa.set(getRepairNegativeMass(ps.pa()));
  }
  else {
    ps_lept_mass.pa.set(ps.pa());
  }

  if (ps.pp().m2() < 0.) {
    ps_lept_mass.pp.set(getRepairNegativeMass(ps.pp()));
  }
  else {
    ps_lept_mass.pp.set(ps.pp());
  }
#elif defined PROCMACRO_ZAZA2l2l
  if (ap_flavor == "13 ") {
    gm(ps.aa(), SMP::mmuon, ps.ap(), SMP::mmuon);
    if (!gm.isAllowed()) {
      hasSucceeded = false;
      return PhaseSpace();
    }
    ps_lept_mass.aa.set(gm.p1());
    ps_lept_mass.ap.set(gm.p2());
  }
  else if (ap_flavor == "15 ") {
    gm(ps.aa(), SMP::mtau, ps.ap(), SMP::mtau);
    if (!gm.isAllowed()) {
      hasSucceeded = false;
      return PhaseSpace();
    }
    ps_lept_mass.aa.set(gm.p1());
    ps_lept_mass.ap.set(gm.p2());
  }
  else {
    if (ps.aa().m2() < 0.) {
      ps_lept_mass.aa.set(getRepairNegativeMass(ps.aa()));
    }
    else {
      ps_lept_mass.aa.set(ps.aa());
    }

    if (ps.ap().m2() < 0.) {
      ps_lept_mass.ap.set(getRepairNegativeMass(ps.ap()));
    }
    else {
      ps_lept_mass.ap.set(ps.ap());
    }
  }

  if (pp_flavor == "13 ") {
    gm(ps.pa(), SMP::mmuon, ps.pp(), SMP::mmuon);
    if (!gm.isAllowed()) {
      hasSucceeded = false;
      return PhaseSpace();
    }
    ps_lept_mass.pa.set(gm.p1());
    ps_lept_mass.pp.set(gm.p2());
  }
  else if (pp_flavor == "15 ") {
    gm(ps.pa(), SMP::mtau, ps.pp(), SMP::mtau);
    if (!gm.isAllowed()) {
      hasSucceeded = false;
      return PhaseSpace();
    }
    ps_lept_mass.pa.set(gm.p1());
    ps_lept_mass.pp.set(gm.p2());
  }
  else {
    if (ps.pa().m2() < 0.) {
      ps_lept_mass.pa.set(getRepairNegativeMass(ps.pa()));
    }
    else {
      ps_lept_mass.pa.set(ps.pa());
    }

    if (ps.pp().m2() < 0.) {
      ps_lept_mass.pp.set(getRepairNegativeMass(ps.pp()));
    }
    else {
      ps_lept_mass.pp.set(ps.pp());
    }
  }
#elif defined PROCMACRO_ZAZA4l
  if (ap_flavor == "13 ") {
    gm(ps.aa(), SMP::mmuon, ps.ap(), SMP::mmuon);
    if (!gm.isAllowed()) {
      hasSucceeded = false;
      return PhaseSpace();
    }
    ps_lept_mass.aa.set(gm.p1());
    ps_lept_mass.ap.set(gm.p2());
    gm(ps.pa(), SMP::mmuon, ps.pp(), SMP::mmuon);
    if (!gm.isAllowed()) {
      hasSucceeded = false;
      return PhaseSpace();
    }
    ps_lept_mass.pa.set(gm.p1());
    ps_lept_mass.pp.set(gm.p2());
  }
  else if (ap_flavor == "15 ") {
    gm(ps.aa(), SMP::mtau, ps.ap(), SMP::mtau);
    if (!gm.isAllowed()) {
      hasSucceeded = false;
      return PhaseSpace();
    }
    ps_lept_mass.aa.set(gm.p1());
    ps_lept_mass.ap.set(gm.p2());
    gm(ps.pa(), SMP::mtau, ps.pp(), SMP::mtau);
    if (!gm.isAllowed()) {
      hasSucceeded = false;
      return PhaseSpace();
    }
    ps_lept_mass.pa.set(gm.p1());
    ps_lept_mass.pp.set(gm.p2());
  }
  else {
    if (ps.aa().m2() < 0.) {
      ps_lept_mass.aa.set(getRepairNegativeMass(ps.aa()));
    }
    else {
      ps_lept_mass.aa.set(ps.aa());
    }

    if (ps.ap().m2() < 0.) {
      ps_lept_mass.ap.set(getRepairNegativeMass(ps.ap()));
    }
    else {
      ps_lept_mass.ap.set(ps.ap());
    }

    if (ps.pa().m2() < 0.) {
      ps_lept_mass.pa.set(getRepairNegativeMass(ps.pa()));
    }
    else {
      ps_lept_mass.pa.set(ps.pa());
    }

    if (ps.pp().m2() < 0.) {
      ps_lept_mass.pp.set(getRepairNegativeMass(ps.pp()));
    }
    else {
      ps_lept_mass.pp.set(ps.pp());
    }
  }
#else
     fatal_error("Error: giveLeptonsMass(): unknown PROCMACRO");
#endif

  completePhaseSpace(ps_lept_mass);
  return ps_lept_mass;
}

const int getNumFlavourComb()
{
#if defined PROCMACRO_WW2l2v
    return 6;
#elif defined PROCMACRO_ZAZ_2l2v
    return 6;
#elif defined PROCMACRO_ZAZA2l2l
    return 3;
#elif defined PROCMACRO_ZAZA4l
    return 3;
#elif defined PROCMACRO_WWZAZ_2l2v
    return 3;
#else
     fatal_error("Error: getNumFlavourComb(): unknown PROCMACRO");
     return 0;
#endif
}  
}     // unnamed namespace

const bool writeEvent(ostream& os, const EventInfo& eventInfo)
{
  const double weight = eventInfo.weight;
  const double factorizationScale = eventInfo.factorizationScale;
  const double renormalizationScale = eventInfo.renormalizationScale;
  const PhaseSpace& truePS = eventInfo.truePS;
  
  /*
  // test flavor sampling
  static int eCount1 = 0;
  static int mCount1 = 0;
  static int tCount1 = 0;
  static int eCount2 = 0;
  static int mCount2 = 0;
  static int tCount2 = 0;
  static int counter = 0;
  counter += 1;
  */

  /*
  lepton IDs: (add minus sign for anti-particle)
  e-     11,   nu_e     12
  mu-    13,   nu_mu    14
  tau-   15,   nu_tau   16
  */

  string aa_flavor;
  string ap_flavor;
  string pa_flavor;
  string pp_flavor;

  const int numFlavourComb = getNumFlavourComb();
  const int flavorSwitch = int(randomNumberGenerator->uniformInZeroOne()*numFlavourComb);

#if defined PROCMACRO_WW2l2v
  switch (flavorSwitch) {
  case 0:
    aa_flavor = "-11 "; ap_flavor = "12 ";     // W^+ -> electron
    pa_flavor = "-14 "; pp_flavor = "13 ";     // W^- -> muon
    break;
  case 1:
    aa_flavor = "-11 "; ap_flavor = "12 ";     // W^+ -> electron
    pa_flavor = "-16 "; pp_flavor = "15 ";     // W^- -> tau
    break;
  case 2:
    aa_flavor = "-13 "; ap_flavor = "14 ";     // W^+ -> muon
    pa_flavor = "-16 "; pp_flavor = "15 ";     // W^- -> tau
    break;
  case 3:
    aa_flavor = "-13 "; ap_flavor = "14 ";     // W^+ -> muon
    pa_flavor = "-12 "; pp_flavor = "11 ";     // W^- -> electron
    break;
  case 4:
    aa_flavor = "-15 "; ap_flavor = "16 ";     // W^+ -> tau
    pa_flavor = "-12 "; pp_flavor = "11 ";     // W^- -> electron
    break;
  case 5:
    aa_flavor = "-15 "; ap_flavor = "16 ";     // W^+ -> tau
    pa_flavor = "-14 "; pp_flavor = "13 ";     // W^- -> muon
    break;
  default:
    fatal_error("writeEvent: invalid switch value", flavorSwitch);
  }
#elif defined PROCMACRO_ZAZ_2l2v
  switch (flavorSwitch) {
  case 0:
    aa_flavor = "-11 "; ap_flavor = "11 ";     // Z -> electron
    pa_flavor = "-14 "; pp_flavor = "14 ";     // Z -> muon neutrino
    break;
  case 1:
    aa_flavor = "-11 "; ap_flavor = "11 ";     // Z -> electron
    pa_flavor = "-16 "; pp_flavor = "16 ";     // Z -> tau neutrino
    break;
  case 2:
    aa_flavor = "-13 "; ap_flavor = "13 ";     // Z -> muon
    pa_flavor = "-16 "; pp_flavor = "16 ";     // Z -> tau neutrino
    break;
  case 3:
    aa_flavor = "-13 "; ap_flavor = "13 ";     // Z -> muon
    pa_flavor = "-12 "; pp_flavor = "12 ";     // Z -> electron neutrino
    break;
  case 4:
    aa_flavor = "-15 "; ap_flavor = "15 ";     // Z -> tau
    pa_flavor = "-12 "; pp_flavor = "12 ";     // Z -> electron neutrino
    break;
  case 5:
    aa_flavor = "-15 "; ap_flavor = "15 ";     // Z -> tau
    pa_flavor = "-14 "; pp_flavor = "14 ";     // Z -> muon neutrino
    break;
  default:
    fatal_error("writeEvent: invalid switch value", flavorSwitch);
  }
#elif defined PROCMACRO_ZAZA2l2l
  switch (flavorSwitch) {
  case 0:
    aa_flavor = "-11 "; ap_flavor = "11 ";
    pa_flavor = "-13 "; pp_flavor = "13 ";
    break;
  case 1:
    aa_flavor = "-11 "; ap_flavor = "11 ";
    pa_flavor = "-15 "; pp_flavor = "15 ";
    break;
  case 2:
    aa_flavor = "-13 "; ap_flavor = "13 ";
    pa_flavor = "-15 "; pp_flavor = "15 ";
    break;
  default:
    fatal_error("writeEvent: invalid switch value", flavorSwitch);
  }
#elif defined PROCMACRO_ZAZA4l
  switch (flavorSwitch) {
  case 0:
    aa_flavor = "-11 "; ap_flavor = "11 ";
    pa_flavor = "-11 "; pp_flavor = "11 ";
    break;
  case 1:
    aa_flavor = "-13 "; ap_flavor = "13 ";
    pa_flavor = "-13 "; pp_flavor = "13 ";
    break;
  case 2:
    aa_flavor = "-15 "; ap_flavor = "15 ";
    pa_flavor = "-15 "; pp_flavor = "15 ";
    break;
  default:
    fatal_error("writeEvent: invalid switch value", flavorSwitch);
  }
#elif defined PROCMACRO_WWZAZ_2l2v
  switch (flavorSwitch) {
  case 0:
    aa_flavor = "-11 "; ap_flavor = "12 ";     // W^+ -> electron
    pa_flavor = "-12 "; pp_flavor = "11 ";     // W^- -> electron
    break;
  case 1:
    aa_flavor = "-13 "; ap_flavor = "14 ";     // W^+ -> muon
    pa_flavor = "-14 "; pp_flavor = "13 ";     // W^- -> muon
    break;
  case 2:
    aa_flavor = "-15 "; ap_flavor = "16 ";     // W^+ -> tau
    pa_flavor = "-16 "; pp_flavor = "15 ";     // W^- -> tau
    break;
  default:
    fatal_error("writeEvent: invalid switch value", flavorSwitch);
  }
#else
     fatal_error("Error: writeEvent(): unknown PROCMACRO");
#endif

  enum IntermediateResonancesType { VV, HIGGSANDVV };
  const IntermediateResonancesType ires = (AmpSqr::includesOnlyBackground(ampSqr.selection())) ? VV : HIGGSANDVV ;

  int numberOfParticleStates = 6;   // external particles
  string aX_mothers = "1 2";
  string pX_mothers = "1 2";
  switch (ires) {
  case VV:
    numberOfParticleStates += 2;
    aX_mothers = "3 3";
    pX_mothers = "4 4";
    break;
  case HIGGSANDVV:
    numberOfParticleStates += 3;
    aX_mothers = "4 4";
    pX_mothers = "5 5";
    break;
  }

#if defined PROCMACRO_WW2l2v
  const string v_a = "24";
  const string v_p = "-24";
#elif defined PROCMACRO_WWZAZ_2l2v
  string v_a = "";
  string v_p = "";
  if (wwzaz_2l2v_intermediate_state_in_events == W_PAIR) {
    v_a = "24";
    v_p = "-24";
  }
  else if (wwzaz_2l2v_intermediate_state_in_events == Z_PAIR) {
    v_a = "23";
    v_p = "23";
  }
  else {
    fatal_error("at 1: invalid value for wwzaz_2l2v_intermediate_state_in_events", wwzaz_2l2v_intermediate_state_in_events);
  }
#elif defined PROCMACRO_ZAZA2l2l || defined PROCMACRO_ZAZA4l || defined PROCMACRO_ZAZ_2l2v
  const string v_a = "23";
  const string v_p = "23";
#else
  const string v_a = "";    // unused
  const string v_p = "";    // unused
#endif

#if defined PROCMACRO_ZAZA4l
  ConstValue<FourMomentum> a;
  ConstValue<FourMomentum> p;
  const double da = fabs(truePS.a().m() - SMP::mZ);
  const double dp = fabs(truePS.p().m() - SMP::mZ);
  const double da2 = fabs(truePS.a2().m() - SMP::mZ);
  const double dp2 = fabs(truePS.p2().m() - SMP::mZ);
  if (min(da, dp) < min(da2, dp2)) {
    a.set(truePS.a());
    p.set(truePS.p());
  }
  else {
    a.set(truePS.a2());
    p.set(truePS.p2());
  }
#elif defined PROCMACRO_WWZAZ_2l2v
  ConstValue<FourMomentum> a;
  ConstValue<FourMomentum> p;
  if (wwzaz_2l2v_intermediate_state_in_events == W_PAIR) {
    a.set(truePS.a());
    p.set(truePS.p());
  }
  else if (wwzaz_2l2v_intermediate_state_in_events == Z_PAIR) {
    a.set(truePS.a2());
    p.set(truePS.p2());
  }
  else {
    fatal_error("at 2: invalid value for wwzaz_2l2v_intermediate_state_in_events", wwzaz_2l2v_intermediate_state_in_events);
  }
#else
  const ConstValue<FourMomentum>& a = truePS.a;
  const ConstValue<FourMomentum>& p = truePS.p;
#endif
  ConstValue<FourMomentum> h(a() + p());
  
  bool hasSucceeded = false;
  const PhaseSpace leptMassPS = giveLeptonsMass(truePS, aa_flavor, ap_flavor, pa_flavor, pp_flavor, hasSucceeded);

  if (hasSucceeded) {
    os << "<event>" << endl;
    os << setprecision(7);
    os << numberOfParticleStates << " 661 " << weight << " " << factorizationScale << " " << SMP::alpha << " " << alphas(renormalizationScale) << endl;
    os << setprecision(11);
    os << "21 -1 0 0 501 502 " << leptMassPS.i().px() << " " << leptMassPS.i().py() << " " << leptMassPS.i().pz() << " " << leptMassPS.i().E() << " " << leptMassPS.i().m_signed() << " 0. 9." << endl;
    os << "21 -1 0 0 502 501 " << leptMassPS.i_().px() << " " << leptMassPS.i_().py() << " " << leptMassPS.i_().pz() << " " << leptMassPS.i_().E() << " " << leptMassPS.i_().m_signed() << " 0. 9." << endl;
    switch (ires) {
    case VV:
      os << v_a << " 2 1 2 0 0 " << a().px() << " " << a().py() << " " << a().pz() << " " << a().E() << " " << a().m_signed() << " 0. 9." << endl;      
      os << v_p << " 2 1 2 0 0 " << p().px() << " " << p().py() << " " << p().pz() << " " << p().E() << " " << p().m_signed() << " 0. 9." << endl;
      break;
    case HIGGSANDVV:
      os << "25 2 1 2 0 0 " << h().px() << " " << h().py() << " " << h().pz() << " " << h().E() << " " << h().m_signed() << " 0. 0." << endl;      
      os << v_a << " 2 3 3 0 0 " << a().px() << " " << a().py() << " " << a().pz() << " " << a().E() << " " << a().m_signed() << " 0. 9." << endl;      
      os << v_p << " 2 3 3 0 0 " << p().px() << " " << p().py() << " " << p().pz() << " " << p().E() << " " << p().m_signed() << " 0. 9." << endl;
      break;
    }
    os << ap_flavor + "1 " << aX_mothers << " 0 0 " << leptMassPS.ap().px() << " " << leptMassPS.ap().py() << " " << leptMassPS.ap().pz() << " " << leptMassPS.ap().E() << " " << leptMassPS.ap().m_signed() << " 0. 9." << endl;
    os << aa_flavor + "1 " << aX_mothers << " 0 0 " << leptMassPS.aa().px() << " " << leptMassPS.aa().py() << " " << leptMassPS.aa().pz() << " " << leptMassPS.aa().E() << " " << leptMassPS.aa().m_signed() << " 0. 9." << endl;
    os << pa_flavor + "1 " << pX_mothers << " 0 0 " << leptMassPS.pa().px() << " " << leptMassPS.pa().py() << " " << leptMassPS.pa().pz() << " " << leptMassPS.pa().E() << " " << leptMassPS.pa().m_signed() << " 0. 9." << endl;
    os << pp_flavor + "1 " << pX_mothers << " 0 0 " << leptMassPS.pp().px() << " " << leptMassPS.pp().py() << " " << leptMassPS.pp().pz() << " " << leptMassPS.pp().E() << " " << leptMassPS.pp().m_signed() << " 0. 9." << endl;
    os << "</event>" << endl;
  }

  /*
  // test flavor sampling
  if (counter == 5000) {
    std::cout << std::endl << std::endl << "Test flavor sampling:" << std::endl;
    std::cout << "  1: elect. frac. = " << double(eCount1)/counter << std::endl;
    std::cout << "  1: muon frac.   = " << double(mCount1)/counter << std::endl;
    std::cout << "  1: tau frac.    = " << double(tCount1)/counter << std::endl;
    std::cout << "  2: elect. frac. = " << double(eCount2)/counter << std::endl;
    std::cout << "  2: muon frac.   = " << double(mCount2)/counter << std::endl;
    std::cout << "  2: tau frac.    = " << double(tCount2)/counter << std::endl;
    std::cout << std::endl;
  }
  */

  return hasSucceeded;
}

void writeEventFile(const string eventsFilename)
{
    cout << "========================================================================" << endl << "Writing event file ..." << endl;
    ofstream eventFileStream(eventsFilename.c_str());

    string pdfcode_LHAGLUE;
    const string pdfname = Pdf::pdfsetName() ;
    if (pdfname == "MSTW2008lo68cl.LHgrid")
      pdfcode_LHAGLUE = "21000 ";
    else if (pdfname == "MSTW2008nlo68cl.LHgrid")
      pdfcode_LHAGLUE = "21100 ";
    else if (pdfname == "MSTW2008nnlo68cl.LHgrid")
      pdfcode_LHAGLUE = "21200 ";
    else if (pdfname == "CT10.LHgrid")
      pdfcode_LHAGLUE = "10800 ";
    else if (pdfname == "CT10nnlo.LHgrid")
      pdfcode_LHAGLUE = "11200 ";
    else if (pdfname == "cteq66.LHgrid")
      pdfcode_LHAGLUE = "10550 ";
    else if (pdfname == "cteq6m.LHpdf")
      pdfcode_LHAGLUE = "10000 ";
    else if (pdfname == "cteq6l.LHpdf")
      pdfcode_LHAGLUE = "10041 ";
    else if (pdfname == "cteq6ll.LHpdf")
      pdfcode_LHAGLUE = "10042 ";
    else 
      fatal_error("pdfcode_LHAGLUE: unknown pdfname ", pdfname);

    double totXsecValEstimate = 0.;
    double totXsecVarEstimate = 0.;
    double totMaxEventWeight = 0.;
    for (int i = 0; i < _partialEventSetVector.size(); ++i) {
      totXsecValEstimate += _partialEventSetVector[i].xsecValEstimate;
      totXsecVarEstimate += pow2(_partialEventSetVector[i].xsecErrEstimate);
      totMaxEventWeight = max(totMaxEventWeight, _partialEventSetVector[i].maxEventWeight);
    }
    const double totXsecErrEstimate = sqrt(totXsecVarEstimate);

    const int numFlavourComb = getNumFlavourComb();
    const double fb2pb = 1/1000.;

    eventFileStream << "<LesHouchesEvents version=\"1.0\">" << endl
		    << "<init>" << endl
		    << "2212 2212 " << PhaseSpace::E_CMS()/2. << " "
		    << PhaseSpace::E_CMS()/2. << " 0 0 "
		    << pdfcode_LHAGLUE << pdfcode_LHAGLUE
		    << (unweightEvents ? "3" : "2") << " 1" << endl
		    << setprecision(6) << (totXsecValEstimate*fb2pb*numFlavourComb) << " "
		    << setprecision(2) << (totXsecErrEstimate*fb2pb*numFlavourComb) << " "
		    << setprecision(6) << (unweightEvents ? 1. : (totMaxEventWeight*numFlavourComb))
		    << " 661" << endl
		    << "</init>" << endl;

    vector<double> probUpperLimits(_partialEventSetVector.size());
    double upperLimit = 0.;
    for (int i = 0; i < _partialEventSetVector.size(); ++i) {
      upperLimit += _partialEventSetVector[i].numberOfEvents/float(::numberOfEvents);
      if (i == _partialEventSetVector.size()-1) {
	probUpperLimits[i] = 1.;
      }
      else {
	probUpperLimits[i] = upperLimit;
      }
    }
    int eventCounter = 0;
    int n = ::numberOfEvents;
    while (eventCounter < n) {
      if (n >= 20 && eventCounter%(n/20) == 0)
	printProgress(float(eventCounter)/n);
      const double prob = randomNumberGenerator->uniformInZeroOne();
      int section = -1;
      for (int i = 0; i < _partialEventSetVector.size(); ++i) {
	if (prob <= probUpperLimits[i]) {
	  section = i;
	  assert(_partialEventSetVector[section].numberOfEvents > 0);
	  break;
	}
      }
      assert(section >= 0);
      vector<EventInfo>& eventInfoVector = _partialEventSetVector.at(section).eventInfoVector;
      if (eventInfoVector.empty()) {
	continue;
      }
      else {
	const bool hasSucceeded = writeEvent(eventFileStream, eventInfoVector.back());
	eventInfoVector.pop_back();
	if (hasSucceeded) {
	  ++eventCounter;
	}
	else {
	  --n;
	}
      }
    }
    printProgress(1.);
    if (n < numberOfEvents) {
      std::cout << endl << (numberOfEvents-n) << " events discarded (giveLeptonsMass failed)" << endl;
    }
    for (int i = 0; i < _partialEventSetVector.size(); ++i) {
      assert(_partialEventSetVector[i].eventInfoVector.empty());
    }

    eventFileStream << "</LesHouchesEvents>" << endl;
    std::cout << endl << n << " events written to file "+eventsFilename << endl;
}

EventInfo::EventInfo(const double weight_, const double factorizationScale_, const double renormalizationScale_, const PhaseSpace truePS_)
  : weight(weight_), factorizationScale(factorizationScale_), renormalizationScale(renormalizationScale_), truePS(truePS_)
{}

PartialEventSet::PartialEventSet()
  : numberOfEvents(0),
    eventCounter(0),
    xsecValEstimate(0.), 
    xsecErrEstimate(0.), 
    maxEventWeight(0.), 
    maxEventWeightEstimate(0.)
{}

bool PartialEventSet::generatingEvents = false;
bool PartialEventSet::abortLoop = false;

void setNumberOfEventsForSections(const int totNumberOfEvents, vector<PartialEventSet>& partialEventSetVector)
{
  double totxsec = 0.;
  for (int i = 0; i < partialEventSetVector.size(); ++i) {
    totxsec += partialEventSetVector[i].xsecValEstimate;
  }
  int totEvCnt = 0;
  for (int i = 0; i < partialEventSetVector.size(); ++i) {
    if (i == partialEventSetVector.size()-1) {
       partialEventSetVector[i].numberOfEvents = totNumberOfEvents - totEvCnt;
       assert(partialEventSetVector[i].numberOfEvents >= 0);
    }
    else {
      partialEventSetVector[i].numberOfEvents = int(std::floor(totNumberOfEvents*partialEventSetVector[i].xsecValEstimate/totxsec + 0.5));
      totEvCnt += partialEventSetVector[i].numberOfEvents;
    }
  }
  int checkSum = 0;
  for (int i = 0; i < partialEventSetVector.size(); ++i) {
    std::cout << "section " << i << ": " << partialEventSetVector[i].numberOfEvents << " events" << std::endl;
    checkSum += partialEventSetVector[i].numberOfEvents;
  }
  assert(checkSum == totNumberOfEvents);
}

void printProgress(const double fraction)
{
  assert(0. <= fraction && fraction <= 1.);
  static bool first = true;
  if (first) {
    first = false;
  }
  else {
    cout << string(4, '\b');
  }
  cout << fixed << setprecision(0) << setw(3) << fraction * 100 << "%";
  cout << setprecision(16);     // reset precision to default
  cout.setf(ios_base::fmtflags(0), ios_base::floatfield);   // reset fixed to default
  cout.flush();
}

vector<PartialEventSet> _partialEventSetVector;

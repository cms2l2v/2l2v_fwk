#ifndef DRIVER_H
#define DRIVER_H

#include <vector>
using std::vector;
#include <string>
using std::string;
#include <fstream>
using std::ifstream;
#include <cassert>
/* assert macro */

#include "dvegas.h"
#include "histosuite.h"

using namespace HepSource;

class Driver 
{
public:
  Driver(const vector<Dvegas*>& dvegas, OmniComp *const omniComp = 0);
  void run(HistoSuite *const histoSuite_ptr);
  void adaptDvegasObjects();
  const double getResult(const int i) const;
  const double getError(const int i) const;
  const int getNumberOfEstimates(const int i) const;
  void resetCumulativeEstimates();
  void resetSectionWeights();

  void saveState(const string& filename) const;
  void restoreWeights(istream& is);

  void setWeights(const vector<double>& weights);
private:
  const vector<Dvegas*> _dvegas;
  vector<double> _weights;
  vector<Dvegas::CellAccumulators> _cellAcc;
  OmniComp *const _omniComp;
  vector<CumulativeEstimate> _estimate;
};

inline const double Driver::getResult(const int i) const { assert(0 <= i && i < _estimate.size()); return _estimate[i].estimate(); }

inline const double Driver::getError(const int i) const { assert(0 <= i && i < _estimate.size()); return _estimate[i].standardDeviation(); }

inline const int Driver::getNumberOfEstimates(const int i) const { assert(0 <= i && i < _estimate.size()); return _estimate[i].numberOfEstimates(); }

#endif  /* DRIVER_H */

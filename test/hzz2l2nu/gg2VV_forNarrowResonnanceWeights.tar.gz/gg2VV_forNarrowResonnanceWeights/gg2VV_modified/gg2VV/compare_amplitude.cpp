#include <cmath>
using std::fabs;
#include <iostream>
using std::cout;
using std::ostream;
#include <iomanip>
using std::endl;
using std::setprecision;
#include <vector>

#include "compare_amplitude.h"
#include "settings.h"
#include "phasespace.h"
#include "amp.h"
#include "amp_formcalc.h"
#include "clock.h"

// helper functions -------------------------------------------------------

namespace 
{  
PhaseSpace& getAddedPhaseSpace(vector<PhaseSpace>& psList)
{
  psList.push_back(PhaseSpace());
  return psList.back();
}
}   // unnamed namespace

// ------------------------------------------------------------------------

void compare_amplitude()
{
  Clock clock;

  AmpSqrFormcalc ampsqr_cont(AmpSqr::CONTINUUMBACKGROUND);
  AmpSqrFormcalc ampsqr_higgs(AmpSqr::HIGGSSIGNAL);
  AmpSqrFormcalc ampsqr_higgspluscont(AmpSqr::HIGGSSIGNAL+AmpSqr::CONTINUUMBACKGROUND);
  ampsqr_higgspluscont.initialize(); // get init LoopTools write-out at top of output

  cout << endl;
  SMP::report();

  vector<PhaseSpace> psList;
  PhaseSpace* ps_ptr = 0;
  string description;

#if defined PROCMACRO_WWZAZ_2l2v
  description = "g g  -> e+ nu_e {nu_bar}_e e-";

  ps_ptr = &getAddedPhaseSpace(psList);
  ps_ptr->i.set(FourMomentum(1699.623236457713, 0, 0, 1699.623236457713));
  ps_ptr->i_.set(FourMomentum(16.39467539475094, -0, -0, -16.39467539475094));
  ps_ptr->aa.set(FourMomentum(33.47716119802502, -16.04069447390404, -7.749926263560233, 28.34351928718088));
  ps_ptr->ap.set(FourMomentum(786.9028772123371, -119.2129144324192, 85.99743388013187, 773.0516545248549));
  ps_ptr->pa.set(FourMomentum(847.8390204985316, 130.0849915263451, -75.40097060747141, 834.4001397956206));
  ps_ptr->pp.set(FourMomentum(47.79885294358664, 5.168617379980011, -2.846537009101304, 47.43324745532195));

  ps_ptr = &getAddedPhaseSpace(psList);
  ps_ptr->i.set(FourMomentum(24.37932231371495, 0, 0, 24.37932231371495));
  ps_ptr->i_.set(FourMomentum(169.9650726254478, -0, -0, -169.9650726254478));
  ps_ptr->aa.set(FourMomentum(24.68647658557316, -23.35070288448202, 6.328070269846092, -4.911448632591473));
  ps_ptr->ap.set(FourMomentum(61.13199749455215, 17.07141997405976, 39.41658321552058, -43.49736434954588));
  ps_ptr->pa.set(FourMomentum(83.52794185233591, 8.839134217268576, -31.30088130031634, -76.93530792945347));
  ps_ptr->pp.set(FourMomentum(24.99797900670101, -2.55985130684635, -14.44377218505011, -20.24162940014154));

  ps_ptr = &getAddedPhaseSpace(psList);
  ps_ptr->i.set(FourMomentum(1699.623236457713, 0, 0, 1699.623236457713));
  ps_ptr->i_.set(FourMomentum(16.39467539475094, -0, -0, -16.39467539475094));
  ps_ptr->aa.set(FourMomentum(34.23496249035692, -17.08626666669011, -9.423354474331283, 28.12992247699952));
  ps_ptr->ap.set(FourMomentum(47.03747968057485, 4.660392262300409, -2.52568411213066, 46.73784503405896));
  ps_ptr->pa.set(FourMomentum(833.4388284015896, 128.1690773375886, -74.31939986208762, 820.1643707855059));
  ps_ptr->pp.set(FourMomentum(801.3066412798485, -115.7432029332135, 86.26843844855802, 788.1964227663052));

#elif defined PROCMACRO_WW2l2v
  description = "g g  -> e+ nu_e {nu_bar}_mu mu-";

  ps_ptr = &getAddedPhaseSpace(psList);
  ps_ptr->i.set(FourMomentum(1699.623236457713, 0, 0, 1699.623236457713));
  ps_ptr->i_.set(FourMomentum(16.39467539475094, -0, -0, -16.39467539475094));
  ps_ptr->aa.set(FourMomentum(33.47716119802502, -16.04069447390404, -7.749926263560233, 28.34351928718088));
  ps_ptr->ap.set(FourMomentum(786.9028772123371, -119.2129144324192, 85.99743388013187, 773.0516545248549));
  ps_ptr->pa.set(FourMomentum(847.8390204985316, 130.0849915263451, -75.40097060747141, 834.4001397956206));
  ps_ptr->pp.set(FourMomentum(47.79885294358664, 5.168617379980011, -2.846537009101304, 47.43324745532195));

  ps_ptr = &getAddedPhaseSpace(psList);
  ps_ptr->i.set(FourMomentum(24.37932231371495, 0, 0, 24.37932231371495));
  ps_ptr->i_.set(FourMomentum(169.9650726254478, -0, -0, -169.9650726254478));
  ps_ptr->aa.set(FourMomentum(24.68647658557316, -23.35070288448202, 6.328070269846092, -4.911448632591473));
  ps_ptr->ap.set(FourMomentum(61.13199749455215, 17.07141997405976, 39.41658321552058, -43.49736434954588));
  ps_ptr->pa.set(FourMomentum(83.52794185233591, 8.839134217268576, -31.30088130031634, -76.93530792945347));
  ps_ptr->pp.set(FourMomentum(24.99797900670101, -2.55985130684635, -14.44377218505011, -20.24162940014154));

#elif defined PROCMACRO_ZAZA2l2l
  description = "g g  -> e+ e- mu+ mu-";

  ps_ptr = &getAddedPhaseSpace(psList);
  ps_ptr->i.set(FourMomentum(2743.302386700293, 0, 0, 2743.302386700293));
  ps_ptr->i_.set(FourMomentum(10.78833381098275, -0, -0, -10.78833381098275));
  ps_ptr->aa.set(FourMomentum(266.4741884847791, -1.206753035923889, -5.582257692251619, 266.4129788031904));
  ps_ptr->ap.set(FourMomentum(364.989264405234, -107.8606043915737, -14.7819930370059, 348.3744333805398));
  ps_ptr->pa.set(FourMomentum(98.54935498086192, -7.88518440706212, -13.4174587128793, 97.31274857745379));
  ps_ptr->pp.set(FourMomentum(2024.077912640335, 116.9525418345569, 33.7817094421363, 2020.41389212806));

  ps_ptr = &getAddedPhaseSpace(psList);
  ps_ptr->i.set(FourMomentum(24.37932231371495, 0, 0, 24.37932231371495));
  ps_ptr->i_.set(FourMomentum(169.9650726254478, -0, -0, -169.9650726254478));
  ps_ptr->aa.set(FourMomentum(24.68647658557316, -23.35070288448202, 6.328070269846092, -4.911448632591473));
  ps_ptr->ap.set(FourMomentum(61.13199749455215, 17.07141997405976, 39.41658321552058, -43.49736434954588));
  ps_ptr->pa.set(FourMomentum(83.52794185233591, 8.839134217268576, -31.30088130031634, -76.93530792945347));
  ps_ptr->pp.set(FourMomentum(24.99797900670101, -2.55985130684635, -14.44377218505011, -20.24162940014154));

#elif defined PROCMACRO_ZAZ_2l2v
  description = "g g  -> e+ e- {nu_bar}_mu nu_mu";

  ps_ptr = &getAddedPhaseSpace(psList);
  ps_ptr->i.set(FourMomentum(1699.623236457713, 0, 0, 1699.623236457713));
  ps_ptr->i_.set(FourMomentum(16.39467539475094, -0, -0, -16.39467539475094));
  ps_ptr->aa.set(FourMomentum(34.23496249035692, -17.08626666669011, -9.423354474331283, 28.12992247699952));
  ps_ptr->ap.set(FourMomentum(801.3066412798485, -115.7432029332135, 86.26843844855802, 788.1964227663052));
  ps_ptr->pa.set(FourMomentum(833.4388284015896, 128.1690773375886, -74.31939986208762, 820.1643707855059));
  ps_ptr->pp.set(FourMomentum(47.03747968057485, 4.660392262300409, -2.52568411213066, 46.73784503405896));

#elif defined PROCMACRO_ZAZA4l
  description = "g g  -> e+ e- e+ e-";

  ps_ptr = &getAddedPhaseSpace(psList);
  ps_ptr->i.set(FourMomentum(2743.302386700293, 0, 0, 2743.302386700293));
  ps_ptr->i_.set(FourMomentum(10.78833381098275, -0, -0, -10.78833381098275));
  ps_ptr->aa.set(FourMomentum(266.4741884847791, -1.206753035923889, -5.582257692251619, 266.4129788031904));
  ps_ptr->ap.set(FourMomentum(364.989264405234, -107.8606043915737, -14.7819930370059, 348.3744333805398));
  ps_ptr->pa.set(FourMomentum(98.54935498086192, -7.88518440706212, -13.4174587128793, 97.31274857745379));
  ps_ptr->pp.set(FourMomentum(2024.077912640335, 116.9525418345569, 33.7817094421363, 2020.41389212806));

  // e+: exchange aa and pa
  ps_ptr = &getAddedPhaseSpace(psList);
  ps_ptr->i.set(FourMomentum(2743.302386700293, 0, 0, 2743.302386700293));
  ps_ptr->i_.set(FourMomentum(10.78833381098275, -0, -0, -10.78833381098275));
  ps_ptr->pa.set(FourMomentum(266.4741884847791, -1.206753035923889, -5.582257692251619, 266.4129788031904));
  ps_ptr->ap.set(FourMomentum(364.989264405234, -107.8606043915737, -14.7819930370059, 348.3744333805398));
  ps_ptr->aa.set(FourMomentum(98.54935498086192, -7.88518440706212, -13.4174587128793, 97.31274857745379));
  ps_ptr->pp.set(FourMomentum(2024.077912640335, 116.9525418345569, 33.7817094421363, 2020.41389212806));

  // e-: exchange ap and pp
  ps_ptr = &getAddedPhaseSpace(psList);
  ps_ptr->i.set(FourMomentum(2743.302386700293, 0, 0, 2743.302386700293));
  ps_ptr->i_.set(FourMomentum(10.78833381098275, -0, -0, -10.78833381098275));
  ps_ptr->aa.set(FourMomentum(266.4741884847791, -1.206753035923889, -5.582257692251619, 266.4129788031904));
  ps_ptr->pp.set(FourMomentum(364.989264405234, -107.8606043915737, -14.7819930370059, 348.3744333805398));
  ps_ptr->pa.set(FourMomentum(98.54935498086192, -7.88518440706212, -13.4174587128793, 97.31274857745379));
  ps_ptr->ap.set(FourMomentum(2024.077912640335, 116.9525418345569, 33.7817094421363, 2020.41389212806));

  // e+: exchange aa and pa
  // e-: exchange ap and pp
  ps_ptr = &getAddedPhaseSpace(psList);
  ps_ptr->i.set(FourMomentum(2743.302386700293, 0, 0, 2743.302386700293));
  ps_ptr->i_.set(FourMomentum(10.78833381098275, -0, -0, -10.78833381098275));
  ps_ptr->pa.set(FourMomentum(266.4741884847791, -1.206753035923889, -5.582257692251619, 266.4129788031904));
  ps_ptr->pp.set(FourMomentum(364.989264405234, -107.8606043915737, -14.7819930370059, 348.3744333805398));
  ps_ptr->aa.set(FourMomentum(98.54935498086192, -7.88518440706212, -13.4174587128793, 97.31274857745379));
  ps_ptr->ap.set(FourMomentum(2024.077912640335, 116.9525418345569, 33.7817094421363, 2020.41389212806));

  // next PS point
  ps_ptr = &getAddedPhaseSpace(psList);
  ps_ptr->i.set(FourMomentum(24.37932231371495, 0, 0, 24.37932231371495));
  ps_ptr->i_.set(FourMomentum(169.9650726254478, -0, -0, -169.9650726254478));
  ps_ptr->aa.set(FourMomentum(24.68647658557316, -23.35070288448202, 6.328070269846092, -4.911448632591473));
  ps_ptr->ap.set(FourMomentum(61.13199749455215, 17.07141997405976, 39.41658321552058, -43.49736434954588));
  ps_ptr->pa.set(FourMomentum(83.52794185233591, 8.839134217268576, -31.30088130031634, -76.93530792945347));
  ps_ptr->pp.set(FourMomentum(24.99797900670101, -2.55985130684635, -14.44377218505011, -20.24162940014154));

  // e+: exchange aa and pa
  ps_ptr = &getAddedPhaseSpace(psList);
  ps_ptr->i.set(FourMomentum(24.37932231371495, 0, 0, 24.37932231371495));
  ps_ptr->i_.set(FourMomentum(169.9650726254478, -0, -0, -169.9650726254478));
  ps_ptr->pa.set(FourMomentum(24.68647658557316, -23.35070288448202, 6.328070269846092, -4.911448632591473));
  ps_ptr->ap.set(FourMomentum(61.13199749455215, 17.07141997405976, 39.41658321552058, -43.49736434954588));
  ps_ptr->aa.set(FourMomentum(83.52794185233591, 8.839134217268576, -31.30088130031634, -76.93530792945347));
  ps_ptr->pp.set(FourMomentum(24.99797900670101, -2.55985130684635, -14.44377218505011, -20.24162940014154));

  // e-: exchange ap and pp
  ps_ptr = &getAddedPhaseSpace(psList);
  ps_ptr->i.set(FourMomentum(24.37932231371495, 0, 0, 24.37932231371495));
  ps_ptr->i_.set(FourMomentum(169.9650726254478, -0, -0, -169.9650726254478));
  ps_ptr->aa.set(FourMomentum(24.68647658557316, -23.35070288448202, 6.328070269846092, -4.911448632591473));
  ps_ptr->pp.set(FourMomentum(61.13199749455215, 17.07141997405976, 39.41658321552058, -43.49736434954588));
  ps_ptr->pa.set(FourMomentum(83.52794185233591, 8.839134217268576, -31.30088130031634, -76.93530792945347));
  ps_ptr->ap.set(FourMomentum(24.99797900670101, -2.55985130684635, -14.44377218505011, -20.24162940014154));

  // e+: exchange aa and pa
  // e-: exchange ap and pp
  ps_ptr = &getAddedPhaseSpace(psList);
  ps_ptr->i.set(FourMomentum(24.37932231371495, 0, 0, 24.37932231371495));
  ps_ptr->i_.set(FourMomentum(169.9650726254478, -0, -0, -169.9650726254478));
  ps_ptr->pa.set(FourMomentum(24.68647658557316, -23.35070288448202, 6.328070269846092, -4.911448632591473));
  ps_ptr->pp.set(FourMomentum(61.13199749455215, 17.07141997405976, 39.41658321552058, -43.49736434954588));
  ps_ptr->aa.set(FourMomentum(83.52794185233591, 8.839134217268576, -31.30088130031634, -76.93530792945347));
  ps_ptr->ap.set(FourMomentum(24.99797900670101, -2.55985130684635, -14.44377218505011, -20.24162940014154));

#else
  fatal_error("compare_amplitude: invalid matrix element selection");
#endif

  ps_ptr = 0;

  for (vector<PhaseSpace>::iterator it = psList.begin(); it != psList.end(); ++it) {
    checkAndCompletePhaseSpace(*it);
  }
  

  cout << endl;
  cout << "=================================================================" << endl;
  cout << description << endl;
  cout << "i i_ -> aa ap pa pp (a=aa+ap, p=pa+pp)" << endl;
  cout << "mod-squared amplitudes (polar. and colour averaged, spin summed)" << endl;
#if defined PROCMACRO_ZAZA4l
  cout << "including symmetry factor 1/(2!2!)" << endl;
#endif
  cout << "H = Higgs amplitude, cont = continuum amplitude" << endl;
  cout << "fixed-width propagators" << endl;
#if defined QUADPREC
  cout << "quadruple precision evaluation" << endl;
#elif defined MIXEDPREC
  cout << "mixed precision evaluation" << endl;
#else
  cout << "double precision evaluation" << endl;
#endif
  cout << "=================================================================" << endl;
  cout << endl;
  vector<PhaseSpace>::const_iterator ps_it = psList.begin();
  while (ps_it != psList.end()) {
    ps_it->print(cout);
    cout << endl;
    cout << setprecision(16);
    ampsqr_higgspluscont.initialize();
    clock.start();
    const double ampsqrhiggspluscont = ampsqr_higgspluscont.ampSqr(*ps_it);
    clock.stop();
    ampsqr_higgs.initialize();
    const double ampsqrhiggs = ampsqr_higgs.ampSqr(*ps_it);
    ampsqr_cont.initialize();
    const double ampsqrcont = ampsqr_cont.ampSqr(*ps_it);
    cout << "----------------------" << endl;
    cout << "gg2VV-3.0: |H+cont|^2 = " << ampsqrhiggspluscont << "  [";
    clock.writeTime(cout);
    cout << "]" << endl;
    cout << "gg2VV-3.0: |H|^2      = " << ampsqrhiggs << endl;
    cout << "gg2VV-3.0: |cont|^2   = " << ampsqrcont << endl;
    cout << "gg2VV-3.0: R_1 := |H+cont|^2/(|H|^2+|cont|^2) = "  << setprecision(3) << ampsqrhiggspluscont/(ampsqrhiggs+ampsqrcont) << endl << setprecision(16);
    cout << "----------------------" << endl;
    cout << endl;
    ++ps_it;
  }
}

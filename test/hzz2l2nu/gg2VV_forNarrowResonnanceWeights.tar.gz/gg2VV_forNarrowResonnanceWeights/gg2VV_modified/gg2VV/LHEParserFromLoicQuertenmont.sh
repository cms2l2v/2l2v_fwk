#!/bin/bash
#export SCRAM_ARCH=slc5_amd64_gcc462
#. /afs/cern.ch/cms/cmsset_default.sh
#eval `scramv1 runtime -sh`
executable=`echo $0 | sed 's/.sh/.C/'` #assume the .sh and .C file have the same name
#root -l -b -q $executable+"(\"$1\", \"$2\")"



root -l -b << EOF 
  TString makeshared(gSystem->GetMakeSharedLib());
  makeshared.ReplaceAll("-W ", "-Wno-deprecated-declarations -Wno-deprecated ");
  makeshared.ReplaceAll("-Wshadow ", " -std=c++0x -D__USE_XOPEN2K8 ");
  gSystem->SetMakeSharedLib(makeshared);
  .x $executable+("$1", "$2")
EOF


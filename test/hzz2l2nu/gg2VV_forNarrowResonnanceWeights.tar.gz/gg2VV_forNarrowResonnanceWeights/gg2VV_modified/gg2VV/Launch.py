#!/usr/bin/env python

import urllib
import string
import os
import sys
import glob

NEventsPreRun = 5000 #set to zero if the initialization has already been run and you just want to do more stat
mHlist = [200, 250, 300, 350, 400, 450, 500, 550, 600, 650, 700, 750, 800, 850, 900, 950, 1000]
Plist  = [0,1,2]
CPlist = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0]

NEventsPreRun = 10000
#mHlist = [1000]
#CPlist = [0.5]

NEventsPerRun = 100000
NRuns = 30
FirstRun = 0;

for P in Plist:
   for mH in mHlist:
      for CP in CPlist:
            if(P==0 and not (mH==200 and CP==1.0)):continue
            JobName = str(mH) + '_' + str(P) + '_' + str(CP)
            EmptyJob = True

            #prepare the directory
            os.system("mkdir -p results/"+JobName)
            
            #prepare and write the shell script that will be used to run
            shellConfig  = ''
            shellConfig += 'cd ' + os.getcwd() +'/../\n'
            shellConfig += '. ./ENV.sh\n'
            shellConfig += 'cd gg2VV/results/'+JobName+'\n'
            shellConfig += 'ln -s ../../gg2VV gg2VV\n'
            if(NEventsPreRun>0 and not os.path.isfile(os.getcwd()+'/results/'+JobName+'/gg2VV.dat')  ):
               shellConfig += './gg2VV ' + str(NEventsPreRun) +  ' ' + str(P) + ' ' + str(mH) + ' ' + str(CP) +  '\n'
               shellConfig += 'rm gg2VV_*Events.dat' + '\n'
               EmptyJob = False

            for R in range(FirstRun,NRuns):
               if(os.path.isfile(os.getcwd()+'/results/'+JobName+'/gg2VV_'+str(R) + '_histo.root') ): continue #SKIP RUN THAT ALREADY EXIST
               shellConfigRun  = ''
               shellConfigRun += 'cd ' + os.getcwd() +'/../\n'
               shellConfigRun += '. ./ENV.sh\n'
               shellConfigRun += 'export SCRAM_ARCH=slc5_amd64_gcc462\n'
               shellConfigRun += '. /afs/cern.ch/cms/cmsset_default.sh\n'
               shellConfigRun += 'eval `scramv1 runtime -sh`\n'
               shellConfigRun += 'cd -\n'
#               shellConfigRun += 'cd gg2VV/results/'+JobName+'\n'
               shellConfigRun += 'ln -s '+os.getcwd()+'/results/'+JobName+'/gg2VV gg2VV_'+str(R)+'\n'
               shellConfigRun += 'ln -s '+os.getcwd()+'/results/'+JobName+'/gg2VV.init-new gg2VV_'+str(R)+'.init\n'
               shellConfigRun += 'ln -s '+os.getcwd()+'/results/'+JobName+'/gg2VV.evt-new gg2VV_'+str(R)+'.evt\n'
               shellConfigRun += 'echo ' + str(R) + ' >> gg2VV_'+str(R)+'.rngseed\n'
               shellConfigRun += './gg2VV_'+str(R)+' ' + str(NEventsPerRun) + ' ' + str(P) + ' ' + str(mH) + ' ' + str(CP) + '\n'
               shellConfigRun += 'sh ' + os.getcwd() + '/LHEParserFromLoicQuertenmont.sh gg2VV_'+str(R)+'_*.dat '+' gg2VV_'+str(R) + '_histo.root' + '\n'
#               shellConfigRun += 'rm gg2VV_'+str(R)+'_*.dat' + '\n'
               shellConfigRun += 'ls -lth\n'
               shellConfigRun += 'mv gg2VV_'+str(R)+'_histo.root ' + os.getcwd()+'/results/'+JobName+'/gg2VV_'+str(R) + '_histo.root' + '\n'
               config_file=open('results/'+JobName+'/run_R'+str(R)+'.sh','w')
               config_file.write(shellConfigRun)
               config_file.close()
               shellConfig += 'bsub -q 8nh -J ' + JobName+'_R'+str(R) +' "sh ' +  os.getcwd()+'/results/'+JobName+'/run_R'+str(R)+'.sh' + '"\n'
               EmptyJob = False

            config_file=open('results/'+JobName+'/run.sh','w')
            config_file.write(shellConfig)
            config_file.close()

            #submit the job
            #print('bsub -q 8nh -J ' + JobName +' "sh ' + os.getcwd()+'/results/'+JobName+'/run.sh'  + '"')
            if(not EmptyJob):
               print "Submitting prejobs for " + JobName
               os.system('bsub -q 8nh -J ' + JobName +' "sh ' + os.getcwd()+'/results/'+JobName+'/run.sh'  + '"')

#include <algorithm>
using std::max;
#include <iostream>
using std::cout;
#include <fstream>
using std::ofstream;
using std::ifstream;
#include <iomanip>
using std::setprecision;
using std::endl;
#include <cmath>
using std::sqrt;

#include "settings.h"
#include "driver.h"
#include "events.h"
#include "utilities.h"
#include "geometry.h"
#include "small_powers.h"
#include "maxeventweightestimate.h"

// -----------------------------------------------------------------------------

Driver::Driver(const vector<Dvegas*>& dvegas, OmniComp *const omniComp)
// default: omniComp = 0
  : _dvegas(dvegas), _weights(_dvegas.size(), 1.0/_dvegas.size()),
    _omniComp(omniComp), _estimate(_dvegas[0]->numberOfIntegrands())
{
  for (int i = 1; i < _dvegas.size(); ++i)
    assert(_dvegas[i]->numberOfIntegrands() == _estimate.size());
}

void Driver::run(HistoSuite *const histoSuite_ptr)
{
  assert(_cellAcc.empty());
  _cellAcc.resize(_dvegas.size());
  const int numberOfSections = _dvegas.size();
  const int numberOfIntegrands = _dvegas[0]->numberOfIntegrands();
  vector<double> resultOfIteration(numberOfIntegrands);
  vector<double> varianceOfIteration(numberOfIntegrands);
  vector<double> efficiency(numberOfSections, 0.);
  assert(_weights.size() == numberOfSections);
  vector<double> newWeights(numberOfSections);
  for (int s = 0; s < numberOfSections; ++s) {
    // grid adaptation runs
    const Int64 numberOfShotsForSection = max(gridAdaptationNumberOfShots * (_weights[s]*numberOfSections), 1000);
    double relativeError = 0.;
    double previousRelativeError = 0.;
    bool doMoreGridAdaptationRuns = true;
    int gridAdaptationRunsCounter = 0;
    while (doMoreGridAdaptationRuns) {
      // test run to determine efficiency
      bool haveEfficiencyEstimate = false;
      Int64 numberOfShotsForEfficiencyRun = min(0.05 * numberOfShotsForSection, 100000);
      while (!haveEfficiencyEstimate) {
	cout << "Efficiency test run (section " << s << "):" << endl;
	_dvegas[s]->resetEstimates();
	_dvegas[s]->attachOmniComp(_omniComp);
	bool caughtException = false;
	try {
	  _dvegas[s]->collectData(numberOfShotsForEfficiencyRun);
	}
	catch (HepSource::Dvegas::NoNonzeroIntegrandValuesSampledException) {
	  caughtException = true;
	}
	_dvegas[s]->detachOmniComp();      
	if (caughtException) {     // no hits, increase shots and try again
	  static int noHitsCounter = 0;
	  ++noHitsCounter;
	  if (noHitsCounter > 6) {
	    fatal_error("\nABORTED:\ndsigma appears to be zero in a PS region.\nIf this is false increase gridAdaptationNumberOfShots.\nIf it is true eliminate in main.cpp the section dvegas[", s);
	  }
	  numberOfShotsForEfficiencyRun *= 2;
	}
	else {
	  efficiency[s] = _dvegas[s]->getInfoEfficiency(0);
	  const int minHits = 100;
	  if (numberOfShotsForEfficiencyRun * efficiency[s] > minHits) {
	    haveEfficiencyEstimate = true;
	  }
	  else {
	    numberOfShotsForEfficiencyRun = (minHits/efficiency[s]*1.2);  // safety factor
	  }
	}
      }

      const bool haveOptimalGrid = previousRelativeError > 0. &&
	fabs(relativeError/previousRelativeError - 1.) < 0.1;

      doMoreGridAdaptationRuns = gridAdaptationRunsCounter < maxNumberOfGridAdaptationIterations && !haveOptimalGrid;

      if (doMoreGridAdaptationRuns) {
	++gridAdaptationRunsCounter;
	_dvegas[s]->resetEstimates();
	_dvegas[s]->attachOmniComp(_omniComp);
	cout << "========================================================================" << endl;
	cout << "Grid adaptation run (section " << s << "):" << endl;
	try {
	  _cellAcc[s] = _dvegas[s]->collectData(numberOfShotsForSection/efficiency[s]);
	}
	catch (HepSource::Dvegas::NoNonzeroIntegrandValuesSampledException) {
	  fatal_error("\nABORTED: no hits for section dvegas[", s);
	}
	_dvegas[s]->detachOmniComp();
	_dvegas[s]->info(scales_ptr_vector.size());
	efficiency[s] = _dvegas[s]->getInfoEfficiency(0);
	previousRelativeError = relativeError;
	relativeError = _dvegas[s]->standardDeviation(0)/fabs(_dvegas[s]->integral(0));
	newWeights[s] = _dvegas[s]->standardDeviation(0)*sqrt(numberOfShotsForSection);
	_dvegas[s]->adaptWeights(_cellAcc[s]);     // adapt VEGAS grid
      }
    }
  }

  if (maxNumberOfGridAdaptationIterations > 0 && numberOfSections > 1) {
    cout << "Adapting section weights" << endl;
    double sumOfWeights = 0.;
    for (int s = 0; s < numberOfSections; ++s) {
      sumOfWeights += newWeights[s];
    }
    for (int s = 0; s < numberOfSections; ++s) {
      newWeights[s] /= sumOfWeights;
    }
    _weights = newWeights;
  }

  for (int s = 0; s < numberOfSections; ++s) {
    // main run (fill histograms and determine max event weight)
    if (histoSuite_ptr != 0) {
      _dvegas[s]->attachOmniHistoSuite(histoSuite_ptr);
    }
    _dvegas[s]->resetEstimates();
    MaxEventWeightEstimate::value = 0.;
    _dvegas[s]->attachOmniComp(_omniComp);
    cout << "========================================================================" << endl;
    cout << "Main run (section " << s << "):" << endl;
    const Int64 mainRunNumberOfShotsForSection = mainRunNumberOfShots * max(_weights[s]*numberOfSections, 0.1);
    try {
      _cellAcc[s] = _dvegas[s]->collectData(mainRunNumberOfShotsForSection/efficiency[s]);
    }
    catch (HepSource::Dvegas::NoNonzeroIntegrandValuesSampledException) {
      fatal_error("\nABORTED: no hits for section dvegas[", s);
    }
    _dvegas[s]->detachOmniComp();
    if (_dvegas[s]->hasOmniHistoSuiteAttached()) {
      _dvegas[s]->detachOmniHistoSuite();
    }
    _dvegas[s]->info(scales_ptr_vector.size());
    for (int i = 0; i < numberOfIntegrands; ++i) {
      resultOfIteration[i] += _dvegas[s]->integral(i);
      varianceOfIteration[i] += pow(_dvegas[s]->standardDeviation(i), 2);
    }
    _partialEventSetVector[s].maxEventWeight = MaxEventWeightEstimate::value;
    _dvegas[s]->adaptWeights(_cellAcc[s]);     // adapt VEGAS grid
  }
  _cellAcc.clear();

  // update cumulative result (only one iteration by default):
  for (int i = 0; i < numberOfIntegrands; ++i) {
    _estimate[i].addEstimate(Estimate(resultOfIteration[i], varianceOfIteration[i]));
  }
}

void Driver::adaptDvegasObjects()
{
  assert(_cellAcc.empty() || _cellAcc.size() == _dvegas.size());
  for (int s = 0; s < _cellAcc.size(); ++s)
    _dvegas[s]->adaptWeights(_cellAcc[s]);
  _cellAcc.clear();
}

void Driver::resetCumulativeEstimates()
{
  _estimate.assign(_estimate.size(), CumulativeEstimate());
  _cellAcc.clear();
}

void Driver::saveState(const string& filename) const
{
  ofstream fout(filename.c_str());
  fout << setprecision(16);
  fout << _dvegas.size() << csep;
  for (int s = 0; s < _dvegas.size(); ++s)
    _dvegas[s]->saveStateToStream(fout);
  assert(_weights.size() == _dvegas.size());
  for (int s = 0; s < _weights.size(); ++s)
    fout << _weights[s] << csep;
}

void Driver::restoreWeights(istream& is)
{
  resetCumulativeEstimates();
  const int numberOfSavedDvegasObjects = getObj<int>(is);
  assert(numberOfSavedDvegasObjects == _dvegas.size());     // simplifying restriction
  for (int s = 0; s < _dvegas.size(); ++s)
    _dvegas[s]->restoreWeightsFromStream(is);
  assert(_weights.size() == _dvegas.size());
  for (int s = 0; s < _weights.size(); ++s)
    _weights[s] = getObj<double>(is);
}

void Driver::resetSectionWeights()
{
  _weights.assign(_weights.size(), 1.0/_weights.size());
}

void Driver::setWeights(const vector<double>& weights)
{
  assert(weights.size() == _weights.size());
  double sum = 0.;
  for (int i = 0; i < weights.size(); ++i)
    sum += weights[i];
  if (sum < 0.99 || 1.01 < sum)
    cout << "WARNING: new Driver weights not normalized, sum = " << sum << endl;
  _weights = weights;
}

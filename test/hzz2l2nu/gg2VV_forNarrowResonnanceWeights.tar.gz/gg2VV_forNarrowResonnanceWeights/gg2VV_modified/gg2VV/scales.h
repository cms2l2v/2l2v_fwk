#ifndef SCALES_H
#define SCALES_H

#include "phasespace.h"

#include <iostream>
using std::ostream;

class Scales
{
public:
  enum Type { FIXED, ROOT_S_HAT };
  virtual void operator()(const PhaseSpace& ps, const double renScaleFactor = 1., const double facScaleFactor = 1.) = 0;

  virtual const double renormalizationScale() const = 0;
  virtual const double strongCouplingFactor() const = 0;     // rectify g_s := 1
  virtual const double factorizationScale() const = 0;
  virtual const Type type() const = 0;
  virtual void writeScaleChoice(ostream& os) const = 0;

  Scales();  
  virtual ~Scales() {}
};

// --------------------------------------------------------------------

class FixedScales : public Scales
{
public:
  FixedScales(const double centralScale);
  void operator()(const PhaseSpace& ps, const double renScaleFactor, const double facScaleFactor);

  const double centralScale() const;
  const double renormalizationScale() const;
  const double strongCouplingFactor() const;     // rectify g_s := 1
  const double factorizationScale() const;
  const Type type() const;
  void writeScaleChoice(ostream& os) const;
private:
  const double _centralScale;
  double _renScaleFactor;
  double _facScaleFactor;
  double _renormalizationScale;
  double _strongCouplingFactor;
  double _factorizationScale;
};

inline const double FixedScales::centralScale() const { return _centralScale; }

inline const double FixedScales::renormalizationScale() const { return _renormalizationScale; }

inline const double FixedScales::strongCouplingFactor() const { return _strongCouplingFactor; }

inline const double FixedScales::factorizationScale() const { return _factorizationScale; }

inline const Scales::Type FixedScales::type() const { return FIXED; }

// --------------------------------------------------------------------

class RootshatScales : public Scales
{
public:
  RootshatScales(const double commonFactor = 1.);
  void operator()(const PhaseSpace& ps, const double renScaleFactor, const double facScaleFactor);

  const double renormalizationScale() const;
  const double strongCouplingFactor() const;     // rectify g_s := 1
  const double factorizationScale() const;
  const Type type() const;
  void writeScaleChoice(ostream& os) const;
private:
  const double _commonFactor;
  double _renScaleFactor;
  double _facScaleFactor;
  double _renormalizationScale;
  double _strongCouplingFactor;
  double _factorizationScale;
};

inline const double RootshatScales::renormalizationScale() const { return _renormalizationScale; }

inline const double RootshatScales::strongCouplingFactor() const { return _strongCouplingFactor; }

inline const double RootshatScales::factorizationScale() const { return _factorizationScale; }

inline const Scales::Type RootshatScales::type() const { return ROOT_S_HAT; }

#endif     /* SCALES_H */

#ifndef COMPARE_AMPLITUDE_H
#define COMPARE_AMPLITUDE_H

void compare_amplitude();

#endif  /* COMPARE_AMPLITUDE_H */

#include <cmath>
using std::sqrt;
using std::exp;
using std::fabs;

#include "detector.h"
#include "settings.h"
#include "rng.h"
#include "small_powers.h"

namespace
{
const double gaussDeviation(const double stddev)
{
  double dev, gaussianProbability;
  do {
    dev = (3 * stddev) * (2 * randomNumberGenerator->uniformInZeroOne() - 1);
    gaussianProbability = exp(- 0.5 * pow2(dev/stddev));  // < 1.0, but not normalized
  } while (randomNumberGenerator->uniformInZeroOne() > gaussianProbability);
  return dev;
}

const FourVector smear(const FourMomentum& fm, const double deltaE)
{
  if (fm.E() > 0.0 && fm.E() + deltaE > 0.0) {
    return (1. + deltaE/fm.E()) * fm;
  }
  return 1.e-15 * fm;
}

const FourVector slbdecay(const FourMomentum& fm)
{
  // rescale b mom. to simulate semileptonic decays and neutrino loss in calorimeter

  const double random_number = randomNumberGenerator->uniformInZeroOne();
  double shrink_fac;
  if (random_number < 0.6)
    shrink_fac = 1.0;
  else if (random_number < 0.75)
    shrink_fac = 0.95;
  else if (random_number < 0.854)
    shrink_fac = 0.85;
  else if (random_number < 0.923)
    shrink_fac = 0.75;
  else if (random_number < 0.964)
    shrink_fac = 0.65;
  else if (random_number < 0.987)
    shrink_fac = 0.55;
  else if (random_number < 0.9965)
    shrink_fac = 0.45;
  else if (random_number < 0.9995)
    shrink_fac = 0.35;
  else
    shrink_fac = 0.25;

  const ThreeVector pvec = shrink_fac * fm.fvec().vec();
  const double E = sqrt(pvec.sqr() + pow2(SMP::mb));     // on-shell

  return FourVector(E, pvec);
}
}     // unnamed namespace

// --------------------------------------------------------------------

const PhaseSpace detector_LHC(const PhaseSpace& truePS)
{
  PhaseSpace measuredPS;

#if defined PROCMACRO_WW2l2v
  measuredPS.aa.set(resolveChargedLepton(truePS.aa()));
  measuredPS.pp.set(resolveChargedLepton(truePS.pp()));
  measuredPS.a2.set(measuredPS.aa()+measuredPS.pp());
  measuredPS.p2.set(resolveMissmom(truePS.p2()));
#elif defined PROCMACRO_ZAZ_2l2v
  measuredPS.aa.set(resolveChargedLepton(truePS.aa()));
  measuredPS.ap.set(resolveChargedLepton(truePS.ap()));
  measuredPS.a.set(measuredPS.aa()+measuredPS.ap());
  measuredPS.p.set(resolveMissmom(truePS.p()));
#elif defined PROCMACRO_ZAZA2l2l
  measuredPS.aa.set(resolveChargedLepton(truePS.aa()));
  measuredPS.ap.set(resolveChargedLepton(truePS.ap()));
  measuredPS.pa.set(resolveChargedLepton(truePS.pa()));
  measuredPS.pp.set(resolveChargedLepton(truePS.pp()));
  completePhaseSpace(measuredPS);
#elif defined PROCMACRO_ZAZA4l
  measuredPS.aa.set(resolveChargedLepton(truePS.aa()));
  measuredPS.ap.set(resolveChargedLepton(truePS.ap()));
  measuredPS.pa.set(resolveChargedLepton(truePS.pa()));
  measuredPS.pp.set(resolveChargedLepton(truePS.pp()));
  completePhaseSpace(measuredPS);
#elif defined PROCMACRO_WWZAZ_2l2v
  measuredPS.aa.set(resolveChargedLepton(truePS.aa()));
  measuredPS.pp.set(resolveChargedLepton(truePS.pp()));
  measuredPS.a2.set(measuredPS.aa()+measuredPS.pp());
  measuredPS.p2.set(resolveMissmom(truePS.p2()));
#else
  fatal_error("error: operator(): unknown process");
#endif

  return measuredPS;
}

/*
  taken from http://arxiv.org/abs/arXiv:1209.0494, p. 3
  
  references for resolveChargedLepton() and resolveHadron():
  =========================================================

%\cite{Aad:2008zzm}
\bibitem{Aad:2008zzm}
  G.~Aad {\it et al.}  [ATLAS Collaboration],
  %``The ATLAS Experiment at the CERN Large Hadron Collider,''
  JINST {\bf 3} (2008) S08003.
  %%CITATION = JINST,3,S08003;%%

%\cite{}
\bibitem{}
  G. L. Bayatian et al. (CMS Collaboration). J.Phys. G 34 (2007) 995.

  reference for resolveMissmom():
  ===============================

%\cite{}
\bibitem{}
  [CMS Collaboration],
  %``Particle-Flow Event Reconstruction in CMS and Performance for Jets, Taus, and MET,''
  CMS-PAS-PFT-09-001.
  %%CITATION = CMS-PAS-PFT-09-001;%%

 */

const FourVector resolveChargedLepton(const FourMomentum& fm)
{
  // limit: |eta| < 2.5
  return smear(fm, gaussDeviation(fm.E() * 0.02));
}

const FourVector resolveHadron(const FourMomentum& fm)
{
  const double stddev =
    fm.E() * sqrt(pow2(5.2/fm.E()) + pow2(0.16)/fm.E() + pow2(0.033));
  return smear(fm, gaussDeviation(stddev));
}

const FourVector resolveMissmom(const FourMomentum& fm_miss)
{
  const double Etmiss = fm_miss.Et();
  const double stddev = Etmiss * (2.92/Etmiss - 0.07);
  const double fac_px = 1. + gaussDeviation(stddev)/Etmiss;
  const double fac_py = 1. + gaussDeviation(stddev)/Etmiss;
  return FourVector(fm_miss.E(),
                    fm_miss.px() * fac_px,
                    fm_miss.py() * fac_py,
                    fm_miss.pz());
}

#include <typeinfo>
using std::bad_cast;
#include <cassert>
/* assert macro */
#include <iostream>
using std::cout;
#include <iomanip>
using std::endl;

#include "histosuite.h"
#include "settings.h"
#include "utilities.h"
#include "geometry.h"
#include "phasespace.h"

// helper ----------------
const int HistoSuite::numberOfNamedHistograms()
{
  return 15;
}

HistoSuite::HistoSuite()
  : continuumMappingDim(10), 
    higgsResonantMappingDim(12),
#if defined PROCMACRO_WWZAZ_2l2v
    list(PHistoList(numberOfNamedHistograms()+2*continuumMappingDim+2*higgsResonantMappingDim, PHisto(0))),
#elif defined PROCMACRO_ZAZA2l2l || defined PROCMACRO_ZAZA4l
    list(PHistoList(numberOfNamedHistograms()+2*12+10, PHisto(0))),
#else
    list(PHistoList(numberOfNamedHistograms()+continuumMappingDim+higgsResonantMappingDim, PHisto(0))),
#endif
    m4l(list[0]),
    ma(list[1]),
    ma2(list[2]),
    mp(list[3]),
    mp2(list[4]),
    etal(list[5]),
    ptl(list[6]),
    ptmiss(list[7]),
    ptlmax(list[8]),
    ptlmin(list[9]),
    mll(list[10]),
    absdeletall(list[11]),
    abscosthetallsys(list[12]),
    costhetall(list[13]),
    absdelphill(list[14])
{
  m4l = new Histo("M(4l)", 0., 4000., 2.5);
  ma = new Histo("M(a)", 0., 150., 1.);
  mp = new Histo("M(p)", 0., 150., 1.);
  ma2 = new Histo("M(a2)", 0., 150., 1.);
  mp2 = new Histo("M(p2)", 0., 150., 1.);
  etal = new Histo("etal", -5., 5., 0.2);
  ptl = new Histo("ptl", 0., 500., 2.5);
  ptmiss = new Histo("ptmiss", 0., 500., 2.5);
  ptlmax = new Histo("ptlmax", 0., 500., 2.5);
  ptlmin = new Histo("ptlmin", 0., 500., 2.5);
  mll = new Histo("mll", 0., 1000., 5.);
  absdeletall = new Histo("absdeletall", 0., 5., 0.1);
  abscosthetallsys = new Histo("abscosthetallsys", 0., 1., 0.02);
  costhetall = new Histo("costhetall", -1., 1., 0.05);
  absdelphill = new Histo("absdelphill", 0., 180., 3.);

  // -----------------------------------------------------------------------------
  
#if defined PROCMACRO_WWZAZ_2l2v
  for (int i=0; i < continuumMappingDim; ++i) {
    list.at(numberOfNamedHistograms()+i) = new Histo("cont WW random "+toString<int>(i+1), 0., 1., 0.02);
  }  
  for (int i=0; i < continuumMappingDim; ++i) {
    list.at(numberOfNamedHistograms()+continuumMappingDim+i) = new Histo("cont ZZ random "+toString<int>(i+1), 0., 1., 0.02);
  }
  
  for (int i=0; i < higgsResonantMappingDim; ++i) {
    list.at(numberOfNamedHistograms()+2*continuumMappingDim+i) = new Histo("higgsRes WW random "+toString<int>(i+1), 0., 1., 0.02);
  }
  for (int i=0; i < higgsResonantMappingDim; ++i) {
    list.at(numberOfNamedHistograms()+2*continuumMappingDim+higgsResonantMappingDim+i) = new Histo("higgsRes ZZ random "+toString<int>(i+1), 0., 1., 0.02);
  }
#elif defined PROCMACRO_ZAZA2l2l || defined PROCMACRO_ZAZA4l
  for (int i=0; i < 12; ++i) {
    list.at(numberOfNamedHistograms()+i) = new Histo("resHiggs random "+toString<int>(i+1), 0., 1., 0.02);
  }

  for (int i=0; i < 12; ++i) {
    list.at(numberOfNamedHistograms()+12+i) = new Histo("nonResHiggsBelow random "+toString<int>(i+1), 0., 1., 0.02);
  }
  
  for (int i=0; i < 10; ++i) {
    list.at(numberOfNamedHistograms()+2*12+i) = new Histo("cont/nonResHiggsAbove random "+toString<int>(i+1), 0., 1., 0.02);
  }
#else
  for (int i=0; i < continuumMappingDim; ++i) {
    list.at(numberOfNamedHistograms()+i) = new Histo("cont random "+toString<int>(i+1), 0., 1., 0.02);
  }
  
  for (int i=0; i < higgsResonantMappingDim; ++i) {
    list.at(numberOfNamedHistograms()+continuumMappingDim+i) = new Histo("higgsRes random "+toString<int>(i+1), 0., 1., 0.02);
  }
#endif
}

void HistoSuite::fill(const PhaseSpace& truePS, const PhaseSpace& measuredPS,
                      const double dsigma, const double weight, const int type)
{
  assert(weight > 0.0);

#if defined PROCMACRO_WW2l2v || defined PROCMACRO_WWZAZ_2l2v
  const ConstValue<FourMomentum>& l1 = truePS.aa;
  const ConstValue<FourMomentum>& l2 = truePS.pp;
  ConstValue<FourMomentum> miss(truePS.pa() + truePS.ap());
#elif defined PROCMACRO_ZAZ_2l2v
  const ConstValue<FourMomentum>& l1 = truePS.aa;
  const ConstValue<FourMomentum>& l2 = truePS.ap;
  ConstValue<FourMomentum> miss(truePS.pa() + truePS.pp());
#endif

  // -----------------------------------------------------------------------------

  m4l->fill(truePS.E_partonCMS(), dsigma, weight); 
  ma->fill(truePS.a().m(), dsigma, weight); 
  mp->fill(truePS.p().m(), dsigma, weight); 
#ifdef PROCMACRO_ZAZA4l
  ma2->fill(truePS.a2().m(), dsigma, weight); 
  mp2->fill(truePS.p2().m(), dsigma, weight); 
#endif

  // -----------------------------------------------------------------------------

  etal->fill(truePS.aa().eta(), dsigma, weight); 
  ptl->fill(truePS.aa().pt(), dsigma, weight); 

#if defined PROCMACRO_WW2l2v || defined PROCMACRO_WWZAZ_2l2v || defined PROCMACRO_ZAZ_2l2v
  ConstValue<FourMomentum> ll(l1() + l2());
  ptmiss->fill(miss().pt(), dsigma, weight); 
  mll->fill(ll().m(), dsigma, weight);
  const FourMomentumPair llpair(l1, l2);
  absdeletall->fill(fabs(llpair.Deta()), dsigma, weight); 
  abscosthetallsys->fill(fabs(ll().pz()/ll().pabs()), dsigma, weight); 
  costhetall->fill(llpair.costh(), dsigma, weight); 
  absdelphill->fill(deg(llpair.Dphi()), dsigma, weight); 
  ptlmax->fill(max(l1().pt(), l2().pt()), dsigma, weight); 
  ptlmin->fill(min(l1().pt(), l2().pt()), dsigma, weight); 
#endif
  
  // -----------------------------------------------------------------------------

#if defined PROCMACRO_WWZAZ_2l2v
  if (truePS.randomNumber().size() == continuumMappingDim) {
    if ((numberOfPsMappings == 2 && type == Mapping::WW) || (numberOfPsMappings == 4 && type == Mapping::NONRESONANTHIGGS+2*Mapping::WW)) {
      for (int i=0; i < continuumMappingDim; ++i) {
	list[numberOfNamedHistograms()+i]->fill(truePS.randomNumber()[i], dsigma, weight);
      }
    }
    else if ((numberOfPsMappings == 2 && type == Mapping::ZZ) || (numberOfPsMappings == 4 && type == Mapping::NONRESONANTHIGGS+2*Mapping::ZZ)) {
      for (int i=0; i < continuumMappingDim; ++i) {
	list[numberOfNamedHistograms()+continuumMappingDim+i]->fill(truePS.randomNumber()[i], dsigma, weight);
      }
    }
    else {
      fatal_error("error: HistoSuite::fill: unknown CONTINUUM PS mapping");
    }
  }
  else if (truePS.randomNumber().size() == higgsResonantMappingDim) {
    if ((numberOfPsMappings == 2 && type == Mapping::WW) || (numberOfPsMappings == 4 && type == Mapping::RESONANTHIGGS+2*Mapping::WW)) {
      for (int i=0; i < higgsResonantMappingDim; ++i) {
	list[numberOfNamedHistograms()+2*continuumMappingDim+i]->fill(truePS.randomNumber()[i], dsigma, weight);
      }
    }
    else if ((numberOfPsMappings == 2 && type == Mapping::ZZ) || (numberOfPsMappings == 4 && type == Mapping::RESONANTHIGGS+2*Mapping::ZZ)) {
      for (int i=0; i < higgsResonantMappingDim; ++i) {
	list[numberOfNamedHistograms()+2*continuumMappingDim+higgsResonantMappingDim+i]->fill(truePS.randomNumber()[i], dsigma, weight);
      }
    }
    else {
      fatal_error("error: HistoSuite::fill: unknown HIGGSRESONANT PS mapping");
    }
  }
  else {
    fatal_error("error: HistoSuite::fill: unknown WW/ZZ PS mapping");
  }
#elif defined PROCMACRO_ZAZA2l2l || defined PROCMACRO_ZAZA4l
  if ((numberOfPsMappings > 1 && type == Mapping::RESONANTHIGGS) || resonantHiggsOnly || applyingHiggsNWA) {
    assert(truePS.randomNumber().size() == 12);
    for (int i=0; i < 12; ++i) {
      list[numberOfNamedHistograms()+i]->fill(truePS.randomNumber()[i], dsigma, weight);
    }
  }
  else if (numberOfPsMappings > 1 && type == Mapping::NONRESONANTHIGGSBELOW) {
    assert(truePS.randomNumber().size() == 12);    
    for (int i=0; i < 12; ++i) {
      list[numberOfNamedHistograms()+12+i]->fill(truePS.randomNumber()[i], dsigma, weight);
    }
  }
  else if (AmpSqr::includesOnlyBackground(ampSqr.selection()) || resonantVVcontOnly || type == Mapping::NONRESONANTHIGGSABOVE) {
    assert(truePS.randomNumber().size() == 10);    
    for (int i=0; i < 10; ++i) {
      list[numberOfNamedHistograms()+2*12+i]->fill(truePS.randomNumber()[i], dsigma, weight);
    }
  }
  else {
    fatal_error("error: HistoSuite::fill: unknown PS mapping");
  }
#else
  if (truePS.randomNumber().size() == continuumMappingDim) {
    for (int i=0; i < continuumMappingDim; ++i) {
      list[numberOfNamedHistograms()+i]->fill(truePS.randomNumber()[i], dsigma, weight);
    }
  }
  else if (truePS.randomNumber().size() == higgsResonantMappingDim) {
    for (int i=0; i < higgsResonantMappingDim; ++i) {
      list[numberOfNamedHistograms()+continuumMappingDim+i]->fill(truePS.randomNumber()[i], dsigma, weight);
    }
  }
  else {
    fatal_error("error: HistoSuite::fill: unknown PS mapping");
  }
#endif
}

void HistoSuite::print(ostream& os)
{
  for (PHistoList::const_iterator it = list.begin(); it != list.end(); ++it)
    (*it)->print(os);
}

HistoSuite& HistoSuite::operator+=(const HistoSuite& partial)
{
  assert(list.size() == partial.list.size());
  PHistoList::const_iterator it = list.begin();
  PHistoList::const_iterator pit = partial.list.begin();
  while (it != list.end()) {
    Histo& histo = **it;
    const Histo& partialHisto = **pit;
    histo += partialHisto;
    ++it;
    ++pit;
  }
  return *this;
}

void HistoSuite::updateEstimatesWithPartialEstimates()
{
  for (PHistoList::const_iterator it = list.begin(); it != list.end(); ++it)
    (*it)->updateEstimatesWithPartialEstimates();
}

void HistoSuite::updatePartialEstimates(const Int64 numberOfShots)
{
  for (PHistoList::const_iterator it = list.begin(); it != list.end(); ++it)
    (*it)->updatePartialEstimates(numberOfShots);
}

void HistoSuite::toStream(ostream& os)
{
  for (PHistoList::const_iterator it = list.begin(); it != list.end(); ++it)
    (*it)->toStream(os);
}

HistoSuite *const HistoSuite::cloneEmpty() const
{
  return new HistoSuite();
}

void HistoSuite::fromStream(istream& is)
{
  for (PHistoList::const_iterator it = list.begin(); it != list.end(); ++it)
    (*it)->fromStream(is);
}

HistoSuite& HistoSuite::operator+=(const OmniHistoSuite& partial)
{
  try {
    const HistoSuite& partialHistoSuite = dynamic_cast<const HistoSuite&>(partial);
    operator+=(partialHistoSuite);
  }
  catch (bad_cast) {
    fatal_error("HistoSuite::operator+=(const OmniHistoSuite& partial): arg not of type HistoSuite");
  }
  return *this;
}

HistoSuite::~HistoSuite()
{
  for (PHistoList::const_iterator it = list.begin(); it != list.end(); ++it)
    delete *it;     // pointer to Histo
}

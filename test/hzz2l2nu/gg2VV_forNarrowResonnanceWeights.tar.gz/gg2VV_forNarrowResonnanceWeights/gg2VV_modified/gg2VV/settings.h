#ifndef SETTINGS_H
#define SETTINGS_H

#include <sstream>
using std::ostringstream;
#include <string>
using std::string;

#include "amp.h"
#include "selection.h"
#include "scales.h"
#include "events.h"
#include "64bittypes.h"

extern int maxNumberOfGridAdaptationIterations;
extern Int64 gridAdaptationNumberOfShots; //MODIFIED BY LOIC QUERTENMONT
extern Int64 mainRunNumberOfShots; //MODIFIED BY LOIC QUERTENMONT
extern long int seedForRandomNumberGenerator;

extern const bool generateEvents;
extern const bool unweightEvents;
extern int numberOfEvents; //MODIFIED BY LOIC QUERTENMONT
extern const int iterationsGridAdaptation;
extern const int shotsPerIterGridAdaptation;
extern const int shotsEstimateRun;

enum WWZAZ_2l2vIntermediateStatesType { W_PAIR, Z_PAIR };
extern const int wwzaz_2l2v_intermediate_state_in_events;

extern unsigned int amplitude_selection; //MODIFIED BY LOIC QUERTENMONT

extern AmpSqr& ampSqr;

extern const double minInvMassPhotonProp;

extern const Selection& selection;

extern vector<Scales*> scales_ptr_vector;
void initialize_scales();
extern const int scale_variation_factor;

extern bool nonresonantHiggsOnly; //MODIFIED BY LOIC QUERTENMONT
extern const bool resonantHiggsOnly;
extern const bool resonantVVcontOnly;

extern int numberOfPsMappings;
extern const double compositePhaseSpaceParameter;
extern const double contSingleResVUpperBound;

typedef const double (*Alphas)(const double scale);
extern const Alphas alphas;

extern const bool applyingHiggsBarScheme;
extern const bool applyingHiggsFixedWidthBreitWigner;

extern const bool applyingHiggsNWA;
extern const bool applyingNWA;

extern const bool requestPDFError;
extern bool _calculatePDFError;
extern bool _calculateScaleError;

extern const string settingsDescription;

extern const string lhapdf_file;

namespace StandardModelParameters
{
  // couplings
  extern const double alpha;
  extern const double sin2w;
  extern const double gfermi;     // [GeV^-2]
  // masses [GeV]
  extern const double mb;
  extern const double mt;
  extern const double mW;
  extern const double mZ;
  extern double mH;  //MODIFIED BY LOIC QUERTENMONT
  extern const double mmuon;
  extern const double mtau;
  // widths [GeV]
  extern const double wW;
  extern const double wZ;
  extern double wH;  //MODIFIED BY LOIC QUERTENMONT
  // process dependent vector boson mass and width
  extern const double mV;
  extern const double wV;
  // CKM matrix
  extern const double CKM_lambda;
  extern const double CKM_A;
  extern const double CKM_rho_bar;
  extern const double CKM_eta_bar;

  // helper functions defined in smp.cpp:
  const double W_width();
  const double Z_width();
  const double gamma_H_HTO();
  const double H_width();
  const double H_width_BCKK_paper();
  const double t_width();
  void report();
}
namespace SMP = StandardModelParameters;

namespace BeyondStandardModelParameters
{
  extern double HggCouplingRescalingFactor;  //MODIFIED BY LOIC QUERTENMONT
  extern double HWWCouplingRescalingFactor;  //MODIFIED BY LOIC QUERTENMONT
  extern double HZZCouplingRescalingFactor;  //MODIFIED BY LOIC QUERTENMONT
}
namespace BSM = BeyondStandardModelParameters;

typedef void (*Compare_amplitude_ptr)();
extern Compare_amplitude_ptr compare_amplitude_ptr;


void getParametersFromCommandLine(int argc, char* argv[]); //ADDED BY LOIC QUERTENMONT


#endif  /* SETTINGS_H */

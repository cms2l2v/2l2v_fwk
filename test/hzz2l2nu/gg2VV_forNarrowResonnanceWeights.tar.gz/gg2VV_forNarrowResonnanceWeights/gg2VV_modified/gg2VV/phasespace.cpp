#include <cassert>
/* assert macro */
#include <iostream>
using std::ostream;
using std::cout;
#include <iomanip>
using std::endl;
using std::setprecision;

#include "phasespace.h"
#include "geometry.h"
#include "check.h"
#include "small_powers.h"
#include "settings.h"
#include "utilities.h"
#include "kinematics.h"
#include "rng.h"

PhaseSpace::PhaseSpace()
{}

void PhaseSpace::check() const
{
  using ::check;
  const double err = 1.e-3;

  // 4-momentum conservation
  FourVector netMomentum;
  netMomentum += i().fvec();
  netMomentum += i_().fvec();
  netMomentum -= ap().fvec();
  netMomentum -= aa().fvec();
  netMomentum -= pa().fvec();
  netMomentum -= pp().fvec();
  check(netMomentum, FourVector(0.,0.,0.,0.),
        "PhaseSpace: 4-momentum not conserved", err);

  // on-shell conditions
  check(i().m2(), 0.0, "PhaseSpace: external particle off-shell: i", err);
  check(i_().m2(), 0.0, "PhaseSpace: external particle off-shell: i_", err);
  check(ap().m2(), 0.0, "PhaseSpace: external particle off-shell: ap", err);
  check(aa().m2(), 0.0, "PhaseSpace: external particle off-shell: aa", err);
  check(pa().m2(), 0.0, "PhaseSpace: external particle off-shell: pa", err);
  check(pp().m2(), 0.0, "PhaseSpace: external particle off-shell: pp", err);

}

void PhaseSpace::print(ostream& os) const
{
  os << setprecision(16);
  os << "=== START: phase space configuration ============================" << endl;
  os << "(E,px,py,pz) in GeV, physical momentum flow:" << endl;
  os << "i  (" << i() << ")" << endl;
  os << "i_ (" << i_() << ")" << endl;
  os << "aa (" << aa() << ")" << endl;
  os << "ap (" << ap() << ")" << endl;
  os << "pa (" << pa() << ")" << endl;
  os << "pp (" << pp() << ")" << endl;
  os << "------------------------" << endl;
  if (a.isSet() && p.isSet() && E_partonCMS.isSet()) {
    os << "a (" << a() << ")" << endl;
    os << "p (" << p() << ")" << endl;
    os << "------------------------" << endl;
    os << "inv. a mass = " << a().m() << endl;
    os << "inv. p mass = " << p().m() << endl;
    os << "p_T(a) = " << a().pt() << endl;
    os << "------------------------" << endl;
    os << "parton CMS energy = " << E_partonCMS() << endl;
  }
  else {
    os << "warning: a, p, or E_partonCMS not set" << endl;
  }
  os << "=== END: phase space configuration =============================" << endl;
}

void PhaseSpace::printCode(ostream& os) const 
{
  os << setprecision(16);
  os << "  ps_ptr = &getAddedPhaseSpace(psList);" << endl;
  os << "  ps_ptr->i.set(FourMomentum(" << i() << "));" << endl;
  os << "  ps_ptr->i_.set(FourMomentum(" << i_() << "));" << endl;
  os << "  ps_ptr->aa.set(FourMomentum(" << aa() << "));" << endl;
  os << "  ps_ptr->ap.set(FourMomentum(" << ap() << "));" << endl;
  os << "  ps_ptr->pa.set(FourMomentum(" << pa() << "));" << endl;
  os << "  ps_ptr->pp.set(FourMomentum(" << pp() << "));" << endl;
}

const PhaseSpace boost(const PhaseSpace& ps, const FourVector& r, const bool reverse_r)     // default: reverse_r = false
{
  PhaseSpace boosted;
  boosted.i.set(boost(ps.i(), r, reverse_r));
  boosted.i_.set(boost(ps.i_(), r, reverse_r));
  boosted.aa.set(boost(ps.aa(), r, reverse_r));
  boosted.ap.set(boost(ps.ap(), r, reverse_r));
  boosted.pa.set(boost(ps.pa(), r, reverse_r));
  boosted.pp.set(boost(ps.pp(), r, reverse_r));
  checkAndCompletePhaseSpace(boosted);
  return boosted;
}

const PhaseSpace map_to_float(const PhaseSpace& ps)
{
  PhaseSpace ps_float;
  ps_float.i.set(map_to_float(ps.i()));
  ps_float.i_.set(map_to_float(ps.i_()));
  ps_float.aa.set(map_to_float(ps.aa()));
  ps_float.ap.set(map_to_float(ps.ap()));
  ps_float.pa.set(map_to_float(ps.pa()));
  ps_float.pp.set(map_to_float(ps.pp()));
  completePhaseSpace(ps_float);
  return ps_float;
}

void checkAndCompletePhaseSpace(PhaseSpace& ps)
{
  ps.check();
  completePhaseSpace(ps);
}

void completePhaseSpace(PhaseSpace& ps)
{
  ps.a.set(ps.aa() + ps.ap());
  ps.p.set(ps.pa() + ps.pp());
  ps.a2.set(ps.aa() + ps.pp());
  ps.p2.set(ps.pa() + ps.ap());
  ps.E_partonCMS.set(FourMomentum(ps.a() + ps.p()).m());
}

using MappingComponents::Propagator;
using MappingComponents::Resonance;
using MappingComponents::ResonancePlusMassless;
using MappingComponents::TwoBodyDecay;
using MappingComponents::TwoToJetsAndResiduum;
using MappingComponents::TwoToResonanceAndTwoBodyDecay;
typedef MappingComponents::FinalStateParticle FSP;

namespace Mapping
{
const bool minInvMassPhotonPropCutsPassed(const PhaseSpace& truePS)
{
  bool minInvMassPhotonPropCutsPassed = false;
  if (amplitude_selection == AmpSqr::HIGGSSIGNAL) {
    minInvMassPhotonPropCutsPassed = true;
  }
  else {
#if defined PROCMACRO_WW2l2v
    minInvMassPhotonPropCutsPassed = true;
#elif defined PROCMACRO_ZAZ_2l2v
    minInvMassPhotonPropCutsPassed = truePS.a().m() > minInvMassPhotonProp;
#elif defined PROCMACRO_WWZAZ_2l2v
    minInvMassPhotonPropCutsPassed = truePS.a2().m() > minInvMassPhotonProp;
#elif defined PROCMACRO_ZAZA2l2l
    minInvMassPhotonPropCutsPassed = truePS.a().m() > minInvMassPhotonProp
      && truePS.p().m() > minInvMassPhotonProp;
#elif defined PROCMACRO_ZAZA4l
    minInvMassPhotonPropCutsPassed = truePS.a().m() > minInvMassPhotonProp
      && truePS.p().m() > minInvMassPhotonProp
      && truePS.a2().m() > minInvMassPhotonProp
      && truePS.p2().m() > minInvMassPhotonProp;
#endif    
  }
  return minInvMassPhotonPropCutsPassed;
}

// =============================================================================

#if !defined PROCMACRO_WWZAZ_2l2v
void continuum(const vector<double>& randomNumber, PhaseSpace& ps)
{
  assert(randomNumber.size() == 10);
  static TwoToJetsAndResiduum reaction;
  static TwoBodyDecay decay;

  static Propagator* propv_a = 0;
  static Propagator* propv_p = 0;
  if (!propv_a) {
    assert(!propv_p);
    if (amplitude_selection == AmpSqr::HIGGSSIGNAL) {
      propv_a = new Resonance(SMP::mV, SMP::wV, PhaseSpace::E_CMS());
      propv_p = new Resonance(SMP::mV, SMP::wV, PhaseSpace::E_CMS());
    }
    else {
#if defined PROCMACRO_WW2l2v  
       propv_a = new Resonance(SMP::mV, SMP::wV, PhaseSpace::E_CMS());
       propv_p = new Resonance(SMP::mV, SMP::wV, PhaseSpace::E_CMS());
#elif defined PROCMACRO_ZAZA2l2l || defined PROCMACRO_ZAZA4l
       propv_a = new ResonancePlusMassless(SMP::mV, SMP::wV, minInvMassPhotonProp, PhaseSpace::E_CMS());
       propv_p = new ResonancePlusMassless(SMP::mV, SMP::wV, minInvMassPhotonProp, PhaseSpace::E_CMS());
#elif defined PROCMACRO_ZAZ_2l2v
       propv_a = new ResonancePlusMassless(SMP::mV, SMP::wV, minInvMassPhotonProp, PhaseSpace::E_CMS());
       propv_p = new Resonance(SMP::mV, SMP::wV, PhaseSpace::E_CMS());
#endif
    }
  }

  double weight = 1.;
  propv_a->operator()(randomNumber[0], weight, applyingNWA);
  if (weight == 0.) {
    ps.weight.set(0.);
    return;
  }
  propv_p->operator()(randomNumber[1], weight, applyingNWA);
  if (weight == 0.) {
    ps.weight.set(0.);
    return;
  }
  reaction(vector<double>(randomNumber.end()-4, randomNumber.end()),
           ps.E_CMS(), vector<FSP>(1, FSP(propv_a->m())), FSP(propv_p->m()));
  weight *= reaction.weight();
  if (weight == 0.) {
    ps.weight.set(0.);
    return;
  }
  ps.E_partonCMS.set(reaction.E_partonCMS());
  ps.i.set(reaction.in1());
  ps.x.set(reaction.x1());
  ps.i_.set(reaction.in2());
  ps.x_.set(reaction.x2());
  const FourMomentum prop1 = reaction.out(0);
  const FourMomentum prop2 = reaction.out_res();
  decay(randomNumber[2], randomNumber[3], prop1, 0., 0., weight);
  if (weight == 0.) {
    ps.weight.set(0.);
    return;
  }
  const FourMomentum prop1_a = decay.p1();
  const FourMomentum prop1_p = decay.p2();
  decay(randomNumber[4], randomNumber[5], prop2, 0., 0., weight);
  if (weight == 0.) {
    ps.weight.set(0.);
    return;
  }
  const FourMomentum prop2_a = decay.p1();
  const FourMomentum prop2_p = decay.p2();

#if defined PROCMACRO_ZAZA4l
  const bool generate_a_p = randomNumberGenerator->uniformInZeroOne() < 0.5;
  weight *= 2.;
  if (generate_a_p) {
    ps.a.set(prop1);
    ps.aa.set(prop1_a);
    ps.ap.set(prop1_p);
    ps.p.set(prop2);
    ps.pa.set(prop2_a);
    ps.pp.set(prop2_p);
    ps.a2.set(ps.aa() + ps.pp());
    ps.p2.set(ps.pa() + ps.ap());
    const double fac_a_p = propv_a->f(ps.a().m2()) * propv_p->f(ps.p().m2());
    const double fac_a2_p2 = propv_a->f(ps.a2().m2()) * propv_p->f(ps.p2().m2());
    weight *= fac_a2_p2/(fac_a_p + fac_a2_p2);
  }
  else {   // generate a2_p2
    ps.a2.set(prop1);
    ps.aa.set(prop1_a);
    ps.pp.set(prop1_p);
    ps.p2.set(prop2);
    ps.pa.set(prop2_a);
    ps.ap.set(prop2_p);
    ps.a.set(ps.aa() + ps.ap());
    ps.p.set(ps.pa() + ps.pp());
    const double fac_a_p = propv_a->f(ps.a().m2()) * propv_p->f(ps.p().m2());
    const double fac_a2_p2 = propv_a->f(ps.a2().m2()) * propv_p->f(ps.p2().m2());
    weight *= fac_a_p/(fac_a_p + fac_a2_p2);
  }
#else
  ps.a.set(prop1);
  ps.aa.set(prop1_a);
  ps.ap.set(prop1_p);
  ps.p.set(prop2);
  ps.pa.set(prop2_a);
  ps.pp.set(prop2_p);
  ps.a2.set(ps.aa() + ps.pp());
  ps.p2.set(ps.pa() + ps.ap());
#endif

  ps.weight.set(weight);
  ps.randomNumber.set(randomNumber);
}

void contSingleResV(const vector<double>& randomNumber, PhaseSpace& ps)
{
  assert(randomNumber.size() == 12);
  static TwoToJetsAndResiduum reaction;
  static TwoBodyDecay decay;

  static Propagator* propv_a = 0;
  static Propagator* propv_p = 0;
  if (!propv_a) {
    assert(!propv_p);
    if (amplitude_selection == AmpSqr::HIGGSSIGNAL) {
      propv_a = new Resonance(SMP::mV, SMP::wV, contSingleResVUpperBound);
      propv_p = new Resonance(SMP::mV, SMP::wV, contSingleResVUpperBound);
    }
    else {
#if defined PROCMACRO_ZAZA2l2l || defined PROCMACRO_ZAZA4l
       propv_a = new ResonancePlusMassless(SMP::mV, SMP::wV, minInvMassPhotonProp, contSingleResVUpperBound);
       propv_p = new ResonancePlusMassless(SMP::mV, SMP::wV, minInvMassPhotonProp, contSingleResVUpperBound);
#else
       assert(false);
#endif
    }
  }

  FSP fsp1;
  FSP fsp2;
  double weight = 1.;

  const bool propv_a_mapping_first = randomNumberGenerator->uniformInZeroOne() < 0.5;
  weight *= 2.;
  if (propv_a_mapping_first) {
    propv_a->operator()(randomNumber[0], contSingleResVUpperBound - propv_p->minInvMass(), weight, applyingNWA);
    if (weight == 0.) {
      ps.weight.set(0.);
      return;
    }
    propv_p->operator()(randomNumber[1], contSingleResVUpperBound - propv_a->m(), weight, applyingNWA);
    if (weight == 0. || !(contSingleResVUpperBound > propv_a->m() + propv_p->m())) {
      ps.weight.set(0.);
      return;
    }
    const double f_a = propv_a->mappedFunction(propv_a->m2());
    const double f_p = propv_p->mappedFunction(propv_p->m2());
    weight *= f_a/(f_a + f_p);
  }
  else {
    propv_p->operator()(randomNumber[2], contSingleResVUpperBound - propv_a->minInvMass(), weight, applyingNWA);
    if (weight == 0.) {
      ps.weight.set(0.);
      return;
    }
    propv_a->operator()(randomNumber[3], contSingleResVUpperBound - propv_p->m(), weight, applyingNWA);
    if (weight == 0. || !(contSingleResVUpperBound > propv_a->m() + propv_p->m())) {
      ps.weight.set(0.);
      return;
    }
    const double f_p = propv_p->mappedFunction(propv_p->m2());
    const double f_a = propv_a->mappedFunction(propv_a->m2());
    weight *= f_p/(f_a + f_p);
  }

  fsp1.set(propv_a->m());
  fsp2.set(propv_p->m());
  reaction(vector<double>(randomNumber.end()-4, randomNumber.end()),
           ps.E_CMS(), vector<FSP>(1, fsp2), fsp1);
  weight *= reaction.weight();
  if (weight == 0.) {
    ps.weight.set(0.);
    return;
  }
  ps.E_partonCMS.set(reaction.E_partonCMS());
  ps.i.set(reaction.in1());
  ps.x.set(reaction.x1());
  ps.i_.set(reaction.in2());
  ps.x_.set(reaction.x2());
  const FourMomentum prop1 = reaction.out(0);
  const FourMomentum prop2 = reaction.out_res();
  decay(randomNumber[4], randomNumber[5], prop1, 0., 0., weight);
  if (weight == 0.) {
    ps.weight.set(0.);
    return;
  }
  const FourMomentum prop1_a = decay.p1();
  const FourMomentum prop1_p = decay.p2();
  decay(randomNumber[6], randomNumber[7], prop2, 0., 0., weight);
  if (weight == 0.) {
    ps.weight.set(0.);
    return;
  }
  const FourMomentum prop2_a = decay.p1();
  const FourMomentum prop2_p = decay.p2();

#if defined PROCMACRO_ZAZA4l
  const bool generate_a_p = randomNumberGenerator->uniformInZeroOne() < 0.5;
  weight *= 2.;
  if (generate_a_p) {
    ps.a.set(prop1);
    ps.aa.set(prop1_a);
    ps.ap.set(prop1_p);
    ps.p.set(prop2);
    ps.pa.set(prop2_a);
    ps.pp.set(prop2_p);
    ps.a2.set(ps.aa() + ps.pp());
    ps.p2.set(ps.pa() + ps.ap());
    const double fac_a_p = propv_a->f(ps.a().m2()) * propv_p->f(ps.p().m2());
    const double fac_a2_p2 = propv_a->f(ps.a2().m2()) * propv_p->f(ps.p2().m2());
    weight *= fac_a2_p2/(fac_a_p + fac_a2_p2);
  }
  else {   // generate a2_p2
    ps.a2.set(prop1);
    ps.aa.set(prop1_a);
    ps.pp.set(prop1_p);
    ps.p2.set(prop2);
    ps.pa.set(prop2_a);
    ps.ap.set(prop2_p);
    ps.a.set(ps.aa() + ps.ap());
    ps.p.set(ps.pa() + ps.pp());
    const double fac_a_p = propv_a->f(ps.a().m2()) * propv_p->f(ps.p().m2());
    const double fac_a2_p2 = propv_a->f(ps.a2().m2()) * propv_p->f(ps.p2().m2());
    weight *= fac_a_p/(fac_a_p + fac_a2_p2);
  }
#else
  ps.a.set(prop1);
  ps.aa.set(prop1_a);
  ps.ap.set(prop1_p);
  ps.p.set(prop2);
  ps.pa.set(prop2_a);
  ps.pp.set(prop2_p);
  ps.a2.set(ps.aa() + ps.pp());
  ps.p2.set(ps.pa() + ps.ap());
#endif

  ps.weight.set(weight);
  ps.randomNumber.set(randomNumber);
}

void higgsResonant(const vector<double>& randomNumber, PhaseSpace& ps)
{
  assert(randomNumber.size() == 12);
  static TwoToResonanceAndTwoBodyDecay reaction;
  static TwoBodyDecay decay;
  static Resonance rh(SMP::mH, SMP::wH, PhaseSpace::E_CMS());

  static Propagator* propv_a = 0;
  static Propagator* propv_p = 0;
  if (!propv_a) {
    assert(!propv_p);
    if (amplitude_selection == AmpSqr::HIGGSSIGNAL) {
      propv_a = new Resonance(SMP::mV, SMP::wV, PhaseSpace::E_CMS());
      propv_p = new Resonance(SMP::mV, SMP::wV, PhaseSpace::E_CMS());
    }
    else {
#if defined PROCMACRO_WW2l2v  
       propv_a = new Resonance(SMP::mV, SMP::wV, PhaseSpace::E_CMS());
       propv_p = new Resonance(SMP::mV, SMP::wV, PhaseSpace::E_CMS());
#elif defined PROCMACRO_ZAZA2l2l || defined PROCMACRO_ZAZA4l
       propv_a = new ResonancePlusMassless(SMP::mV, SMP::wV, minInvMassPhotonProp, PhaseSpace::E_CMS());
       propv_p = new ResonancePlusMassless(SMP::mV, SMP::wV, minInvMassPhotonProp, PhaseSpace::E_CMS());
#elif defined PROCMACRO_ZAZ_2l2v
       propv_a = new ResonancePlusMassless(SMP::mV, SMP::wV, minInvMassPhotonProp, PhaseSpace::E_CMS());
       propv_p = new Resonance(SMP::mV, SMP::wV, PhaseSpace::E_CMS());
#endif
    }
  }

  FSP fsp1;
  FSP fsp2;
  double weight = 1.;

  rh(randomNumber[0], weight, applyingHiggsNWA);
  if (weight == 0. || !(rh.m() > propv_a->minInvMass() + propv_p->minInvMass())) {
    ps.weight.set(0.);
    return;
  }
  const bool propv_a_mapping_first = randomNumberGenerator->uniformInZeroOne() < 0.5;
  weight *= 2.;
  if (propv_a_mapping_first) {
    propv_a->operator()(randomNumber[1], rh.m()-propv_p->minInvMass(), weight, applyingNWA);
    if (weight == 0.) {
      ps.weight.set(0.);
      return;
    }
    propv_p->operator()(randomNumber[2], rh.m()-propv_a->m(), weight, applyingNWA);
    if (weight == 0. || !(rh.m() > propv_a->m() + propv_p->m())) {
      ps.weight.set(0.);
      return;
    }
    const double f_a = propv_a->mappedFunction(propv_a->m2());
    const double f_p = propv_p->mappedFunction(propv_p->m2());
    weight *= f_a/(f_a + f_p);
  }
  else {
    propv_p->operator()(randomNumber[3], rh.m()-propv_a->minInvMass(), weight, applyingNWA);
    if (weight == 0.) {
      ps.weight.set(0.);
      return;
    }
    propv_a->operator()(randomNumber[4], rh.m()-propv_p->m(), weight, applyingNWA);
    if (weight == 0. || !(rh.m() > propv_a->m() + propv_p->m())) {
      ps.weight.set(0.);
      return;
    }
    const double f_p = propv_p->mappedFunction(propv_p->m2());
    const double f_a = propv_a->mappedFunction(propv_a->m2());
    weight *= f_p/(f_a + f_p);
  }

  fsp1.set(propv_a->m());
  fsp2.set(propv_p->m());
  reaction(vector<double>(randomNumber.end()-3, randomNumber.end()),
	   ps.E_CMS(), rh, fsp1, fsp2);
  weight *= reaction.weight();
  if (weight == 0.) {
    ps.weight.set(0.);
    return;
  }
  ps.E_partonCMS.set(reaction.E_partonCMS());
  ps.i.set(reaction.in1());
  ps.x.set(reaction.x1());
  ps.i_.set(reaction.in2());
  ps.x_.set(reaction.x2());
  const FourMomentum prop1 = reaction.out1();
  const FourMomentum prop2 = reaction.out2();
  decay(randomNumber[5], randomNumber[6], prop1, 0., 0., weight);
  if (weight == 0.) {
    ps.weight.set(0.);
    return;
  }
  const FourMomentum prop1_a = decay.p1();
  const FourMomentum prop1_p = decay.p2();
  decay(randomNumber[7], randomNumber[8], prop2, 0., 0., weight);
  if (weight == 0.) {
    ps.weight.set(0.);
    return;
  }
  const FourMomentum prop2_a = decay.p1();
  const FourMomentum prop2_p = decay.p2();

#if defined PROCMACRO_ZAZA4l
  const bool generate_a_p = randomNumberGenerator->uniformInZeroOne() < 0.5;
  weight *= 2.;
  if (generate_a_p) {
    ps.a.set(prop1);
    ps.aa.set(prop1_a);
    ps.ap.set(prop1_p);
    ps.p.set(prop2);
    ps.pa.set(prop2_a);
    ps.pp.set(prop2_p);
    ps.a2.set(ps.aa() + ps.pp());
    ps.p2.set(ps.pa() + ps.ap());
    const double fac_a_p = propv_a->f(ps.a().m2()) * propv_p->f(ps.p().m2());
    const double fac_a2_p2 = propv_a->f(ps.a2().m2()) * propv_p->f(ps.p2().m2());
    weight *= fac_a2_p2/(fac_a_p + fac_a2_p2);
  }
  else {   // generate a2_p2
    ps.a2.set(prop1);
    ps.aa.set(prop1_a);
    ps.pp.set(prop1_p);
    ps.p2.set(prop2);
    ps.pa.set(prop2_a);
    ps.ap.set(prop2_p);
    ps.a.set(ps.aa() + ps.ap());
    ps.p.set(ps.pa() + ps.pp());
    const double fac_a_p = propv_a->f(ps.a().m2()) * propv_p->f(ps.p().m2());
    const double fac_a2_p2 = propv_a->f(ps.a2().m2()) * propv_p->f(ps.p2().m2());
    weight *= fac_a_p/(fac_a_p + fac_a2_p2);
  }
#else
  ps.a.set(prop1);
  ps.aa.set(prop1_a);
  ps.ap.set(prop1_p);
  ps.p.set(prop2);
  ps.pa.set(prop2_a);
  ps.pp.set(prop2_p);
  ps.a2.set(ps.aa() + ps.pp());
  ps.p2.set(ps.pa() + ps.ap());
#endif

  ps.weight.set(weight);
  ps.randomNumber.set(randomNumber);
}
#endif   /* !defined PROCMACRO_WWZAZ_2l2v */

#if defined PROCMACRO_WWZAZ_2l2v
void continuum_WW(const vector<double>& randomNumber, PhaseSpace& ps)
{
  assert(randomNumber.size() == 10);
  static TwoToJetsAndResiduum reaction;
  static TwoBodyDecay decay;

  static Propagator* propv_a = 0;
  static Propagator* propv_p = 0;
  static Propagator* propv_a2 = 0;
  static Propagator* propv_p2 = 0;
  if (!propv_a) {
    assert(!propv_p);
    propv_a = new Resonance(SMP::mW, SMP::wW, PhaseSpace::E_CMS());
    propv_p = new Resonance(SMP::mW, SMP::wW, PhaseSpace::E_CMS());
    if (amplitude_selection == AmpSqr::HIGGSSIGNAL) {
       propv_a2 = new Resonance(SMP::mZ, SMP::wZ, PhaseSpace::E_CMS());
    }
    else {
       propv_a2 = new ResonancePlusMassless(SMP::mZ, SMP::wZ, minInvMassPhotonProp, PhaseSpace::E_CMS());
    }
    propv_p2 = new Resonance(SMP::mZ, SMP::wZ, PhaseSpace::E_CMS());
  }

  double weight = 1.;
  propv_a->operator()(randomNumber[0], weight, applyingNWA);
  if (weight == 0.) {
    ps.weight.set(0.);
    return;
  }
  propv_p->operator()(randomNumber[1], weight, applyingNWA);
  if (weight == 0.) {
    ps.weight.set(0.);
    return;
  }
  reaction(vector<double>(randomNumber.end()-4, randomNumber.end()),
           ps.E_CMS(), vector<FSP>(1, FSP(propv_a->m())), FSP(propv_p->m()));
  weight *= reaction.weight();
  if (weight == 0.) {
    ps.weight.set(0.);
    return;
  }
  ps.E_partonCMS.set(reaction.E_partonCMS());
  ps.i.set(reaction.in1());
  ps.x.set(reaction.x1());
  ps.i_.set(reaction.in2());
  ps.x_.set(reaction.x2());
  const FourMomentum prop1 = reaction.out(0);
  const FourMomentum prop2 = reaction.out_res();
  decay(randomNumber[2], randomNumber[3], prop1, 0., 0., weight);
  if (weight == 0.) {
    ps.weight.set(0.);
    return;
  }
  const FourMomentum prop1_a = decay.p1();
  const FourMomentum prop1_p = decay.p2();
  decay(randomNumber[4], randomNumber[5], prop2, 0., 0., weight);
  if (weight == 0.) {
    ps.weight.set(0.);
    return;
  }
  const FourMomentum prop2_a = decay.p1();
  const FourMomentum prop2_p = decay.p2();

  ps.a.set(prop1);
  ps.aa.set(prop1_a);
  ps.ap.set(prop1_p);
  ps.p.set(prop2);
  ps.pa.set(prop2_a);
  ps.pp.set(prop2_p);
  ps.a2.set(ps.aa() + ps.pp());
  ps.p2.set(ps.pa() + ps.ap());
  const double fac_a_p = propv_a->f(ps.a().m2()) * propv_p->f(ps.p().m2());
  const double fac_a2_p2 = propv_a2->f(ps.a2().m2()) * propv_p2->f(ps.p2().m2());
  weight *= fac_a2_p2/(fac_a_p + fac_a2_p2);

  ps.weight.set(weight);
  ps.randomNumber.set(randomNumber);
}

void continuum_ZZ(const vector<double>& randomNumber, PhaseSpace& ps)
{
  assert(randomNumber.size() == 10);
  static TwoToJetsAndResiduum reaction;
  static TwoBodyDecay decay;

  static Propagator* propv_a = 0;
  static Propagator* propv_p = 0;
  static Propagator* propv_a2 = 0;
  static Propagator* propv_p2 = 0;
  if (!propv_a) {
    assert(!propv_p);
    propv_a = new Resonance(SMP::mW, SMP::wW, PhaseSpace::E_CMS());
    propv_p = new Resonance(SMP::mW, SMP::wW, PhaseSpace::E_CMS());
    if (amplitude_selection == AmpSqr::HIGGSSIGNAL) {
       propv_a2 = new Resonance(SMP::mZ, SMP::wZ, PhaseSpace::E_CMS());
    }
    else {
       propv_a2 = new ResonancePlusMassless(SMP::mZ, SMP::wZ, minInvMassPhotonProp, PhaseSpace::E_CMS());
    }
    propv_p2 = new Resonance(SMP::mZ, SMP::wZ, PhaseSpace::E_CMS());
  }

  double weight = 1.;
  propv_a2->operator()(randomNumber[0], weight, applyingNWA);
  if (weight == 0.) {
    ps.weight.set(0.);
    return;
  }
  propv_p2->operator()(randomNumber[1], weight, applyingNWA);
  if (weight == 0.) {
    ps.weight.set(0.);
    return;
  }
  reaction(vector<double>(randomNumber.end()-4, randomNumber.end()),
           ps.E_CMS(), vector<FSP>(1, FSP(propv_a2->m())), FSP(propv_p2->m()));
  weight *= reaction.weight();
  if (weight == 0.) {
    ps.weight.set(0.);
    return;
  }
  ps.E_partonCMS.set(reaction.E_partonCMS());
  ps.i.set(reaction.in1());
  ps.x.set(reaction.x1());
  ps.i_.set(reaction.in2());
  ps.x_.set(reaction.x2());
  const FourMomentum prop1 = reaction.out(0);
  const FourMomentum prop2 = reaction.out_res();
  decay(randomNumber[2], randomNumber[3], prop1, 0., 0., weight);
  if (weight == 0.) {
    ps.weight.set(0.);
    return;
  }
  const FourMomentum prop1_a = decay.p1();
  const FourMomentum prop1_p = decay.p2();
  decay(randomNumber[4], randomNumber[5], prop2, 0., 0., weight);
  if (weight == 0.) {
    ps.weight.set(0.);
    return;
  }
  const FourMomentum prop2_a = decay.p1();
  const FourMomentum prop2_p = decay.p2();

  ps.a2.set(prop1);
  ps.aa.set(prop1_a);
  ps.pp.set(prop1_p);
  ps.p2.set(prop2);
  ps.pa.set(prop2_a);
  ps.ap.set(prop2_p);
  ps.a.set(ps.aa() + ps.ap());
  ps.p.set(ps.pa() + ps.pp());
  const double fac_a_p = propv_a->f(ps.a().m2()) * propv_p->f(ps.p().m2());
  const double fac_a2_p2 = propv_a2->f(ps.a2().m2()) * propv_p2->f(ps.p2().m2());
  weight *= fac_a_p/(fac_a_p + fac_a2_p2);

  ps.weight.set(weight);
  ps.randomNumber.set(randomNumber);
}

void higgsResonant_WW(const vector<double>& randomNumber, PhaseSpace& ps)
{
  assert(randomNumber.size() == 12);
  static TwoToResonanceAndTwoBodyDecay reaction;
  static TwoBodyDecay decay;
  static Resonance rh(SMP::mH, SMP::wH, PhaseSpace::E_CMS());

  static Propagator* propv_a = 0;
  static Propagator* propv_p = 0;
  static Propagator* propv_a2 = 0;
  static Propagator* propv_p2 = 0;
  if (!propv_a) {
    assert(!propv_p);
    propv_a = new Resonance(SMP::mW, SMP::wW, PhaseSpace::E_CMS());
    propv_p = new Resonance(SMP::mW, SMP::wW, PhaseSpace::E_CMS());
    if (amplitude_selection == AmpSqr::HIGGSSIGNAL) {
       propv_a2 = new Resonance(SMP::mZ, SMP::wZ, PhaseSpace::E_CMS());
    }
    else {
       propv_a2 = new ResonancePlusMassless(SMP::mZ, SMP::wZ, minInvMassPhotonProp, PhaseSpace::E_CMS());
    }
    propv_p2 = new Resonance(SMP::mZ, SMP::wZ, PhaseSpace::E_CMS());
  }

  FSP fsp1;
  FSP fsp2;
  double weight = 1.;

  rh(randomNumber[0], weight, applyingHiggsNWA);
  if (weight == 0. || !(rh.m() > propv_a->minInvMass() + propv_p->minInvMass())) {
    ps.weight.set(0.);
    return;
  }
  const bool propv_a_mapping_first = randomNumberGenerator->uniformInZeroOne() < 0.5;
  weight *= 2.;
  if (propv_a_mapping_first) {
    propv_a->operator()(randomNumber[1], rh.m()-propv_p->minInvMass(), weight, applyingNWA);
    if (weight == 0.) {
      ps.weight.set(0.);
      return;
    }
    propv_p->operator()(randomNumber[2], rh.m()-propv_a->m(), weight, applyingNWA);
    if (weight == 0. || !(rh.m() > propv_a->m() + propv_p->m())) {
      ps.weight.set(0.);
      return;
    }
    const double f_a = propv_a->mappedFunction(propv_a->m2());
    const double f_p = propv_p->mappedFunction(propv_p->m2());
    weight *= f_a/(f_a + f_p);
  }
  else {
    propv_p->operator()(randomNumber[3], rh.m()-propv_a->minInvMass(), weight, applyingNWA);
    if (weight == 0.) {
      ps.weight.set(0.);
      return;
    }
    propv_a->operator()(randomNumber[4], rh.m()-propv_p->m(), weight, applyingNWA);
    if (weight == 0. || !(rh.m() > propv_a->m() + propv_p->m())) {
      ps.weight.set(0.);
      return;
    }
    const double f_p = propv_p->mappedFunction(propv_p->m2());
    const double f_a = propv_a->mappedFunction(propv_a->m2());
    weight *= f_p/(f_a + f_p);
  }

  fsp1.set(propv_a->m());
  fsp2.set(propv_p->m());
  reaction(vector<double>(randomNumber.end()-3, randomNumber.end()),
	   ps.E_CMS(), rh, fsp1, fsp2);
  weight *= reaction.weight();
  if (weight == 0.) {
    ps.weight.set(0.);
    return;
  }
  ps.E_partonCMS.set(reaction.E_partonCMS());
  ps.i.set(reaction.in1());
  ps.x.set(reaction.x1());
  ps.i_.set(reaction.in2());
  ps.x_.set(reaction.x2());
  const FourMomentum prop1 = reaction.out1();
  const FourMomentum prop2 = reaction.out2();
  decay(randomNumber[5], randomNumber[6], prop1, 0., 0., weight);
  if (weight == 0.) {
    ps.weight.set(0.);
    return;
  }
  const FourMomentum prop1_a = decay.p1();
  const FourMomentum prop1_p = decay.p2();
  decay(randomNumber[7], randomNumber[8], prop2, 0., 0., weight);
  if (weight == 0.) {
    ps.weight.set(0.);
    return;
  }
  const FourMomentum prop2_a = decay.p1();
  const FourMomentum prop2_p = decay.p2();

  ps.a.set(prop1);
  ps.aa.set(prop1_a);
  ps.ap.set(prop1_p);
  ps.p.set(prop2);
  ps.pa.set(prop2_a);
  ps.pp.set(prop2_p);
  ps.a2.set(ps.aa() + ps.pp());
  ps.p2.set(ps.pa() + ps.ap());
  const double fac_a_p = propv_a->f(ps.a().m2()) * propv_p->f(ps.p().m2());
  const double fac_a2_p2 = propv_a2->f(ps.a2().m2()) * propv_p2->f(ps.p2().m2());
  weight *= fac_a2_p2/(fac_a_p + fac_a2_p2);

  ps.weight.set(weight);
  ps.randomNumber.set(randomNumber);
}

void higgsResonant_ZZ(const vector<double>& randomNumber, PhaseSpace& ps)
{
  assert(randomNumber.size() == 12);
  static TwoToResonanceAndTwoBodyDecay reaction;
  static TwoBodyDecay decay;
  static Resonance rh(SMP::mH, SMP::wH, PhaseSpace::E_CMS());

  static Propagator* propv_a = 0;
  static Propagator* propv_p = 0;
  static Propagator* propv_a2 = 0;
  static Propagator* propv_p2 = 0;
  if (!propv_a) {
    assert(!propv_p);
    propv_a = new Resonance(SMP::mW, SMP::wW, PhaseSpace::E_CMS());
    propv_p = new Resonance(SMP::mW, SMP::wW, PhaseSpace::E_CMS());
    if (amplitude_selection == AmpSqr::HIGGSSIGNAL) {
       propv_a2 = new Resonance(SMP::mZ, SMP::wZ, PhaseSpace::E_CMS());
    }
    else {
       propv_a2 = new ResonancePlusMassless(SMP::mZ, SMP::wZ, minInvMassPhotonProp, PhaseSpace::E_CMS());
    }
    propv_p2 = new Resonance(SMP::mZ, SMP::wZ, PhaseSpace::E_CMS());
  }

  FSP fsp1;
  FSP fsp2;
  double weight = 1.;

  rh(randomNumber[0], weight, applyingHiggsNWA);
  if (weight == 0. || !(rh.m() > propv_a2->minInvMass() + propv_p2->minInvMass())) {
    ps.weight.set(0.);
    return;
  }
  const bool propv_a2_mapping_first = randomNumberGenerator->uniformInZeroOne() < 0.5;
  weight *= 2.;
  if (propv_a2_mapping_first) {
    propv_a2->operator()(randomNumber[1], rh.m()-propv_p2->minInvMass(), weight, applyingNWA);
    if (weight == 0.) {
      ps.weight.set(0.);
      return;
    }
    propv_p2->operator()(randomNumber[2], rh.m()-propv_a2->m(), weight, applyingNWA);
    if (weight == 0. || !(rh.m() > propv_a2->m() + propv_p2->m())) {
      ps.weight.set(0.);
      return;
    }
    const double f_a = propv_a2->mappedFunction(propv_a2->m2());
    const double f_p = propv_p2->mappedFunction(propv_p2->m2());
    weight *= f_a/(f_a + f_p);
  }
  else {
    propv_p2->operator()(randomNumber[3], rh.m()-propv_a2->minInvMass(), weight, applyingNWA);
    if (weight == 0.) {
      ps.weight.set(0.);
      return;
    }
    propv_a2->operator()(randomNumber[4], rh.m()-propv_p2->m(), weight, applyingNWA);
    if (weight == 0. || !(rh.m() > propv_a2->m() + propv_p2->m())) {
      ps.weight.set(0.);
      return;
    }
    const double f_p = propv_p2->mappedFunction(propv_p2->m2());
    const double f_a = propv_a2->mappedFunction(propv_a2->m2());
    weight *= f_p/(f_a + f_p);
  }

  fsp1.set(propv_a2->m());
  fsp2.set(propv_p2->m());
  reaction(vector<double>(randomNumber.end()-3, randomNumber.end()),
	   ps.E_CMS(), rh, fsp1, fsp2);
  weight *= reaction.weight();
  if (weight == 0.) {
    ps.weight.set(0.);
    return;
  }
  ps.E_partonCMS.set(reaction.E_partonCMS());
  ps.i.set(reaction.in1());
  ps.x.set(reaction.x1());
  ps.i_.set(reaction.in2());
  ps.x_.set(reaction.x2());
  const FourMomentum prop1 = reaction.out1();
  const FourMomentum prop2 = reaction.out2();
  decay(randomNumber[5], randomNumber[6], prop1, 0., 0., weight);
  if (weight == 0.) {
    ps.weight.set(0.);
    return;
  }
  const FourMomentum prop1_a = decay.p1();
  const FourMomentum prop1_p = decay.p2();
  decay(randomNumber[7], randomNumber[8], prop2, 0., 0., weight);
  if (weight == 0.) {
    ps.weight.set(0.);
    return;
  }
  const FourMomentum prop2_a = decay.p1();
  const FourMomentum prop2_p = decay.p2();

  ps.a2.set(prop1);
  ps.aa.set(prop1_a);
  ps.pp.set(prop1_p);
  ps.p2.set(prop2);
  ps.pa.set(prop2_a);
  ps.ap.set(prop2_p);
  ps.a.set(ps.aa() + ps.ap());
  ps.p.set(ps.pa() + ps.pp());
  const double fac_a_p = propv_a->f(ps.a().m2()) * propv_p->f(ps.p().m2());
  const double fac_a2_p2 = propv_a2->f(ps.a2().m2()) * propv_p2->f(ps.p2().m2());
  weight *= fac_a_p/(fac_a_p + fac_a2_p2);

  ps.weight.set(weight);
  ps.randomNumber.set(randomNumber);
}
#endif   /* defined PROCMACRO_WWZAZ_2l2v */
}     // namespace Mapping

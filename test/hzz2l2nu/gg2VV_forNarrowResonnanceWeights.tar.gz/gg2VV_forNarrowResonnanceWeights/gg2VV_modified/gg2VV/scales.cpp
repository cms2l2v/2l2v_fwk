#include <algorithm>
using std::min;
#include <cassert>
/* assert macro */

#include "scales.h"
#include "settings.h"
#include "utilities.h"
#include "pi.h"
#include "settings.h"

#include <iostream>
using std::ostream;
using std::streamsize;

Scales::Scales()
{}

// --------------------------------------------------------------------

FixedScales::FixedScales(const double centralScale)
  : Scales(), _centralScale(centralScale)
{
  assert(_centralScale > 0.);
}

void FixedScales::operator()(const PhaseSpace& ps, const double renScaleFactor, const double facScaleFactor)
{
  _renScaleFactor = renScaleFactor;
  assert(_renScaleFactor > 0.);
  _facScaleFactor = facScaleFactor;
  assert(_facScaleFactor > 0.);

  _renormalizationScale = _centralScale * _renScaleFactor;
  const int numberOfQCDVertices = 2;
  _strongCouplingFactor = pow(FourPi*alphas(_renormalizationScale), numberOfQCDVertices);
  _factorizationScale = _centralScale * _facScaleFactor;
}

void FixedScales::writeScaleChoice(ostream& os) const
{
  const streamsize orig_precision = os.precision();
  os.precision(16);
  os << "mu_R = mu_F = " << _centralScale << " GeV";
  os.precision(orig_precision);
}

// --------------------------------------------------------------------


RootshatScales::RootshatScales(const double commonFactor)
  : Scales(), _commonFactor(commonFactor)
{
  assert(_commonFactor > 0.);
}

void RootshatScales::operator()(const PhaseSpace& ps, const double renScaleFactor, const double facScaleFactor)
{
  _renScaleFactor = renScaleFactor;
  assert(_renScaleFactor > 0.);
  _facScaleFactor = facScaleFactor;
  assert(_facScaleFactor > 0.);

  const double centralScale = _commonFactor * ps.E_partonCMS();
  _renormalizationScale = centralScale * _renScaleFactor;
  const int numberOfQCDVertices = 2;
  _strongCouplingFactor = pow(FourPi*alphas(_renormalizationScale), numberOfQCDVertices);
  _factorizationScale = centralScale * _facScaleFactor;
}

void RootshatScales::writeScaleChoice(ostream& os) const
{
  const streamsize orig_precision = os.precision();
  os.precision(16);
  os << "mu_R = mu_F = ";
  if (_commonFactor != 1.0) {
    os << _commonFactor << " * ";
  }
  os << "root_s_hat";
  os.precision(orig_precision);
}

// --------------------------------------------------------------------

#include "maxeventweightestimate.h"

namespace MaxEventWeightEstimate
{
double value = 0.;
}

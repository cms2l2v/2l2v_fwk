#include "clock.h"

#include <iostream>
using std::ostream;
using std::ios_base;
using std::streamsize;

void Clock::start()
{
  _time_milliseconds = 0.;
  gettimeofday(&_start, NULL);
}

void Clock::stop()
{
  gettimeofday(&_end, NULL);
  _time_milliseconds  = (_end.tv_sec - _start.tv_sec) * 1000.;   // sec to ms
  _time_milliseconds += (_end.tv_usec - _start.tv_usec)/1000.;   // \mu sec to ms
}

void Clock::writeTime(ostream& os) const
{
  const ios_base::fmtflags orig_flags = os.flags();
  const streamsize orig_precision = os.precision();
  os.setf(ios_base::fixed, ios_base::floatfield);
  os.precision(3);
  os << _time_milliseconds << " ms (wall-clock time)";
  os.flags(orig_flags);
  os.precision(orig_precision);
}

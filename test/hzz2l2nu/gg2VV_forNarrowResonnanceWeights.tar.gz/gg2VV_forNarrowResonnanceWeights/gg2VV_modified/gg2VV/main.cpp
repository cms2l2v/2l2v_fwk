#include <iostream>
using std::ostream;
using std::cout;
#include <iomanip>
using std::endl;
using std::setprecision;
#include <fstream>
using std::ofstream;
using std::ifstream;
#include <string>
using std::string;
#include <cmath>
using std::fabs;
using std::sqrt;
#include <cstdlib>
using std::exit;

#include "check.h"
#include "settings.h"
#include "pdf.h"
#include "dvegas.h"
#include "omnicomp.h"
#include "histosuite.h"
#include "driver.h"
#include "utilities.h"
#include "pi.h"
#include "rng.h"
#include "init_barscheme.h"
#include "events.h"

int numberOfPsMappings = 0;   // declared in settings.h

// helper: ------------------------------------------------------------

namespace {
void printResults(ostream& os, const Driver& d, const int numberOfPsMappings)
{
  os << "************************************************************************" << endl;
  if (numberOfPsMappings > 1) {
    os << "Combined r";
  }
  else {
    os << "R";
  }
  os << "esult:" << endl;
  const int maxMemberNumber = Pdf::getMaxMemberNumber();
  const bool usingNNPDF = lhapdf_file.size() >= 5 && lhapdf_file.substr(0,5) == string("NNPDF");
  if (usingNNPDF) {
    assert(maxMemberNumber > 1);
  }
  const int numberOfScales = scales_ptr_vector.size();
  double central = 0.;
  AsymmetricError pdfError;
  if (!usingNNPDF) {
    central = d.getResult(0);
  }
  if (_calculatePDFError || usingNNPDF) {
    vector<double> noncentralValues(maxMemberNumber);
    for (int i = 0; i < maxMemberNumber; ++i) {
      noncentralValues[i] = d.getResult(numberOfScales+4+i);
    }
    if (usingNNPDF) {
      const CentralValueAndErrorForEnsemble mc_method_results = getResultsForPDFMonteCarloMethod(noncentralValues);
      central = mc_method_results.centralValue;
      pdfError.plus = mc_method_results.error;
      pdfError.minus = mc_method_results.error;
    }
    else {
      pdfError = getErrorForPDFHepdataMethod(central, noncentralValues);
    }
  }
  os << setprecision(16) << "scale1:  " << central;
  os << " MC: +- " << setprecision(2) << d.getError(0) << " (+-" << d.getError(0)/d.getResult(0)*100 << "%)";
  double symScaleError = 0.;
  if (_calculateScaleError) {
    const double same_direction_variation_low = d.getResult(numberOfScales);
    const double same_direction_variation_high = d.getResult(numberOfScales+1);
    const double opposite_direction_variation_low = d.getResult(numberOfScales+2);
    const double opposite_direction_variation_high = d.getResult(numberOfScales+3);
    assert(same_direction_variation_low < central && central < same_direction_variation_high);
    assert(opposite_direction_variation_low < central && central < opposite_direction_variation_high);
    const double low = min(same_direction_variation_low, opposite_direction_variation_low);
    const double high = max(same_direction_variation_high, opposite_direction_variation_high);
    symScaleError = (high-low)/(high+low);
    os << " scale(x" << scale_variation_factor << "): - " << setprecision(16) << central-low << " (-" << setprecision(2) << (1.-low/central)*100 << "%) + " << setprecision(16) << high-central << " (+" << setprecision(2) << (high/central-1.)*100 << "%)";
  }
  if (_calculatePDFError) {
    os << " PDF: - " << setprecision(16) << pdfError.minus << " (-" << setprecision(2) << pdfError.minus/central*100 << "%) + " << setprecision(16) << pdfError.plus << " (+" << setprecision(2) << pdfError.plus/central*100 << "%)";
  }
  cout << " fb";
  if (_calculateScaleError) {
    cout << ", sym. scale error (h-l)/(h+l): +-" << symScaleError*100 << "%";
  }
  if (_calculatePDFError) {
    cout << ", sym. PDF error 0.5(dm+dp)/c: +-" << 0.5*(pdfError.minus+pdfError.plus)/central*100 << "%";
  }
  cout << endl;
  for (int i = 1; i < numberOfScales; ++i) {
    os << setprecision(16) << "scale" << i+1 << ":  " << d.getResult(i) << " MC: +- " << setprecision(2) << d.getError(i) << " (+-" << d.getError(i)/d.getResult(i)*100 << "%)" << endl;
  }
  os << setprecision(16);
  os << "(cross sections for single charged lepton/neutrino flavour combination!)" << endl;
  os << "************************************************************************" << endl;
}

void attemptToUpdateRngSeedFromFile(char* argv[])
{
  ifstream fin((string(argv[0])+".rngseed").c_str());
  if (fin) {
    seedForRandomNumberGenerator = getObj<long int>(fin);
    fin.close();
    randomNumberGenerator->setSeedAndLuxuryLevel(seedForRandomNumberGenerator, 0);
    cout << endl << ("Random number generator seed set to value in "+string(argv[0])+".rngseed") << endl << endl;
  }
  else {
    cout << endl << ("No file "+string(argv[0])+".rngseed found") << endl << endl;
  }
}
}     // unnamed namespace

// --------------------------------------------------------------------

bool _calculatePDFError = false;
bool _calculateScaleError = true;

int main(int argc, char* argv[])
{
  getParametersFromCommandLine(argc, argv); //ADDED BY LOIC QUERTENMONT

  using HepSource::Dvegas;
  using HepSource::OmniComp;
  if (compare_amplitude_ptr) {
    (*compare_amplitude_ptr)();
    exit(0);
  }
  attemptToUpdateRngSeedFromFile(argv);
  initialize_scales();
  if (generateEvents) {
    assert(scales_ptr_vector.size() == 1);
    _calculateScaleError = false;
  }
  test_libkinematics();
  ampSqr.initialize();
  Pdf::initialize();
  const int pdfSetMaxMemberNumber = Pdf::getMaxMemberNumber();
  if (requestPDFError && pdfSetMaxMemberNumber > 1 && !generateEvents) {
    assert(pdfSetMaxMemberNumber%2 == 0);   // +- pairs
    _calculatePDFError = true;
  }

  assert(!(nonresonantHiggsOnly && resonantHiggsOnly));
  assert(!((resonantHiggsOnly || nonresonantHiggsOnly) && AmpSqr::includesOnlyBackground(ampSqr.selection())));
#if defined PROCMACRO_WWZAZ_2l2v
  numberOfPsMappings = (AmpSqr::includesOnlyBackground(ampSqr.selection()) || nonresonantHiggsOnly || resonantHiggsOnly || applyingHiggsNWA) ? 2 : 4;
#elif defined PROCMACRO_ZAZA2l2l || defined PROCMACRO_ZAZA4l
  if (AmpSqr::includesOnlyBackground(ampSqr.selection()) || resonantHiggsOnly || applyingHiggsNWA || resonantVVcontOnly) {
    numberOfPsMappings = 1;
  }
  else if (nonresonantHiggsOnly) {
    numberOfPsMappings = 2;
  }
  else {
    numberOfPsMappings = 3;
  }
#else
  numberOfPsMappings = (AmpSqr::includesOnlyBackground(ampSqr.selection()) || nonresonantHiggsOnly || resonantHiggsOnly || applyingHiggsNWA) ? 1 : 2;
#endif

//  OmniComp omniComp(argc, argv); //MODIFIED BY LQ
    OmniComp omniComp(1, argv); //MODIFIED BY LQ


  // create empty file to record start time via time stamp
  ofstream starttimefile((string(argv[0])+".starttime").c_str());
  starttimefile.close();
  // write settings and parameters:
  // ------------------------------
  cout << endl;
  cout << setprecision(16);
  cout << "Process: ";
#if defined PROCMACRO_WW2l2v
  cout << "gg -> (WW or H->WW) -> l~ v v~ l (different flavour)";
#endif
#if defined PROCMACRO_WWZAZ_2l2v
  cout << "gg -> (WW or H->WW and ZA Z or H->ZZ) -> l~ v v~ l (same flavour)";
#endif
#if defined PROCMACRO_ZAZA2l2l
  cout << "gg -> (ZAZA or H->ZZ) -> l~ l l~ l (different flavour)";
#endif
#if defined PROCMACRO_ZAZ_2l2v
  cout << "gg -> (ZA Z or H->ZZ) -> ";
#if defined PROCMACRO_WWZAZ_2l2v
  cout << "l~ v v~ l  (including WW)";
#else
  cout << "l~ l v~ v  (excluding WW)";
#endif
#endif
#if defined PROCMACRO_ZAZA4l
  cout << "gg -> (ZAZA or H->ZZ) -> l~ l l~ l (same flavour)";
#endif
  cout << endl;
  cout << "Cross sections for single charged lepton/neutrino flavour combination" << endl;
  cout << "Active amplitude contributions: ";
  ampSqr.writeSelection(cout);
  cout << endl;
  if (applyingHiggsNWA) {
    cout << "Narrow-width approximation is applied to Higgs boson" << endl;
    if (ampSqr.selection() != AmpSqr::HIGGSSIGNAL) {
      fatal_error("Error: not ampSqr.selection() == AmpSqr::HIGGSSIGNAL");
    }
  }

  assert(!(applyingHiggsBarScheme && applyingHiggsFixedWidthBreitWigner));
  if (applyingHiggsFixedWidthBreitWigner || applyingHiggsNWA) {
    const int nk_barscheme_in = 0;
    init_barscheme_(&nk_barscheme_in);
    if (AmpSqr::includesSignal(ampSqr.selection()) && !applyingHiggsNWA) {
      cout << "Higgs propagator scheme: fixed-width Breit-Wigner" << endl;
    }
  }  
  else if (applyingHiggsBarScheme) {
    const int nk_barscheme_in = 1;
    init_barscheme_(&nk_barscheme_in);
    if (AmpSqr::includesSignal(ampSqr.selection())) {
      cout << "Higgs propagator scheme: Bar scheme, arXiv:1112.5517, Eqs. (36,37)" << endl;
    }
  }
  else {
    fatal_error("Error: no Higgs propagator scheme selected");
  }

  if (applyingNWA) {
#if defined PROCMACRO_WWZAZ_2l2v
      fatal_error("Error: narrow-width approximation cannot be applied to weak bosons for WWZAZ_2l2v process");
#endif
    cout << "Narrow-width approximation is applied to weak boson (W,Z)" << endl;
  }
  cout << "E_CMS = " << PhaseSpace::E_CMS() << " GeV (hadron collision)" << endl;
  for (int i = 0; i < scales_ptr_vector.size(); ++i) {
    cout << "Scale " << i+1 << ": ";
    scales_ptr_vector[i]->writeScaleChoice(cout);
    cout << endl;
  }
  cout << "PDF set: " << Pdf::pdfsetName() << " (LHAPDF)" << endl;
  cout << "Selection cuts: ";
  selection.writeSelection(cout);
#if defined PROCMACRO_WWZAZ_2l2v || defined PROCMACRO_ZAZA2l2l || defined PROCMACRO_ZAZ_2l2v || defined PROCMACRO_ZAZA4l
  cout << " (PS generation imposes photon virtuality > (" << minInvMassPhotonProp << " GeV)^2)";
#endif
  cout << endl;
  cout << "Mode: ";
  if (generateEvents) {
    cout << "generate " << numberOfEvents << " " << ((unweightEvents) ? "un" : "") << "weighted events";
  }
  else {
    cout << "calculate cross section(s)";
  }
  cout << endl << "maxNumberOfGridAdaptationIterations: " << maxNumberOfGridAdaptationIterations;
  cout << endl << "gridAdaptationNumberOfShots: " << gridAdaptationNumberOfShots;
  cout << endl << "mainRunNumberOfShots: " << mainRunNumberOfShots;
  cout << endl << "Random number generator seed: " << seedForRandomNumberGenerator;
  cout << endl;
  cout << endl;
  cout << "Parameters/settings description:" << endl;
  cout << settingsDescription << endl;
  cout << endl;
  SMP::report();   // SM parameters
  cout << endl;
  cout << "Selection cuts code:" << endl;
#if defined PROCMACRO_WWZAZ_2l2v || defined PROCMACRO_ZAZA2l2l || defined PROCMACRO_ZAZ_2l2v || defined PROCMACRO_ZAZA4l
  cout << "PS generation imposes photon virtuality > (" << minInvMassPhotonProp << " GeV)^2" << endl;
#endif
#if defined MIXEDPREC
#if defined PROCMACRO_ZAZA4l
  cout << "Technical cut applied: p_T(V) > 2 GeV" << endl;
#else
  cout << "Technical cut applied: p_T(V) > 1 GeV" << endl;
#endif
#endif
  cout << "------------------------------------------------------------------------" << endl;
  selection.writeSelectionCode(cout);
  cout << "------------------------------------------------------------------------" << endl;

#if defined PROCMACRO_ZAZA4l || defined PROCMACRO_WWZAZ_2l2v
  assert(!applyingNWA);
#endif

  int numberOfIntegrands = 0;
  if (generateEvents) {
    numberOfIntegrands = 1;
  }
  else {
    numberOfIntegrands = scales_ptr_vector.size() + 4; // scale var.:++l,++h,+-l,+-h
    if (_calculatePDFError) {
      numberOfIntegrands += pdfSetMaxMemberNumber;
    }
  }
  vector<Dvegas*> dvegas(numberOfPsMappings);
  const vector<int> dDimSizes(1, 1);     // helicities not importance sampled
  assert(Mapping::RESONANTHIGGS == 0 && Mapping::NONRESONANTHIGGS == 1);
#if defined PROCMACRO_WWZAZ_2l2v
  assert(Mapping::WW == 0 && Mapping::ZZ == 1);
  if (numberOfPsMappings == 2) {
    if (resonantHiggsOnly || applyingHiggsNWA) {
      dvegas[0] = new Dvegas(12, 30, dDimSizes, numberOfIntegrands, Mapping::WW);
      dvegas[1] = new Dvegas(12, 30, dDimSizes, numberOfIntegrands, Mapping::ZZ);
    }
    else {
      dvegas[0] = new Dvegas(10, 30, dDimSizes, numberOfIntegrands, Mapping::WW);
      dvegas[1] = new Dvegas(10, 30, dDimSizes, numberOfIntegrands, Mapping::ZZ);
    }
  }
  else if (numberOfPsMappings == 4) {
    dvegas[0] = new Dvegas(12, 30, dDimSizes, numberOfIntegrands, Mapping::RESONANTHIGGS+2*Mapping::WW);
    dvegas[1] = new Dvegas(10, 30, dDimSizes, numberOfIntegrands, Mapping::NONRESONANTHIGGS+2*Mapping::WW);
    dvegas[2] = new Dvegas(12, 30, dDimSizes, numberOfIntegrands, Mapping::RESONANTHIGGS+2*Mapping::ZZ);
    dvegas[3] = new Dvegas(10, 30, dDimSizes, numberOfIntegrands, Mapping::NONRESONANTHIGGS+2*Mapping::ZZ);
  }
#elif defined PROCMACRO_ZAZA2l2l || defined PROCMACRO_ZAZA4l
  if (numberOfPsMappings == 1) {
    if (resonantHiggsOnly || applyingHiggsNWA) {
      dvegas[0] = new Dvegas(12, 30, dDimSizes, numberOfIntegrands, Integrand::NONE);
    }
    else {
      dvegas[0] = new Dvegas(10, 30, dDimSizes, numberOfIntegrands, Integrand::NONE);
    }
  }
  else if (numberOfPsMappings == 2) {
    dvegas[0] = new Dvegas(12, 30, dDimSizes, numberOfIntegrands, Mapping::NONRESONANTHIGGSBELOW);
    dvegas[1] = new Dvegas(10, 30, dDimSizes, numberOfIntegrands, Mapping::NONRESONANTHIGGSABOVE);
  }
  else if (numberOfPsMappings == 3) {
    if (SMP::mH - SMP::wH * compositePhaseSpaceParameter < 0.) {
      assert(SMP::mH > contSingleResVUpperBound);
      dvegas.resize(2);
      dvegas[0] = new Dvegas(12, 30, dDimSizes, numberOfIntegrands, Mapping::RESONANTHIGGS);
      dvegas[1] = new Dvegas(10, 30, dDimSizes, numberOfIntegrands, Mapping::NONRESONANTHIGGSABOVE);
      numberOfPsMappings = 2;
    }
    else {
      dvegas[0] = new Dvegas(12, 30, dDimSizes, numberOfIntegrands, Mapping::RESONANTHIGGS);
      dvegas[1] = new Dvegas(12, 30, dDimSizes, numberOfIntegrands, Mapping::NONRESONANTHIGGSBELOW);
      dvegas[2] = new Dvegas(10, 30, dDimSizes, numberOfIntegrands, Mapping::NONRESONANTHIGGSABOVE);
    }
  }
#else
  if (numberOfPsMappings == 1) {
    if (resonantHiggsOnly || applyingHiggsNWA) {
      dvegas[0] = new Dvegas(12, 30, dDimSizes, numberOfIntegrands, Integrand::NONE);
    }
    else {
      dvegas[0] = new Dvegas(10, 30, dDimSizes, numberOfIntegrands, Integrand::NONE);
    }
    // 10 PS dimensions, 30 bins (weights) per dimension, 1 mapping

    /*
    const int corrDim = (ampSqr.selection() & AmpSqr::HIGGSSIGNAL) ? 2 : 0;
    dvegas[0] = new Dvegas(10, 30, corrDim, dDimSizes, 0, 1, Integrand::NONE);
    // 10 PS dimensions, 30 bins (weights) per dimension, 
    // 2 correlated dim.: m(W-), m(W+) to resolve Higgs resonance p(H) = p(W-)+p(W+),
    // 0 auxilliary dim., 1 integrand, 1 mapping
    */
  }
  else if (numberOfPsMappings == 2) {
    dvegas[0] = new Dvegas(12, 30, dDimSizes, numberOfIntegrands, Mapping::RESONANTHIGGS);
    dvegas[1] = new Dvegas(10, 30, dDimSizes, numberOfIntegrands, Mapping::NONRESONANTHIGGS);
  }
#endif

  Driver driver(dvegas, &omniComp);
  _partialEventSetVector.resize(dvegas.size());
  
  ifstream fin((string(argv[0])+".init").c_str());
  if (fin) {
    driver.restoreWeights(fin);
    fin.close();
    cout << endl << "Run initialized with saved grid (file "+string(argv[0])+".init)" << endl;
    maxNumberOfGridAdaptationIterations = 0;
  }
  else {
    cout << endl << "Run initialized with flat grid (no file "+string(argv[0])+".init found)" << endl;
  }

  ifstream fevt((string(argv[0])+".evt").c_str());
  if (fevt) {
    if (fin && generateEvents) {
      for (int i = 0; i < _partialEventSetVector.size(); ++i) {
  	_partialEventSetVector[i].maxEventWeightEstimate  = getObj<double>(fevt);
  	_partialEventSetVector[i].xsecValEstimate  = getObj<double>(fevt);
  	_partialEventSetVector[i].xsecErrEstimate  = getObj<double>(fevt);
      }
      cout << "Event generation initialized with file "+string(argv[0])+".evt" << endl;
    }
    fevt.close();
  }

  if (!(generateEvents && fin && fevt)) {
    PartialEventSet::generatingEvents = false;
    HistoSuite *const histoSuite_ptr = new HistoSuite();

    driver.run(histoSuite_ptr);

    printResults(cout, driver, numberOfPsMappings);

    histoSuite_ptr->updateEstimatesWithPartialEstimates();
    ofstream histoStream((string(argv[0])+".dat").c_str());
    histoSuite_ptr->print(histoStream);

    driver.saveState(string(argv[0])+".init-new");

    delete histoSuite_ptr;

    ofstream evtNewStream((string(argv[0])+".evt-new").c_str());
    for (int i = 0; i < _partialEventSetVector.size(); ++i) {
      _partialEventSetVector[i].maxEventWeightEstimate = _partialEventSetVector[i].maxEventWeight;
      _partialEventSetVector[i].xsecValEstimate = dvegas[i]->integral(0);
      _partialEventSetVector[i].xsecErrEstimate = dvegas[i]->standardDeviation(0);

      evtNewStream << setprecision(16);
      evtNewStream << _partialEventSetVector[i].maxEventWeightEstimate << csep;
      evtNewStream << _partialEventSetVector[i].xsecValEstimate << csep;
      evtNewStream << _partialEventSetVector[i].xsecErrEstimate << csep;
    }
  }
  
  if (generateEvents) {
    Dvegas::abortLoopPtr = &PartialEventSet::abortLoop;
    PartialEventSet::generatingEvents = true;
    for (int i = 0; i < _partialEventSetVector.size(); ++i) {
      _partialEventSetVector[i].maxEventWeight = 0.;
      assert(_partialEventSetVector[i].eventCounter == 0);
    }
    // create empty file to record event generation start time via time stamp
    ofstream starttimefile2((string(argv[0])+".event_generation_starttime").c_str());
    starttimefile2.close();
    cout << endl << "Run to generate " << numberOfEvents << " " << (unweightEvents ? "un" : "") << "weighted events" << endl << endl;
    setNumberOfEventsForSections(numberOfEvents, _partialEventSetVector);
    cout << endl;
    for (int s = 0; s < dvegas.size(); ++s) {
      if (_partialEventSetVector[s].numberOfEvents == 0) {
	continue;
      }
      dvegas[s]->resetEstimates();
      dvegas[s]->attachOmniComp(&omniComp);
      PartialEventSet::abortLoop = false;
      cout << "Event generation for section " << s << " (ignore shots number)" << endl;
      try {
	dvegas[s]->collectData(1000000000);
      }
      catch (HepSource::Dvegas::NoNonzeroIntegrandValuesSampledException) {
	fatal_error("\nABORTED: no hits for section dvegas[", s);
      }
      dvegas[s]->detachOmniComp();
    }
    writeEventFile(string(argv[0])+"_"+(unweightEvents ? "un" : "")+"weightedEvents.dat");
  }

  for (int i = 0; i < dvegas.size(); ++i) {
    delete dvegas[i];
  }

  return 0;
}

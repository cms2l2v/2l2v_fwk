#ifndef GG2VV_INTEGRAND_H
#define GG2VV_INTEGRAND_H

#include "integrand.h"
#include "histosuite.h"

class IntegrandWithHistos : public HepSource::Integrand
{
public:
  IntegrandWithHistos();
  const bool canAttachOmniHistoSuite() const;
  void attachOmniHistoSuite(HepSource::OmniHistoSuite *const omniHistoSuite);
  void createAndAttachEmptyOmniHistoSuite();
  HistoSuite *const omniHistoSuite() const;
  void detachOmniHistoSuite();
protected:
  HistoSuite* _histoSuite;
};

inline const bool IntegrandWithHistos::canAttachOmniHistoSuite() const { return true; }

inline HistoSuite *const IntegrandWithHistos::omniHistoSuite() const { return _histoSuite; }

inline void IntegrandWithHistos::detachOmniHistoSuite() { _histoSuite = 0; }

// --------------------------------------------------------------

class GG2VV_Integrand : public IntegrandWithHistos
{
public:
  void operator()(const vector<double>& x, const vector<int>& k, const double& weight,
                  const vector<double>& aux, vector<double>& f);
};

#endif  /* GG2VV_INTEGRAND_H */

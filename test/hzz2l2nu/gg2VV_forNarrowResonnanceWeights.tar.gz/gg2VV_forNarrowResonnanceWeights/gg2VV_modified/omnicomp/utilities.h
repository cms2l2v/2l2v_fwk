#ifndef UTILITIES_H
#define UTILITIES_H

#include <cstdlib>
using std::exit;
#include <iostream>
using std::ostream;
using std::istream;
using std::cerr;
#include <iomanip>
using std::endl;
#include <string>
using std::string;
#include <sstream>
using std::ostringstream;

void terminate();

const bool path_exists(const string& path);

// string helpers --------
template <typename T>
const string toString(const T& obj)
{
  ostringstream oss;
  if (!(oss << obj)) {
    cerr << "error: failed to convert object to string" << endl;
    terminate();
  }
  return oss.str();
}
// -----------------------

// stream helpers --------
inline ostream& csep(ostream& s)     // customizable stream item separator
{
  s << '\n';
  //s.flush();
  return s;
}

template <typename T>
const T getObj(istream& is)
{
  T buf;
  if (!(is >> buf)) {
    cerr << "error: failed to read object from istream" << endl;
    terminate();
  }
  return buf;
}
// -----------------------

// error helpers ---------
void fatal_error(const string& s);

template<typename T>
void fatal_error(const string& s, const T& value)
{
  cerr << s << value << endl;
  terminate();
}
// -----------------------

#endif     /* UTILITIES_H */

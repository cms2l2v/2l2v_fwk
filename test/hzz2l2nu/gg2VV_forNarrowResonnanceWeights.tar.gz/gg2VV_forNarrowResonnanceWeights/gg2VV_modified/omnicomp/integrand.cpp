// Author: Nikolas Kauer <kauer@physik.uni-wuerzburg.de>

#include <iostream>
using std::cerr;
#include <iomanip>
using std::endl;
#include "integrand.h"
#include "omnihistosuite.h"
#include "utilities.h"

namespace HepSource
{
void Integrand::attachOmniHistoSuite(OmniHistoSuite *const omniHistoSuite)
{
  cerr << "error in Integrand::attachOmniHistoSuite(): "
       << "integrand does not fill histograms" << endl;
  ::terminate();
} 

void Integrand::createAndAttachEmptyOmniHistoSuite()
{
  cerr << "error in Integrand::createAndAttachEmptyOmniHistoSuite(): "
       << "integrand does not fill histograms" << endl;
  ::terminate();
}

OmniHistoSuite *const Integrand::omniHistoSuite() const
{
  cerr << "error in Integrand::omniHistoSuite(): "
       << "integrand does not have histograms" << endl;
  ::terminate();
  return 0;
} 

void Integrand::detachOmniHistoSuite()
{
  cerr << "error in Integrand::detachOmniHistoSuite(): "
       << "integrand does not have histograms" << endl;
  ::terminate();
}
}     // HepSource

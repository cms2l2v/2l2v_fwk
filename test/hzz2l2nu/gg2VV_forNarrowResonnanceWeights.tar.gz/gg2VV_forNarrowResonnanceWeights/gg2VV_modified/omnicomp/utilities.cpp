#include <cstdlib>
using std::exit;
#include <iostream>
using std::cerr;
#include <iomanip>
using std::endl;
#include <string>
using std::string;

#include "utilities.h"
#include <sys/stat.h>

void terminate()
{
  exit(1);
}

const bool path_exists(const string& path)
{
  // http://www.techbytes.ca/techbyte103.html
  struct stat statInfo;
  int stat_return;
  bool exists;

  stat_return = stat(path.c_str(), &statInfo);   // attempt to get file attributes
  if (stat_return == 0) {
    exists = true;
    // We were able to get the file attributes
    // so the file obviously exists.
  }
  else {
    exists = false;
    // We were not able to get the file attributes.
    // This may mean that we don't have permission to
    // access the folder which contains this file. If you
    // need to do that level of checking, lookup the
    // return values of stat which will give you
    // more details on why stat failed.
  }
  return exists;
}

void fatal_error(const string& s)
{
  cerr << s << endl;
  terminate();
}

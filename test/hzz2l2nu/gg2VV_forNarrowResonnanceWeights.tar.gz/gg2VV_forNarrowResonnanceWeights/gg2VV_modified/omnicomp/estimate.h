#ifndef ESTIMATE_H
#define ESTIMATE_H

// Author: Nikolas Kauer <kauer@physik.uni-wuerzburg.de>

#include <iostream>
using std::ostream;
using std::istream;
#include "64bittypes.h"

struct Estimate
{
  Float64 estimate;
  Float64 variance;
  Estimate();
  Estimate(const Float64 estimate, const Float64 variance);
};

// --------------------------------------------------------------

class SampleSet
{
public:
  SampleSet();
  virtual ~SampleSet();
  void addSample(const Float64& value, const Float64& weight = 1.0);
  virtual const Estimate getEstimate();
  const Estimate getEstimate(const Int64 totalNumberOfWeightedValues);

  void toStream(ostream& os) const;
  void fromStream(istream& is);
  SampleSet& operator+=(const SampleSet& partial);
protected:
  Float64 _sumOfWeightedValues;
  Float64 _sumOfWeightedValueSquares;
  Float64 _sumOfWeights;
  Float64 _sumOfWeightSquares;
  Int64 _numberOfWeightedValues;
  void reset();
};

// --------------------------------------------------------------

class GlobalSampleSet : public SampleSet
{
public:
  GlobalSampleSet();
  const Estimate getEstimate();
  GlobalSampleSet& operator+=(const GlobalSampleSet& partial);

  const Int64 numberOfWeightedValues() const;
  const Float64 sumOfWeightedValues() const;
private:
  SampleSet& operator+=(const SampleSet& partial);
};

inline const Int64 GlobalSampleSet::numberOfWeightedValues() const { return _numberOfWeightedValues; }

inline const Float64 GlobalSampleSet::sumOfWeightedValues() const { return _sumOfWeightedValues; }

// --------------------------------------------------------------

class CumulativeEstimate
{
public:
  CumulativeEstimate();
  virtual ~CumulativeEstimate();

  const double estimate() const;
  const double standardDeviation() const;
  const double chiSquarePerEstimate() const;

  void addEstimate(const Estimate& estimate);
  const int numberOfEstimates() const;

  virtual void print(ostream& os) const;     // output for human readers
  void toStream(ostream& os) const;
  void fromStream(istream& is);
  CumulativeEstimate& operator+=(const CumulativeEstimate& partial);
private:
  // buffered:
  mutable double _estimate;
  mutable double _standardDeviation;
  mutable double _chiSquarePerEstimate;
  mutable bool _valuesUnknown;
  void computeValues() const;

  Float64 _weightedSumOfEstimates;
  Float64 _sumOfWeights;
  Float64 _weightedSumOfEstimateSquares;
  int _numberOfEstimates;
};

inline const int CumulativeEstimate::numberOfEstimates() const { return _numberOfEstimates; }

#endif     /* ESTIMATE_H */

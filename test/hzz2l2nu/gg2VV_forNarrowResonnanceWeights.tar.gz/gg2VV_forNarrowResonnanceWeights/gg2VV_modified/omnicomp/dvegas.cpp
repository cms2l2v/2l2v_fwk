// Author: Nikolas Kauer <kauer@physik.uni-wuerzburg.de>

#include <iostream>
using std::ostream;
using std::istream;
using std::cout;
using std::cerr;
#include <fstream>
using std::ofstream;
using std::ifstream;
#include <sstream>
using std::ostringstream;
using std::istringstream;
#include <iomanip>
using std::endl;
using std::setprecision;
#include <string>
using std::string;
#include <vector>
using std::vector;
#include <stdexcept>
using std::bad_alloc;
using std::out_of_range;
#include <algorithm>
using std::max;
using std::stable_sort;
#include <cmath>
using std::pow;
using std::sqrt;
using std::log;
using std::fabs;
#include <cstdlib>
using std::exit;
using std::ldiv;
using std::ldiv_t;
#include <cassert>
/* assert macro */
#include <ctime>
using std::time_t;
using std::time;
using std::difftime;
/* NULL macro */
#include "dvegas.h"
#include "integrand.h"
#include "omnicomp.h"
#include "rng.h"
#include "utilities.h"
#include "maxeventweightestimate.h"

namespace HepSource
{
const int powInt(const int n, const int k) { return int(pow(double(n), k)); }
const Int64 powInt64(const int n, const int k) { return Int64(pow(double(n), k)); }

// --------------------------------------------------------------
// --------------------------------------------------------------
// --------------------------------------------------------------

template<typename C>
MultidimensionalArray<C>::MultidimensionalArray(const int dim, const int length)
{
  consHelper(dim, length);
}

template<typename C>
void MultidimensionalArray<C>::resize(const int dim, const int length)
{
  delete _v;
  consHelper(dim, length);
}

template<typename C>
void MultidimensionalArray<C>::consHelper(const int dim, const int length)
{
  bool abort = false;
  if (dim < 0) {
    cerr << "error in MultidimensionalArray(): "
         << "negative number of dimensions: " << dim << endl;
    abort = true;
  }
  if (length < 0) {
    cerr << "error in MultidimensionalArray(): "
         << "negative length: " << length << endl;
    abort = true;
  }
  if (dim > 0 && length == 0) {
    cerr << "error in MultidimensionalArray(): "
         << "dim > 0 and length = 0" << endl;
    abort = true;
  }
  if (abort)
    terminate();

  _dim = dim;
  _length = (_dim > 0) ? length : 0;
  _size = powInt64(_length, _dim);
  _v = 0;
}

template<typename C>
void MultidimensionalArray<C>::reset(const C& c)     // default: c = C()
{
  if (_size > 0) {
    delete _v;
    try {
      _v = new vector<C>(_size, c);
    }
    catch (bad_alloc) {
      cerr << "error in MultidimensionalArray(): not enough memory, "
           << "use smaller dim and/or length or add memory" << endl;
      terminate();
    }
  }
}

template<typename C>
MultidimensionalArray<C>& MultidimensionalArray<C>::operator=(const MultidimensionalArray& mda)
{
  if (this != &mda) {
    _dim = mda.dim();
    _length = mda.length();
    _size = mda.size();
    delete _v;
    if (mda._v == 0) {
      _v = 0;
    }
    else {
      assert(_size > 0);
      try {
        _v = new vector<C>(*mda._v);
      }
      catch (bad_alloc) {
        cerr << "error in MultidimensionalArray(): not enough memory, "
             << "use smaller dim and/or length or add memory" << endl;
        terminate();
      }
    }
  }
  return *this;
}

template<typename C>
MultidimensionalArray<C>::MultidimensionalArray(const MultidimensionalArray& mda)
  : _v(0)
{
  operator=(mda);
}

template<typename C>
MultidimensionalArray<C>::~MultidimensionalArray()
{
  delete _v;
}

template<typename C>
C& MultidimensionalArray<C>::at(const Int64 sequentialIndex) throw (out_of_range)
{
  if (!(0 <= sequentialIndex && sequentialIndex < size())) {
    throw out_of_range("MultidimensionalArray");
  }
  return (*_v)[sequentialIndex];
}

template<typename C>
const C& MultidimensionalArray<C>::at(const Int64 sequentialIndex) const throw (out_of_range)
{
  if (!(0 <= sequentialIndex && sequentialIndex < size())) {
    throw out_of_range("MultidimensionalArray");
  }
  return (*_v)[sequentialIndex];
}

template<typename C>
const vector<int> MultidimensionalArray<C>::seqIdxToIndexes(const Int64 sequentialIndex) const throw (out_of_range)
{
  if (sequentialIndex < 0 || sequentialIndex >= _size) {
    throw out_of_range("MultidimensionalArray");
  }
  vector<int> listOfIndexes(_dim);
  int i = _dim - 1;
  Int64 index = sequentialIndex;
  while (i >= 0) {
    ldiv_t n = ldiv(index, _length);
    listOfIndexes[i] = n.rem;
    index = n.quot;
    --i;
  }
  return listOfIndexes;
}

template<typename C>
const Int64 MultidimensionalArray<C>::indexesToSeqIdx(const vector<int>& listOfIndexes) const throw (out_of_range)
{
  if (listOfIndexes.size() != _dim) {
    cerr << "error: wrong number of indexes: " << listOfIndexes.size() << endl;
    terminate();
  }
  Int64 seqIndex = 0;
  Int64 stride = 1;
  int i = _dim - 1;
  while (i >= 0) {
    if (listOfIndexes[i] < 0 || listOfIndexes[i] >= _length) {
      throw out_of_range("MultidimensionalArray");
    }
    seqIndex += stride * listOfIndexes[i];
    stride *= _length;
    --i;
  }
  return seqIndex;
}

template<typename C>
const vector<C> MultidimensionalArray<C>::getProjection(const int dim, const Int64 projectionIterator) const
{
  assert(0 <= dim && dim < _dim);
  assert(0 <= projectionIterator && projectionIterator < _size/_length);
  vector<C> projection;
  projection.reserve(_length);
  const Int64 stride = powInt64(_length, (_dim-1)-dim);
  const Int64 offset = (projectionIterator/stride)*stride*_length + (projectionIterator%stride);
  for (int i = 0; i < _length; ++i)
    projection.push_back((*_v)[offset + i * stride]);
  return projection;
}

template<typename C>
void MultidimensionalArray<C>::putProjection(const int dim, const Int64 projectionIterator, const vector<C>& newWeights)
{
  assert(0 <= dim && dim < _dim);
  assert(0 <= projectionIterator && projectionIterator < _size/_length);
  assert(newWeights.size() == _length);
  const Int64 stride = powInt64(_length, (_dim-1)-dim);
  const Int64 offset = (projectionIterator/stride)*stride*_length + (projectionIterator%stride);
  for (int i = 0; i < _length; ++i)
    (*_v)[offset + i * stride] = newWeights[i];
}

template<typename C>
void MultidimensionalArray<C>::toStream(ostream& os) const
{
  os << _dim << csep;
  os << _length << csep;
  os << _size << csep;
  if (_size > 0) {
    assert(_v != 0);
    assert(_v->size() == _size);
    for (int i = 0; i < _v->size(); ++i)
      os << (*_v)[i] << csep;
  }
}

template<typename C>
void MultidimensionalArray<C>::fromStream(istream& is)
{
  _dim = getObj<int>(is);
  _length = getObj<int>(is);
  _size = getObj<Int64>(is);

  if (_size > 0) {
    if (_v == 0)
      _v = new vector<C>();
    try {
      _v->resize(_size);
    }
    catch (bad_alloc) {
      cerr << "error in MultidimensionalArray(): "
           << "not enough memory to restore state from string" << endl;
      terminate();
    }
    for (Int64 i = 0; i < _v->size(); ++i)
      is >> (*_v)[i];
  }
  else {
    delete _v;
    _v = 0;
  }
}

template<typename C>
MultidimensionalArray<C>& MultidimensionalArray<C>::operator+=(const MultidimensionalArray& partial)
{
  assert(size() == partial.size());
  for (Int64 i = 0; i < size(); ++i)
    (*_v)[i] += (*partial._v)[i];
  return *this;
}

template class MultidimensionalArray<Float64>;     // explicit instantiation
template class MultidimensionalArray<Dvegas::CellAccumulators::Accumulator>;

// --------------------------------------------------------------
// --------------------------------------------------------------
// --------------------------------------------------------------

GlobalAccumulator::GlobalAccumulator()
  : _globalSampleSet(), 
    _sumOfNegativeIntegrandValues(0.0), _numberOfShotsWhereIntegrandIsZero(0)
{}

void GlobalAccumulator::addValue(const double value, const double weight)
{
  _globalSampleSet.addSample(value, weight);
  if (value == 0.0)
    ++_numberOfShotsWhereIntegrandIsZero;
  else if (value < 0.0)
    _sumOfNegativeIntegrandValues += value * weight;
}

void GlobalAccumulator::toStream(ostream& os) const
{
  _globalSampleSet.toStream(os);
  os << _sumOfNegativeIntegrandValues << csep;
  os << _numberOfShotsWhereIntegrandIsZero << csep;
}

void GlobalAccumulator::fromStream(istream& is)
{
  _globalSampleSet.fromStream(is);
  _sumOfNegativeIntegrandValues = getObj<Float64>(is);
  _numberOfShotsWhereIntegrandIsZero = getObj<Int64>(is);
}

GlobalAccumulator& GlobalAccumulator::operator+=(const GlobalAccumulator& partial)
{
  _globalSampleSet += partial._globalSampleSet;
  _sumOfNegativeIntegrandValues += partial._sumOfNegativeIntegrandValues;
  _numberOfShotsWhereIntegrandIsZero += partial._numberOfShotsWhereIntegrandIsZero;
  return *this;
}

// --------------------------------------------------------------

IntegrandEstimate::IntegrandEstimate()
  : CumulativeEstimate()
{}

void IntegrandEstimate::print(ostream& os) const
{
  os << setprecision(16) << estimate() << " +- " << setprecision(2)
     << standardDeviation() << " (" << standardDeviation()/estimate()*100 << "%)";
  if (numberOfEstimates() > 1) {
    os << ", chi^2/iteration = " << chiSquarePerEstimate()
       << " (" << numberOfEstimates() << " iterations)";
  }
  os << setprecision(16);     // reset to default
}

// --------------------------------------------------------------

SeparabilityTestForTwoDim::SeparabilityTestForTwoDim(const int numberOfBinsOnEachAxis)
  : _numberOfBinsOnEachAxis(numberOfBinsOnEachAxis),
    _separabilityStats(0., 0.), _separabilityStatsUnknown(true)
{
  vector<Float64> temp(_numberOfBinsOnEachAxis);
  _accumulator.assign(_numberOfBinsOnEachAxis, temp);
}

void SeparabilityTestForTwoDim::addShot(const int binIndexX, const int binIndexY, const Float64 value)
{
  assert(0 <= binIndexX && binIndexX < _numberOfBinsOnEachAxis
         && 0 <= binIndexY && binIndexY < _numberOfBinsOnEachAxis );
  _accumulator[binIndexX][binIndexY] += value;
}

SeparabilityTestForTwoDim::SeparabilityStats::SeparabilityStats(const double average_, const double standardDeviation_)
  : average(average_), standardDeviation(standardDeviation_)
{}

const SeparabilityTestForTwoDim::SeparabilityStats SeparabilityTestForTwoDim::separabilityStats() const
{
  if (_separabilityStatsUnknown) {
    vector<Float64> fixedXsumOverY(_numberOfBinsOnEachAxis);
    vector<Float64> fixedYsumOverX(_numberOfBinsOnEachAxis);
    Float64 sumOverXAndY = 0.0;
    for (int xIdx = 0; xIdx < _numberOfBinsOnEachAxis; ++xIdx) {
      for (int yIdx = 0; yIdx < _numberOfBinsOnEachAxis; ++yIdx) {
        const Float64& value = _accumulator[xIdx][yIdx];
        fixedXsumOverY[xIdx] += value;
        fixedYsumOverX[yIdx] += value;
        sumOverXAndY += value;
      }
    }
    Float64 sumOfValues = 0.0;
    Float64 sumOfValueSquares = 0.0;
    int numberOfValues = 0;
    for (int xIdx = 0; xIdx < _numberOfBinsOnEachAxis; ++xIdx) {
      for (int yIdx = 0; yIdx < _numberOfBinsOnEachAxis; ++yIdx) {
        const double e1 = fabs(fixedYsumOverX[yIdx] * fixedXsumOverY[xIdx]);
        const double e2 = fabs(_accumulator[xIdx][yIdx] * sumOverXAndY);
        if (e1 != 0.0 && e2 != 0.0) {
          const double value = e1/e2;
          sumOfValues += value;
          sumOfValueSquares += value * value;
          ++numberOfValues;
        }
      }
    }
    if (numberOfValues > 0) {
      _separabilityStats.average = sumOfValues/numberOfValues;
      _separabilityStats.standardDeviation = sqrt(sumOfValueSquares/numberOfValues
        - pow(sumOfValues/numberOfValues, 2));
    }
    _separabilityStatsUnknown = false;
  }
  assert(0.0 <= _separabilityStats.average
         && 0.0 <= _separabilityStats.standardDeviation);
  return _separabilityStats;
}

void SeparabilityTestForTwoDim::toStream(ostream& os) const
{
  os << _numberOfBinsOnEachAxis << csep;
  for (int i = 0; i < _accumulator.size(); ++i)
    for (int j = 0; j < _accumulator[i].size(); ++j)
      os << _accumulator[i][j] << csep;
}

void SeparabilityTestForTwoDim::fromStream(istream& is)
{
  _numberOfBinsOnEachAxis = getObj<int>(is);
  for (int i = 0; i < _numberOfBinsOnEachAxis; ++i)
    for (int j = 0; j < _numberOfBinsOnEachAxis; ++j)
      _accumulator[i][j] = getObj<Float64>(is);
  _separabilityStatsUnknown = true;
}

SeparabilityTestForTwoDim& SeparabilityTestForTwoDim::operator+=(const SeparabilityTestForTwoDim& partial)
{
  assert(_numberOfBinsOnEachAxis == partial._numberOfBinsOnEachAxis);
  for (int i = 0; i < _accumulator.size(); ++i)
    for (int j = 0; j < _accumulator[i].size(); ++j)
      _accumulator[i][j] += partial._accumulator[i][j];
  _separabilityStatsUnknown = true;
  return *this;
}

// --------------------------------------------------------------
// --------------------------------------------------------------
// --------------------------------------------------------------

Dvegas::AccPtrs::AccPtrs(vector<GlobalAccumulator> *const accumulators,
  CellAccumulators *const cellAccumulators, CorrelationsDetector *const 
  correlationsDetector)
  : _accumulators(accumulators), _cellAccumulators(cellAccumulators),
    _correlationsDetector(correlationsDetector)
{}

void Dvegas::AccPtrs::toStream(ostream& os) const
{
  os << ((_accumulators != 0) ? true : false) << csep;
  os << ((_cellAccumulators != 0) ? true : false) << csep;
  os << ((_correlationsDetector != 0) ? true : false) << csep;

  if (_accumulators != 0) {
    os << _accumulators->size() << csep;
    for (int i = 0; i < _accumulators->size(); ++i)
      (*_accumulators)[i].toStream(os);
  }

  if (_cellAccumulators != 0)
    _cellAccumulators->toStream(os);

  if (_correlationsDetector != 0)
    _correlationsDetector->toStream(os);
}

void Dvegas::AccPtrs::deleteAcc() const
{
  delete _accumulators;
  delete _cellAccumulators;
  delete _correlationsDetector;
}

Dvegas::AccPtrs::AccPtrs()
  : _accumulators(0), _cellAccumulators(0), _correlationsDetector(0)
{}

void Dvegas::AccPtrs::fromStream(istream& is)
{
  const bool haveAccumulators = getObj<bool>(is);
  const bool haveCellAccumulators = getObj<bool>(is);
  const bool haveCorrelationsDetector = getObj<bool>(is);

  if (haveAccumulators) {
    if (_accumulators == 0)
      _accumulators = new vector<GlobalAccumulator>();
    _accumulators->resize(getObj<int>(is));
    for (int i = 0; i < _accumulators->size(); ++i)
      (*_accumulators)[i].fromStream(is);
  }
  else {
    delete _accumulators;
    _accumulators = 0;
  }

  if (haveCellAccumulators) {
    if (_cellAccumulators == 0)
      _cellAccumulators = new CellAccumulators();
    _cellAccumulators->fromStream(is);
  }
  else {
    delete _cellAccumulators;
    _cellAccumulators = 0;
  }

  if (haveCorrelationsDetector) {
    if (_correlationsDetector == 0)
      _correlationsDetector = new CorrelationsDetector();
    _correlationsDetector->fromStream(is);
  }
  else {
    delete _correlationsDetector;
    _correlationsDetector = 0;
  }
}

Dvegas::AccPtrs& Dvegas::AccPtrs::operator+=(const AccPtrs& partial)
{
  if (_accumulators != 0) {
    for (int i = 0; i < _accumulators->size(); ++i)
      (*_accumulators)[i] += (*partial._accumulators)[i];
  }

  if (_cellAccumulators != 0)
    *_cellAccumulators += *partial._cellAccumulators;

  if (_correlationsDetector != 0)
    *_correlationsDetector += *partial._correlationsDetector;

  return *this;
}

// should implement reference counting if used more generally
Dvegas::AccPtrs::AccPtrs(const AccPtrs& accPtrs)
  : _accumulators(accPtrs._accumulators),
    _cellAccumulators(accPtrs._cellAccumulators),
    _correlationsDetector(accPtrs._correlationsDetector)
{}

// should implement reference counting if used more generally
Dvegas::AccPtrs& Dvegas::AccPtrs::operator=(const AccPtrs& accPtrs)
{
  if (this != &accPtrs) {
    _accumulators = accPtrs._accumulators;
    _cellAccumulators = accPtrs._cellAccumulators;
    _correlationsDetector = accPtrs._correlationsDetector;
  }
  return *this;
}

// --------------------------------------------------------------

Dvegas::ShotParameters::ShotParameters(const Dvegas& dvegas)
  : weight(0.), x(dvegas._cDim), k(dvegas._dDimSizes.size()), aux(dvegas._aDim),
    f(dvegas._f), contIndexes(dvegas._cDim), discIndexes(k)
{}

// --------------------------------------------------------------

Dvegas::CellAccumulators::Accumulator::Accumulator()
  : sumOfIntegrandValues(0.), sumOfIntegrandValueSquares(0.), numberOfShots(0)
{}

void Dvegas::CellAccumulators::Accumulator::addValue(const double value)
{
  sumOfIntegrandValues += value;
  sumOfIntegrandValueSquares += pow(value, 2);
  ++numberOfShots;
}

void Dvegas::CellAccumulators::Accumulator::toStream(ostream& os) const
{
  os << sumOfIntegrandValues << csep;
  os << sumOfIntegrandValueSquares << csep;
  os << numberOfShots << csep;
}

ostream& operator<<(ostream& os, const Dvegas::CellAccumulators::Accumulator& a)
{
  a.toStream(os);
  return os;
}

void Dvegas::CellAccumulators::Accumulator::fromStream(istream& is)
{
  sumOfIntegrandValues = getObj<Float64>(is);
  sumOfIntegrandValueSquares = getObj<Float64>(is);
  numberOfShots = getObj<Int64>(is);
}

istream& operator>>(istream& is, Dvegas::CellAccumulators::Accumulator& a)
{
  a.fromStream(is);
  return is;
}

Dvegas::CellAccumulators::Accumulator& Dvegas::CellAccumulators::Accumulator::operator+=(const Accumulator& partial)
{
  sumOfIntegrandValues += partial.sumOfIntegrandValues;
  sumOfIntegrandValueSquares += partial.sumOfIntegrandValueSquares;
  numberOfShots += partial.numberOfShots;
  return *this;
}

// --------------------------------------------------------------

Dvegas::CellAccumulators::CellAccumulators(const Dvegas& dvegas)
{
  vector<Accumulator> cTemp(dvegas._cBin);
  contDimAcc.assign(dvegas._cDim, cTemp);

  //discDimAcc = vector< vector<Accumulator> >();
  discDimAcc.reserve(dvegas._dDimSizes.size());
  for (int i = 0; i < dvegas._dDimSizes.size(); ++i)
    discDimAcc.push_back(vector<Accumulator>(dvegas._dDimSizes[i]));

  if (dvegas._corrDim > 0) {
    corrDimAcc.reserve(dvegas._corrDimWeights.size());
    for (int i = 0; i < dvegas._corrDimWeights.size(); ++i) {
      corrDimAcc.push_back(MultidimensionalArray<Accumulator>(dvegas._corrDimWeights[i].dim(), dvegas._cBin));
      corrDimAcc.back().initialize();
    }
  }
}

void Dvegas::CellAccumulators::addShot(const ShotParameters& sp)
{
  const double weightedValue = sp.f[0] * sp.weight;

  for (int i = 0; i < contDimAcc.size(); ++i)
    contDimAcc[i][sp.contIndexes[i]].addValue(weightedValue);

  for (int i = 0; i < discDimAcc.size(); ++i)
    discDimAcc[i][sp.discIndexes[i]].addValue(weightedValue);

  if (corrDimAcc.size() > 0) {
    vector<int>::const_iterator it = sp.contIndexes.begin();    
    for (int i = 0; i < corrDimAcc.size(); ++i) {
      const vector<int> corrIndexes(it, it + corrDimAcc[i].dim());
      corrDimAcc[i][corrIndexes].addValue(weightedValue);
      it += corrDimAcc[i].dim();
    }
  }
}

void Dvegas::CellAccumulators::toStream(ostream& os) const
{
  os << contDimAcc.size() << csep;
  if (contDimAcc.size() > 0) {
    os << contDimAcc[0].size() << csep;
    for (int i = 0; i < contDimAcc.size(); ++i)
      for (int j = 0; j < contDimAcc[i].size(); ++j)
        contDimAcc[i][j].toStream(os);
  }

  os << discDimAcc.size() << csep;
  for (int i = 0; i < discDimAcc.size(); ++i) {
    os << discDimAcc[i].size() << csep;
    for (int j = 0; j < discDimAcc[i].size(); ++j)
      discDimAcc[i][j].toStream(os);
  }

  os << corrDimAcc.size() << csep;
  for (int i = 0; i < corrDimAcc.size(); ++i)
    corrDimAcc[i].toStream(os);
}

Dvegas::CellAccumulators::CellAccumulators()
{}

void Dvegas::CellAccumulators::fromStream(istream& is)
{
  const int cDim = getObj<int>(is);
  if (cDim > 0) {
    {
      const int cBin = getObj<int>(is);
      if (contDimAcc.size() > 0 && cBin == contDimAcc[0].size()) {
        contDimAcc.resize(cDim, contDimAcc[0]);
      }
      else {
        vector<Dvegas::CellAccumulators::Accumulator> cTemp(cBin);
        contDimAcc.assign(cDim, cTemp);
      }
    }
    for (int i = 0; i < contDimAcc.size(); ++i)
      for (int j = 0; j < contDimAcc[i].size(); ++j)
        contDimAcc[i][j].fromStream(is);
  }

  const int dDim = getObj<int>(is);
  if (dDim > 0) {
    discDimAcc.resize(dDim);
    for (int i = 0; i < discDimAcc.size(); ++i) {
      discDimAcc[i].resize(getObj<int>(is));
      for (int j = 0; j < discDimAcc[i].size(); ++j)
        discDimAcc[i][j].fromStream(is);
    }
  }

  const int corrDimSets = getObj<int>(is);
  if (corrDimSets > 0) {
    corrDimAcc.resize(corrDimSets, MultidimensionalArray<Dvegas::CellAccumulators::Accumulator>(0, 0));
    for (int i = 0; i < corrDimAcc.size(); ++i)
      corrDimAcc[i].fromStream(is);
  }
}

Dvegas::CellAccumulators& Dvegas::CellAccumulators::operator+=(const CellAccumulators& partial)
{
  for (int i = 0; i < contDimAcc.size(); ++i)
    for (int j = 0; j < contDimAcc[i].size(); ++j)
      contDimAcc[i][j] += partial.contDimAcc[i][j];
  
  for (int i = 0; i < discDimAcc.size(); ++i)
    for (int j = 0; j < discDimAcc[i].size(); ++j)
      discDimAcc[i][j] += partial.discDimAcc[i][j];
  
  for (int i = 0; i < corrDimAcc.size(); ++i)
    corrDimAcc[i] += partial.corrDimAcc[i];

  return *this;
}

// --------------------------------------------------------------

Dvegas::DiscreteWeights::DiscreteWeights(const int numberOfIndexValues)
  : _weights(numberOfIndexValues, 1.0/numberOfIndexValues)
{}

const double Dvegas::DiscreteWeights::getIndexValueAndWeight(const double randomInZeroOne, int& indexValue) const
{
  double random = randomInZeroOne;
  for (int i = 0; i < _weights.size(); ++i) {
    if (random < _weights[i]) {
      indexValue = i;
      break;
    }
    else
      random -= _weights[i];
  }
  double weight = 1.0/_weights[indexValue];
  if (const bool calculateAverageRatherThanSum = false)
    weight /= _weights.size();
  return weight;
}

void Dvegas::DiscreteWeights::setWeights(const vector<double>& normalizedWeights)
{
  assert(normalizedWeights.size() == _weights.size());
  _weights = normalizedWeights;
}

void Dvegas::DiscreteWeights::toStream(ostream& os) const
{
  os << _weights.size() << csep;
  for (int i = 0; i < _weights.size(); ++i)
    os << _weights[i] << csep;
}

void Dvegas::DiscreteWeights::fromStream(istream& is)
{
  const int size = getObj<int>(is);
  _weights.resize(size);
  for (int i = 0; i < _weights.size(); ++i)
    _weights[i] = getObj<double>(is);
}

// --------------------------------------------------------------

Dvegas::ContinuousWeights::ContinuousWeights(const int numberOfBins)
  : _numberOfBins(numberOfBins)
{
  if (_numberOfBins > 0) {
    _binEdges.reserve(_numberOfBins+1);
    for (int i = 0; i < _numberOfBins+1; ++i) {
      _binEdges.push_back(i/double(_numberOfBins));
    }
  }
}

const int Dvegas::ContinuousWeights::getIndexAndNewRandom(double& randomInZeroOne) const
{
  // select one of the bins with equal probability
  const int binIdx = int(_numberOfBins * randomInZeroOne);   // in [0, _numberOfBins-1]
  // recycle random number (will be relative position in bin):
  randomInZeroOne = _numberOfBins * randomInZeroOne - binIdx;
  return binIdx;
}

const double Dvegas::ContinuousWeights::getWeightAndWeightedRandom(const int binIdx, double& randomInZeroOne) const
{
  // map to position in non-flat grid:
  const double binWidth = _binEdges[binIdx+1] - _binEdges[binIdx];
  randomInZeroOne = _binEdges[binIdx] + binWidth * randomInZeroOne;
  const double weight = binWidth * _numberOfBins;
  return weight;     // weight = 1.0 for flat grid
}

void Dvegas::ContinuousWeights::setWeights(const vector<double>& normalizedBinWeights)
{
  assert(normalizedBinWeights.size() == _numberOfBins);
  const double averageBinWeight = 1.0/_numberOfBins;

  vector<double> newBinEdges(_numberOfBins+1);
  newBinEdges[0] = 0.0;

  int oldBinIdx = 0;
  double accumulatedWeight = 0.0;
  for (int i = 1; i < _numberOfBins; ++i) {
    // merge several old bins if binWeight < averageBinWeight
    while (accumulatedWeight < averageBinWeight)
      accumulatedWeight += normalizedBinWeights[oldBinIdx++];
    // now: accumulatedWeight >= averageBinWeight, allocate next bin
    // shrink rightmost bin (shrinkFactor in [0,1), large shrinkFactor -> small new bin)
    const double shrinkFactor = (accumulatedWeight - averageBinWeight)/normalizedBinWeights[oldBinIdx-1];
    const double oldWidth = _binEdges[oldBinIdx] - _binEdges[oldBinIdx-1];
    // _binEdges[oldBinIdx] is right edge of last old bin
    newBinEdges[i] = _binEdges[oldBinIdx] - oldWidth * shrinkFactor;
    accumulatedWeight = accumulatedWeight - averageBinWeight;     // another bin done
  }

  newBinEdges[_numberOfBins] = 1.0;
  
  _binEdges = newBinEdges;
}

void Dvegas::ContinuousWeights::toStream(ostream& os) const
{
  os << _numberOfBins << csep;
  assert(_binEdges.size() == _numberOfBins + 1);
  for (int i = 0; i < _binEdges.size(); ++i)
    os << _binEdges[i] << csep;
}

void Dvegas::ContinuousWeights::fromStream(istream& is)
{
  _numberOfBins = getObj<int>(is);
  _binEdges.resize(_numberOfBins + 1);
  for (int i = 0; i < _binEdges.size(); ++i)
    _binEdges[i] = getObj<double>(is);
}

// --------------------------------------------------------------

Dvegas::CorrelatedWeights::CorrelatedWeights(const int corrDim, const int corrBin)
  : _flatGrid(false), _weights(corrDim, corrBin)
{}

void Dvegas::CorrelatedWeights::reset()
{
  _weights.reset(flatWeight());
  _flatGrid = true;
  _optim.reset(_weights.size());
}

const double Dvegas::CorrelatedWeights::getIndexesAndWeight(const double randomInZeroOne, vector<int>& corrIndexes) const
{
  assert(corrIndexes.size() == _weights.dim() || corrIndexes.size() == 0);
  if (_flatGrid) {
    corrIndexes = _weights.seqIdxToIndexes(Int64(_weights.size() * randomInZeroOne));
    return 1.0;
  }
  else {
    if (randomNumberGenerator->uniformInZeroOne() <= _optim.sumOfNonTinyWeights || !_optim.optimizeEnabled) {
      double random = randomInZeroOne * _optim.sumOfNonTinyWeights;
      for (Int64 i = 0; i < _weights.size() - _optim.numberOfTinyWeights; ++i) {
        const Int64 j = (_optim.optimizeEnabled) ? _optim.idxMap[i] : i;
        const Float64 weight = _weights[j];
        if (random < weight) {
          corrIndexes = _weights.seqIdxToIndexes(j);
          return flatWeight()/weight;
        }
        else
          random -= weight;
      }
    }
    else {
      const Int64 seqIdxForTiny = (_weights.size()-1) - Int64(randomInZeroOne * _optim.numberOfTinyWeights);
      corrIndexes = _weights.seqIdxToIndexes(_optim.idxMap[seqIdxForTiny]);
      return flatWeight()/_optim.tinyWeight;
    }
  }
  return 0.0;     // compiler
}
  
void Dvegas::CorrelatedWeights::setWeights(const MultidimensionalArray<Float64>& normalizedWeights)
{
  assert(normalizedWeights.dim() == _weights.dim());
  assert(normalizedWeights.length() == _weights.length());
  assert(normalizedWeights.size() == _weights.size());
  _weights = normalizedWeights;
  _flatGrid = false;  
}

void Dvegas::CorrelatedWeights::rebinProjection(const int dim, const vector<double>& oldBinEdges, const vector<double>& newBinEdges)
{
  // bin contents are not rescaled, just moved according to the new bin boundaries
  _flatGrid = false;
  assert(oldBinEdges.front() == newBinEdges.front() && oldBinEdges.back() == newBinEdges.back());

  vector<Float64> newWeights(_weights.length());
  vector<Float64> oldWeights;
  const Int64 numberOfProj = powInt64(_weights.length(), _weights.dim()-1);
  for (Int64 projectionIterator = 0; projectionIterator < numberOfProj; ++projectionIterator) {
    oldWeights = _weights.getProjection(dim, projectionIterator);
    int n = 1, o = 1;
    double acc = 0.0;
    while (n < newBinEdges.size() || o < oldBinEdges.size()) {
      if (oldBinEdges[o] < newBinEdges[n]) {
        acc += oldWeights[o-1];
        ++o;
      }
      else if (oldBinEdges[o] == newBinEdges[n]) {
        newWeights[n-1] = oldWeights[o-1] + acc;
        ++o;
        ++n; acc = 0.0;
      }
      else if (oldBinEdges[o] > newBinEdges[n]) {
        const double lastProcessedEdge = max(oldBinEdges[o-1], newBinEdges[n-1]);
        const double remainingFraction =
          (oldBinEdges[o]-newBinEdges[n])/(oldBinEdges[o]-lastProcessedEdge);
        newWeights[n-1] = (1.0 - remainingFraction) * oldWeights[o-1] + acc;
        ++n; acc = 0.0;
        oldWeights[o-1] *= remainingFraction;
      }
    }
    _weights.putProjection(dim, projectionIterator, newWeights);
  }
}

void Dvegas::CorrelatedWeights::optimize()
{
  // fill _optim.idxMap and set _optim.{sumOfNonTinyWeights, numberOfTinyWeights, tinyWeight}
  if (_flatGrid)
    return;     // uniform weight: no optimization necessary, see getIndexesAndWeight()
  if (!optimizeEnabled()) {
    cerr << "error: invalid call to optimize(): optimize not enabled" << endl;
    terminate();
  }
  cout << "optimizing correlation sampling ... ";
  assert(_weights.size() == _optim.idxMap.size());     // numberOfWeights
  const Float64 nonTinyWeightThreshold = 0.0001/_weights.size();     // >= 99.99% is importance sampled
  _optim.sumOfNonTinyWeights = 0.0;
  _optim.numberOfTinyWeights = 0;     // found so far
  Int64 iterator = 0;
  for (Int64 index = 0; index < _weights.size(); ++index) {
    const Float64 weight = _weights[index];
    if (weight > nonTinyWeightThreshold) {
      _optim.sumOfNonTinyWeights += weight;
      // usually next sequential cell corresponds to neighboring cell with similar weight:
      // use previous insertion point as start for search for next insertion point
      const Int64 numberOfNonTinyWeights = index - _optim.numberOfTinyWeights;     // found so far
      if (numberOfNonTinyWeights > 0) {
        while (1) {
          if (iterator < numberOfNonTinyWeights && weight <= _weights[_optim.idxMap[iterator]])
            ++iterator;
          else if (iterator > 0 && _weights[_optim.idxMap[iterator-1]] < weight)
            --iterator;
          else
            break;
        }
        // make space for insertion before element at iterator
        Int64 i = numberOfNonTinyWeights - 1;
        while (i >= iterator) {
          _optim.idxMap[i+1] = _optim.idxMap[i];
          --i;
        }
      }      
      _optim.idxMap[iterator] = index;
    }
    else {
      ++_optim.numberOfTinyWeights;
      _optim.idxMap[_weights.size() - _optim.numberOfTinyWeights] = index;
    }
  }
  if (_optim.numberOfTinyWeights > 0) {
    _optim.tinyWeight = (1.0 - _optim.sumOfNonTinyWeights)/_optim.numberOfTinyWeights;
  }
  else {     // _optim.numberOfTinyWeights == 0
    _optim.sumOfNonTinyWeights = 1.0;
    _optim.tinyWeight = 0.0;
  }
  cout << "done" << endl;

  /*
  assert(_optim.numberOfTinyWeights < _weights.size());
  for (Int64 i = 1; i < _weights.size()-_optim.numberOfTinyWeights; ++i)
    assert(_weights[_optim.idxMap[i-1]] >= _weights[_optim.idxMap[i]]);
  */
}

void Dvegas::CorrelatedWeights::toStream(ostream& os) const
{
  os << ((_flatGrid) ? true : false) << csep;
  if (_flatGrid) {
    os << _weights.dim() << csep;
    os << _weights.length() << csep;
  }
  else {
    _weights.toStream(os);
  }
}

void Dvegas::CorrelatedWeights::fromStream(istream& is)
{
  const bool haveFlatGrid = getObj<bool>(is);
  if (haveFlatGrid) {
    _flatGrid = true;
    const int dim = getObj<int>(is);
    const int length = getObj<int>(is);
    _weights.resize(dim, length);
    _weights.initialize(flatWeight());
  }
  else {
    _flatGrid = false;
    _weights.fromStream(is);
  }
  _optim.reset(_weights.size());
}

void Dvegas::CorrelatedWeights::Optim::reset(const Int64 numberOfWeights)
{
  optimizeEnabled = false;
  sumOfNonTinyWeights = 1.0;
  numberOfTinyWeights = 0;
  tinyWeight = 0.;

  try {
    idxMap.resize(numberOfWeights);
    optimizeEnabled = true;
  }
  catch (bad_alloc) {
    cout << "warning: not enough memory, cannot optimize "
         << "shot generation for corr. dim." << endl;
    assert(optimizeEnabled == false);
  }
}

// --------------------------------------------------------------

Dvegas::CorrelationsDetector::CorrelationsDetector(const Dvegas& dvegas)
{
  const int& numberOfDimensions = dvegas._cDim;
  assert(numberOfDimensions > 0);
  const int& numberOfBins = dvegas._cBin;
  assert(numberOfBins > 0);
  const int numberOfTests = numberOfDimensions*(numberOfDimensions - 1)/2;
  _pairs.reserve(numberOfTests);
  for (int i = 0; i < numberOfDimensions; ++i) {
    for (int j = i+1; j < numberOfDimensions; ++j)
      _pairs.push_back(Pair(i, j, SeparabilityTestForTwoDim(numberOfBins)));
  }
}

void Dvegas::CorrelationsDetector::addShot(const ShotParameters& sp)
{
  const double weightedValue = sp.f[0] * sp.weight;
  for (int i = 0; i < _pairs.size(); ++i) {
    Pair& pair = _pairs[i];
    pair.test.addShot(sp.contIndexes[pair.dim1], sp.contIndexes[pair.dim2], weightedValue);
  }
}

void Dvegas::CorrelationsDetector::sort()
{
  stable_sort(_pairs.begin(), _pairs.end(), _lessSeparable);
}

void Dvegas::CorrelationsDetector::info() const
{
  assert(!_pairs.empty());
  for (int i = 0; i < _pairs.size(); ++i) {
    const SeparabilityTestForTwoDim::SeparabilityStats s =
      _pairs[i].test.separabilityStats();
    cout << "correlation stats for dim pair (" << setprecision(16) 
         << _pairs[i].dim1 << ", " << _pairs[i].dim2 << "): "
         << s.average - 1. << " +/- " << setprecision(2)
         << s.standardDeviation << setprecision(16) << endl;
  }
}

void Dvegas::CorrelationsDetector::toStream(ostream& os) const
{
  os << _pairs.size() << csep;
  for (int i = 0; i < _pairs.size(); ++i)
    _pairs[i].toStream(os);
}

Dvegas::CorrelationsDetector::CorrelationsDetector()
{}

void Dvegas::CorrelationsDetector::fromStream(istream& is)
{
  _pairs.resize(getObj<int>(is), 
    Dvegas::CorrelationsDetector::Pair(0, 0, SeparabilityTestForTwoDim(0)));
  for (int i = 0; i < _pairs.size(); ++i)
    _pairs[i].fromStream(is);
}

Dvegas::CorrelationsDetector& Dvegas::CorrelationsDetector::operator+=(const CorrelationsDetector& partial)
{
  for (int i = 0; i < _pairs.size(); ++i)
    _pairs[i].test += partial._pairs[i].test;
  return *this;
}

// --------------------------------------------------------------

Dvegas::CorrelationsDetector::Pair::Pair(int dim1_, int dim2_, SeparabilityTestForTwoDim test_)
  : dim1(dim1_), dim2(dim2_), test(test_)
{}

void Dvegas::CorrelationsDetector::Pair::toStream(ostream& os) const
{
  os << dim1 << csep;
  os << dim2 << csep;
  test.toStream(os);
}

void Dvegas::CorrelationsDetector::Pair::fromStream(istream& is)
{
  dim1 = getObj<int>(is);
  dim2 = getObj<int>(is);
  test.fromStream(is);
}

// --------------------------------------------------------------
// --------------------------------------------------------------
// --------------------------------------------------------------

// default: sampling = IMPORTANCE
Dvegas::Dvegas(const int aDim, const int f, const Integrand::Type itype)
  : _integrand(0)
{
  initialize(0, 0, vector<int>(), vector<int>(), aDim, f, itype, NONE);
}

Dvegas::Dvegas(const int cDim, const int cBin, const int f,
               const Integrand::Type itype, const Sampling sampling)
  : _integrand(0)
{
  initialize(cDim, cBin, vector<int>(), vector<int>(), 0, f, itype, sampling);
}

Dvegas::Dvegas(const int cDim, const int cBin, const vector<int>& dDimSizes,
               const int f, const Integrand::Type itype, const Sampling sampling)
  : _integrand(0)
{
  initialize(cDim, cBin, vector<int>(), dDimSizes, 0, f, itype, sampling);
}

Dvegas::Dvegas(const int cDim, const int cBin, const int corrDim,
               const vector<int>& dDimSizes, const int aDim, const int f,
               const Integrand::Type itype, const Sampling sampling)
  : _integrand(0)
{
  initialize(cDim, cBin, vector<int>((corrDim > 0) ? 1 : 0, corrDim), dDimSizes, aDim, f, itype, sampling);
}

Dvegas::Dvegas(const int cDim, const int cBin, const vector<int>& corrDim,
               const vector<int>& dDimSizes, const int aDim, const int f,
               const Integrand::Type itype, const Sampling sampling)
  : _integrand(0)
{
  initialize(cDim, cBin, corrDim, dDimSizes, aDim, f, itype, sampling);
}

Dvegas::Dvegas()
  : _integrand(0)
{
  initialize(0, 0, vector<int>(), vector<int>(), 0, 0, Integrand::NONE, NONE);
}

void Dvegas::initialize(const int cDim, const int cBin, const vector<int>& corrDim, const vector<int>& dDimSizes,
                        const int aDim, const int f, const Integrand::Type itype, const Sampling sampling)
{
  _cDim = cDim;
  _cBin = cBin;
  _corrDim = corrDim.empty() ? 0 : corrDim.back();
  _dDimSizes = dDimSizes;
  _aDim = aDim;
  _f = f;

  delete _integrand;
  _integrand = Integrand::make(itype);

  _sampling = sampling;
  _curvature = 0.5;
  _rootAmpl = 0.0;

  if (_corrDim > _cDim) {
    cerr << "error: correlations specified for nonexistent continuous dimensions" << endl;
    terminate();
  }
  for (int i = 0; i < corrDim.size(); ++i) {
    const int numberOfCorrelatedDimensionsForThisSet =
      (i > 0) ? corrDim[i] - corrDim[i-1] : corrDim[0];
    if (numberOfCorrelatedDimensionsForThisSet <= 0) {
      cerr << "error: corrDim has nonpositive indexes or is not strictly increasing" << endl;
      terminate();
    }
    else if (numberOfCorrelatedDimensionsForThisSet == 1) {
      cout << "error: set with one element: i = " << i << ", no correlations taken into account" << endl;
      terminate();
    }
    _corrDimWeights.push_back(CorrelatedWeights(numberOfCorrelatedDimensionsForThisSet, _cBin));
  }
  int check = 0;
  for (int i = 0; i < _corrDimWeights.size(); ++i)
    check += _corrDimWeights[i].dim();
  assert(check == _corrDim);
  reset();

  _detectCorrelations = false;

  _omniComp = 0;
}

Dvegas::~Dvegas()
{
  delete _integrand;
}

void Dvegas::disableOptimize(const int setOfCorrelatedWeights)
{
  if (0 <= setOfCorrelatedWeights
      && setOfCorrelatedWeights < _corrDimWeights.size()) {
    _corrDimWeights[setOfCorrelatedWeights].disableOptimize();
  }
  else {
    cerr << "error: setOfCorrelatedWeights out of bounds: "
         << setOfCorrelatedWeights << endl;
    terminate();
  }
}

void Dvegas::reset()
{
  resetEstimates();
  resetWeights();
}

void Dvegas::resetWeights()
{
  // equal weights for continuous dimensions (i.e. flat grid)
  _contDimWeights.assign(_cDim, ContinuousWeights(_cBin));

  // equal weights for discrete dimensions
  _discDimWeights = vector<DiscreteWeights>();
  for (int i = 0; i < _dDimSizes.size(); ++i)
    _discDimWeights.push_back(DiscreteWeights(_dDimSizes[i]));

  // correlated dimensions
  for (int i = 0; i < _corrDimWeights.size(); ++i)
    _corrDimWeights[i].reset();
}

void Dvegas::resetEstimates()
{
  _newestIterationStats.assign(_f, IntegrandEstimate());
  _allIterationsStats.assign(_f, IntegrandEstimate());
}

Dvegas::CellAccumulators Dvegas::collectData(const Int64 numberOfShots) throw (NoNonzeroIntegrandValuesSampledException)
{
  cout << "========================================================================" << endl;
  cout << "iteration with " << numberOfShots << " shots" << endl;

  const bool delegateEvaluation = _omniComp != 0;
  const AccPtrs accPtrs = evaluateIntegrand(numberOfShots, delegateEvaluation);

  vector<GlobalAccumulator>& accumulators = *accPtrs.accumulators();
  CellAccumulators& cellAcc = *accPtrs.cellAccumulators();
  CorrelationsDetector *const & _correlationsDetector = accPtrs.correlationsDetector();

  // save values that are reset by call to getEstimate()
  _info.efficiency.assign(_f, 0.);
  _info.positiveContribution.assign(_f, 0.);
  _info.negativeContribution.assign(_f, 0.);
  for (int i = 0; i < _f; ++i) {
    _info.efficiency[i] = accumulators[i].efficiency();
    _info.positiveContribution[i] = accumulators[i].positiveContribution();
    _info.negativeContribution[i] = accumulators[i].negativeContribution();
  }

  if (_info.efficiency[0] == 0.0) {
    // no hits!  Are integrand and mapping OK?
    throw NoNonzeroIntegrandValuesSampledException();
  }
  _newestIterationStats.assign(_f, IntegrandEstimate());
  assert(_newestIterationStats.size() == _allIterationsStats.size());
  for (int i = 0; i < _newestIterationStats.size(); ++i) {
    const Estimate estimate = accumulators[i].getEstimate();
    _newestIterationStats[i].addEstimate(estimate);
    _allIterationsStats[i].addEstimate(estimate);
  }

  if (_correlationsDetector) {
    cout << "+++++++++++++++++++++++++++++++++++++++++++++++++++" << endl;
    if (!_correlationsDetector->denseCoverage(numberOfShots))
      cout << "WARNING: sparse coverage, test not reliable" << endl;
    _correlationsDetector->sort();
    _correlationsDetector->info();
    cout << "+++++++++++++++++++++++++++++++++++++++++++++++++++" << endl;
    delete _correlationsDetector;
  }
  if (hasOmniHistoSuiteAttached())
    omniHistoSuite()->updatePartialEstimates(numberOfShots);

  delete accPtrs.accumulators();
  CellAccumulators cellAcc_(*accPtrs.cellAccumulators());
  delete accPtrs.cellAccumulators();
  return cellAcc_;
}

// -----------------------
class UpdateOutputHelper
{
public:
  UpdateOutputHelper(const CORBA::Float fractionBetweenOutputs);
  UpdateOutputHelper(const CORBA::Float fractionBetweenOutputs, const int secondsBetweenOutputs);
  void init();
  const bool shouldUpdateOutput(const CORBA::Float fractionComputed) const;
  void haveUpdatedOutput(const CORBA::Float fractionComputed);
  void disableTimedOutput();
private:
  const CORBA::Float _fractionBetweenOutputs;
  CORBA::Float _fractionAtLastOutput;

  const bool _timedOutput;
  const int _secondsBetweenOutputs;
  bool _timedOutputActive;
  time_t _lastOutputTime;
};

UpdateOutputHelper updateOutputHelper(0.1, 5 * 60);     // 10%, 5 min

inline void UpdateOutputHelper::disableTimedOutput() { _timedOutputActive = false; }

UpdateOutputHelper::UpdateOutputHelper(const CORBA::Float fractionBetweenOutputs)
  : _fractionBetweenOutputs(fractionBetweenOutputs), _timedOutput(false), 
    _secondsBetweenOutputs(0)
{
  init();
}

UpdateOutputHelper::UpdateOutputHelper(const CORBA::Float fractionBetweenOutputs, const int secondsBetweenOutputs)
  : _fractionBetweenOutputs(fractionBetweenOutputs), _timedOutput(true), 
    _secondsBetweenOutputs(secondsBetweenOutputs)
{
  init();
  assert(_secondsBetweenOutputs > 0);
}

void UpdateOutputHelper::init()
{
  _fractionAtLastOutput = 0.0;
  if (_timedOutput) {
    _timedOutputActive = true;
    _lastOutputTime = time(NULL);
  }
  else {
    _timedOutputActive = false;
  }
}

const bool UpdateOutputHelper::shouldUpdateOutput(const CORBA::Float fractionComputed) const
{
  if (_timedOutputActive) {
    if (difftime(time(NULL), _lastOutputTime) > _secondsBetweenOutputs)
      return true;
  }
  return fractionComputed > _fractionAtLastOutput + _fractionBetweenOutputs;
}

void UpdateOutputHelper::haveUpdatedOutput(const CORBA::Float fractionComputed)
{
  if (fractionComputed > _fractionAtLastOutput + _fractionBetweenOutputs)
    _fractionAtLastOutput += _fractionBetweenOutputs;
  if (_timedOutputActive)
    _lastOutputTime = time(NULL);
}
// -----------------------
  
const Dvegas::AccPtrs Dvegas::evaluateIntegrand(const Int64 numberOfShots, const bool delegateEvaluation)
{
  AccPtrs accPtrs(new vector<GlobalAccumulator>(_f), new CellAccumulators(*this),
                  (_detectCorrelations) ? new CorrelationsDetector(*this) : 0);
  _detectCorrelations = false;     // reset to default

  vector<GlobalAccumulator>& accumulators = *accPtrs.accumulators();
  CellAccumulators& cellAcc = *accPtrs.cellAccumulators();
  CorrelationsDetector *const & _correlationsDetector = accPtrs.correlationsDetector();

  if (delegateEvaluation) {
    assert(_omniComp != 0);
    OmniParameters parameters;
    parameters.numberOfShots = numberOfShots;
    parameters.haveCorrelationsDetector = _correlationsDetector != 0;
    const list<string> partialResults =
      _omniComp->distributeComputations(parameters, saveStateToString());
    AccPtrs partial;
    for (list<string>::const_iterator it = partialResults.begin();
         it != partialResults.end(); ++it) {
      istringstream iss(*it);
      partial.fromStream(iss);
      accPtrs += partial;
      const bool isTransmittingExternalMaxEventWeightEstimate = getObj<bool>(iss);
      if (isTransmittingExternalMaxEventWeightEstimate) {
	const double externalEstimate = getObj<double>(iss);
	MaxEventWeightEstimate::addEstimateValue(externalEstimate);
      }
      const bool isTransmittingExternalHistoSuiteResults = getObj<bool>(iss);
      if (isTransmittingExternalHistoSuiteResults) {
        assert(hasOmniHistoSuiteAttached());
        OmniHistoSuite *const partialOmniHistoSuite = omniHistoSuite()->cloneEmpty();
        partialOmniHistoSuite->fromStream(iss);
        const OmniHistoSuite& const_partialOmniHistoSuite = *partialOmniHistoSuite;
        *omniHistoSuite() += const_partialOmniHistoSuite;
        delete partialOmniHistoSuite;
      }
    }
    partial.deleteAcc();
  }
  else {
    HepSource::updateOutputHelper.init();
    for (int i = 0; i < _corrDimWeights.size(); ++i) {
      if (_corrDimWeights[i].optimizeEnabled())
        _corrDimWeights[i].optimize();
    }

    ShotParameters sp(*this);     // recycled
    for (Int64 k = 0; k < numberOfShots; ++k) {
      sp.weight = 1.0;
      if (_cDim > 0) randomNumberGenerator->uniformInZeroOne(sp.x);
      for (int i = _corrDim; i < _cDim; ++i) {
        sp.weight *= _contDimWeights[i].getWeightAndWeightedRandomAndIndex(sp.x[i], sp.contIndexes[i]);
      }
      if (_corrDim > 0) {
        int it = 0;
        for (int i = 0; i < _corrDimWeights.size(); ++i) {
          vector<int> corrIndexes;
          sp.weight *= _corrDimWeights[i].getIndexesAndWeight(randomNumberGenerator->uniformInZeroOne(), corrIndexes);
          const int start = it;
          const int stop = start + _corrDimWeights[i].dim();
          while (it < stop) {
            sp.contIndexes[it] = corrIndexes[it-start];
            sp.weight *= _contDimWeights[it].getWeightAndWeightedRandom(sp.contIndexes[it], sp.x[it]);
            ++it;
          }
        }
      }
      for (int i = 0; i < _discDimWeights.size(); ++i)     // discrete dimensions
        sp.weight *= _discDimWeights[i].getIndexValueAndWeight(randomNumberGenerator->uniformInZeroOne(), sp.k[i]);
      if (_aDim > 0) randomNumberGenerator->uniformInZeroOne(sp.aux);     // auxilliary dimensions
      // **************************
      (*_integrand)(sp.x, sp.k, sp.weight, sp.aux, sp.f);
      // **************************
      for (int i = 0; i < accumulators.size(); ++i) {
        accumulators[i].addValue(sp.f[i], sp.weight);
      }
      cellAcc.addShot(sp);     // for adaptation
      if (_correlationsDetector)
        _correlationsDetector->addShot(sp);

      if (_omniComp && k%100 == 0) {
        const CORBA::Float fractionComputed = CORBA::Float(k)/numberOfShots;
        if (HepSource::updateOutputHelper.shouldUpdateOutput(fractionComputed)) {
          _omniComp->outputRef()->updateProgressOutput(
            _omniComp->workerId(), fractionComputed);
          HepSource::updateOutputHelper.haveUpdatedOutput(fractionComputed);
          HepSource::updateOutputHelper.disableTimedOutput();     // at most once
          _omniComp->tendToOrbWork();
        }
      }
      if (abortLoopPtr && (*abortLoopPtr))
	break;
    }
    if (_omniComp && !(abortLoopPtr && (*abortLoopPtr)))
      _omniComp->outputRef()->updateProgressOutput(_omniComp->workerId(), 1.0);
  }

  return accPtrs;
}

void Dvegas::info() const
{
  info(_f);
}

void Dvegas::info(const int numberOfIntegrandsToDisplayInfoFor) const
{
  const int& n = numberOfIntegrandsToDisplayInfoFor;
  for (int i = 0; i < n; ++i) {
    if (n > 1) {
      cout << "integrand " << i+1 << ": ";
    }
    _newestIterationStats.at(i).print(cout);
    if (_info.positiveContribution.at(i) != 0. && _info.negativeContribution.at(i) != 0.) {
      cout << ", >0: " << _info.positiveContribution.at(i);
      cout << ", <0: " << _info.negativeContribution.at(i);
    }
    cout << ", efficiency: " << setprecision(2) << _info.efficiency.at(i) << setprecision(16);
    cout << endl;
  }
  if (_allIterationsStats.at(0).numberOfEstimates() > 1) {
    cout << "Cumulative:" << endl;
    for (int i = 0; i < n; ++i) {
      if (n > 1) {
	cout << "integrand " << i+1 << ": ";
      }
      _allIterationsStats.at(i).print(cout);
      cout << endl;
    }
  }
  cout << "========================================================================" << endl;
}

// --------------------------------------------------------------
// --------------------------------------------------------------
// --------------------------------------------------------------

// prototypes for adaptWeights()
vector<Float64> getRawWeights(const Sampling, const vector<Dvegas::CellAccumulators::Accumulator>&);
vector<Float64> smoothArray(const vector<Float64>&, const int = 3);
MultidimensionalArray<Float64> getRawWeights(const Sampling, const MultidimensionalArray<Dvegas::CellAccumulators::Accumulator>&);
MultidimensionalArray<Float64> smoothArray(const MultidimensionalArray<Float64>&, const int = 3);
template<class C> C& promoteSmallerWeights(const double, const double, C&);
template<class C> const C& normalize(C&);

// full adaptation
void Dvegas::adaptWeights(CellAccumulators& cellAcc)
{
  adaptContinuousWeights(cellAcc);
  adaptCorrelatedWeights(cellAcc);
  adaptDiscreteWeights(cellAcc);     
}

// uncorrelated continuous dimensions
void Dvegas::adaptContinuousWeights(CellAccumulators& cellAcc)
{
  for (int i = _corrDim; i < _cDim; ++i) {
    //_contDimWeights[i].setWeights(normalize(promoteSmallerWeights(_curvature, _rootAmpl, smoothArray(getRawWeights(IMPORTANCE, cellAcc.contDimAcc[i])))));
    vector<Float64> rawWeights = getRawWeights(IMPORTANCE, cellAcc.contDimAcc[i]);
    vector<Float64> smoothedWeights = smoothArray(rawWeights);
    _contDimWeights[i].setWeights(normalize(
      promoteSmallerWeights(_curvature, _rootAmpl, smoothedWeights)));
  }
}

// correlated continuous dimensions
void Dvegas::adaptCorrelatedWeights(CellAccumulators& cellAcc)
{
  if (_corrDim > 0) {
    int it = 0;
    for (int i = 0; i < _corrDimWeights.size(); ++i) {
      cout << "adapting correlated dimensions (set " << i+1 << ") ... ";
      //_corrDimWeights[i].setWeights(normalize(promoteSmallerWeights(_curvature, _rootAmpl, smoothArray(getRawWeights(_sampling, cellAcc.corrDimAcc[i])))));
      MultidimensionalArray<Float64> rawWeights = getRawWeights(_sampling, cellAcc.corrDimAcc[i]);
      cout << "[smoothing ... ";
      MultidimensionalArray<Float64> smoothedWeights = smoothArray(rawWeights);
      cout << "done] ... ";
      _corrDimWeights[i].setWeights(normalize(promoteSmallerWeights(_curvature, _rootAmpl, smoothedWeights)));
      if (const bool variableGridForCorrDim = true) {
        const int start = it;
        const int stop = start + _corrDimWeights[i].dim();
        while (it < stop) {
          const vector<double> oldBinEdges = _contDimWeights[it].binEdges();
          //_contDimWeights[it].setWeights(normalize(promoteSmallerWeights(_curvature, _rootAmpl, smoothArray(getRawWeights(IMPORTANCE, cellAcc.contDimAcc[it])))));
          vector<Float64> rawWeights = getRawWeights(IMPORTANCE, cellAcc.contDimAcc[it]);
          vector<Float64> smoothedWeights = smoothArray(rawWeights);
          _contDimWeights[it].setWeights(normalize(
            promoteSmallerWeights(_curvature, _rootAmpl, smoothedWeights)));
          const vector<double> newBinEdges = _contDimWeights[it].binEdges();
          _corrDimWeights[i].rebinProjection(it-start, oldBinEdges, newBinEdges);
          ++it;
        }
      }
      cout << "done" << endl;
    }
  }
}

// discrete dimensions
void Dvegas::adaptDiscreteWeights(CellAccumulators& cellAcc)
{
  for (int i = 0; i < _dDimSizes.size(); ++i) {
    //_discDimWeights[i].setWeights(normalize(promoteSmallerWeights(_curvature, _rootAmpl, getRawWeights(_sampling, cellAcc.discDimAcc[i]))));
    vector<Float64> rawWeights = getRawWeights(_sampling, cellAcc.discDimAcc[i]);
    _discDimWeights[i].setWeights(normalize(
      promoteSmallerWeights(_curvature, _rootAmpl, rawWeights)));
  }
}

// --------------------------------------------------------------
// --------------------------------------------------------------

/*
   void getRawWeights() should be
   template<template<class T, class Allocator = allocator<T> > class C>
   for compatibility with C++ Standard Library containers 
   (here used with C = vector and C = MultidimensionalArray)
   but gcc-3.0.1's g++ aborts with internal compiler error
*/

void getRawWeights(const MultidimensionalArray<Dvegas::CellAccumulators::Accumulator>& acc, MultidimensionalArray<Float64>& rawWeights, const Sampling sampling)
{
  assert(rawWeights.size() == acc.size());
  Int64 numberOfCellsNotAdapted = 0;
  Float64 sumOfWeightsFromAdaptation = 0.0;
  switch (sampling) {
  case NONE:
    numberOfCellsNotAdapted = acc.size();
    break;
  case IMPORTANCE:
    for (Int64 i = 0; i < acc.size(); ++i) {
      const Dvegas::CellAccumulators::Accumulator& a = acc[i];
      if (a.numberOfShots >= 1) {
        const Float64 rawWeight = sqrt(a.sumOfIntegrandValueSquares);   // compare with alternatives
        rawWeights[i] = rawWeight;
        sumOfWeightsFromAdaptation += rawWeight;
      }
      else {
        ++numberOfCellsNotAdapted;
      }
    }
    break;
  case STRATIFIED:
    for (Int64 i = 0; i < acc.size(); ++i) {
      const Dvegas::CellAccumulators::Accumulator& a = acc[i];
      if (a.numberOfShots >= 2) {
        const Float64 rawWeight = sqrt(a.sumOfIntegrandValueSquares/a.numberOfShots
          - pow(a.sumOfIntegrandValues/a.numberOfShots, 2));
        rawWeights[i] = rawWeight;
        sumOfWeightsFromAdaptation += rawWeight;
      }
      else {
        ++numberOfCellsNotAdapted;
      }
    }
    break;
  default:
    cerr << "error in getRawWeights(): invalid sampling type" << endl;
    terminate();
  }
  if (numberOfCellsNotAdapted > 0) {
    assert(numberOfCellsNotAdapted <= acc.size());
    if (acc.size() - numberOfCellsNotAdapted > 0) { 
      const Float64 average = sumOfWeightsFromAdaptation/(acc.size()-numberOfCellsNotAdapted);
      const int minimumHitsRequiredForAdaptation = (sampling == STRATIFIED) ? 2 : 1;
      for (Int64 i = 0; i < acc.size(); ++i) {
        if (acc[i].numberOfShots < minimumHitsRequiredForAdaptation)
          rawWeights[i] = average;
      }
    }
    else {
      if (sampling != NONE)
        cout << "warning: cannot adapt, continuing with flat weights" << endl;
      for (Int64 i = 0; i < acc.size(); ++i)
        rawWeights[i] = 1.0;
    }
  }
}

MultidimensionalArray<Float64> getRawWeights(const Sampling sampling, const MultidimensionalArray<Dvegas::CellAccumulators::Accumulator>& acc)
{
  MultidimensionalArray<Float64> rawWeights(acc.dim(), acc.length());
  rawWeights.initialize();
  getRawWeights(acc, rawWeights, sampling);
  return rawWeights;
}

void getRawWeights(const vector<Dvegas::CellAccumulators::Accumulator>& acc, vector<Float64>& rawWeights, const Sampling sampling)
{
  assert(rawWeights.size() == acc.size());
  Int64 numberOfCellsNotAdapted = 0;
  Float64 sumOfWeightsFromAdaptation = 0.0;
  switch (sampling) {
  case NONE:
    numberOfCellsNotAdapted = acc.size();
    break;
  case IMPORTANCE:
    for (Int64 i = 0; i < acc.size(); ++i) {
      const Dvegas::CellAccumulators::Accumulator& a = acc[i];
      if (a.numberOfShots >= 1) {
        const Float64 rawWeight = sqrt(a.sumOfIntegrandValueSquares);   // compare with alternatives
        rawWeights[i] = rawWeight;
        sumOfWeightsFromAdaptation += rawWeight;
      }
      else {
        ++numberOfCellsNotAdapted;
      }
    }
    break;
  case STRATIFIED:
    for (Int64 i = 0; i < acc.size(); ++i) {
      const Dvegas::CellAccumulators::Accumulator& a = acc[i];
      if (a.numberOfShots >= 2) {
        const Float64 rawWeight = sqrt(a.sumOfIntegrandValueSquares/a.numberOfShots
          - pow(a.sumOfIntegrandValues/a.numberOfShots, 2));
        rawWeights[i] = rawWeight;
        sumOfWeightsFromAdaptation += rawWeight;
      }
      else {
        ++numberOfCellsNotAdapted;
      }
    }
    break;
  default:
    cerr << "error in getRawWeights(): invalid sampling type" << endl;
    terminate();
  }
  if (numberOfCellsNotAdapted > 0) {
    assert(numberOfCellsNotAdapted <= acc.size());
    if (acc.size() - numberOfCellsNotAdapted > 0) { 
      const Float64 average = sumOfWeightsFromAdaptation/(acc.size()-numberOfCellsNotAdapted);
      const int minimumHitsRequiredForAdaptation = (sampling == STRATIFIED) ? 2 : 1;
      for (Int64 i = 0; i < acc.size(); ++i) {
        if (acc[i].numberOfShots < minimumHitsRequiredForAdaptation)
          rawWeights[i] = average;
      }
    }
    else {
      if (sampling != NONE)
        cout << "warning: cannot adapt, continuing with flat weights" << endl;
      for (Int64 i = 0; i < acc.size(); ++i)
        rawWeights[i] = 1.0;
    }
  }
}

vector<Float64> getRawWeights(const Sampling sampling, const vector<Dvegas::CellAccumulators::Accumulator>& acc)
{
  vector<Float64> rawWeights(acc.size());
  getRawWeights(acc, rawWeights, sampling);
  return rawWeights;
}


// -----------------------

template<class C>
void smoothArray(const C& array, C& smoothedArray, const int numberOfAdjacentCellsToAverageOverInOneDimension = 3)
{
  assert(array.size() == smoothedArray.size());
  assert(&array != &smoothedArray);     // array and smoothedArray must be two different objects
  assert(numberOfAdjacentCellsToAverageOverInOneDimension % 2 == 1);     // odd number
  const typename C::difference_type numberOfAdjacentCellsToAverageOver =
    powInt(numberOfAdjacentCellsToAverageOverInOneDimension, array.dim());
  const typename C::difference_type maxOffset = numberOfAdjacentCellsToAverageOverInOneDimension/2;

  for (typename C::difference_type seqIdx = 0; seqIdx < array.size(); ++seqIdx) {
    typename C::value_type sum = 0.;
    typename C::difference_type numberOutOfBounds = 0;
    vector<int> centralCellIndexes = array.seqIdxToIndexes(seqIdx);
    assert(centralCellIndexes.size() == array.dim());
    for (int i = 0; i < numberOfAdjacentCellsToAverageOver; ++i) {
      vector<int> adjacentCellIndexes(array.dim());
      for (int d = 0, cnt = i; d < array.dim(); ++d) {
        adjacentCellIndexes[d] = (centralCellIndexes[d]-maxOffset)
          + cnt%numberOfAdjacentCellsToAverageOverInOneDimension;
        cnt /= numberOfAdjacentCellsToAverageOverInOneDimension;     // integer division
      }
      try {
        sum += array.at(adjacentCellIndexes);
      }
      catch (out_of_range) {
        ++numberOutOfBounds;
      }
    }
    assert(numberOutOfBounds < numberOfAdjacentCellsToAverageOver);
    smoothedArray[seqIdx] = sum/(numberOfAdjacentCellsToAverageOver - numberOutOfBounds);
  }
}

template void smoothArray< MultidimensionalArray<Float64> >(const MultidimensionalArray<Float64>&, MultidimensionalArray<Float64>&, const int);

MultidimensionalArray<Float64> smoothArray(const MultidimensionalArray<Float64>& array, const int numberOfAdjacentCellsToAverageOverInOneDimension)     // default avg = 3
{
  MultidimensionalArray<Float64> smoothedArray(array.dim(), array.length());
  smoothedArray.initialize();
  smoothArray< MultidimensionalArray<Float64> >(array, smoothedArray, numberOfAdjacentCellsToAverageOverInOneDimension);
  return smoothedArray;
}

//template void smoothArray< vector<Float64> >(const vector<Float64>&, vector<Float64>&, const int);

// simplify (specialize) for 1-dimensional array

template<>
void smoothArray< vector<Float64> >(const vector<Float64>& array, vector<Float64>& smoothedArray, const int numberOfAdjacentCellsToAverageOver)
{
  assert(array.size() == smoothedArray.size());
  assert(&array != &smoothedArray);     // array and smoothedArray must be two different objects
  assert(numberOfAdjacentCellsToAverageOver % 2 == 1);     // odd number
  const vector<Float64>::difference_type maxOffset = numberOfAdjacentCellsToAverageOver/2;
  
  for (vector<Float64>::difference_type seqIdx = 0; seqIdx < array.size(); ++seqIdx) {
    vector<Float64>::value_type sum = 0.;
    vector<Float64>::difference_type numberOutOfBounds = 0;
    for (vector<Float64>::difference_type avgIdx = seqIdx - maxOffset; avgIdx <= seqIdx + maxOffset; ++avgIdx) {
      try {
        sum += array.at(avgIdx);
      }
      catch (out_of_range) {
        ++numberOutOfBounds;
      }
    }
    assert(numberOutOfBounds < numberOfAdjacentCellsToAverageOver);
    smoothedArray[seqIdx] = sum/(numberOfAdjacentCellsToAverageOver - numberOutOfBounds);
  }
}

vector<Float64> smoothArray(const vector<Float64>& array, const int numberOfAdjacentCellsToAverageOver)     // default avg = 3
{
  vector<Float64> smoothedArray(array.size());
  smoothArray< vector<Float64> >(array, smoothedArray, numberOfAdjacentCellsToAverageOver);
  return smoothedArray;
}

// --------------------------------------------------------------

template<class C>
C& promoteSmallerWeights(const double curvature, const double rootAmpl, C& weights)
{
  typename C::value_type maxWeight = 0.0;
  for (typename C::difference_type i = 0; i < weights.size(); ++i) {
    const typename C::value_type& weight = weights[i];
    assert(weight >= 0.0);
    if (weight > maxWeight)
      maxWeight = weight;
  }
  assert(0.0 <= curvature && curvature <= 1.0 && 0.0 <= rootAmpl && rootAmpl <= 1.0);
  if (rootAmpl == 0.0) {     // fast since no implicit exp() or log()
    for (typename C::difference_type i = 0; i < weights.size(); ++i) {
      //weight = ( weight/maxWeight * (1.0 + curvature * (1.0 - weight/maxWeight)) ) * maxWeight;
      weights[i] *= 1.0 + curvature * (1.0 - weights[i]/maxWeight);
    }
  }
  else {
    for (typename C::difference_type i = 0; i < weights.size(); ++i) {
      typename C::value_type& weight = weights[i];
      weight = pow(weight/maxWeight*(1.0+curvature*(1.0-weight/maxWeight)), 1.0-rootAmpl)*maxWeight;
    }
  }
  /* Lepage's VEGAS:
  assert(0.0 <= rootAmpl <= 2.0);
  for (typename C::difference_type i = 0; i < weights.size(); ++i) {
    typename C::value_type& weight = weights[i];
    weight = pow((weight/maxWeight - 1.0)/log(weight/maxWeight), rootAmpl) * maxWeight;
  }
  */
  return weights;
}

template MultidimensionalArray<Float64>& promoteSmallerWeights< MultidimensionalArray<Float64> >(const double, const double, MultidimensionalArray<Float64>&);
template vector<Float64>& promoteSmallerWeights< vector<Float64> >(const double, const double, vector<Float64>&);

// --------------------------------------------------------------

template<class C>
const C& normalize(C& weights)
{
  typename C::value_type sumOfWeights = 0.0;
  for (typename C::difference_type i = 0; i < weights.size(); ++i) {
    const typename C::value_type& weight = weights[i];
    assert(weight >= 0.0);
    sumOfWeights += weight;
  }
  for (typename C::difference_type i = 0; i < weights.size(); ++i)
    weights[i] /= sumOfWeights;
  return weights;
}

template const MultidimensionalArray<Float64>& normalize< MultidimensionalArray<Float64> >(MultidimensionalArray<Float64>&);
template const vector<Float64>& normalize< vector<Float64> >(vector<Float64>&);

// --------------------------------------------------------------
// --------------------------------------------------------------
// --------------------------------------------------------------

void Dvegas::saveStateToFile(const string& filename) const     // default: filename = "dvegas.state"
{
  ofstream fout(filename.c_str());
  if (!fout) {
    cerr << "error: cannot open output file " << filename << endl;
    terminate();
  }
  saveStateToStream(fout);
}

void Dvegas::restoreStateFromFile(const string& filename)     // default: filename = "dvegas.state"
{
  ifstream fin(filename.c_str());
  if (!fin) {
    cerr << "error: cannot open input file " << filename << endl;
    terminate();
  }
  restoreStateFromStream(fin);
}

void Dvegas::restoreWeightsFromFile(const string& filename)     // default: filename = "dvegas.state"
{
  restoreStateFromFile(filename);
  resetEstimates();
}

void Dvegas::saveStateToStream(ostream& os) const
{
  os << setprecision(16);

  os << _sampling << csep;
  os << _cDim << csep;
  os << _cBin << csep;
  os << _corrDim << csep;
  os << _dDimSizes.size() << csep;
  for (int i = 0; i < _dDimSizes.size(); ++i)
    os << _dDimSizes[i] << csep;
  os << _aDim << csep;
  os << _f << csep;
  os << _curvature << csep;
  os << _rootAmpl << csep;

  const Integrand::Type itype =
    (_integrand) ? _integrand->type() : Integrand::NONE;
  os << itype << csep;
  if (_integrand)
    os << hasOmniHistoSuiteAttached() << csep;

  assert(_discDimWeights.size() == _dDimSizes.size());
  for (int i = 0; i < _discDimWeights.size(); ++i)
    _discDimWeights[i].toStream(os);
  assert(_contDimWeights.size() == _cDim);
  for (int i = 0; i < _contDimWeights.size(); ++i)
    _contDimWeights[i].toStream(os);
  os << _corrDimWeights.size() << csep;
  for (int i = 0; i < _corrDimWeights.size(); ++i)
    _corrDimWeights[i].toStream(os);
  assert(_allIterationsStats.size() == _f);
  for (int i = 0; i < _allIterationsStats.size(); ++i)
    _allIterationsStats[i].toStream(os);

  os << _detectCorrelations << csep;

  os << setprecision(16);     // reset to default
  os.flush();
}

void Dvegas::restoreStateFromStream(istream& is, const bool checkAndAttachNewHisto)
// default: checkAndAttachNewHisto = false
{
  _sampling = Sampling(getObj<int>(is));
  _cDim = getObj<int>(is);
  _cBin = getObj<int>(is);
  _corrDim = getObj<int>(is);
  _dDimSizes.resize(getObj<int>(is));
  for (int i = 0; i < _dDimSizes.size(); ++i)
    _dDimSizes[i] = getObj<int>(is);
  _aDim = getObj<int>(is);
  _f = getObj<int>(is);
  _curvature = getObj<double>(is);
  _rootAmpl = getObj<double>(is);

  delete _integrand;
  _integrand = Integrand::make(Integrand::Type(getObj<int>(is)));
  if (_integrand) {
    const bool hadOmniHistoSuiteAttached = getObj<bool>(is);
    if (checkAndAttachNewHisto && hadOmniHistoSuiteAttached)
      _integrand->createAndAttachEmptyOmniHistoSuite();
  }

  _discDimWeights.resize(_dDimSizes.size(), DiscreteWeights(1));
  for (int i = 0; i < _dDimSizes.size(); ++i)
    _discDimWeights[i].fromStream(is);
  _contDimWeights.resize(_cDim, ContinuousWeights(1));
  for (int i = 0; i < _cDim; ++i)
    _contDimWeights[i].fromStream(is);
  _corrDimWeights.resize(getObj<int>(is), CorrelatedWeights(0, 0));
  for (int i = 0; i < _corrDimWeights.size(); ++i)
    _corrDimWeights[i].fromStream(is);
  _allIterationsStats.resize(_f);
  for (int i = 0; i < _f; ++i)
    _allIterationsStats[i].fromStream(is);

  _detectCorrelations = getObj<bool>(is);
}

void Dvegas::restoreWeightsFromStream(istream& is)
{
  restoreStateFromStream(is);
  resetEstimates();  
}

const string Dvegas::saveStateToString() const
{
  ostringstream oss;
  saveStateToStream(oss);
  return oss.str();
}

void Dvegas::restoreStateFromString(const string& s, const bool checkAndAttachNewHisto)
// default: checkAndAttachNewHisto = false
{
  istringstream iss(s);
  restoreStateFromStream(iss, checkAndAttachNewHisto);
}

void Dvegas::restoreWeightsFromString(const string& s)
{
  restoreStateFromString(s);
  resetEstimates();
}

// --------------------------------------------------------------

// digital watermark with version information
void Dvegas::printVersion() const
{
  cout << "Dvegas version 2.1.0";
}

// --------------------------------------------------------------

void Dvegas::attachOmniHistoSuite(OmniHistoSuite *const omniHistoSuite)
{
  if (canAttachOmniHistoSuite()) {
    if (hasOmniHistoSuiteAttached())
      _integrand->detachOmniHistoSuite();
    _integrand->attachOmniHistoSuite(omniHistoSuite);
  }
  else {
    cerr << "error in Dvegas::attachOmniHistoSuite(): "
         << "integrand does not fill histograms" << endl;
    terminate();
  }
}

void Dvegas::detachOmniHistoSuite()
{
  if (hasOmniHistoSuiteAttached()) {
    _integrand->detachOmniHistoSuite();
  }
  else {
    cerr << "error in Dvegas::detachOmniHistoSuite(): no suite attached" << endl;
    terminate();
  }
}

// --------------------------------------------------------------

void Dvegas::activateCorrelationsDetector()
{
  if (_cDim >= 2) {
    _detectCorrelations = true;
  }
  else {
    _detectCorrelations = false;
    cout << "warning: correlations detector not activated: "
         << "cDim < 2, cDim = " << _cDim << endl;
  }
}

// --------------------------------------------------------------

void Dvegas::attachOmniComp(OmniComp *const omniComp)
{
  if (omniComp) {
    if (omniComp == _omniComp) {
      cerr << "error in Dvegas::attachOmniComp(): "
           << "OmniComp object already attached" << endl;
      terminate();
    }
    if (_omniComp)
      detachOmniComp();
    assert(_omniComp == 0);
    _omniComp = omniComp;
    if (_omniComp->dvegasPtr() != this)
      _omniComp->setDvegas(this);
  }
  else {
    cerr << "error in Dvegas::attachOmniComp(): "
         << "no OmniComp object to attach (NULL pointer)" << endl;
    terminate();
  }
}

void Dvegas::detachOmniComp()
{
  if (_omniComp) {
    _omniComp->setDvegas(0);
    _omniComp = 0;
  }
  else {
    cerr << "error in Dvegas::detachOmniComp(): no OmniComp object attached" << endl;
    terminate();
  }
}

// --------------------------------------------------------------

bool* Dvegas::abortLoopPtr = 0;

// --------------------------------------------------------------
// --------------------------------------------------------------
// --------------------------------------------------------------

void VEGAS(Dvegas& dvegas, const Int64 numberOfShots, const int numberOfIterations, const int init) // default: init = 0
{
  if (init != 2) {
    // discard data
    if (init == 0) {
      dvegas.reset();
    }
    else if (init == 1) {
      dvegas.resetEstimates();
    }
    else {
      cerr << "error: VEGAS(): invalid init:" << init << endl;
      terminate();
    }
  }
  
  for (int i = 0; i < numberOfIterations; ++i) {
    Dvegas::CellAccumulators cellAcc = dvegas.collectData(numberOfShots);
    dvegas.info();
    if (i < numberOfIterations - 1)
      dvegas.adaptWeights(cellAcc);
  }
  // diagnostics
  if (dvegas.chiSquarePerIteration(0) > 5.0) {
    cout << "WARNING: estimates are inconsistent, X^2/iter. >> 1: "
         << dvegas.chiSquarePerIteration(0) << endl;
  }
  else if (dvegas.isAdaptingContinuousDimensions() && init == 0 && numberOfIterations == 2) {
    cout << "NOTE: in rare cases errors can be seriously underestimated after 1st adaptation" << endl;
  }
}
}     // HepSource

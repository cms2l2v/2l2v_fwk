// Author: Nikolas Kauer <kauer@physik.uni-wuerzburg.de>

#include <iostream>
using std::ostream;
using std::istream;
using std::cerr;
#include <iomanip>
using std::endl;
using std::setprecision;
using std::setw;
#include <string>
using std::string;
using std::getline;
#include <cmath>
using std::fabs;
#include <cassert>
/* assert macro */
#include "histo.h"
#include "64bittypes.h"
#include "utilities.h"
#include "geometry.h"

const bool operator==(const EquiPartition& a, const EquiPartition& b)
{
  const Float64 eps = 1.e-13;
  bool isEqual = true;
  if (a.lowest() != 0. || b.lowest() != 0.) {
    isEqual = isEqual && fabs((a.lowest() - b.lowest())/min(a.lowest(), b.lowest())) < eps;
  }
  if (a.nextBeyondHighest() != 0. || b.nextBeyondHighest() != 0.) {
    isEqual = isEqual && fabs((a.nextBeyondHighest() - b.nextBeyondHighest())/min(a.nextBeyondHighest(), b.nextBeyondHighest())) < eps;
  }
  if (a.binSize() != 0. || b.binSize() != 0.) {
    isEqual = isEqual && fabs((a.binSize() - b.binSize())/min(a.binSize(), b.binSize())) < eps;
  }
  isEqual = isEqual && a.numberOfBins() == b.numberOfBins();
  return isEqual;
}

enum OutOfRange { HISTO_UNDERFLOW = -1, HISTO_OVERFLOW = -2 };  // all negative

// --------------------------------------------------------------

EquiPartition::EquiPartition(const Float64& lowest, const Float64& nextBeyondHighest, const Float64& binSize)
  : _lowest(lowest), _nextBeyondHighest(nextBeyondHighest), _binSize(binSize)
{
  const Float64 range = _nextBeyondHighest - _lowest;
  assert(range > 0.0);
  const int numberOfBins = int(double(range/_binSize) + 0.5);     // round
  const Float64 eps = 1.e-13;
  if (fabs(double(range - numberOfBins * _binSize)) > eps) {
    cerr << "error in EquiPartition::EquiPartition(): "
         << "range not integer multiple of binSize: " << range/_binSize << endl;
    terminate();
  }
  _numberOfBins = numberOfBins;
}

EquiPartition::~EquiPartition()
{}

const int EquiPartition::getIndex(const Float64& x) const
{
  if (x < _lowest) {
    return HISTO_UNDERFLOW;
  }
  else if (x >= _nextBeyondHighest) {
    return HISTO_OVERFLOW;
  }
  const int index = int( (x - _lowest)/_binSize );
  assert(0 <= index && index < _numberOfBins);
  return index;
}

void EquiPartition::toStream(ostream& os) const
{
  os << setprecision(16);
  os << _lowest << csep;
  os << _nextBeyondHighest << csep;
  os << _binSize << csep;
  os << _numberOfBins << csep;
}

void EquiPartition::fromStream(istream& is)
{
  _lowest = getObj<Float64>(is);
  _nextBeyondHighest = getObj<Float64>(is);
  _binSize = getObj<Float64>(is);
  _numberOfBins = getObj<int>(is);
}

// --------------------------------------------------------------

Bin::Bin()
  : sampleSet(), estimate(), _partialEstimate(0.), _varianceOfPartialEstimate(0.)
{}

void Bin::updateEstimate()
{
  estimate.addEstimate(sampleSet.getEstimate());
}

void Bin::updatePartialEstimate(const Int64 numberOfShots)
{
  const Estimate e = sampleSet.getEstimate(numberOfShots);
  _partialEstimate += e.estimate;
  _varianceOfPartialEstimate += e.variance;
}

void Bin::updateEstimateWithPartialEstimate()
{
  estimate.addEstimate(Estimate(_partialEstimate, _varianceOfPartialEstimate));
  _partialEstimate = 0.0;
  _varianceOfPartialEstimate = 0.0;
}

void Bin::toStream(ostream& os) const
{
  sampleSet.toStream(os);
  const bool haveEstimate_ = haveEstimate();
  os << haveEstimate_ << csep;
  if (haveEstimate_)
    estimate.toStream(os);
}

void Bin::fromStream(istream& is)
{
  sampleSet.fromStream(is);
  assert(!haveEstimate());
  const bool hasEstimate = getObj<bool>(is);
  if (hasEstimate)
    estimate.fromStream(is);
}

Bin& Bin::operator+=(const Bin& partial)
{
  sampleSet += partial.sampleSet;
  if (partial.haveEstimate())
    estimate += partial.estimate;
  return *this;
}

// --------------------------------------------------------------

Histo::Histo(const string& name, const Float64& lowest, const Float64& nextBeyondHighest, const Float64& binSize, const bool simpleOutOfRange)     // default: binSize = Float64(1), simpleOutOfRange = false
  : _name(name), _partition(lowest, nextBeyondHighest, binSize),
    _simpleOutOfRange(simpleOutOfRange), _sumOfOutOfRangeWeights(0.0)
{
  _bins.assign(_partition.numberOfBins(), Bin());
}

Histo::~Histo()
{}

void Histo::fill(const Float64& x, const Float64& y, const Float64& weight)
// default: weight = 1.0
{
  const int index = _partition.getIndex(x);
  if (index >= 0) {
    _bins[index].sampleSet.addSample(y, weight);
  }
  else if (_simpleOutOfRange) {
    _sumOfOutOfRangeWeights += weight;
  }
  else if (index == HISTO_UNDERFLOW) {
    _underflow.sampleSet.addSample(y, weight);
  }
  else if (index == HISTO_OVERFLOW) {
    _overflow.sampleSet.addSample(y, weight);
  }
  else {
    cerr << "error in Histo::fill(): invalid index: " << index << endl;
    terminate();
  }
}

void Histo::updateEstimates()
{
  for (int i = 0; i < _bins.size(); ++i)
    _bins[i].updateEstimate();
  if (!simpleOutOfRange()) {
    _underflow.updateEstimate();
    _overflow.updateEstimate();
  }
}

void Histo::updatePartialEstimates(const Int64 numberOfShots)
{
  for (int i = 0; i < _bins.size(); ++i)
    _bins[i].updatePartialEstimate(numberOfShots);
  if (!simpleOutOfRange()) {
    _underflow.updatePartialEstimate(numberOfShots);
    _overflow.updatePartialEstimate(numberOfShots);
  }
}

void Histo::updateEstimatesWithPartialEstimates()
{
  for (int i = 0; i < _bins.size(); ++i)
    _bins[i].updateEstimateWithPartialEstimate();
  if (!simpleOutOfRange()) {
    _underflow.updateEstimateWithPartialEstimate();
    _overflow.updateEstimateWithPartialEstimate();
  }  
}

void Histo::print(ostream& os) const
{
  os << setprecision(16);
  os << "============================================================" << endl;
  os << "title: " << name() << endl;
  os << "# equi-partition (lowest, next beyond highest, bin size, number of bins)" << endl;
  os << "partition: "
     << _partition.lowest() << " "
     << _partition.nextBeyondHighest() << " "
     << _partition.binSize() << " "
     << _partition.numberOfBins() << endl;
  os << "# in-range bins (index, density, error, chi^2/iteration)" << endl;
  for (int i = 0; i < _bins.size(); ++i) {
    os << setw(3) << i+1 << " "
       << _bins[i].estimate.estimate() << " "
       << setprecision(2)
       << _bins[i].estimate.standardDeviation() << " "
       << _bins[i].estimate.chiSquarePerEstimate()
       << setprecision(16) << endl;
  }
  if (_simpleOutOfRange) {
    os << "sum of out-of-range weights: " << _sumOfOutOfRangeWeights << endl;
  }
  else {
    os << "# out-of-range bins (density, error, chi^2/iteration)" << endl;
    os << "underflow: "
       << _underflow.estimate.estimate() << " "
       << setprecision(2)
       << _underflow.estimate.standardDeviation() << " "
       << _underflow.estimate.chiSquarePerEstimate()
       << setprecision(16) << endl;
    os << "overflow : "
       << _overflow.estimate.estimate() << " "
       << setprecision(2)
       << _overflow.estimate.standardDeviation() << " "
       << _overflow.estimate.chiSquarePerEstimate()
       << setprecision(16) << endl;
  }
  os << "============================================================" << endl;
}

void Histo::toStream(ostream& os) const
{
  os << _name << csep;
  _partition.toStream(os);
  assert(_bins.size() == _partition.numberOfBins());
  for (int i = 0; i < _bins.size(); ++i)
    _bins[i].toStream(os);
  os << _simpleOutOfRange << csep;
  if (_simpleOutOfRange) {
    os << _sumOfOutOfRangeWeights << csep;
  }
  else {
    _underflow.toStream(os);
    _overflow.toStream(os);
  }
}

void Histo::fromStream(istream& is)
{
  do {     // remove leading whitespace (e.g. due to csep)
    getline(is, _name);
  } while (_name.empty());
  _partition.fromStream(is);
  _bins.resize(_partition.numberOfBins());
  for (int i = 0; i < _bins.size(); ++i)
    _bins[i].fromStream(is);
  _simpleOutOfRange = getObj<bool>(is);
  if (_simpleOutOfRange) {
    _sumOfOutOfRangeWeights = getObj<Float64>(is);
  }
  else {
    _underflow.fromStream(is);
    _overflow.fromStream(is);
  }
}

Histo& Histo::operator+=(const Histo& partial)
{
  assert(_name == partial._name);
  assert(_partition == partial._partition);
  assert(_bins.size() == partial._bins.size());
  for (int i = 0; i < _bins.size(); ++i)
    _bins[i] += partial._bins[i];
  assert(_simpleOutOfRange == partial._simpleOutOfRange);
  if (_simpleOutOfRange) {
    _sumOfOutOfRangeWeights += partial._sumOfOutOfRangeWeights;
  }
  else {
    _underflow += partial._underflow;
    _overflow += partial._overflow;
  }
  return *this;
}

// Author: Nikolas Kauer <kauer@physik.uni-wuerzburg.de>

#include <iostream>
using std::cout;
using std::cerr;
#include <fstream>
using std::ofstream;
using std::ifstream;
#include <ios>
using std::ios_base;
#include <sstream>
using std::ostringstream;
using std::istringstream;
#include <iomanip>
using std::endl;
using std::setw;
using std::setprecision;
using std::fixed;
#include <string>
using std::string;
using std::getline;
#include <vector>
using std::vector;
#include <list>
using std::list;
#include <algorithm>
using std::find;
#include <stdexcept>
using std::bad_alloc;
#include <cassert>
/* assert macro */
#include <ctime>
using std::time_t;
using std::time;
using std::difftime;
#include <cmath>
using std::sin;
#include "dvegas.h"
#include "omnicomp.h"
#include "rng.h"
#include "utilities.h"
#include "maxeventweightestimate.h"
#include <omniORB4/omniURI.h>   /* nameToString(), should be CosNaming::NamingContextExt::to_string() */
#include <unistd.h>
/* sleep(seconds) */

namespace HepSource
{
namespace OmniCompImplementation
{
void terminate(CORBA::ORB_ptr orb)
{
  orb->destroy();
  ::terminate();
}

const string directorySeparator = "/";     // operating system specific

// email address used as unique id for omniNames (option -n)
const string userId = "nkauer@users.sourceforge.net";

// --------------------------------------------------------------

class ExecutableInfo
{
public:
  ExecutableInfo(const string& argv_0);
  const string loc() const;
  const string path() const;
  const string name() const;
private:
  string _loc;      // location: path and name
  string _path;     // path to executable, excluding last slash
  string _name;     // path-stripped executable name
};

inline const string ExecutableInfo::loc() const { return _loc; }

inline const string ExecutableInfo::path() const { return _path; }

inline const string ExecutableInfo::name() const { return _name; }

ExecutableInfo::ExecutableInfo(const string& argv_0)
  : _loc(argv_0)
{
  string::size_type lastSepIdx = argv_0.rfind(directorySeparator);
  _path = (lastSepIdx != string::npos) ? argv_0.substr(0, lastSepIdx+1) : "";
  _name = argv_0.substr(lastSepIdx+1, string::npos);
}

// --------------------------------------------------------------

class Options
{
public:
  Options(int argc, char* argv[]);
  const bool have(const string& arg) const;
  const bool haveNot(const string& arg) const;
  const bool valid(const list<string>& knownArgs) const;
  const double getSpeed() const;
private:
  list<string> _args;
  double _speed;
};

inline const bool Options::have(const string& arg) const { return !haveNot(arg); }

inline const double Options::getSpeed() const { return _speed; }

Options::Options(int argc, char* argv[])
  : _speed(1.)
{
  if (argc > 1) {
    for (int i = 1; i < argc; ++i) {
      const string arg(argv[i]);
      if (arg.substr(0,2) == "-s") {
	assert(arg.size() > 2);     // blank(s) between "-s" and <speed> not supported
	istringstream is(arg.substr(2, string::npos));
	_speed = getObj<double>(is);
	assert(_speed > 1.);   // processor clock speed [MHz], e.g. from /proc/cpuinfo
      }
      else {
	_args.push_back(arg);
      }
    }
    // remove duplicates
    _args.sort();
    _args.unique();
  }
}

const bool Options::haveNot(const string& arg) const
{
  list<string>::const_iterator it = find(_args.begin(), _args.end(), arg);
  return (it == _args.end());
}

const bool Options::valid(const list<string>& knownArgs) const
{
  list<string>::const_iterator argsIt = _args.begin();
  while (argsIt != _args.end()) {
    list<string>::const_iterator knownArgsIt =
      find(knownArgs.begin(), knownArgs.end(), *argsIt);
    if (knownArgsIt == knownArgs.end())
      return false;
    ++argsIt;
  }
  return true;
}

// --------------------------------------------------------------
// --------------------------------------------------------------
// --------------------------------------------------------------

class Names
{
public:
  Names(CORBA::ORB_ptr orb, const string& userId, const string& jobId, const string& exeName);
  void bindWorker(const CORBA::Object_ptr workerRef);
  void findAndAppendBoundWorkers(vector<OmniWorker_var>& workerRefs);
  void removeBindings();
private:
  CORBA::ORB_ptr _orb;
  const string _exeName;
  CosNaming::NamingContext_var _rootContext;
  CosNaming::Name _userName;
  CosNaming::NamingContext_var _userContext;
  CosNaming::Name _jobName;
  CosNaming::NamingContext_var _jobContext;

  CosNaming::NamingContext_var bindOrResolveContext(
    CosNaming::NamingContext_ptr parent, CosNaming::Name childName);
};

Names::Names(CORBA::ORB_ptr orb, const string& userId, const string& jobId, const string& exeName)
  : _orb(orb), _exeName(exeName)
{
  try {
    CORBA::Object_var obj = _orb->resolve_initial_references("NameService");
    _rootContext = CosNaming::NamingContext::_narrow(obj);
    if (CORBA::is_nil(_rootContext)) {
      cerr << _exeName << ": failed to narrow the root naming context" << endl;
      terminate(_orb);
    }
  }
  catch (CORBA::ORB::InvalidName& ex) {
    cerr << _exeName << ": CORBA::ORB::InvalidName [no NameService]" << endl;
    terminate(_orb);
  }

  _userName.length(1);
  _userName[0].id = CORBA::string_dup(userId.c_str());
  _userContext = bindOrResolveContext(_rootContext, _userName);
  
  _jobName.length(1);
  _jobName[0].id = CORBA::string_dup(jobId.c_str());
  _jobContext = bindOrResolveContext(_userContext, _jobName);
}

// helper ----------------
const string intTostring(const int i)
{
  ostringstream a;
  a << i;
  return a.str();
}

char* stringToString_var(const string& s)
{
  CORBA::String_var svar = CORBA::string_alloc(s.length());
  assert(svar != 0);     // allocation succeeded
  s.copy(svar, string::npos);
  svar[s.length()] = 0;     // add terminator
  return svar._retn();      // yields ownership of memory
}
// usage: CORBA::String_var svar = stringToString_var(s);

char* intToString_var(const int i)
{
  return stringToString_var(intTostring(i));
}
// usage: CORBA::String_var svar = intToString_var(i);
// -----------------------

void Names::bindWorker(const CORBA::Object_ptr objref)
{
  CosNaming::Name objectName;
  objectName.length(1);
  int objId = 0;     // 0, 1, 2, 3, ...
  while (true) {
    objectName[0].id = intToString_var(objId);
    try {
      _jobContext->bind(objectName, objref);
      cout << "OmniComp: bound worker with id " << objId << endl;
      break;
    }
    catch (CosNaming::NamingContext::AlreadyBound& ex) {
      ++objId;
    }
    catch (...) {
      cerr << _exeName << ": error in Names::bindWorker()" << endl;
      terminate(_orb);
    }
  }
}

void Names::findAndAppendBoundWorkers(vector<OmniWorker_var>& workerRefs)
{
  CosNaming::Name objectName;
  objectName.length(1);
  int objId = 0;     // 0, 1, 2, 3, ...
  while (true) {
    objectName[0].id = intToString_var(objId);
    try {
      CORBA::Object_var obj = _jobContext->resolve(objectName);
      OmniWorker_var workerRef = OmniWorker::_narrow(obj);
      if (CORBA::is_nil(workerRef)) {
        cerr << _exeName << ": can't narrow a reference to type OmniWorker "
             << "(or it was nil)" << endl;
        terminate(_orb);
      }
      else {
        workerRefs.push_back(workerRef);
      }
      ++objId;
    }
    catch (CosNaming::NamingContext::NotFound& ex) {
      break;
    }
    catch (...) {
      cerr << _exeName << ": error in Names::findAndAppendBoundWorkers()" << endl;
      terminate(_orb);
    }
  }
}

void Names::removeBindings()
{
  CosNaming::Name objectName;
  objectName.length(1);
  int objId = 0;     // 0, 1, 2, 3, ...
  while (true) {
    objectName[0].id = intToString_var(objId);
    try {
      _jobContext->unbind(objectName);
      cout << "OmniComp: unbound worker with id " << objId << endl;
      ++objId;
    }
    catch (CosNaming::NamingContext::NotFound& ex) {
      break;
    }
    catch (...) {
      cerr << _exeName << ": error in Names::removeBindings()" << endl;
      terminate(_orb);
    }
  }

  // delete job context
  try {
    _jobContext->destroy();
    _userContext->unbind(_jobName);
    cout << "OmniComp: deleted job context" << endl;
  }
  catch (CosNaming::NamingContext::NotEmpty& ex) {
    cerr << _exeName << ": cannot delete non-empty job context "
         << "[worker(s) with discontinuous id?]" << endl;
    terminate(_orb);
  }

  // delete user context
  try {
    _userContext->destroy();
    _rootContext->unbind(_userName);
    cout << "OmniComp: deleted user context" << endl;
  }
  catch (CosNaming::NamingContext::NotEmpty& ex) {
    cout << "OmniComp: user context not empty (not deleted)" << endl;
  }
}

CosNaming::NamingContext_var Names::bindOrResolveContext(
  CosNaming::NamingContext_ptr parent, CosNaming::Name childName)
{
  CosNaming::NamingContext_var child;
  try {
    child = parent->bind_new_context(childName);
  }
  catch (CosNaming::NamingContext::AlreadyBound& ex) {
    CORBA::Object_var obj = parent->resolve(childName);
    child = CosNaming::NamingContext::_narrow(obj);
    if (CORBA::is_nil(child)) {
      cerr << _exeName << ": failed to narrow naming context: "
           << omni::omniURI::nameToString(childName) << endl;
      terminate(_orb);
    }
  }
  return child._retn();
}

// --------------------------------------------------------------
// --------------------------------------------------------------
// --------------------------------------------------------------

// OmniWorker object implementation.

class OmniWorker_i : public POA_OmniWorker, public PortableServer::RefCountServantBase
{
public:
  OmniWorker_i(OmniComp *const omniComp);
  virtual ~OmniWorker_i();

  // CORBA interface
  virtual void initialize(CORBA::Short id, OmniProgressOutput_ptr outputRef);
  virtual CORBA::Boolean acceptingComputations();
  virtual CORBA::LongLong currentSpeed();
  virtual void startComputation(const OmniParameters& parameters, const char* dvegasState);
  virtual CORBA::Boolean haveResults();
  virtual char* getResults();
  virtual void shutdown();

  const bool isInitialized() const;
  const CORBA::Boolean processingJob();
  const bool computationPending();
  const bool shutdownRequested() const;
private:
  CORBA::Boolean _acceptingComputations;
  bool _isInitialized;
  bool _shutdownRequested;

  OmniComp *const _omniComp;
private:     // prevent copy construction and assignment
  OmniWorker_i(const OmniWorker_i&);
  OmniWorker_i& operator=(const OmniWorker_i&);
};

inline const bool OmniWorker_i::isInitialized() const { return _isInitialized; }

inline const CORBA::Boolean OmniWorker_i::processingJob() { return !acceptingComputations(); }

inline const bool OmniWorker_i::computationPending() { return processingJob() && !haveResults(); }

inline const bool OmniWorker_i::shutdownRequested() const { return _shutdownRequested; }

OmniWorker_i::OmniWorker_i(OmniComp *const omniComp)
  : _acceptingComputations(false), _isInitialized(false), _shutdownRequested(false),
    _omniComp(omniComp)
{}

OmniWorker_i::~OmniWorker_i()
{}

void OmniWorker_i::initialize(CORBA::Short id, OmniProgressOutput_ptr outputRef)
{
  assert(id >= 0);
  _omniComp->setWorkerId(id);
  randomNumberGenerator->varySeedToGetIndependentRandomNumberStreams(id);
  if (CORBA::is_nil(_omniComp->outputRef())) {
    if (!CORBA::is_nil(outputRef)) {
      _omniComp->setOutputRef(outputRef);
    }
    else {
      cerr << "OmniWorker_i::setOutput(): warning: reference is nil" << endl;
      // should throw user exception here
    }
  }

  _isInitialized = true;
  _acceptingComputations = true;
}

CORBA::Boolean OmniWorker_i::acceptingComputations()
{
  return _acceptingComputations;
}

CORBA::LongLong OmniWorker_i::currentSpeed()
{
  return CORBA::LongLong(_omniComp->getSpeed());
}

void OmniWorker_i::startComputation(const OmniParameters& parameters, const char* dvegasState)
{
  assert(acceptingComputations());
  _acceptingComputations = false;
  _omniComp->setupComputation(parameters, dvegasState);
  assert(!haveResults());
}

CORBA::Boolean OmniWorker_i::haveResults()
{
  return _omniComp->resultsPtr() != 0;
}

char* OmniWorker_i::getResults()
{
  assert(haveResults());
  if (!acceptingComputations())
    _acceptingComputations = true;
  return stringToString_var(*_omniComp->resultsPtr());
}

void OmniWorker_i::shutdown()
{
  _shutdownRequested = true;
}

// --------------------------------------------------------------

// OmniProgressOutput object implementation.

class OmniProgressOutput_i : public POA_OmniProgressOutput, public PortableServer::RefCountServantBase
{
public:
  OmniProgressOutput_i();
  virtual ~OmniProgressOutput_i();

  // CORBA interface
  virtual void updateProgressOutput(CORBA::Short id, CORBA::Float fractionComputed);

  void start();
  void finalize();
private:
  map<int, CORBA::Float> _fractions;
  void printOutput();
  const bool _overwrite;
  int _lengthOfMostRecentOutput;
};

OmniProgressOutput_i::OmniProgressOutput_i()
  : _overwrite(true)
{}

OmniProgressOutput_i::~OmniProgressOutput_i()
{}

void OmniProgressOutput_i::updateProgressOutput(CORBA::Short id, CORBA::Float fractionComputed)
{
  _fractions[id] = fractionComputed;
  printOutput();
}

void OmniProgressOutput_i::start()
{
  _fractions.clear();
  cout << "work done so far ..." << endl;
  _lengthOfMostRecentOutput = 0;
}

void OmniProgressOutput_i::finalize()
{
  cout << endl;
  _lengthOfMostRecentOutput = 0;
}

void OmniProgressOutput_i::printOutput()
{
  if (_overwrite && _lengthOfMostRecentOutput != 0) {
    cout << string(_lengthOfMostRecentOutput, '\b');
  }
  else if (!_overwrite && _lengthOfMostRecentOutput != 0) {
    cout << endl;
  }
  const int fieldLength = 5;
  int counter = 0;
  for (map<int, CORBA::Float>::const_iterator it = _fractions.begin();
       it != _fractions.end(); ++it) {
    ++counter;
    while (it->first > counter - 1) {
      cout << string(fieldLength, ' ');
      ++counter;
    }
    cout << fixed << setprecision(0) << setw(3) << it->second * 100 << "% ";
    cout << setprecision(16);     // reset setprecision to default
    cout.setf(ios_base::fmtflags(0), ios_base::floatfield);   // reset fixed to default
  }
  if (counter > 0) _lengthOfMostRecentOutput = counter * fieldLength;
  cout.flush();
}
}     // OmniCompImplementation

// --------------------------------------------------------------
// --------------------------------------------------------------
// --------------------------------------------------------------

using namespace OmniCompImplementation;

#define CATCH_CORBA_AND_OTHER_EXCEPTIONS_MACRO \
catch (...) { \
  try { \
    throw; \
  } \
  catch (CORBA::COMM_FAILURE& ex) { \
    cerr << exeInfo()->name() << ": COMM_FAILURE, unable to contact the object" << endl; \
  } \
  catch (CORBA::SystemException&) { \
    cerr << exeInfo()->name() << ": CORBA::SystemException" << endl; \
  } \
  catch (CORBA::Exception&) { \
    cerr << exeInfo()->name() << ": CORBA::Exception" << endl; \
  } \
  catch (omniORB::fatalException& fe) { \
    cerr << exeInfo()->name() << ": omniORB::fatalException:" << endl; \
    cerr << "  file: " << fe.file() << endl; \
    cerr << "  line: " << fe.line() << endl; \
    cerr << "  mesg: " << fe.errmsg() << endl; \
  } \
  catch (...) { \
    cerr << exeInfo()->name() << ": unknown exception" << endl; \
  } \
  terminate(_orb); \
}

OmniComp::OmniComp(int argc, char* argv[])
  : _exeInfo(new ExecutableInfo(argv[0])), _speed(0.), _names(0), _localWorker(0),
    _workerId(0), _output(0), _dvegas(0), _numberOfShots(0),
    _results(new string("initialized to dummy string"))
{
  try {
    _orb = CORBA::ORB_init(argc, argv, "omniORB4");    // strips ORB args
    processCLOptionsAndInitRegistryAndOutputAndWorker(argc, argv);
 
    if (isMaster()) {
      cout << exeInfo()->name() << ": OmniComp master process started"
           << (hasWorker() ? " (includes 1 worker)" : "") << endl;
      resolveWorkerRefs();
      for (CORBA::Short i = 0; i < numberOfWorkers(); ++i)
        _workerRefs[i]->initialize(i, _outputRef);
    }
    else {
      cout << exeInfo()->name() << ": OmniComp worker process started" << endl;
      readEvalPrintLoop();
      terminate(_orb);
    }
  }
  CATCH_CORBA_AND_OTHER_EXCEPTIONS_MACRO
}

OmniComp::~OmniComp()
{
  try {
    if (isMaster()) {
      for (CORBA::Short i = 0; i < numberOfWorkers(); ++i)
        _workerRefs[i]->shutdown();
      if (_names) {
        _names->removeBindings();     // clean up omniNames registry
      }
      else {
        ofstream dummy(iorFileName().c_str(), ios_base::trunc);   // delete IOR strings
      }
    }
    else {
      delete _dvegas;
    }
    delete _results;
    delete _names;
    delete _exeInfo;
    _orb->destroy();
  }
  CATCH_CORBA_AND_OTHER_EXCEPTIONS_MACRO
}

const list<string> OmniComp::distributeComputations(const OmniParameters& parameters,
  const string& dvegasState)
{
  assert(isMaster());
  list<string> partialResults;
  try {
    vector<Int64> workerNumberOfShots(numberOfWorkers());
    if (numberOfWorkers() == 1) {
      workerNumberOfShots[0] = parameters.numberOfShots;
    }
    else {
      const Int64 totalNumberOfShots = parameters.numberOfShots;
      vector<Int64> workerSpeeds(numberOfWorkers());
      Int64 sumOfSpeeds = 0;
      cout << "determining current worker speeds ";
      cout.flush();
      bool haveNotSetSpeed = false;
      for (CORBA::Short i = 0; i < numberOfWorkers(); ++i) {
        cout << '.';
        cout.flush();
        workerSpeeds[i] = _workerRefs[i]->currentSpeed();
	if (workerSpeeds[i] == 1.)
	  haveNotSetSpeed = true;
        sumOfSpeeds += workerSpeeds[i];
      }
      cout << " done" << endl;
      if (haveNotSetSpeed && sumOfSpeeds > numberOfWorkers())
	fatal_error("clock speed specified for some but not all workers");
      Int64 sumSoFar = 0;
      for (CORBA::Short i = 0; i < numberOfWorkers() - 1; ++i) {
        workerNumberOfShots[i] =
          Int64(double(workerSpeeds[i])/sumOfSpeeds * totalNumberOfShots);
        sumSoFar += workerNumberOfShots[i];
      }
      workerNumberOfShots[numberOfWorkers() - 1] = totalNumberOfShots - sumSoFar;
    }

    output()->start();

    list<int> unfinishedWorkers;
    OmniParameters workerParameters = parameters;
    for (CORBA::Short i = 0; i < numberOfWorkers(); ++i) {
      assert(_workerRefs[i]->acceptingComputations());
      workerParameters.numberOfShots = workerNumberOfShots[i];
      _workerRefs[i]->startComputation(workerParameters, dvegasState.c_str());
      unfinishedWorkers.push_back(i);
    }

    while (unfinishedWorkers.size() > 0) {
      if (hasWorker()) {
        if (_localWorker->isInitialized() && _localWorker->computationPending())
          performComputation();
      }
      else {
        sleep(5);     // optional (not C++ standard-compliant)
      }
      tendToOrbWork();
      for (list<int>::iterator it = unfinishedWorkers.begin();
           it != unfinishedWorkers.end(); ) {
        if (_workerRefs[*it]->haveResults())
          it = unfinishedWorkers.erase(it);
        else
          ++it;
      }
    }

    output()->finalize();

    for (CORBA::Short i = 0; i < numberOfWorkers(); ++i) {
      CORBA::String_var partialResult = _workerRefs[i]->getResults();
      partialResults.push_back(partialResult.in());
    }
  }
  CATCH_CORBA_AND_OTHER_EXCEPTIONS_MACRO
  return partialResults;
}

void OmniComp::tendToOrbWork() const
{
  if (_orb->work_pending())
    _orb->perform_work();
}

void OmniComp::processCLOptionsAndInitRegistryAndOutputAndWorker(int argc, char* argv[])
{
  try {
    Options options(argc, argv);
    list<string> validOptions;
    validOptions.push_back("-w");
    validOptions.push_back("-d");
    validOptions.push_back("-m");
    validOptions.push_back("-n");
    _speed = options.getSpeed();     // special treatment: option "-s<speed>"

    if (!options.valid(validOptions)) {
      cerr << exeInfo()->name() << ": invalid option specified" << endl;
      cerr << "valid options:" << endl;
      list<string>::iterator it = validOptions.begin();
      while (it != validOptions.end()) {
        cerr << *it << endl;
        ++it;
      }
      terminate(_orb);
    }
    if (options.have("-w") && options.have("-m")) {
      cerr << exeInfo()->name() << ": invalid options: -w and -m are exclusive"
           << endl;
      terminate(_orb);
    }

    _isMaster = options.haveNot("-w");

    // setup worker registry
    const string exeInfoNameTrunc =
      exeInfo()->name().substr(0, exeInfo()->name().find('.'));
    const string jobId = (options.have("-d")) ? exeInfoNameTrunc : exeInfo()->name();
    _iorFileName = exeInfo()->path() + jobId + ".workers";
    if (options.have("-n"))
      _names = new Names(_orb, userId, jobId, exeInfo()->name());

    // create servants (are deleted automatically)
    if (options.have("-w") || options.haveNot("-m")) {
      _localWorker = new OmniWorker_i(this);
      assert(hasWorker());
    }
    if (isMaster())
      _output = new OmniProgressOutput_i();

    createCORBAObjectsWithServants();
    if (hasWorker() && !isMaster())
      registerLocalWorker();
  }
  CATCH_CORBA_AND_OTHER_EXCEPTIONS_MACRO
}

void OmniComp::createCORBAObjectsWithServants()
{
  try {
    CORBA::Object_var obj = _orb->resolve_initial_references("RootPOA");
    PortableServer::POA_var poa = PortableServer::POA::_narrow(obj);
    if (_localWorker != 0) {
      poa->activate_object(_localWorker);
      _localWorkerRef = _localWorker->_this();     // obtain reference
      _localWorker->_remove_ref();     // POA now owns _localWorker object
    }
    if (_output != 0) {
      poa->activate_object(_output);
      _outputRef = _output->_this();
      _output->_remove_ref();
    }
    PortableServer::POAManager_var pman = poa->the_POAManager();
    pman->activate();     // POA starts accepting requests on its objects
  }
  CATCH_CORBA_AND_OTHER_EXCEPTIONS_MACRO
}

void OmniComp::registerLocalWorker() const
{
  try {
    if (_names) {     // with naming service
      _names->bindWorker(_localWorkerRef);
    }
    else {            // append stringified IOR to file
      CORBA::String_var iorString = _orb->object_to_string(_localWorkerRef);
      ofstream iorFile(iorFileName().c_str(), ios_base::app);
      if (!iorFile) {
        cerr << exeInfo()->name() << ": cannot open file "
             << "\"" << iorFileName() << "\"" << endl;
        terminate(_orb);
      }
      iorFile << iorString << endl;
    }
  }
  CATCH_CORBA_AND_OTHER_EXCEPTIONS_MACRO
}

void OmniComp::resolveWorkerRefs()
{
  try {
    // get external worker obj refs
    if (_names) {
      _names->findAndAppendBoundWorkers(_workerRefs);
    }
    else {     // via IOR strings from file
      ifstream iorFile(iorFileName().c_str());
      while (iorFile) {
        string iorString;
        iorFile >> iorString;
        if (!iorString.empty()) {
          CORBA::Object_var obj = _orb->string_to_object(iorString.c_str());
          OmniWorker_var workerRef = OmniWorker::_narrow(obj);
          if (CORBA::is_nil(workerRef)) {
            cerr << exeInfo()->name() << ": can't narrow a reference to type "
                 << "OmniWorker (or it was nil)" << endl;
            terminate(_orb);
          }
          else {
            _workerRefs.push_back(workerRef);
          }
        }
      }
    }
    // report about externals
    const string additional = hasWorker() ? "additional " : "";
    if (numberOfWorkers() == 0)
      cout << "no " << additional << "workers found" << endl;
    else
      cout << numberOfWorkers() << " " << additional << "worker(s) found" << endl;
    // append local worker obj
    if (hasWorker())
      _workerRefs.push_back(_localWorkerRef);
    if (numberOfWorkers() == 0) {
      cerr << exeInfo()->name() << ": no workers found" << endl;
      terminate(_orb);
    }
  }
  CATCH_CORBA_AND_OTHER_EXCEPTIONS_MACRO
}

// --------------------------------------------------------------

void OmniComp::setupComputation(const OmniParameters& parameters, const char* dvegasState)
{
  if (!isMaster()) {
    if (_dvegas != 0 && _dvegas->hasOmniHistoSuiteAttached())
      delete _dvegas->omniHistoSuite();     // delete worker histos attached below
    delete _dvegas;
    _dvegas = new Dvegas();
    _dvegas->restoreStateFromString(dvegasState, true);     //checkAndAttachNewHisto[s]
    _dvegas->attachOmniComp(this);
    MaxEventWeightEstimate::value = 0.;
  }

  _numberOfShots = parameters.numberOfShots;
  if (parameters.haveCorrelationsDetector)
    _dvegas->activateCorrelationsDetector();

  delete _results;
  _results = 0;
}

void OmniComp::readEvalPrintLoop()
{
  assert(hasWorker());
  while (true) {
    tendToOrbWork();
    if (_localWorker->isInitialized() && _localWorker->computationPending())
      performComputation();
    if (_localWorker->shutdownRequested() && !_localWorker->processingJob())
      return;
    sleep(5);     // optional (not C++ standard-compliant)
  }
}

void OmniComp::performComputation()
{
  assert(_localWorker->isInitialized() && _localWorker->computationPending());

  const Dvegas::AccPtrs accPtrs = _dvegas->evaluateIntegrand(_numberOfShots, false);

  ostringstream resultsStream;
  resultsStream << setprecision(16);
  accPtrs.toStream(resultsStream);
  if (MaxEventWeightEstimate::value > 0.) {
    const bool haveMaxEventWeightEstimateToTransmit = true;
    resultsStream << haveMaxEventWeightEstimateToTransmit << csep;
    resultsStream << MaxEventWeightEstimate::value << csep;
  }
  else {
    const bool haveMaxEventWeightEstimateToTransmit = false;
    resultsStream << haveMaxEventWeightEstimateToTransmit << csep;
  }
  const bool haveExternalHistoSuiteResultsToTransmit =
    _dvegas->hasOmniHistoSuiteAttached() && !isMaster();
  resultsStream << haveExternalHistoSuiteResultsToTransmit << csep;
  if (haveExternalHistoSuiteResultsToTransmit)
    _dvegas->omniHistoSuite()->toStream(resultsStream);
  resultsStream.flush();

  assert(!_localWorker->haveResults());
  _results = new string(resultsStream.str());
  accPtrs.deleteAcc();

  assert(_localWorker->haveResults());
}
}     // HepSource

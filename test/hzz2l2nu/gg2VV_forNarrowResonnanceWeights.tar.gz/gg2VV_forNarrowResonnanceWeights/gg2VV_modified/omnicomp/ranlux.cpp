// http://sources.redhat.com/gsl/ref/gsl-ref_17.html#SEC253

#include <cassert>
/* assert macro */

#include "rng.h"
#include "gsl_ranlux.h"

#include "settings.h"
/* seedForRandomNumberGenerator */

class GSLRandomNumberGenerator : public RandomNumberGenerator
{
public:
  GSLRandomNumberGenerator(gsl_rng *const r, const long int seed);
  ~GSLRandomNumberGenerator();

  using RandomNumberGenerator::uniformInZeroOne;
  const double uniformInZeroOne();
  void setSeedAndLuxuryLevel(const long int seed, const int dummy);
  void varySeedToGetIndependentRandomNumberStreams(const long int unique);
private:
  long int _seed;
  gsl_rng* _gslRandomNumberGenerator;
private:     // prevent copy construction and assignment
  GSLRandomNumberGenerator(const GSLRandomNumberGenerator&);
  GSLRandomNumberGenerator& operator=(const GSLRandomNumberGenerator&);  
};

// --------------------------------------------------------------

RandomNumberGenerator *const randomNumberGenerator = new GSLRandomNumberGenerator(gsl_rng_alloc(gsl_rng_ranlxs1), seedForRandomNumberGenerator);

// --------------------------------------------------------------

GSLRandomNumberGenerator::GSLRandomNumberGenerator(gsl_rng *const r, const long int seed)
  : _seed(0), _gslRandomNumberGenerator(r)
{
  setSeedAndLuxuryLevel(seed, 0);
}

GSLRandomNumberGenerator::~GSLRandomNumberGenerator()
{
  gsl_rng_free(_gslRandomNumberGenerator);
}

const double GSLRandomNumberGenerator::uniformInZeroOne()
{
  return gsl_rng_uniform_pos(_gslRandomNumberGenerator);
}

void GSLRandomNumberGenerator::setSeedAndLuxuryLevel(const long int seed, const int dummy)
{
  assert(seed >= 0);
  _seed = seed;
  gsl_rng_set(_gslRandomNumberGenerator, seed);
}

void GSLRandomNumberGenerator::varySeedToGetIndependentRandomNumberStreams(const long int unique)
{
  setSeedAndLuxuryLevel(_seed + unique, 0);
}

// Author: Nikolas Kauer <kauer@physik.uni-wuerzburg.de>

#include <iostream>
using std::cerr;
#include <iomanip>
using std::endl;
using std::setprecision;
#include <cmath>
using std::pow;
using std::sqrt;
using std::fabs;
#include <cassert>
/* assert macro */

#include "estimate.h"
#include "utilities.h"

Estimate::Estimate()
  : estimate(0.0), variance(0.0)
{}

Estimate::Estimate(const Float64 estimate_, const Float64 variance_)
  : estimate(estimate_), variance(variance_)
{}

// --------------------------------------------------------------

SampleSet::SampleSet()
{
  reset();
}

SampleSet::~SampleSet()
{}

void SampleSet::addSample(const Float64& value, const Float64& weight)
// default: weight = 1.0
{
  const Float64 weightedValue = value * weight;
  _sumOfWeightedValues += weightedValue;
  _sumOfWeightedValueSquares += weightedValue * weightedValue;
  _sumOfWeights += weight;
  _sumOfWeightSquares += weight * weight;
  ++_numberOfWeightedValues;
}

const Estimate SampleSet::getEstimate()
{
  Estimate e;
  if (_numberOfWeightedValues > 0) {
    assert(_sumOfWeights > 0.0);
    e.estimate = _sumOfWeightedValues/_sumOfWeights;
    if (_numberOfWeightedValues > 1) {
      e.variance = (_sumOfWeightedValueSquares
        - pow(_sumOfWeightedValues, 2)/_sumOfWeights)/pow(_sumOfWeights, 2);
    }
    reset();
  }
  return e;
}

const Estimate SampleSet::getEstimate(const Int64 totalNumberOfWeightedValues)
{
  Estimate e;
  if (_numberOfWeightedValues > 0) {
    const double sumOfWeights = double(totalNumberOfWeightedValues);
    e.estimate = _sumOfWeightedValues/sumOfWeights;
    if (_numberOfWeightedValues > 1) {
      e.variance = (_sumOfWeightedValueSquares
		    - pow(_sumOfWeightedValues, 2)/sumOfWeights)
        /pow(sumOfWeights, 2);
    }
    reset();
  }
  return e;
}

void SampleSet::toStream(ostream& os) const
{
  os << setprecision(16);
  os << _sumOfWeightedValues << csep;
  os << _sumOfWeightedValueSquares << csep;
  os << _sumOfWeights << csep;
  os << _sumOfWeightSquares << csep;
  os << _numberOfWeightedValues << csep;
}

void SampleSet::fromStream(istream& is)
{
  _sumOfWeightedValues = getObj<Float64>(is);
  _sumOfWeightedValueSquares = getObj<Float64>(is);
  _sumOfWeights = getObj<Float64>(is);
  _sumOfWeightSquares = getObj<Float64>(is);
  _numberOfWeightedValues = getObj<Int64>(is);
}

SampleSet& SampleSet::operator+=(const SampleSet& partial)
{
  _sumOfWeightedValues += partial._sumOfWeightedValues;
  _sumOfWeightedValueSquares += partial._sumOfWeightedValueSquares;
  _sumOfWeights += partial._sumOfWeights;
  _sumOfWeightSquares += partial._sumOfWeightSquares;
  _numberOfWeightedValues += partial._numberOfWeightedValues;
  return *this;
}

void SampleSet::reset()
{
  _sumOfWeightedValues = 0.0;
  _sumOfWeightedValueSquares = 0.0;
  _sumOfWeights = 0.0;
  _sumOfWeightSquares = 0.0;
  _numberOfWeightedValues = 0;
}

// --------------------------------------------------------------

GlobalSampleSet::GlobalSampleSet()
  : SampleSet()
{}

const Estimate GlobalSampleSet::getEstimate()
{
  Estimate e;
  if (_numberOfWeightedValues > 0) {
    assert(_sumOfWeights > 0.0);
    e.estimate = _sumOfWeightedValues/_numberOfWeightedValues;
    if (_numberOfWeightedValues > 1) {
      e.variance = (_sumOfWeightedValueSquares
        - pow(_sumOfWeightedValues, 2)/_numberOfWeightedValues)
        /pow(double(_numberOfWeightedValues), 2);
    }
    reset();
  }
  return e;
}

GlobalSampleSet& GlobalSampleSet::operator+=(const GlobalSampleSet& partial)
{
  SampleSet::operator+=(partial);
  return *this;
}

// --------------------------------------------------------------

CumulativeEstimate::CumulativeEstimate()
  : _estimate(0.), _standardDeviation(0.), _chiSquarePerEstimate(1.),
    _valuesUnknown(true),
    _weightedSumOfEstimates(0.), _sumOfWeights(0.),
    _weightedSumOfEstimateSquares(0.), _numberOfEstimates(0)
{}

CumulativeEstimate::~CumulativeEstimate()
{}

const double CumulativeEstimate::estimate() const
{
  if (_valuesUnknown) {
    computeValues();
    _valuesUnknown = false;
  }
  return _estimate;
}

const double CumulativeEstimate::standardDeviation() const
{
  if (_valuesUnknown) {
    computeValues();
    _valuesUnknown = false;
  }
  return _standardDeviation;
}

const double CumulativeEstimate::chiSquarePerEstimate() const
{
  if (_valuesUnknown) {
    computeValues();
    _valuesUnknown = false;
  }
  return _chiSquarePerEstimate;
}

void CumulativeEstimate::addEstimate(const Estimate& ae)
{
  // see Eq. (2) - (6) in G.P. Lepage, Cornell pub. CLNS-80/447
  // http://www-lib.kek.jp/cgi-bin/img/tiff2allps?2+compress+198006210

  if (ae.variance > 0.0) {
    const double delta = fabs(ae.estimate - estimate());
    const double combinedStandardDeviation =
      sqrt(pow(standardDeviation(), 2) + ae.variance);
    const bool newEstimateIsCompatible = delta < 2.5*combinedStandardDeviation;
    if (newEstimateIsCompatible) {
      _weightedSumOfEstimates += ae.estimate/ae.variance;
      _sumOfWeights += 1.0/ae.variance;
      _weightedSumOfEstimateSquares += pow(ae.estimate, 2)/ae.variance;
      ++_numberOfEstimates;
    }
    else {
      _weightedSumOfEstimates = ae.estimate/ae.variance;
      _sumOfWeights = 1.0/ae.variance;
      _weightedSumOfEstimateSquares = pow(ae.estimate, 2)/ae.variance;
      _numberOfEstimates = 1;
    }
    _valuesUnknown = true;
  }
}

void CumulativeEstimate::print(ostream& os) const
{
  os << setprecision(16);
  os << estimate() << " +/- " << setprecision(2) << standardDeviation()
     << "   (" << standardDeviation()/estimate()*100 << "%)" << endl;
  if (numberOfEstimates() > 1) {
    os << "chi^2/estimate: " << chiSquarePerEstimate()
       << " based on " << numberOfEstimates() << " estimates" << endl;
  }
  os << setprecision(16);     // reset to default
}

void CumulativeEstimate::toStream(ostream& os) const
{
  os << setprecision(16);
  os << _weightedSumOfEstimates << csep;
  os << _sumOfWeights << csep;
  os << _weightedSumOfEstimateSquares << csep;
  os << _numberOfEstimates << csep;
}

void CumulativeEstimate::fromStream(istream& is)
{
  _weightedSumOfEstimates = getObj<Float64>(is);
  _sumOfWeights = getObj<Float64>(is);
  _weightedSumOfEstimateSquares = getObj<Float64>(is);
  _numberOfEstimates = getObj<int>(is);
  _valuesUnknown = true;
}

CumulativeEstimate& CumulativeEstimate::operator+=(const CumulativeEstimate& partial)
{
  _weightedSumOfEstimates += partial._weightedSumOfEstimates;
  _sumOfWeights += partial._sumOfWeights;
  _weightedSumOfEstimateSquares += partial._weightedSumOfEstimateSquares;
  _numberOfEstimates += partial._numberOfEstimates;
  _valuesUnknown = true;
  return *this;
}

void CumulativeEstimate::computeValues() const
{
  // see Eq. (2) - (6) in G.P. Lepage, Cornell pub. CLNS-80/447
  // http://www-lib.kek.jp/cgi-bin/img/tiff2allps?2+compress+198006210

  if (_numberOfEstimates > 0) {
    assert(_sumOfWeights > 0.0);
    _estimate = _weightedSumOfEstimates / _sumOfWeights;
    _standardDeviation = sqrt(1.0/_sumOfWeights);
  }

  if (_numberOfEstimates > 1) {
    _chiSquarePerEstimate =
      (_weightedSumOfEstimateSquares - _weightedSumOfEstimates * _estimate)
      / (_numberOfEstimates - 1.0);
  }
}

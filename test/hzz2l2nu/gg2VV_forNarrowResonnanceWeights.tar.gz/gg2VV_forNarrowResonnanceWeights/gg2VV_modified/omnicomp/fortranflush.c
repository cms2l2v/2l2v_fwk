#include <stdio.h>

void fortranflush_()
{
  fflush(stdout);
  fflush(stderr);
}

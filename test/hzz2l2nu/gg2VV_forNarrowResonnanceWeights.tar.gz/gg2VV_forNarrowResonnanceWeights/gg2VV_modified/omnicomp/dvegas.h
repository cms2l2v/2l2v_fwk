#ifndef DVEGAS_H
#define DVEGAS_H

// Author: Nikolas Kauer <kauer@physik.uni-wuerzburg.de>

/*
  default integration/summation range:
  (0, 1) for continuous dimensions
  {0, 1, 2, ..., dDimSizes[dim]-1} for discrete dimensions
  ----------------------------------------
  random numbers in (0, 1) are provided
  to facilitate the addition of auxilliary
  dimensions that are not VEGAS driven
*/

#include <iostream>
using std::ostream;
using std::istream;
#include <string>
using std::string;
#include <vector>
using std::vector;
#include <stdexcept>
using std::out_of_range;
#include <cmath>
using std::fabs;
#include "integrand.h"
#include "omnihistosuite.h"
#include "64bittypes.h"
#include "estimate.h"

class OmniParameters;     // defined in omnicomp.hh

namespace HepSource
{
enum Sampling { NONE, IMPORTANCE, STRATIFIED };

// --------------------------------------------------------------

template<typename C>
class MultidimensionalArray
{
public:
  MultidimensionalArray(const int dim, const int length);
  void resize(const int dim, const int length);     // also yields uninitialized state
private:
  void consHelper(const int dim, const int length);
public:
  void initialize(const C& c = C());
  void reset(const C& c = C());
  MultidimensionalArray& operator=(const MultidimensionalArray& mda);
  MultidimensionalArray(const MultidimensionalArray& mda);
  virtual ~MultidimensionalArray();
  const int dim() const;
  const int length() const;
  const Int64 size() const;
  C& operator[](const Int64 sequentialIndex);
  const C& operator[](const Int64 sequentialIndex) const;
  C& operator[](const vector<int>& listOfIndexes);
  const C& operator[](const vector<int>& listOfIndexes) const;
  C& at(const Int64 sequentialIndex) throw (out_of_range);
  const C& at(const Int64 sequentialIndex) const throw (out_of_range);
  C& at(const vector<int>& listOfIndexes) throw (out_of_range);
  const C& at(const vector<int>& listOfIndexes) const throw (out_of_range);
  const vector<int> seqIdxToIndexes(const Int64 sequentialIndex) const throw (out_of_range);
  const Int64 indexesToSeqIdx(const vector<int>& listOfIndexes) const throw (out_of_range);
  const vector<C> getProjection(const int dim, const Int64 projectionIterator) const;
  void putProjection(const int dim, const Int64 projectionIterator, const vector<C>& newWeights);

  void toStream(ostream& os) const;
  void fromStream(istream& is);
  MultidimensionalArray& operator+=(const MultidimensionalArray& partial);

  typedef C value_type;
  typedef Int64 difference_type;
private:
  int _dim;
  int _length;
  Int64 _size;
  vector<C>* _v;
};

template<typename C>
inline void MultidimensionalArray<C>::initialize(const C& c) { reset(c); }     // default: c = C()

template<typename C>
inline const int MultidimensionalArray<C>::dim() const { return _dim; }

template<typename C>
inline const int MultidimensionalArray<C>::length() const { return _length; }

template<typename C>
inline const Int64 MultidimensionalArray<C>::size() const { return _size; }

template<typename C>
inline C& MultidimensionalArray<C>::operator[](const Int64 sequentialIndex) { return (*_v)[sequentialIndex]; }

template<typename C>
inline const C& MultidimensionalArray<C>::operator[](const Int64 sequentialIndex) const { return (*_v)[sequentialIndex]; }

template<typename C>
inline C& MultidimensionalArray<C>::operator[](const vector<int>& listOfIndexes) { return (*_v)[indexesToSeqIdx(listOfIndexes)]; }

template<typename C>
inline const C& MultidimensionalArray<C>::operator[](const vector<int>& listOfIndexes) const { return (*_v)[indexesToSeqIdx(listOfIndexes)]; }

template<typename C>
inline C& MultidimensionalArray<C>::at(const vector<int>& listOfIndexes) throw (out_of_range) { return (*_v)[indexesToSeqIdx(listOfIndexes)]; }

template<typename C>
inline const C& MultidimensionalArray<C>::at(const vector<int>& listOfIndexes) const throw (out_of_range) { return (*_v)[indexesToSeqIdx(listOfIndexes)]; }

// --------------------------------------------------------------

class GlobalAccumulator 
{
public:
  GlobalAccumulator();
  void addValue(const double value, const double weight);
  const Estimate getEstimate();
    
  void toStream(ostream& os) const;
  void fromStream(istream& is);
  GlobalAccumulator& operator+=(const GlobalAccumulator& partial);

  const double efficiency() const;     // non-zero fraction
  const double positiveContribution() const;
  const double negativeContribution() const;
private:
  GlobalSampleSet _globalSampleSet;
  Float64 _sumOfNegativeIntegrandValues;
  Int64 _numberOfShotsWhereIntegrandIsZero;
};

inline const Estimate GlobalAccumulator::getEstimate() { return _globalSampleSet.getEstimate(); }

inline const double GlobalAccumulator::efficiency() const { return 1.0 - _numberOfShotsWhereIntegrandIsZero / double(_globalSampleSet.numberOfWeightedValues()); }

inline const double GlobalAccumulator::positiveContribution() const { return (_globalSampleSet.sumOfWeightedValues() - _sumOfNegativeIntegrandValues) / _globalSampleSet.numberOfWeightedValues(); }

inline const double GlobalAccumulator::negativeContribution() const { return _sumOfNegativeIntegrandValues / _globalSampleSet.numberOfWeightedValues(); }

// --------------------------------------------------------------

class IntegrandEstimate : public CumulativeEstimate
{
public:
  IntegrandEstimate();
  void print(ostream& os) const;     // output for human readers
private:
  CumulativeEstimate& operator+=(const CumulativeEstimate& partial);
};

// --------------------------------------------------------------

class SeparabilityTestForTwoDim
{
public:
  SeparabilityTestForTwoDim(const int numberOfBinsOnEachAxis);
  void addShot(const int binIndexX, const int binIndexY, const Float64 value);
  struct SeparabilityStats
  {
    double average;
    double standardDeviation;
    SeparabilityStats(const double average, const double standardDeviation);
  };
  const SeparabilityStats separabilityStats() const;     // perfectly separable: (1, 0)
  const bool denseCoverage(const Int64 numberOfShots) const;

  void toStream(ostream& os) const;
  void fromStream(istream& is);
  SeparabilityTestForTwoDim& operator+=(const SeparabilityTestForTwoDim& partial);
private:
  int _numberOfBinsOnEachAxis;
  vector< vector<Float64> > _accumulator;
  mutable SeparabilityStats _separabilityStats;     // buffered
  mutable bool _separabilityStatsUnknown;
};

inline const bool SeparabilityTestForTwoDim::denseCoverage(const Int64 numberOfShots) const { return numberOfShots >= 100 * _numberOfBinsOnEachAxis * _numberOfBinsOnEachAxis; }

// --------------------------------------------------------------

class OmniComp;

class Dvegas
{
public:
  Dvegas(const int aDim, const int f, const Integrand::Type itype);
  Dvegas(const int cDim, const int cBin, const int f, const Integrand::Type itype,
         const Sampling sampling = IMPORTANCE);
  Dvegas(const int cDim, const int cBin, const vector<int>& dDimSizes, const int f,
         const Integrand::Type itype, const Sampling sampling = IMPORTANCE);
  Dvegas(const int cDim, const int cBin, const int corrDim,
         const vector<int>& dDimSizes, const int aDim, const int f,
         const Integrand::Type itype, const Sampling sampling = IMPORTANCE);
  Dvegas(const int cDim, const int cBin, const vector<int>& corrDim,
         const vector<int>& dDimSizes, const int aDim, const int f,
         const Integrand::Type itype, const Sampling sampling = IMPORTANCE);
  Dvegas();
private:
  void initialize(const int cDim, const int cBin, const vector<int>& corrDim,
                  const vector<int>& dDimSizes, const int aDim, const int f, 
                  const Integrand::Type itype, const Sampling sampling);
public:
  virtual ~Dvegas();
private:     // prevent copy construction and assignment
  Dvegas(const Dvegas&);
  Dvegas& operator=(const Dvegas&);

  // ***************************
public:
  struct CellAccumulators;
  class NoNonzeroIntegrandValuesSampledException {};
  CellAccumulators collectData(const Int64 numberOfShots) throw (NoNonzeroIntegrandValuesSampledException);
private:
  class AccPtrs;
  const AccPtrs evaluateIntegrand(const Int64 numberOfShots, 
    const bool delegateEvaluation);     // returned pointers own memory
  friend class OmniComp;     // performComputation() uses evaluateIntegrand()
  class CorrelationsDetector;
  class AccPtrs
  {
  public:
    vector<GlobalAccumulator> *const accumulators() const;
    CellAccumulators *const cellAccumulators() const;
    CorrelationsDetector *const correlationsDetector() const;
    AccPtrs(vector<GlobalAccumulator> *const accumulators, CellAccumulators *const
            cellAccumulators, CorrelationsDetector *const correlationsDetector);

    void toStream(ostream& os) const;
    void deleteAcc() const;
    AccPtrs();
    void fromStream(istream& is);     // creates objects
    AccPtrs& operator+=(const AccPtrs& partial);
  private:
    vector<GlobalAccumulator>* _accumulators;
    CellAccumulators* _cellAccumulators;
    CorrelationsDetector* _correlationsDetector;
  public:     // only used in connection with return value of evaluateIntegrand()
    AccPtrs(const AccPtrs& accPtrs);
    AccPtrs& operator=(const AccPtrs& accPtrs);
  };
  struct ShotParameters
  {
    ShotParameters(const Dvegas& dvegas);
    double weight;
    vector<double> x;
    vector<int> k;
    vector<double> aux;
    vector<double> f;
    vector<int> contIndexes;
    vector<int>& discIndexes;     // discIndexes = k
  };
  // ***************************

public:
  // ***************************
  void info() const;     // print info about newest iteration and cumulative
  void info(const int numberOfIntegrandsToDisplayInfoFor) const;
  const CumulativeEstimate getCumulativeEstimate(const int i) const;
  const double integral(const int i) const;
  const double standardDeviation(const int i) const;
  const double chiSquarePerIteration(const int i) const;
  const int numberOfIterations(const int i) const;
  const bool isAdaptingContinuousDimensions() const;
  const int numberOfIntegrands() const;
  // ***************************

  // ***************************
  void adaptWeights(CellAccumulators& cellAcc);
  void adaptContinuousWeights(CellAccumulators& cellAcc);
  void adaptCorrelatedWeights(CellAccumulators& cellAcc);
  void adaptDiscreteWeights(CellAccumulators& cellAcc);
  const double getCurvature() const;
  void setCurvature(const double curvature);
  const double getRootAmpl() const;
  void setRootAmpl(const double rootAmpl);
  // ***************************
  struct CellAccumulators
  {
    struct Accumulator 
    {
      Accumulator();
      Float64 sumOfIntegrandValues;
      Float64 sumOfIntegrandValueSquares;
      Int64 numberOfShots;
      void addValue(const double value);

      void toStream(ostream& os) const;
      void fromStream(istream& is);
      Accumulator& operator+=(const Accumulator& partial);
    };
    vector< vector<Accumulator> > contDimAcc;
    vector< vector<Accumulator> > discDimAcc;
    vector< MultidimensionalArray<Accumulator> > corrDimAcc;

    CellAccumulators(const Dvegas& dvegas);
    void addShot(const ShotParameters& sp);

    void toStream(ostream& os) const;
    CellAccumulators();
    void fromStream(istream& is);
    CellAccumulators& operator+=(const CellAccumulators& partial);
  };
private:
  class DiscreteWeights
  {
  public:
    DiscreteWeights(const int numberOfIndexValues);     // initialized with equal weights
    const double getIndexValueAndWeight(const double randomInZeroOne, int& indexValue) const;
    void setWeights(const vector<double>& normalizedWeights);

    void toStream(ostream& os) const;
    void fromStream(istream& is);
  private:
    vector<double> _weights;
  };
  class ContinuousWeights
  {
  public:
    ContinuousWeights(const int numberOfBins);     // initialized with equal weights
    const double getWeightAndWeightedRandomAndIndex(double& randomInZeroOne, int& binIdx) const;
    // composed of:
    const int getIndexAndNewRandom(double& randomInZeroOne) const;
    const double getWeightAndWeightedRandom(const int binIdx, double& randomInZeroOne) const;

    void setWeights(const vector<double>& normalizedBinWeights);
    const vector<double> binEdges() const;

    void toStream(ostream& os) const;
    void fromStream(istream& is);
  private:
    int _numberOfBins;
    vector<double> _binEdges;       // location of grid divisions
  };
  class CorrelatedWeights
  {
  public:
    CorrelatedWeights(const int corrDim, const int corrBin);     // not initialized
    const int dim() const;
    const int length() const;
    void initialize();     // to flat, normalized weights
    void reset();          // to flat, normalized weights
    const Int64 numberOfCells() const;
    const Float64 flatWeight() const;
    const double getIndexesAndWeight(const double randomInZeroOne, vector<int>& corrIndexes) const;
    void setWeights(const MultidimensionalArray<Float64>& normalizedWeights);
    void rebinProjection(const int dim, const vector<double>& oldBinEdges, const vector<double>& newBinEdges);
    void optimize();
    void disableOptimize();
    const bool optimizeEnabled() const;

    void toStream(ostream& os) const;
    void fromStream(istream& is);
  private:
    bool _flatGrid;
    MultidimensionalArray<Float64> _weights;
    struct Optim
    {
      bool optimizeEnabled;
      vector<Int64> idxMap;
      Float64 sumOfNonTinyWeights;
      Int64 numberOfTinyWeights;
      Float64 tinyWeight;
      void reset(const Int64 numberOfWeights);  // resizes idxMap, zeros not guaranteed
    };
    Optim _optim;
  };
public:
  void disableOptimize(const int setOfCorrelatedWeights);
  
  void reset();          // discard all data
  void resetWeights();
  void resetEstimates();

  void saveStateToFile(const string& filename = "dvegas.state") const;
  void restoreStateFromFile(const string& filename = "dvegas.state");
  void restoreWeightsFromFile(const string& filename = "dvegas.state");
  void saveStateToStream(ostream& os) const;
  void restoreStateFromStream(istream& is, const bool checkAndAttachNewHisto = false);
  void restoreWeightsFromStream(istream& is);
  const string saveStateToString() const;
  void restoreStateFromString(const string& s, const bool checkAndAttachNewHisto = false);
  void restoreWeightsFromString(const string& s);

  void printVersion() const;     // digital watermark with version information
private:
  Sampling _sampling;

  // Sizes
  int _cDim;               // number of continuous dimensions
  int _cBin;               // number of bins for continuous dimensions
  int _corrDim;            // number of correlated continuous dimensions
  vector<int> _dDimSizes;  // number of values for discrete dimensions
  int _aDim;               // number of auxilliary dimensions (no adaptation)
  int _f;                  // number of functions to integrate

  // parameters in [0,1] to control damping of weight adaptation
  double _curvature;     // 0: no damping, 1: full damping for large weights
  double _rootAmpl;      // 0: extra amplification off (fast), 1: maximal damping (no adaptation)

  // ***************************
public:
  const bool canAttachOmniHistoSuite() const;
  void attachOmniHistoSuite(OmniHistoSuite *const omniHistoSuite);
  const bool hasOmniHistoSuiteAttached() const;
  OmniHistoSuite *const omniHistoSuite() const;
  void detachOmniHistoSuite();
private:
  Integrand* _integrand;
  // ***************************

  // adaptWeights()
  vector<DiscreteWeights> _discDimWeights;
  vector<ContinuousWeights> _contDimWeights;
  vector<CorrelatedWeights> _corrDimWeights;

  // info()
  struct Info
  {
    vector<double> efficiency;
    vector<double> positiveContribution;
    vector<double> negativeContribution;
  };
  Info _info;
  vector<IntegrandEstimate> _newestIterationStats;    
  vector<IntegrandEstimate> _allIterationsStats;
public:
  const double getInfoEfficiency(const int i) const;

  // ***************************
public:
  void activateCorrelationsDetector();
private:
  bool _detectCorrelations;
  class CorrelationsDetector
  {
  public:
    CorrelationsDetector(const Dvegas& dvegas);
    void addShot(const ShotParameters& sp);
    void sort();
    const bool denseCoverage(const Int64 numberOfShots) const;
    void info() const;

    void toStream(ostream& os) const;
    CorrelationsDetector();
    void fromStream(istream& is);
    CorrelationsDetector& operator+=(const CorrelationsDetector& partial);
  private:
    struct Pair
    {
      int dim1;
      int dim2;
      SeparabilityTestForTwoDim test;
      Pair(int dim1, int dim2, SeparabilityTestForTwoDim test);

      void toStream(ostream& os) const;
      void fromStream(istream& is);
    };
    vector<Pair> _pairs;
    struct LessSeparable
    {
      bool operator()(const Pair& x, const Pair& y) const;
    };
    LessSeparable _lessSeparable;
  };
  // ***************************

  // ***************************
public:
  void attachOmniComp(OmniComp *const omniComp);
  void detachOmniComp();
private:
  OmniComp* _omniComp;
  // ***************************
public:
  static bool* abortLoopPtr;
};

ostream& operator<<(ostream& os, const Dvegas::CellAccumulators::Accumulator& a);
istream& operator>>(istream& is, Dvegas::CellAccumulators::Accumulator& a);

inline vector<GlobalAccumulator> *const Dvegas::AccPtrs::accumulators() const { return _accumulators; }

inline Dvegas::CellAccumulators *const Dvegas::AccPtrs::cellAccumulators() const { return _cellAccumulators; }

inline Dvegas::CorrelationsDetector *const Dvegas::AccPtrs::correlationsDetector() const { return _correlationsDetector; }

inline const CumulativeEstimate Dvegas::getCumulativeEstimate(const int i) const { assert(0 <= i && i < _f); return _allIterationsStats[i]; }

inline const double Dvegas::integral(const int i) const { assert(0 <= i && i < _f); return _allIterationsStats[i].estimate(); }

inline const double Dvegas::standardDeviation(const int i) const { assert(0 <= i && i < _f); return _allIterationsStats[i].standardDeviation(); }

inline const double Dvegas::chiSquarePerIteration(const int i) const { assert(0 <= i && i < _f); return _allIterationsStats[i].chiSquarePerEstimate(); }

inline const int Dvegas::numberOfIterations(const int i) const { assert(0 <= i && i < _f); return _allIterationsStats[i].numberOfEstimates(); }

inline const bool Dvegas::isAdaptingContinuousDimensions() const { return _cDim > 0; }

inline const int Dvegas::numberOfIntegrands() const { return _f; }

inline const double Dvegas::getCurvature() const { return _curvature; }

inline void Dvegas::setCurvature(const double curvature) { _curvature = curvature; }

inline const double Dvegas::getRootAmpl() const { return _rootAmpl; }

inline void Dvegas::setRootAmpl(const double rootAmpl) { _rootAmpl = rootAmpl; }

inline const double Dvegas::ContinuousWeights::getWeightAndWeightedRandomAndIndex(double& randomInZeroOne, int& binIdx) const
{
  binIdx = getIndexAndNewRandom(randomInZeroOne);
  return getWeightAndWeightedRandom(binIdx, randomInZeroOne);
}

inline const vector<double> Dvegas::ContinuousWeights::binEdges() const { return _binEdges; }

inline const int Dvegas::CorrelatedWeights::dim() const { return _weights.dim(); }

inline const int Dvegas::CorrelatedWeights::length() const { return _weights.length(); }

inline const Int64 Dvegas::CorrelatedWeights::numberOfCells() const { return _weights.size(); }

inline const Float64 Dvegas::CorrelatedWeights::flatWeight() const { return 1.0/numberOfCells(); }

inline void Dvegas::CorrelatedWeights::initialize() { reset(); }

inline void Dvegas::CorrelatedWeights::disableOptimize() { _optim.optimizeEnabled = false; }

inline const bool Dvegas::CorrelatedWeights::optimizeEnabled() const { return _optim.optimizeEnabled; }

inline const bool Dvegas::canAttachOmniHistoSuite() const { return _integrand != 0 && _integrand->canAttachOmniHistoSuite(); }

inline const bool Dvegas::hasOmniHistoSuiteAttached() const { return canAttachOmniHistoSuite() && _integrand->omniHistoSuite() != 0; }

inline OmniHistoSuite *const Dvegas::omniHistoSuite() const { assert(hasOmniHistoSuiteAttached()); return _integrand->omniHistoSuite(); }

inline const double Dvegas::getInfoEfficiency(const int i) const { assert(0 <= i && i < _f); return _info.efficiency[i]; }

inline const bool Dvegas::CorrelationsDetector::denseCoverage(const Int64 numberOfShots) const { return _pairs[0].test.denseCoverage(numberOfShots); }

inline bool Dvegas::CorrelationsDetector::LessSeparable::operator()(const Pair& x, const Pair& y) const { return fabs(1. - x.test.separabilityStats().average) > fabs(1. - y.test.separabilityStats().average); }

// Lepage's VEGAS interface
void VEGAS(Dvegas& dvegas, const Int64 numberOfShots, const int numberOfIterations, const int init = 0);
}     // HepSource

#endif     /* DVEGAS_H */

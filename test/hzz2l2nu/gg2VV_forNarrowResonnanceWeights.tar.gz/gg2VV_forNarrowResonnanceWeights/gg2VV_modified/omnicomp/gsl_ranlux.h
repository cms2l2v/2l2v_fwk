#ifndef GSL_RANLUX_H
#define GSL_RANLUX_H

#include <cstring>
using std::size_t;

extern "C"
{
typedef struct
  {
    const char *name;
    unsigned long int max;
    unsigned long int min;
    size_t size;
    void (*set) (void *state, unsigned long int seed);
    unsigned long int (*get) (void *state);
    double (*get_double) (void *state);
  }
gsl_rng_type;

typedef struct
  {
    const gsl_rng_type * type;
    void *state;
  }
gsl_rng;

extern const gsl_rng_type *gsl_rng_ranlxs1;

gsl_rng *gsl_rng_alloc (const gsl_rng_type * T);
void gsl_rng_free (gsl_rng * r);
void gsl_rng_set (const gsl_rng * r, unsigned long int seed);
double gsl_rng_uniform_pos (const gsl_rng * r);
}

#endif     /* GSL_RANLUX_H */

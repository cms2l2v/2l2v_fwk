#ifndef HISTO_H
#define HISTO_H

// Author: Nikolas Kauer <kauer@physik.uni-wuerzburg.de>

#include <iostream>
using std::ostream;
using std::istream;
#include <string>
using std::string;
#include <vector>
using std::vector;
#include <stdexcept>
using std::out_of_range;
#include <cassert>
/* assert macro */
#include "64bittypes.h"
#include "estimate.h"

class EquiPartition
{
public:
  EquiPartition(const Float64& lowest, const Float64& nextBeyondHighest, const Float64& binSize = Float64(1));
  virtual ~EquiPartition();

  const Float64 lowest() const;
  const Float64 nextBeyondHighest() const;
  const Float64 binSize() const;
  const int numberOfBins() const;

  const int getIndex(const Float64& x) const;
  void toStream(ostream& os) const;
  void fromStream(istream& is);
private:
  Float64 _lowest;
  Float64 _nextBeyondHighest;
  Float64 _binSize;
  int _numberOfBins;
};

inline const Float64 EquiPartition::lowest() const { return _lowest; }

inline const Float64 EquiPartition::nextBeyondHighest() const { return _nextBeyondHighest; }

inline const Float64 EquiPartition::binSize() const { return _binSize; }

inline const int EquiPartition::numberOfBins() const { return _numberOfBins; }

// --------------------------------------------------------------

class Bin
{
public:
  Bin();
  SampleSet sampleSet;
  CumulativeEstimate estimate;
  const bool haveEstimate() const;
  void updateEstimate();
  void updatePartialEstimate(const Int64 numberOfShots);
  void updateEstimateWithPartialEstimate();

  void toStream(ostream& os) const;
  void fromStream(istream& is);
  Bin& operator+=(const Bin& partial);
private:
  double _partialEstimate;
  double _varianceOfPartialEstimate;
};

inline const bool Bin::haveEstimate() const { return estimate.numberOfEstimates() > 0; }

// --------------------------------------------------------------

class Histo
{
public:
  Histo(const string& name, const Float64& lowest, const Float64& nextBeyondHighest, const Float64& binSize = Float64(1), const bool simpleOutOfRange = false);
  virtual ~Histo();

  const string name() const;
  const bool simpleOutOfRange() const;

  void fill(const Float64& x, const Float64& y, const Float64& weight = 1.0);

  const Bin at(const int idx) const throw (out_of_range);
  const Bin underflow() const;
  const Bin overflow() const;

  // simpleOutOfRange mode
  const Float64 sumOfOutOfRangeWeights() const;
  void addToSumOfOutOfRangeWeights(const Float64& weight);

  void updateEstimates();
  void updatePartialEstimates(const Int64 numberOfShots);
  void updateEstimatesWithPartialEstimates();
  void print(ostream& os) const;     // output for human readers
  void toStream(ostream& os) const;
  void fromStream(istream& is);
  Histo& operator+=(const Histo& partial);
private:
  string _name;
  EquiPartition _partition;

  vector<Bin> _bins;
  Bin _underflow;
  Bin _overflow;

  bool _simpleOutOfRange;
  Float64 _sumOfOutOfRangeWeights;
};

inline const string Histo::name() const  { return _name; }

inline const bool Histo::simpleOutOfRange() const { return _simpleOutOfRange; }

inline const Bin Histo::at(const int idx) const throw (out_of_range) { return _bins.at(idx); }

inline const Bin Histo::underflow() const { assert(!_simpleOutOfRange); return _underflow; }

inline const Bin Histo::overflow() const { assert(!_simpleOutOfRange); return _overflow; }

inline const Float64 Histo::sumOfOutOfRangeWeights() const { assert(_simpleOutOfRange); return _sumOfOutOfRangeWeights; }

inline void Histo::addToSumOfOutOfRangeWeights(const Float64& weight) { _sumOfOutOfRangeWeights += weight; }

#endif     /* HISTO_H */

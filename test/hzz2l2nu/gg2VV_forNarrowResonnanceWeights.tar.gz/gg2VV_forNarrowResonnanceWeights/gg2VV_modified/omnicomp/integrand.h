#ifndef INTEGRAND_H
#define INTEGRAND_H

// Author: Nikolas Kauer <kauer@physik.uni-wuerzburg.de>

#include <vector>
using std::vector;
#include "omnihistosuite.h"

namespace HepSource
{
class Integrand
{
public:
  virtual void operator()(const vector<double>& x, const vector<int>& k, const double& weight, const vector<double>& aux, vector<double>& f) = 0;
  virtual const bool canAttachOmniHistoSuite() const;
  virtual void attachOmniHistoSuite(OmniHistoSuite *const omniHistoSuite);
  virtual void createAndAttachEmptyOmniHistoSuite();
  virtual OmniHistoSuite *const omniHistoSuite() const;
  virtual void detachOmniHistoSuite();
  virtual ~Integrand() {}

  typedef int Type;
  enum NoneType { NONE = 0 };
  static Integrand *const make(const Type type);
  const Type type() const;     // used in Dvegas::saveStateToStream()
private:
  Type _type;
};

inline const bool Integrand::canAttachOmniHistoSuite() const { return false; }

inline const Integrand::Type Integrand::type() const { return _type; }
}     // HepSource

#endif     /* INTEGRAND_H */

#ifndef OMNICOMP_H
#define OMNICOMP_H

// Author: Nikolas Kauer <kauer@physik.uni-wuerzburg.de>

#include <list>
using std::list;
#include <map>
using std::map;
#include <cassert>
/* assert macro */
#include "omnicomp.hh"

namespace HepSource
{
namespace OmniCompImplementation
{
  class ExecutableInfo;
  class Names;
  class OmniWorker_i;
  class OmniProgressOutput_i;
}
namespace OCI = OmniCompImplementation;

class OmniComp 
{
public:
  OmniComp(int argc, char* argv[]);
  virtual ~OmniComp();
  const list<string> distributeComputations(const OmniParameters& parameters, 
    const string& dvegasState);
  const double getSpeed() const;
  const int workerId() const;
  void setWorkerId(const int id);
  const OmniProgressOutput_ptr outputRef() const;
  void setOutputRef(const OmniProgressOutput_ptr outputRef);
  void tendToOrbWork() const;
private:
  OCI::ExecutableInfo* _exeInfo;
  const OCI::ExecutableInfo *const exeInfo() const;

  CORBA::ORB_var _orb;

  void processCLOptionsAndInitRegistryAndOutputAndWorker(int argc, char* argv[]);
  double _speed;
  bool _isMaster;
  const bool isMaster() const;
  OCI::Names* _names;
  string _iorFileName;
  const string iorFileName() const;

  OCI::OmniWorker_i* _localWorker;
  OmniWorker_var _localWorkerRef;
  const bool hasWorker() const;
  void createCORBAObjectsWithServants();
  void registerLocalWorker() const;
  int _workerId;

  vector<OmniWorker_var> _workerRefs;
  const int numberOfWorkers() const;
  void resolveWorkerRefs();

  OCI::OmniProgressOutput_i* _output;
  OCI::OmniProgressOutput_i *const output() const;
  OmniProgressOutput_var _outputRef;

  // computation
public:
  const Dvegas *const dvegasPtr() const;
  void setDvegas(Dvegas *const dvegas);
  void setupComputation(const OmniParameters& parameters, const char* dvegasState);
  const string *const resultsPtr() const;
private:
  void readEvalPrintLoop();
  void performComputation();

  Dvegas* _dvegas;
  Int64 _numberOfShots;
  string* _results;

private:     // prevent copy construction and assignment
  OmniComp(const OmniComp&);
  OmniComp& operator=(const OmniComp&);
};

inline const double OmniComp::getSpeed() const { assert(_speed > 0.); return _speed; }

inline const int OmniComp::workerId() const { assert(hasWorker()); return _workerId; }

inline void OmniComp::setWorkerId(const int id) { assert(id >= 0); assert(hasWorker()); assert(_workerId == 0); _workerId = id; }

inline const OmniProgressOutput_ptr OmniComp::outputRef() const { return _outputRef; }

inline void OmniComp::setOutputRef(const OmniProgressOutput_ptr outputRef) { assert(!isMaster()); assert(CORBA::is_nil(_outputRef)); _outputRef = OmniProgressOutput::_duplicate(outputRef); }

inline const OCI::ExecutableInfo *const OmniComp::exeInfo() const { return _exeInfo; }

inline const bool OmniComp::isMaster() const { return _isMaster; }

inline const string OmniComp::iorFileName() const { return _iorFileName; }

inline const bool OmniComp::hasWorker() const { return _localWorker != 0; }

inline const int OmniComp::numberOfWorkers() const { return _workerRefs.size(); }

inline OCI::OmniProgressOutput_i *const OmniComp::output() const { assert(isMaster()); return _output; }

inline const Dvegas *const OmniComp::dvegasPtr() const { return _dvegas; }

inline void OmniComp::setDvegas(Dvegas *const dvegas) { _dvegas = dvegas; }

inline const string *const OmniComp::resultsPtr() const { return _results; }
}     // HepSource

#endif     /* OMNICOMP_H */

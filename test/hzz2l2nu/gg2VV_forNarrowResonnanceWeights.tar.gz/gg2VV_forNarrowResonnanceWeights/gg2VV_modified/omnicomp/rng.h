#ifndef RANDOMNUMBERGENERATOR_H
#define RANDOMNUMBERGENERATOR_H

#include <vector>
using std::vector;

class RandomNumberGenerator
{
public:
  virtual const double uniformInZeroOne() = 0;     // excludes 0 and 1
  virtual void uniformInZeroOne(vector<double>& vectorOfRandomNumbers);
  virtual void setSeedAndLuxuryLevel(const long int seed, const int luxury) = 0;
  virtual void varySeedToGetIndependentRandomNumberStreams(const long int unique) = 0;
  virtual ~RandomNumberGenerator();
};

extern RandomNumberGenerator *const randomNumberGenerator;

#endif     /* RANDOMNUMBERGENERATOR_H */

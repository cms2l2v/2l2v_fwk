#ifndef _64BITTYPES_H
#define _64BITTYPES_H

typedef long long int Int64;     // 64-bit integer (used in FormCalc interface: helicities are integer*8 in squaredme_ call)
typedef double Float64;

#endif     /* _64BITTYPES_H */

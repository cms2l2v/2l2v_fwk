#ifndef OMNIHISTOSUITE_H
#define OMNIHISTOSUITE_H

// Author: Nikolas Kauer <kauer@physik.uni-wuerzburg.de>

#include <iostream>
using std::ostream;
using std::istream;

#include "64bittypes.h"

namespace HepSource
{
class OmniHistoSuite
{
public:
  virtual void updatePartialEstimates(const Int64 numberOfShots) = 0;
  virtual void toStream(ostream& os) = 0;
  virtual OmniHistoSuite *const cloneEmpty() const = 0;
  virtual void fromStream(istream& is) = 0;
  virtual OmniHistoSuite& operator+=(const OmniHistoSuite& partial) = 0;
  virtual ~OmniHistoSuite()
  {}
};
}     // HepSource

#endif     /* OMNIHISTOSUITE_H */

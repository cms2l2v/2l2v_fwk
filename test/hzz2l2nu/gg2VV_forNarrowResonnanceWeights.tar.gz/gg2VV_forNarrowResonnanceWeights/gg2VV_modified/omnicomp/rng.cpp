#include <vector>
using std::vector;

#include "rng.h"

void RandomNumberGenerator::uniformInZeroOne(vector<double>& vectorOfRandomNumbers)
{
  for (int i = 0; i < vectorOfRandomNumbers.size(); ++i)
    vectorOfRandomNumbers[i] = uniformInZeroOne();
}

RandomNumberGenerator::~RandomNumberGenerator()
{}

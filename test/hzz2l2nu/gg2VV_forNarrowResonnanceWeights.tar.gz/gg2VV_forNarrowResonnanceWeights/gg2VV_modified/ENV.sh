# NONINTERACTIVE SHELL FEATURES ##########################################
#
#
#

umask 022

export NKAUERHOME=/afs/cern.ch/user/n/nkauer
export PATH=$NKAUERHOME/tools:$PATH

# Intel compilers
source  /afs/cern.ch/sw/IntelSoftware/linux/all-setup.sh &> /dev/null

# gcc-4.8.2
GCC_TOPDIR=$NKAUERHOME/public/tools/gcc-4.8.2
export PATH=$GCC_TOPDIR/bin:$PATH
if test "$LD_LIBRARY_PATH"; then
    export LD_LIBRARY_PATH=$GCC_TOPDIR/lib64:$GCC_TOPDIR/lib:$LD_LIBRARY_PATH
else
    export LD_LIBRARY_PATH=$GCC_TOPDIR/lib64:$GCC_TOPDIR/lib
fi
export LD_LIBRARY_PATH=$NKAUERHOME/public/libraries/gcc/gmp/lib:$NKAUERHOME/public/libraries/gcc/mpfr/lib:$NKAUERHOME/public/libraries/gcc/mpc/lib:$LD_LIBRARY_PATH
if test "$LD_RUN_PATH"; then
    export LD_RUN_PATH=$GCC_TOPDIR/lib64:$GCC_TOPDIR/lib:$LD_RUN_PATH
else
    export LD_RUN_PATH=$GCC_TOPDIR/lib64:$GCC_TOPDIR/lib
fi
export LD_RUN_PATH=$NKAUERHOME/public/libraries/gcc/gmp/lib:$NKAUERHOME/public/libraries/gcc/mpfr/lib:$NKAUERHOME/public/libraries/gcc/mpc/lib:$LD_RUN_PATH

# MY PROGRAMS ------------------------------------------------------------

export TOPDIR=$PWD

export TD=$TOPDIR

export LIB_TOPDIR=$NKAUERHOME/libraries
#export LIB_TOPDIR=$NKAUERHOME/libraries_slc5

# omniORB
export PATH=$PATH:$LIB_TOPDIR/intel/omniORB/bin
# omniORB naming service (omniNames)
#export OMNIORB_CONFIG=$NKAUERHOME/config/omniORB.cfg
#export OMNINAMES_LOGDIR=$NKAUERHOME/system/log/omninames

# code
alias rmprog="rm -i gg2??_*weightedEvents.dat; rm -i gg2??.*"

# test for 32- or 64-bit system
export LONG_BIT=`getconf LONG_BIT`     # "32" or "64"

# jam to use up to 7 CPU cores
alias jam='jam -j7'
alias make='make -j 7'

# END: MY PROGRAMS -------------------------------------------------------

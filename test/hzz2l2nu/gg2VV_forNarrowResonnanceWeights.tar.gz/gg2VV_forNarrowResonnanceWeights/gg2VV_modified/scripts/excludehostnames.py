from sys import argv
from string import find

excluded_hostnames = [
"lxte109",
"lxte110",
"lxte114",
"lxte507",
"lxte508",
"lxte512",
"lxta201"]

assert len(argv) == 2
filename = argv[1]
assert filename == "clusterDict.py"
inf = open(filename)
lines = inf.readlines()
inf.close()
s = ""
for line in lines:
    excluded = False
    for eh in excluded_hostnames:
        if eh in line:
            s += "#"+line
            excluded = True
            continue
    if not excluded:
        s += line
outf = open(filename, 'w+')
outf.write(s)

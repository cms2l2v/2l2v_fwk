from sys import argv, exit
from os import chdir, getcwd, system
from os.path import abspath, isfile, expandvars, dirname, basename
from string import *
from time import sleep
from commands import getoutput
from math import floor

assert isfile("/usr/bin/nice")

def command(host, speed):
    return "ssh -o StrictHostKeyChecking=no -f -x " + host + " \"(cd "+ executable_path +"; /usr/bin/nice -n 19 ./" + executable_name + " -w -s"+ str(speed) +")\" < /dev/null &> /dev/null"

def commandEqualSpeed(host):
    return "ssh -o StrictHostKeyChecking=no -f " + host + " \"(cd "+ executable_path +"; /usr/bin/nice -n 19 ./" + executable_name + " -w )\" &> /dev/null"

maxProc = 1000     # use at most 1000 processors by default
if len(argv) == 3:
    maxProc = int(argv[2])

currentdir = getcwd()
homedir = expandvars("$HOME")
chdir(homedir)
abshomedir = getcwd()
chdir(currentdir)

clusterDictFile1 = currentdir+"/clusterDict.py"
clusterDictFile2 = abshomedir+"/clusterDict.py"
if isfile(clusterDictFile1):
    execfile(clusterDictFile1)
elif isfile(clusterDictFile2):
    execfile(clusterDictFile2)

# hostnames sorted with decreasing speed
items = clusterDict.items()
items.sort(lambda x,y: cmp(x[1][1],y[1][1]))
items.reverse()
clusterHostNames = map(lambda x: x[0], items)

sumMHz = 0.
numProc = 0
procHostList = []
print "Gathering cluster status information ..."
for hostname in clusterHostNames:
    if numProc >= maxProc:
        break
    uptime = strip(getoutput("ssh -o StrictHostKeyChecking=no -f -x "+hostname+" uptime"))
    if find(uptime, "No route to host") == -1 and find(uptime, "Name or service not known") == -1:
        numProcessors = clusterDict[hostname][0]
        loadAvg_1min = float(split(uptime)[-3][:-1])     # 3rd last entry, remove comma
        numFreeProcessors = int(floor(numProcessors + 0.3 - loadAvg_1min))
        for i in range(min(numFreeProcessors, maxProc-numProc)):
            numProc += 1
            procHostList.append(hostname)
            speed = clusterDict[hostname][1]
            sumMHz += speed
print numProc, "procs with", int(sumMHz/numProc),"MHz per proc"
print

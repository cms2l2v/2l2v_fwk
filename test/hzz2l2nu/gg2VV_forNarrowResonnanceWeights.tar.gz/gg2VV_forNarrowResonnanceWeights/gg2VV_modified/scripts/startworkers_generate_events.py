# python startworkers_generate_events.py <executable> [<maxNumberOfWorkers>]

from sys import argv, exit
from os import chdir, getcwd, system, symlink
from os.path import abspath, isfile, expandvars, dirname, basename, lexists
from string import *
from time import sleep
from commands import getoutput
from math import floor

assert isfile("/usr/bin/nice")

def command(host, this_executable_name):
    return "ssh -o StrictHostKeyChecking=no -f -x " + host + " \"(cd "+ executable_path +"; /usr/bin/nice -n 19 ./" + this_executable_name + ")\" < /dev/null &> " + this_executable_name + "_" + host + ".out"

if len(argv) not in [2, 3]:
    print "usage: python startworkers_generate_events.py <executable> [<maxNumberOfWorkers>]"
    exit(1)

if len(argv) == 2:
    maxNumWorkers = 1000000     # use all available processors/cores
else:    
    maxNumWorkers = int(argv[2])

currentdir = getcwd()
absexecutable = abspath(argv[1])
homedir = expandvars("$HOME")
chdir(homedir)
abshomedir = getcwd()
executable = replace(absexecutable, abshomedir, homedir, 1)
executable_path = dirname(executable)
executable_name = basename(executable)
chdir(currentdir)

assert isfile(executable)

clusterDictFile1 = currentdir+"/clusterDict.py"
clusterDictFile2 = abshomedir+"/clusterDict.py"
if isfile(clusterDictFile1):
    execfile(clusterDictFile1)
elif isfile(clusterDictFile2):
    execfile(clusterDictFile2)

# hostnames sorted with decreasing speed
items = clusterDict.items()
items.sort(lambda x,y: cmp(x[1][1],y[1][1]))
items.reverse()
clusterHostNames = map(lambda x: x[0], items)

sumMHz = 0.
numProc = 0
procHostList = []
print "Gathering cluster status information ..."
for hostname in clusterHostNames:
    if numProc >= maxNumWorkers:
        break
    uptime = strip(getoutput("ssh -o StrictHostKeyChecking=no -f -x "+hostname+" uptime"))
    if find(uptime, "No route to host") == -1 and find(uptime, "Name or service not known") == -1:
        numProcessors = clusterDict[hostname][0]
        loadAvg_1min = float(split(uptime)[-3][:-1])     # 3rd last entry, remove comma
        numFreeProcessors = int(floor(numProcessors + 0.3 - loadAvg_1min))
        for i in range(min(numFreeProcessors, maxNumWorkers-numProc)):
            numProc += 1
            procHostList.append(hostname)
            speed = clusterDict[hostname][1]
            sumMHz += speed
print numProc, "procs with", int(sumMHz/numProc),"MHz per proc"
print

# write used computer names to a file, which can be used by a monitor command
# and the stopworkers command (they can read the file)
hostfile = open(executable_path + "/" + executable_name + ".hosts", 'w+')
numWorkers = 0
seed = 1
for host in procHostList:
    print host#, speed
    this_executable_name = executable_name + "_" + str(seed)
    if not lexists(this_executable_name):
        symlink(executable_name, this_executable_name)
    seedfile = open(this_executable_name+".rngseed", "w+")
    seedfile.write(str(seed))
    seedfile.close()
    commandString = command(host, this_executable_name)
    #print commandString
    retval = system(commandString)
    hostfile.write(host + "\n")
    assert retval == 0
    numWorkers += 1
    seed += 1
assert numWorkers == numProc

print
print "done: all workers have been started"
print
print "when jobs have finished run script combine_event_files.py"

# python combine_event_files.py <executable>

from sys import argv, exit
from string import *
from os.path import isfile

if len(argv) != 2:
    print "usage: python combine_event_files.py <executable>"
    exit(1)

executable = argv[1]

f = executable + ".hosts"
assert isfile(f)
hosts = []
for line in open(f).readlines():
    hosts.append(strip(line))

eventFiles = []
for i in range(len(hosts)):
    file = executable+"_"+str(i+1)+"_unweightedEvents.dat"
    assert isfile(file)
    eventFiles.append(file)

startTag = '<LesHouchesEvents version="1.0">\n'
endTag = '</LesHouchesEvents>\n'

def getInitList(s):
    s1 = split(split(s, '</init>')[0], '<init>')[1]
    return split(s1)

s = open(eventFiles[0]).read()
sList = getInitList(s)
initFirstLine = join(sList[0:10], ' ') + '\n'
initSecondLineEnd = ' ' + join(sList[12:14], ' ') + '\n'

sumVal = 0.
maxError = 0.
for ef in eventFiles:
    s = open(ef).read()
    sList = getInitList(s)
    val, err = sList[10:12]
    print ef, val, err
    val = float(val)
    err = float(err)
    sumVal += val
    maxError = max(maxError, err)
print
avgVal = sumVal/len(eventFiles)
print "avgXS +- maxErr [pb] =", avgVal,"+-",maxError

initSecondLine = str(avgVal) + " " + str(maxError) + initSecondLineEnd
initBlock = '<init>\n' + initFirstLine + initSecondLine + '</init>\n'
outfile = executable+"_unweightedEvents.dat"
fout = open(outfile, 'w+')
fout.write(startTag)
fout.write(initBlock)
for ef in eventFiles:
    s = open(ef).read()
    sEvents = strip(split(split(s, '</init>')[1], '</LesHouchesEvents>')[0])+'\n'
    fout.write(sEvents)
fout.write(endTag)
print
print "combined event file",outfile,"written"

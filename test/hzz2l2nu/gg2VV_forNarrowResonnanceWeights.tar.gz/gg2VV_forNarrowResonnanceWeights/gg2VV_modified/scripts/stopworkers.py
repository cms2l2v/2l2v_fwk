from sys import argv
from os import system
from os.path import isfile, basename
from string import strip
assert len(argv) == 2     # python stopworkers.py <exec>

thisFileName = basename(argv[0])
executable_name = argv[1]
hosts = open(executable_name+".hosts").readlines()
hosts = map(lambda x: strip(x), hosts)     # remove end-of-line character
hosts = dict.fromkeys(hosts).keys()        # remove duplicates
for host in hosts:
    command = "ssh -o StrictHostKeyChecking=no -n " + host + " \"ps -ewo user,pid,command | grep \"$USER\" | grep "+ executable_name +" | grep -v "+ thisFileName +" | awk '{print \\\"kill -TERM \\\",\$2}' | bash \""
    print host
    print command
    system(command)


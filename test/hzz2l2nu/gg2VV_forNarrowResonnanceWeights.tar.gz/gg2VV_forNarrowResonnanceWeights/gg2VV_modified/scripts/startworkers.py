from sys import argv, exit
from os import chdir, getcwd, system
from os.path import abspath, isfile, expandvars, dirname, basename
from string import *
from time import sleep
from commands import getoutput
from math import floor

if isfile("/usr/bin/nice"):
    nicecmd = "/usr/bin/nice"
elif isfile("/bin/nice"):
    nicecmd = "/bin/nice"
else:
    assert false

def command(host, speed):
    return "ssh -o StrictHostKeyChecking=no -f -x " + host + " \"(cd "+ executable_path +"; "+nicecmd+" -n 19 ./" + executable_name + " -w -s"+ str(speed) +")\" < /dev/null &> /dev/null"

def commandEqualSpeed(host):
    return "ssh -o StrictHostKeyChecking=no -f " + host + " \"(cd "+ executable_path +"; "+nicecmd+" -n 19 ./" + executable_name + " -w )\" &> /dev/null"

if len(argv) not in [2, 3]:
    print "usage: python startworkers.py <executable> [<maxCPU>]"
    exit(1)

maxProc = 1000     # use at most 1000 processors by default
if len(argv) == 3:
    maxProc = int(argv[2])

currentdir = getcwd()
absexecutable = abspath(argv[1])
homedir = expandvars("$HOME")
chdir(homedir)
abshomedir = getcwd()
executable = replace(absexecutable, abshomedir, homedir, 1)
executable_path = dirname(executable)
executable_name = basename(executable)
chdir(currentdir)

assert isfile(executable)

clusterDictFile1 = currentdir+"/clusterDict.py"
clusterDictFile2 = abshomedir+"/clusterDict.py"
if isfile(clusterDictFile1):
    execfile(clusterDictFile1)
elif isfile(clusterDictFile2):
    execfile(clusterDictFile2)

# hostnames sorted with decreasing speed
items = clusterDict.items()
items.sort(lambda x,y: cmp(x[1][1],y[1][1]))
items.reverse()
clusterHostNames = map(lambda x: x[0], items)

sumMHz = 0.
numProc = 0
procHostList = []
print "Gathering cluster status information ..."
for hostname in clusterHostNames:
    if numProc >= maxProc:
        break
    uptime = strip(getoutput("ssh -o StrictHostKeyChecking=no -f -x "+hostname+" uptime"))
    if find(uptime, "No route to host") == -1 and find(uptime, "Name or service not known") == -1 and find(uptime, "Input/output error") == -1:
        numProcessors = clusterDict[hostname][0]
        loadAvg_1min = float(split(uptime)[-3][:-1])     # 3rd last entry, remove comma
        numFreeProcessors = int(floor(numProcessors + 0.3 - loadAvg_1min))
        for i in range(min(numFreeProcessors, maxProc-numProc)):
            numProc += 1
            procHostList.append(hostname)
            speed = clusterDict[hostname][1]
            sumMHz += speed
print numProc, "CPUs with", int(sumMHz/numProc),"MHz per CPU"
print

# write used computer names to a file, which can be used by a monitor command
# and the stopworkers command (they can read the file)
open(executable_name+".workers", "w+").close()     # create or truncate
hostfile = open(executable_path + "/" + executable_name + ".hosts", 'w+')
numWorkers = 0
for host in procHostList:
    speed = clusterDict[host][1]
    commandString = command(host, speed)
    #commandString = commandEqualSpeed(host)
    print host#, speed
    #print commandString
    retval = system(commandString)
    hostfile.write(host + "\n")
    assert retval == 0
    while int(getoutput("grep -c . "+executable_name+".workers")) < (numWorkers + 1):
        pass
    numWorkers += 1
assert numWorkers == numProc

print
print "command to start master process:"
print nicecmd+" -n 19 ./" + executable_name + " -m < /dev/null &> " + executable_name + ".out &"
print "cls; tail -f " + executable_name + ".out"
sleep(15)

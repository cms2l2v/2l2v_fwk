from sys import argv
from os import chdir, system, getcwd
from os.path import abspath, expandvars, dirname
from string import strip, split
from commands import getoutput
assert len(argv) == 1     # python cleanup.py

currentdir = getcwd()
homedir = expandvars("$HOME")
chdir(homedir)
abshomedir = getcwd()
chdir(currentdir)

clusterDictFile1 = currentdir+"/clusterDict.py"
clusterDictFile2 = abshomedir+"/clusterDict.py"
if isfile(clusterDictFile1):
    execfile(clusterDictFile1)
elif isfile(clusterDictFile2):
    execfile(clusterDictFile2)

clusterHostNames = map(lambda x: x[0], clusterDict.items())

this_host = split(expandvars("$HOSTNAME"), '.')[0]
if this_host in clusterHostNames:
    clusterHostNames.remove(this_host)

for hostname in clusterHostNames:
    command = "ssh -o StrictHostKeyChecking=no -n -q " + hostname + " \"ps -eo user,pid | grep \"$USER\" | awk '{print \\\"kill -TERM \\\",\$2}' | bash \""
    print hostname
    #print command
    system(command)

from string import *
from os.path import isfile
from commands import getoutput
from sys import exit, stdout

login = "kauer"

def processCpuInfo(cpuinfo):
    nrProcs = 0
    clockSpeed = 0
    for line in split(cpuinfo, "\n"):
        if line == "":
            continue
        colonPos = find(line, ":")
        assert colonPos != -1
        if strip(line[:colonPos]) == "processor":
            nrProcs += 1
        if strip(line[:colonPos]) == "cpu MHz":
            thisClockSpeed = float(strip(line[(colonPos+1):]))
            if clockSpeed == 0:
                clockSpeed = thisClockSpeed
            elif abs(thisClockSpeed - clockSpeed) < 2:
                continue
            elif thisClockSpeed > clockSpeed:
                clockSpeed = thisClockSpeed
                nrProcs = 1
            elif thisClockSpeed < clockSpeed:
                nrProcs -= 1
    assert nrProcs > 0 and clockSpeed > 0
    return (nrProcs, clockSpeed)
    
def getNumberOfProcsAndClockSpeed(hostname):
    test = strip(getoutput("ssh -o StrictHostKeyChecking=no -f -x "+hostname+' \'( [ -e "/proc/cpuinfo" ] && echo "exists" ) || echo "missing"\''))
    if test == "exists":
        cpuinfo = getoutput("ssh -o StrictHostKeyChecking=no -f -x -l "+login+" "+hostname+" cat /proc/cpuinfo")
        nrProcs, clockSpeed = processCpuInfo(cpuinfo)
    elif test == "missing":
        print "error: /proc/cpuinfo not found on",hostname,"(Linux?)"
        exit()
    else:
        nrProcs, clockSpeed = (0, 0) # errors like "ssh: connect to host XXXX port 22: No route to host"
    return (nrProcs, clockSpeed)

input_filename = "hostnames.txt"
assert isfile(input_filename)
hostnames = []
for line in open(input_filename).readlines():
    for string in split(replace(line,","," ")):
        hostnames.append(string)
print "This could take a few minutes ..."
items = []
for hostname in hostnames:
    print "\n"+hostname,
    stdout.flush()
    nrProcs, clockSpeed = getNumberOfProcsAndClockSpeed(hostname)
    if nrProcs == 0 and clockSpeed == 0:
        print "failed",
        continue
    print "("+str(nrProcs)+", "+str(int(clockSpeed))+")",
    if nrProcs > 0 and clockSpeed > 999.:
        items.append((hostname, (nrProcs, clockSpeed)))
        print "added",
items.sort()
items = map(lambda x: '"'+x[0]+'": '+str(x[1]), items)
outString= join(items,",\n")
open("clusterDict.py","w").write("clusterDict = {\n"+outString+"\n}\n")

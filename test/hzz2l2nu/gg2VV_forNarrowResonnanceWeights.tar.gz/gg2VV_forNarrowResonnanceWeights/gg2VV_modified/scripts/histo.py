# histo.py
# generates HBOOK style histogram output from Histo printout
# usage:
# python histo.py (prompts for input and output filenames)
# python histo.py <input_file> (format: somename.dat)
# dots in 1-dim histograms indicate error bars

from string import *
from math import sqrt, floor, log10, ceil
from sys import exit  # for testing
from types import FloatType, IntType
from sys import argv

def stripL(s):
    return replace(s, 'L', '')

def sum(x):
    return reduce(lambda x, y: x+y, x)

class CharRec:
    """character rectangle"""
    def __init__(self, x_len, y_len):
        self.nx = x_len
        self.ny = y_len
        row = self.ny*[' ']  # init with blanks
        self.chars = []
        for i in range(self.nx):
            self.chars = self.chars + [row[:]]
    def inschar(self, char, x_y):
        """insert character"""
        x, y = x_y
        assert 0 <= x and x < self.nx and 0 <= y and y < self.ny
        self.chars[x][y] = char
    def insstr(self, str, x_y, down = 0):
        """insert string"""
        x, y = x_y
        for char in str:
            self.inschar(char, (x, y))
            if down:
                x = x + 1
            else:
                y = y + 1
    def insrec(self, rec, x_y):
        """insert rectangle"""
        x, y = x_y
        for i in range(rec.nx):
            for j in range(rec.ny):
                self.inschar(rec.chars[i][j], (x+i,y+j))
    def string(self):
        """return rectangle as string"""
        string = ""
        for x in range(self.nx):
            string = string + sum(self.chars[x])+"\n"
        return string
    def flip(self):
        """flip rectangle upside-down"""
        for j in range(self.ny):
            col = []
            for i in range(self.nx):
                col.append(self.chars[i][j])
            col.reverse()
            for i in range(self.nx):
                self.chars[i][j] = col[i]
    def getchar(self, x_y):
        """insert character"""
        x, y = x_y
        assert 0 <= x and x < self.nx and 0 <= y and y < self.ny
        return self.chars[x][y]

# number helper functions ------------------------------------------------------
def sign_str(x):
    """returns sign string to prefix number string with, if any"""
    if x > 0.0:
        return "+"
    elif x==0.0:
        return " "
    else:  # x negative
        return ""

def rndsig_str(x, sig_digits = 3):
    if type(x) is not FloatType:
        stderr.write("rndsig: 1st arg not float: ("+str(x)+", "+str(sig_digits)+")\n")
        return "err"
    if type(sig_digits) is not IntType:
        stderr.write("rndsig: 2nd arg not int: ("+str(x)+", "+str(sig_digits)+")\n")
        return "err"
    if (x <= 0.):
        return "0."
    else:
        base = floor(log10(x))
        rnd_point = -(base - sig_digits + 1)
        format_string = "%."+str(int(max(rnd_point,0)))+"f"
        return (format_string % round(x, rnd_point))
# ------------------------------------------------------------------------------

class Partition:
    """partition information (fixed width bins)"""
    def __init__(self, lower, upper, width, nbin):
        assert nbin * width > 0. and upper >= lower 
        assert abs((upper - lower)/(nbin * width) - 1.) < 1.e-13
        self.lower = lower
        self.upper = upper
        self.bin_width = width
        self.bin_count = nbin
    def bin_lower(self, index):
        return self.lower + self.bin_width * index
    def bin_center(self, index):
        return self.bin_lower(index)+0.5*self.bin_width
    def bin_upper(self, index):
        return self.bin_lower(index)+self.bin_width

class RawBin:
    """bin"""
    def __init__(self, density, error, chiSquarePerIteration):
        self.density = density
        self.error = error
        self.chiSquarePerIteration = chiSquarePerIteration

class Bin(RawBin):
    """bin in a partition"""
    def __init__(self, index, density, error, chiSquarePerIteration):
        RawBin.__init__(self, density, error, chiSquarePerIteration)
        self.index = index
        
    def get_x_values(self, partition):
        assert 0 <= self.index and self.index < partition.bin_count
        self.lower = partition.bin_lower(self.index)
        self.upper = partition.bin_upper(self.index)
        self.center = partition.bin_center(self.index)

class Histo:
    """fixed-bin width histogram information"""
    def __init__(self, description, partition, in_range_Bins, out_of_range):
        """histogram info and data"""
        self.dim = 1
        self.description = description
        self.part = partition
        self.bins = in_range_Bins     # map
        for bin in self.bins.values():
            bin.get_x_values(self.part)
        assert len(out_of_range) == 1 or len(out_of_range) == 2
        if len(out_of_range) == 1:
            self.simple_out_of_range = 1
            self.number_of_out_of_range_entries = out_of_range[0]
        elif len(out_of_range) == 2:
            self.simple_out_of_range = 0
            self.underflow_Bin, self.overflow_Bin = out_of_range
        if not self.simple_out_of_range:
            self.underflow = self.underflow_Bin.density
            self.overflow = self.overflow_Bin.density
        else:
            self.underflow = self.overflow = None
        values = map(lambda bin: bin.density, self.bins.values())
        self.tot_val = sum(values)
        self.tot_err = sqrt(sum(map(lambda bin: bin.error**2, self.bins.values())))
        self.min_val = min(values)
        self.max_val = max(values)
        # calculate mean and rms if values can be interpreted as weights
        if (self.dim == 1 and self.tot_val > 0.
            and reduce(lambda x,y: x and y, map(lambda x: x >= 0.0, values))):
            self.mean = sum(map(lambda bin: bin.center*bin.density, self.bins.values()))/self.tot_val
            self.rms = sqrt(sum(map(lambda bin: bin.center**2 * bin.density, self.bins.values()))/self.tot_val)
        else:
            self.mean = self.rms = 0. 

# to_hbook ---------------------------------------------------------------------
def expnt(x):
    return int(floor(log10(x)))

def rnd1sig(x):
    """round to 1 significant digit"""
    return round(x, -expnt(x))

def e_floor(x, e):
    return floor(x*10**(-e))*10**e

def e_ceil(x, e):
    return ceil(x*10**(-e))*10**e

def format(x, nd):
    s = str(x)
    if s[:2] == "0.": s = s[1:]
    if s[-1] == "0": s = s[:-1]
    return s + (nd-(len(s)-find(s,'.')-1)) * ' '

def format_number(number, nrows):
    assert nrows >= 1
    string = (("%."+str(nrows-1)+"e") % number)
    digits, expnt = split(string, 'e')
    digits = replace(digits,'.','')
    expnt = int(expnt)
    return (digits, expnt)
    
def numbers_rectangle(number_list, nrows):
    rec = CharRec(nrows,len(number_list))
    max_number = max(number_list)
    max_expnt = format_number(max_number, nrows)[1]
    for i in range(len(number_list)):
        number = number_list[i]
        assert number >= 0.0
        if number != 0.0:
            digits, expnt = format_number(number, nrows)
            try:
                assert len(digits) == nrows and expnt <= max_expnt
            except:
                print expnt, max_expnt, number, max_number
            new_digits = min(max_expnt-expnt,nrows)*' '
            new_digits = new_digits + digits[:(nrows-len(new_digits))]
        else:
            new_digits = nrows*' '
        rec.insstr(new_digits, (0,i), 1)
    return (rec, max_expnt)

def labels_rectangle((nrows, left_bar_width), max_expnt):
    labels = CharRec(nrows, left_bar_width)
    if max_expnt-nrows+1 < 0:  # have neg expnts
        sigchar = [' ', '']
    else:
        sigchar = ['']
    for i in range(nrows):
        label = "10^"+sigchar[max_expnt<0]+str(max_expnt)
        labels.insstr(label, (i, left_bar_width-len(label)))
        max_expnt = max_expnt-1
    return labels
    
def graph_1d(histo):
    """draw y axis labels and graph"""
    def_height = 32  # default height in chars
    max_height = 40  # lines than fit on screen
    # get y axis labels =======================
    vrange = histo.max_val - histo.min_val
    if vrange > 0.0:
        vdelta = vrange/def_height
        vunit = rnd1sig(vdelta)
        e = expnt(vunit)
        minval = e_floor(histo.min_val, e)
        maxval = e_ceil(histo.max_val, e)
        vrange = maxval - minval
        vdelta_min = vrange/max_height
        while vunit < vdelta_min:
            vunit = vunit + 10**e
        height = int(ceil(vrange/vunit))
        maxval = minval + height * vunit
        labels = []
        for i in range(height):
            nr = minval + (i+1) * vunit
            labels.append(format(nr,-int(e)))
    else:
        height = 1
        minval = maxval = histo.max_val
        labels = [rndsig_str(minval)]
    # improvement: limit vunit to values that lead to
    # small integral multiples, i.e. 0.1, 0.2, 0.4, 0.5
    max_len_labels = max(map(lambda x: len(x), labels))
    left_bar_width = 12  # sync with numbers_1d()
    assert 1+max_len_labels <= left_bar_width
    y_legend = CharRec(height, left_bar_width)
    line = 0
    labels.reverse()
    for label in labels:
        y_legend.insstr(rjust(label, left_bar_width-1), (line,1))
        line = line + 1
    # get graph ===============================
    nbin = histo.part.bin_count
    graph = CharRec(height,nbin)
    last_idx = 0
    y_idx_dict = {}
    for idx in range(nbin):
        this_val = histo.bins[idx].density
        if this_val != minval and this_val != maxval:
            this_idx = int((this_val-minval)/vunit)
        elif this_val == minval:
            this_idx = 0
        else:  # this_val == maxval
            this_idx = height-1
        y_idx_dict[idx] = this_idx  # for error bars
        if this_idx == last_idx or idx == 0:
            graph.inschar('-',(this_idx,idx))
        elif this_idx > last_idx:
            graph.inschar('I',(last_idx,idx))
            last_idx = last_idx + 1
            while this_idx > last_idx:
                graph.inschar('I',(last_idx,idx))
                last_idx = last_idx + 1
            graph.inschar('-',(this_idx,idx))
        elif this_idx < last_idx:
            last_idx = last_idx - 1
            graph.inschar('I',(last_idx,idx-1))
            while this_idx < last_idx:
                last_idx = last_idx - 1
                graph.inschar('I',(last_idx,idx-1))
            graph.inschar('-',(this_idx,idx))
        last_idx = this_idx
    # simple algorithm for error bar, may be off +/- 1 vunit
    for idx in range(nbin):
        if vrange > 0.0:
            del_idx = int(ceil(histo.bins[idx].error/vunit))
        else:
            del_idx = 0  # no error bars for constant graph
        low_idx = max(y_idx_dict[idx]-del_idx, 0)
        high_idx = min(y_idx_dict[idx]+del_idx, graph.nx-1)
        for y_idx in range(low_idx, high_idx+1):
            if graph.getchar((y_idx,idx)) == ' ': graph.inschar('.',(y_idx,idx))
    graph.flip()
    # comine y_legend and graph into one rectangle
    assert y_legend.nx == graph.nx
    bar_padding = 2  # sync with numbers_1d()
    combined = CharRec(graph.nx, y_legend.ny+bar_padding+graph.ny)
    combined.insrec(y_legend, (0,0))
    combined.insrec(graph, (0,y_legend.ny+2))
    return combined.string()

def numbers_1d(histo):
    """draw various numbers for each bin"""
    left_bar_width = 12  # sync with graph_1d()
    bar_padding = 2      # sync with graph_1d()
    string = ""
    ch_label = "CHANNEL"
    start_string = ' '+ch_label
    nbin = histo.part.bin_count
    assert nbin < 1000
    string = ""
    if nbin/100 > 0:
        string = string + start_string + rjust("100",left_bar_width-len(start_string))+bar_padding*' '
        start_string = ' '+len(ch_label)*' '
        last = -1
        for i in range(1,nbin+1):
            this = i/100
            if this != last:
                string = string+str(this)
                last = this
            else:
                string = string+' '
        string = string + "\n"
    if nbin/10 > 0:
        string = string + start_string + rjust("10",left_bar_width-len(start_string))+bar_padding*' '
        start_string = ' '+len(ch_label)*' '
        last = -1
        for i in range(1,nbin+1):
            this = (i%100)/10
            if this != last:
                string = string+str(this)
                last = this
            else:
                string = string+' '
        string = string + "\n"
    string = string + start_string + rjust("1",left_bar_width-len(start_string))+bar_padding*' '
    for i in range(1,nbin+1):
        string = string + str((i%100)%10)
    string = string + "\n\n"

    nrows = 5
    content_nr_list = []
    integrat_nr_list = []
    low_edge_nr_list = []
    val_sum = 0.
    for idx in range(histo.part.bin_count):
        low_edge_nr_list.append(histo.bins[idx].lower)
        content_nr_list.append(histo.bins[idx].density)
        val_sum = val_sum + histo.bins[idx].density
        integrat_nr_list.append(val_sum * histo.part.bin_width)

    val_rec, max_expnt = numbers_rectangle(content_nr_list, nrows)
    labels_rec = labels_rectangle((nrows, left_bar_width), max_expnt)
    contents_rec = CharRec(nrows, labels_rec.ny+bar_padding+val_rec.ny)
    contents_rec.insrec(labels_rec, (0,0))
    contents_rec.insrec(val_rec, (0,labels_rec.ny+bar_padding))
    string = string + " CONTENTS\n"
    string = string + contents_rec.string() + "\n"

    int_rec, max_expnt = numbers_rectangle(integrat_nr_list, nrows)
    labels_rec = labels_rectangle((nrows, left_bar_width), max_expnt)
    integrat_rec = CharRec(nrows, labels_rec.ny+bar_padding+int_rec.ny)
    integrat_rec.insrec(labels_rec, (0,0))
    integrat_rec.insrec(int_rec, (0,labels_rec.ny+bar_padding))
    string = string + " INTEGRAT\n"
    string = string + integrat_rec.string() + "\n"

    nrows = 3
    low_edge_nr_neg_list = map(lambda x: x < 0.0, low_edge_nr_list)
    neg_nums = reduce(lambda x,y: x or y, low_edge_nr_neg_list)
    if neg_nums:
        low_edge_nr_list_pos = map(abs, low_edge_nr_list)
    else:
        low_edge_nr_list_pos = low_edge_nr_list
    lowedg_rec, max_expnt = numbers_rectangle(low_edge_nr_list_pos, nrows)
    labels_rec = labels_rectangle((nrows, left_bar_width), max_expnt)
    low_edge_rec = CharRec(nrows, labels_rec.ny+bar_padding+lowedg_rec.ny)
    low_edge_rec.insrec(labels_rec, (0,0))
    low_edge_rec.insrec(lowedg_rec, (0,labels_rec.ny+bar_padding))
    string = string + ljust(" LOW-EDGE", labels_rec.ny+bar_padding)
    if neg_nums:
        sigchar = [' ','-']
        for i in low_edge_nr_neg_list:
            string = string + sigchar[i]
    string = string + "\n"
    string = string + low_edge_rec.string()
    return string

def to_hbook(histo):
    """return string for 1D histo in HBOOK style"""
    string = "\nnext histo: "+histo.description+"\n\n"
    string = string + graph_1d(histo)
    string = string + "\n"
    string = string + numbers_1d(histo)
    string = string + "\n"
    string = string + "partition: "+str(histo.part.bin_count)+" bins from "\
             +str(histo.part.lower)+" to "+str(histo.part.upper)+"   bin width: "\
             +("%g" % histo.part.bin_width)+"\n"
    string = string + "total: sum = "+("%g" % histo.tot_val)+"   min = "+("%g" % histo.min_val)\
             +"   max = "+("%g" % histo.max_val)+"   mean = "+("%g" % histo.mean)+"   rms = "\
             +("%g" % histo.rms)+"\n"
    totalSum = histo.tot_val*histo.part.bin_width
    totalError = histo.tot_err*histo.part.bin_width
    if histo.underflow is not None:
        uflw_str = ("%g" % histo.underflow)
        totalSum = totalSum + histo.underflow
        totalError = sqrt(totalError**2 + histo.underflow_Bin.error**2)
    else:
        uflw_str = "?"
    if histo.overflow is not None:
        oflw_str = ("%g" % histo.overflow)
        totalSum = totalSum + histo.overflow
        totalError = sqrt(totalError**2 + histo.overflow_Bin.error**2)
    else:
        oflw_str = "?"
    string = string + "   sumInRange * binWidth = "+("%g" % (histo.tot_val*histo.part.bin_width))\
             +"   underflow = "+uflw_str+"   overflow = "+oflw_str+"\n"\
             +"(sumInRange + sumOutOfRange) * binWidth = "+("%g" % totalSum)\
             +" +/- "+("%g" % totalError)+"\n"
    string = string + "\n"
    return string

# to_topdrawer -----------------------------------------------------------------

def RawBin_to_string(rawBin):
    val = rawBin.density
    err = rawBin.error
    cspi = rawBin.chiSquarePerIteration
    if err > 0.:
        additional_info = ("  (  " + ljust("%.2g%%"%(err/val*100.), 8)
                           + "  " + ljust("%.2g"%cspi, 8))
    else:
        additional_info = ""
    return ljust("%.16g"%val, 22) + "  " + ljust("%.2g"%err, 8) + additional_info

def to_topdrawer(histo):
    """return string for 1D histo in topdrawer format"""
    s = "( " + histo.description + "   ***************************************\n"
    s = s + "set intensity 4\n"
    s = s + "set font duplex\n"
    s = s + "set tick size .05\n"
    s = s + "set window  x 2.5 to 9.0 y 3.0 to 8.0\n"
    s = s + "set limits y 0.\n"
    #s = s + "set limits x -1. to 1. y 0.001 to 10.\n"
    #s = s + "set scale y log\n"
    s = s + "set symbol 9O SIZE=1\n"
    s = s + "title 5.414 8.8 \"" + histo.description + "\n"
    s = s + "set order x y dy\n"
    s = s + ("(( partition: range = [" + str(histo.part.lower) + ", "
             + str(histo.part.upper) + "), bin size = " + str(histo.part.bin_width)
             + ", number of bins = " + str(histo.part.bin_count) + "\n")
    if histo.simple_out_of_range:
        s = s + ("( number of out-of-range entries (unweighted): "
                 + str(histo.number_of_out_of_range_entries) + "\n")
    else:
        s = s + "( underflow: " + RawBin_to_string(histo.underflow_Bin) + "\n"
        s = s + "( overflow:  " + RawBin_to_string(histo.overflow_Bin) + "\n"
    for index in range(histo.part.bin_count):
        bin = histo.bins[index]
        s = s + rjust(str(bin.center),7)+"  "+ RawBin_to_string(bin) + "\n"
    s = s + "join\n"
    s = s + "plot\n"
    s = s + "new frame\n\n\n"
    return s

# make_histo -------------------------------------------------------------------

def get_RawBin(s, bin_width = 1.0):
    """string to averaged data"""
    s = split(s)
    density = float(s[0])/bin_width
    error = float(s[1])/bin_width
    chiSquarePerIteration = float(s[2])
    return RawBin(density, error, chiSquarePerIteration)

def make_histo(s):
    """create histo from string"""
    in_range_Bins = {}
    underflow_overflow = 0
    simple_out_of_range = 0
    lines = split(s, '\n')
    for line in lines:
        line = split(line, '#', 1)[0]
        if line == "":
            continue
        components = split(line, ':', 1)
        if len(components) == 1:     # ':' not found
            key = "in-range bin"
            value = strip(components[0])
        else:
            key = strip(components[0])
            value = strip(components[1])
            
        if key == "title":
            title = value
        elif key == "partition":
            s = split(value)
            # equi-partition (lowest, next beyond highest, bin size, number of bins)
            partition = Partition(float(s[0]), float(s[1]), float(s[2]), int(s[3]))
        elif key == "in-range bin":
            s = split(value, ' ', 1)
            index = int(s[0]) - 1
            rb = get_RawBin(s[1], partition.bin_width)
            in_range_Bins[index] = Bin(index, rb.density, rb.error, rb.chiSquarePerIteration)
        elif key == "underflow":
            underflow_overflow = 1
            underflow_Bin = get_RawBin(value)
        elif key == "overflow":
            underflow_overflow = 1
            overflow_Bin = get_RawBin(value)
        elif key == "sum of out-of-range weights":
            simple_out_of_range = 1
            number_of_out_of_range_entries = float(value)

    if underflow_overflow and not simple_out_of_range:
        out_of_range = (underflow_Bin, overflow_Bin)
    elif not underflow_overflow and simple_out_of_range:
        out_of_range = (number_of_out_of_range_entries,)
    else:
        print "make_histo: not (either underflow_overflow or simple_out_of_range)"
        exit(1)
    return Histo(title, partition, in_range_Bins, out_of_range)

# main program -----------------------------------------------------------------

# get filenames and open output files
if len(argv) == 1:  # interactive mode
    input_filename = raw_input("input file: ")
    assert input_filename[-4:] == ".dat"
    hbook_filename_def = input_filename[:-4] + ".hbook"
    hbook_filename = raw_input("hbook output file ["+hbook_filename_def+"]: ")
    if hbook_filename == "":
        hbook_filename = hbook_filename_def
    topdrawer_filename_def = input_filename[:-4] + ".top"
    topdrawer_filename = raw_input(
        "topdrawer output file ["+topdrawer_filename_def+"]: ")
    if topdrawer_filename == "":
        topdrawer_filename = topdrawer_filename_def
else:
    if not (len(argv) == 2 and argv[1][-4:] == ".dat"):
        print "python histo.py <input_file> (format: somename.dat)"
        exit(1)
    input_filename = argv[1]
    hbook_filename = input_filename[:-4] + ".hbook"
    topdrawer_filename = input_filename[:-4] + ".top"
#fhbook = open(hbook_filename, 'w')
ftop = open(topdrawer_filename, 'w')

# process input file
copy_verbatim = 0
parsing_histo = 0
histo_buffer = ""
line_counter = 0
for line in open(input_filename).readlines():
    line_counter = line_counter + 1
    # switches
    if rstrip(line) == "============================================================":
        if parsing_histo:
            histo = make_histo(histo_buffer)
            #fhbook.write(to_hbook(histo))
            ftop.write(to_topdrawer(histo))
            parsing_histo = 0
            histo_buffer = ""
        else:
            parsing_histo = 1
        continue
    elif rstrip(line) == "############################################################":
        if copy_verbatim:
            copy_verbatim = 0
        else:
            copy_verbatim = 1
        continue
    # content
    if copy_verbatim and not parsing_histo:
        #fhbook.write(line)
        ftop.write("(" + line)
    elif parsing_histo and not copy_verbatim:
        histo_buffer = histo_buffer + line
    else:
        print "corrupt input file, detected at line:", line_counter
        print line
        exit(1)

from string import find, strip
from os import listdir

def removeProgressInFile(filename):
    inf = open(filename)
    lines = inf.readlines()
    inf.close()
    s = ""
    for line in lines:
        if find(line, "\b") == -1 and strip(line) != "100%":
            s += line
    outf = open(filename, 'w+')
    outf.write(s)
    outf.close()

files = listdir(".")

for f in files:
    if f[-4:] == ".out":
        removeProgressInFile(f)

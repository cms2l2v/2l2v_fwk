#ifndef GEOMETRY_H
#define GEOMETRY_H

#include <math.h>
#include <ostream>
using std::ostream;

#include "pi.h"
#include "small_powers.h"

// class template Lazy_double -----------------------------------

template<class C>
class Lazy_double
{
public:
  Lazy_double(const C& c, const double (*compute_double)(const C& c));
  Lazy_double& operator=(const Lazy_double& ld);
  
  const double get_value();
  void reset() { _value_is_unknown = true; }
private:
  bool _value_is_unknown;
  double _value;
  const C* _c;
  const double (*_compute_value)(const C& c);
};

// class ThreeVector --------------------------------------------

class ThreeVector 
{
public:
  ThreeVector();
  ThreeVector(double x, double y, double z);
  ThreeVector(const ThreeVector& tv);

  const double x() const;
  const double y() const;
  const double z() const;
  const double sqr() const;
  const double abs() const;

  ThreeVector& operator*=(double d);
  ThreeVector& operator/=(double d);
  ThreeVector& operator+=(const ThreeVector& tv);
  ThreeVector& operator-=(const ThreeVector& tv);

  ThreeVector& operator=(const ThreeVector& tv);
private:
  double _x;
  double _y;
  double _z;

  mutable Lazy_double<ThreeVector> _sqr;
  static const double c_sqr(const ThreeVector& tv);
  mutable Lazy_double<ThreeVector> _abs;
  static const double c_abs(const ThreeVector& tv);

  void reset_derived_variables();
};

inline const double ThreeVector::x() const { return _x; }

inline const double ThreeVector::y() const { return _y; }

inline const double ThreeVector::z() const { return _z; }

inline const double ThreeVector::sqr() const { return _sqr.get_value(); }

inline const double ThreeVector::abs() const { return _abs.get_value(); }

inline void ThreeVector::reset_derived_variables()
{
  _sqr.reset();
  _abs.reset();
}

// operators

inline const ThreeVector operator-(const ThreeVector& op) 
{
  return ThreeVector(-op.x(), -op.y(), -op.z());     // unary minus
}

inline const double operator*(const ThreeVector& op1, const ThreeVector& op2) 
{
  return op1.x()*op2.x() + op1.y()*op2.y() + op1.z()*op2.z();     // dot product
}

inline const ThreeVector operator*(double op1, const ThreeVector& op2) 
{
  return ThreeVector(op1*op2.x(), op1*op2.y(), op1*op2.z());
}

inline const ThreeVector operator*(const ThreeVector& op1, double op2) 
{
  return op2 * op1;
}

inline const ThreeVector operator/(const ThreeVector& op1, double op2)
{
  return ThreeVector(op1.x()/op2, op1.y()/op2, op1.z()/op2);
}

inline const ThreeVector operator+(const ThreeVector& op1, const ThreeVector& op2) 
{
  return ThreeVector(op1.x()+op2.x(), op1.y()+op2.y(), op1.z()+op2.z());
}

inline const ThreeVector operator-(const ThreeVector& op1, const ThreeVector& op2) 
{
  return ThreeVector(op1.x()-op2.x(), op1.y()-op2.y(), op1.z()-op2.z());
}

inline const bool operator==(const ThreeVector& op1, const ThreeVector& op2)
{
  return op1.x() == op2.x() && op1.y() == op2.y() && op1.z() == op2.z();
}

inline const bool operator!=(const ThreeVector& op1, const ThreeVector& op2)
{
  return !(op1 == op2);
}

// class FourVector ---------------------------------------------

class FourVector 
{
public:
  FourVector();
  FourVector(double t, double x, double y, double z);
  FourVector(const FourVector& fv);
  FourVector(double t, const ThreeVector& tv);
  
  const double t() const;
  const double x() const;
  const double y() const;
  const double z() const;
  const double sqr() const;
  const double abs() const;
  const FourVector flip() const;
  const ThreeVector vec() const;

  FourVector& operator*=(double d);
  FourVector& operator/=(double d);
  FourVector& operator+=(const FourVector& fv);
  FourVector& operator-=(const FourVector& fv);

  FourVector& operator=(const FourVector& fv);
private:
  double _t;
  ThreeVector _vec;
  
  mutable Lazy_double<FourVector> _sqr;
  static const double c_sqr(const FourVector& fv);
  mutable Lazy_double<FourVector> _abs;
  static const double c_abs(const FourVector& fv);

  void reset_derived_variables();
};

inline const double FourVector::t() const { return _t; }

inline const double FourVector::x() const { return _vec.x(); }

inline const double FourVector::y() const { return _vec.y(); }
                              
inline const double FourVector::z() const { return _vec.z(); }

inline const double FourVector::sqr() const { return _sqr.get_value(); }
                              
inline const double FourVector::abs() const { return _abs.get_value(); }

inline const FourVector FourVector::flip() const { return FourVector(_t, -_vec); }

inline const ThreeVector FourVector::vec() const { return _vec; }

inline void FourVector::reset_derived_variables()
{
  _sqr.reset();
  _abs.reset();
}

// operators

inline const FourVector operator-(const FourVector& op) 
{
  return FourVector(-op.t(), -op.vec());     // unary minus
}

inline const double operator*(const FourVector& op1, const FourVector& op2) 
{
  return op1.t()*op2.t() - op1.vec()*op2.vec();     // dot product
}

inline const FourVector operator*(double op1, const FourVector& op2) 
{
  return FourVector(op1*op2.t(), op1*op2.vec());
}

inline const FourVector operator*(const FourVector& op1, double op2) 
{
  return op2 * op1;
}

inline const FourVector operator/(const FourVector& op1, double op2)
{
  return FourVector(op1.t()/op2, op1.vec()/op2);
}

inline const FourVector operator+(const FourVector& op1, const FourVector& op2) 
{
  return FourVector(op1.t()+op2.t(), op1.vec()+op2.vec());
}

inline const FourVector operator-(const FourVector& op1, const FourVector& op2) 
{
  return FourVector(op1.t()-op2.t(), op1.vec()-op2.vec());
}

inline const bool operator==(const FourVector& op1, const FourVector& op2)
{
  return op1.t() == op2.t() && op1.vec() == op2.vec();
}

inline const bool operator!=(const FourVector& op1, const FourVector& op2)
{
  return !(op1 == op2);
}

const FourVector boost(const FourVector& p, const FourVector& r, const bool reverse_r = false);

inline const FourVector map_to_float(const FourVector& p)
{
  return FourVector(float(p.t()), float(p.x()), float(p.y()), float(p.z()));
}

// class FourMomentum -------------------------------------------

class FourMomentum
{
public:
  FourMomentum();
  FourMomentum(double E, double px, double py, double pz);
  FourMomentum(const FourMomentum& fm);
  FourMomentum(const FourVector& fv);     // implicit
  FourMomentum(double E, const ThreeVector& pvec);

  const double E() const;       // energy
  const double px() const;      // x momentum component
  const double py() const;      // y momentum component
  const double pz() const;      // z momentum component
  const FourMomentum flip() const;
  const FourVector fvec() const;
  operator FourVector() const;     // implicit

  const double m() const;       // mass := sqrt(p.p)
  const double m_signed() const; // signed mass := sqrt(|p.p|)*sign(p.p)
  const double pt() const;      // transverse momentum
  const double pabs() const;    // absolute momentum |p_vec|
  const double mt() const;      // transverse mass
  const double Et() const;      // transverse energy

  const double m2() const;      // mass squared
  const double pt2() const;
  const double pabs2() const;
  const double mt2() const;

  const double eta() const;     // pseudorapidity
  const double y() const;       // rapidity
  const double phi() const;     // azimuthal angle (in rad)

  const bool m_less(double ref_mass) const;
  const bool m_greater(double ref_mass) const;
    
  FourMomentum& operator*=(double d);
  FourMomentum& operator/=(double d);
  FourMomentum& operator+=(const FourMomentum& fm);
  FourMomentum& operator-=(const FourMomentum& fm);

  FourMomentum& operator=(const FourMomentum& fm);
private:
  FourVector _fvec;

  mutable Lazy_double<FourMomentum> _pt;
  static const double c_pt(const FourMomentum& fm);
  mutable Lazy_double<FourMomentum> _mt;
  static const double c_mt(const FourMomentum& fm);
              
  mutable Lazy_double<FourMomentum> _pt2;
  static const double c_pt2(const FourMomentum& fm);
  mutable Lazy_double<FourMomentum> _mt2;
  static const double c_mt2(const FourMomentum& fm);
              
  mutable Lazy_double<FourMomentum> _eta;
  static const double c_eta(const FourMomentum& fm);
  mutable Lazy_double<FourMomentum> _y;
  static const double c_y(const FourMomentum& fm);
  mutable Lazy_double<FourMomentum> _phi;
  static const double c_phi(const FourMomentum& fm);

  void reset_derived_variables();
};

inline const double FourMomentum::E() const { return _fvec.t(); }

inline const double FourMomentum::px() const { return _fvec.x(); }

inline const double FourMomentum::py() const { return _fvec.y(); }

inline const double FourMomentum::pz() const { return _fvec.z(); }

inline const FourMomentum FourMomentum::flip() const
{
  return FourMomentum(_fvec.flip());
}

inline const FourVector FourMomentum::fvec() const { return _fvec; }

inline FourMomentum::operator FourVector() const { return _fvec; }

inline const double FourMomentum::m() const { return _fvec.abs(); }

inline const double FourMomentum::m_signed() const { return ((_fvec.sqr() < 0.) ? -sqrt(-_fvec.sqr()) : _fvec.abs()); }

inline const double FourMomentum::m2() const { return _fvec.sqr(); }

inline const double FourMomentum::pabs() const { return _fvec.vec().abs(); }

inline const double FourMomentum::pabs2() const { return _fvec.vec().sqr(); }

inline const double FourMomentum::pt() const { return _pt.get_value(); }

inline const double FourMomentum::mt() const { return _mt.get_value(); }

inline const double FourMomentum::pt2() const { return _pt2.get_value(); }

inline const double FourMomentum::mt2() const { return _mt2.get_value(); }

inline const double FourMomentum::eta() const { return _eta.get_value(); }

inline const double FourMomentum::y() const { return _y.get_value(); }

inline const double FourMomentum::phi() const { return _phi.get_value(); }

inline const double FourMomentum::Et() const { return E()*pt()/pabs(); }

inline const bool FourMomentum::m_less(double ref_mass) const
{
  return m2() < pow2(ref_mass);
}

inline const bool FourMomentum::m_greater(double ref_mass) const
{
  return m2() > pow2(ref_mass);
}

inline void FourMomentum::reset_derived_variables()
{
  _pt.reset();
  _mt.reset();
  _pt2.reset();
  _mt2.reset();
  _eta.reset();
  _y.reset();
  _phi.reset();
}

inline const bool operator==(const FourMomentum& op1, const FourMomentum& op2)
{
  return op1.fvec() == op2.fvec();
}

inline const bool operator!=(const FourMomentum& op1, const FourMomentum& op2)
{
  return !(op1 == op2);
}

inline const FourMomentum operator-(const FourMomentum& op1, const FourMomentum& op2) 
{
  return FourMomentum(op1.fvec()-op2.fvec());
}

ostream& operator<<(ostream& s, const FourMomentum& fm);

// class FourMomentumPair ---------------------------------------

#include "constvalue.h"

class FourMomentumPair
{
public:
  FourMomentumPair(const ConstValue<FourMomentum>& p1,
                   const ConstValue<FourMomentum>& p2);

  const double m() const;       // invariant mass
  const double m2() const;
  const double dot() const;     // p1.p2

  const double costh() const;   // angle between 3-momenta (in rad)
  const double dot3() const;    // (p1_vec).(p2_vec)
  
  const double Deta() const;    // delta pseudorapidity (pos. or neg.)
  const double Dy() const;      // delta rapidity (pos. or neg.)
  const double Dphi() const;    // delta phi (in rad, 0 <= dphi <= Pi)
  const double DR() const;      // separation in lego plot (eta, phi)
private:
  const ConstValue<FourMomentum>& _p1;
  const ConstValue<FourMomentum>& _p2;

  mutable Lazy_double<FourMomentumPair> _m;
  static const double c_m(const FourMomentumPair& fmp);
  mutable Lazy_double<FourMomentumPair> _m2;
  static const double c_m2(const FourMomentumPair& fmp);
  mutable Lazy_double<FourMomentumPair> _dot;
  static const double c_dot(const FourMomentumPair& fmp);

  mutable Lazy_double<FourMomentumPair> _costh;
  static const double c_costh(const FourMomentumPair& fmp);
  mutable Lazy_double<FourMomentumPair> _dot3;
  static const double c_dot3(const FourMomentumPair& fmp);

  mutable Lazy_double<FourMomentumPair> _Deta;
  static const double c_Deta(const FourMomentumPair& fmp);
  mutable Lazy_double<FourMomentumPair> _Dy;
  static const double c_Dy(const FourMomentumPair& fmp);
  mutable Lazy_double<FourMomentumPair> _Dphi;
  static const double c_Dphi(const FourMomentumPair& fmp);
  mutable Lazy_double<FourMomentumPair> _DR;
  static const double c_DR(const FourMomentumPair& fmp);

  FourMomentumPair(const FourMomentumPair&);
  FourMomentumPair& operator=(const FourMomentumPair&);
};

inline const double FourMomentumPair::m() const { return _m.get_value(); }

inline const double FourMomentumPair::m2() const { return _m2.get_value(); }

inline const double FourMomentumPair::dot() const { return _dot.get_value(); }

inline const double FourMomentumPair::costh() const { return _costh.get_value(); }

inline const double FourMomentumPair::dot3() const { return _dot3.get_value(); }

inline const double FourMomentumPair::Deta() const { return _Deta.get_value(); }

inline const double FourMomentumPair::Dy() const { return _Dy.get_value(); }

inline const double FourMomentumPair::Dphi() const { return _Dphi.get_value(); }

inline const double FourMomentumPair::DR() const { return _DR.get_value(); }

// Helper functions ---------------------------------------------

inline const double deg(const double& angle_rad)
{
  return angle_rad/Pi*180.;
}

inline const double rad(const double& angle_deg)
{
  return angle_deg/180.*Pi;
}

inline const double min(const double& x1, const double& x2)
{
  return (x1 < x2) ? x1 : x2;
}

inline const double max(const double& x1, const double& x2)
{
  return (x1 > x2) ? x1 : x2;
}

inline const double min(const double& x1, const double& x2, const double& x3)
{
  return min(min(x1, x2), x3);
}

inline const double max(const double& x1, const double& x2, const double& x3)
{
  return max(max(x1, x2), x3);
}

inline const double min(const double& x1, const double& x2, const double& x3, const double& x4)
{
  return min(min(x1, x2, x3), x4);
}

inline const double max(const double& x1, const double& x2, const double& x3, const double& x4)
{
  return max(max(x1, x2, x3), x4);
}

inline const double min(const double& x1, const double& x2, const double& x3,
                   const double& x4, const double& x5, const double& x6)
{
  return min(min(x1, x2, x3), min(x4, x5, x6));
}

inline const double non_neg(const double& x)
{
  return (x >= 0.0) ? x : 0.0;
}

inline const double sign(const double x)
{
  return (x >= 0.) ? +1. : -1.;
}

// Tests --------------------------------------------------------

void test_geometry();     // aborts if a test fails

#endif  /* GEOMETRY_H */

#include <string>
using std::string;
#include <cmath>
using std::fabs;

#include "check.h"
#include "geometry.h"
#include "kinematics.h"
void fatal_error(const string& s);     // utilities.h

void test_libkinematics()
{
  test_geometry();
  test_kinematics();
}

// helper functions ---------------------------------------------------

void check(const bool equal, const string& test_id)
{
  if (!equal)
    fatal_error("check failed: " + test_id);
}

void check(const double actual, const double expected, const string& test_id,
           const double acceptable_relative_error)
// default: acceptable_relative_error = 1.e-10
{
  const double error = (expected != 0.0) ?
    fabs((actual - expected)/expected) : fabs(actual);
  if (error > acceptable_relative_error)
    fatal_error("check failed: " + test_id);
}

void check(const FourVector& actual, const FourVector& expected, const string& test_id,
           const double acceptable_relative_error)
// default: acceptable_relative_error = 1.e-10
{
  check(actual.t(), expected.t(), test_id+": t", acceptable_relative_error);
  check(actual.x(), expected.x(), test_id+": x", acceptable_relative_error);
  check(actual.y(), expected.y(), test_id+": y", acceptable_relative_error);
  check(actual.z(), expected.z(), test_id+": z", acceptable_relative_error);
}


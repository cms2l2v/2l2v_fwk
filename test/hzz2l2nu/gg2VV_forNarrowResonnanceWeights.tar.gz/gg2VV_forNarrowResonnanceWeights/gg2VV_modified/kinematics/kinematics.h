#ifndef KINEMATICS_H
#define KINEMATICS_H

#include <vector>
using std::vector;
#include <cassert>
/* assert macro */

#include "geometry.h"

namespace MappingComponents
{
class Propagator
{
public:
  virtual void operator()(const double randomNumber, double& weight, const bool nwa = false) = 0;
  virtual void operator()(const double randomNumber, const double maxInvMass, double& weight, const bool nwa = false) = 0;
  virtual const double m() const = 0;
  virtual const double m2() const = 0;
  virtual const double minInvMass() const = 0;
  virtual const double mappedFunction(const double s) const = 0;
  virtual const double f(const double s) const = 0;
  virtual ~Propagator() {}
};

class Resonance : public Propagator
{
public:
  Resonance(const double mass, const double width, const double minInvMass, const double maxInvMass);
  Resonance(const double mass, const double width, const double maxInvMass);
  
  const double resonanceMass() const;
  const double resonanceMass2() const;
  const double x(const double s) const;
  const double s(const double x) const;
  const double ds_over_dx(const double s) const;
  const double mappedFunction(const double s) const;
  const double f(const double s) const;

  void operator()(const double randomNumber, double& weight, const bool nwa = false);
  void operator()(const double randomNumber, const double maxInvMass, double& weight, const bool nwa = false);
  const double m() const;
  const double m2() const;
  const double minInvMass() const;
private:
  void initialize(const double mass, const double width, const double minInvMass, const double maxInvMass);
  // fixed parameters:
  double _M;
  double _M2;
  double _minInvMass;
  double _maxInvMass;
  double _MGamma;
  double _xmin;
  // output:
  double _mass;
  double _mass_sqr;
};

inline const double Resonance::resonanceMass() const { return _M; }

inline const double Resonance::resonanceMass2() const { return _M2; }

inline const double Resonance::m() const { return _mass; }

inline const double Resonance::m2() const { return _mass_sqr; }

inline const double Resonance::minInvMass() const { return _minInvMass; }

// --------------------------------------------------------------------

namespace Massless
{
  const double x(const double s);
  const double s(const double x);
  const double ds_over_dx(const double s);  
  const double mappedFunction(const double s);
}

// --------------------------------------------------------------------

class ResonancePlusMassless : public Propagator
{
public:
  ResonancePlusMassless(const double mass, const double width, const double minInvMass, const double maxInvMass);
  const double mappedFunction(const double s) const;
  const double f(const double s) const;
  void operator()(const double randomNumber, double& weight, const bool nwa = false);
  void operator()(const double randomNumber, const double maxInvMass, double& weight, const bool nwa = false);
  const double m() const;
  const double m2() const;
  const double minInvMass() const;
  const Resonance& r() const;
private:
  Resonance _r;
  double _minInvMass;
  double _mappingBoundInvMass;
  bool _mappingBoundInvMassEqualsMinInvMass;
  const double getMappingBoundInvMass(const double mass, const double width);
  double _maxInvMass;
  // output:
  double _mass;
  double _mass_sqr;
};

inline const double ResonancePlusMassless::m() const { return _mass; }

inline const double ResonancePlusMassless::m2() const { return _mass_sqr; }

inline const double ResonancePlusMassless::minInvMass() const { return _minInvMass; }

inline const Resonance& ResonancePlusMassless::r() const { return _r; }

// --------------------------------------------------------------------

class TwoBodyDecay     // isotropic
{
public:
  void operator()(const double randomNumber1, const double randomNumber2,
                  const FourMomentum& in, const double mass1, const double mass2, 
                  double& weight);
  const FourVector p1() const;
  const FourVector p2() const;
private:
  bool _allowed;
  FourVector _out1;
  FourVector _out2;
};

inline const FourVector TwoBodyDecay::p1() const { assert(_allowed); return _out1; }

inline const FourVector TwoBodyDecay::p2() const { assert(_allowed); return _out2; }

// --------------------------------------------------------------------

class FinalStateParticle 
{
public:
  FinalStateParticle();
  FinalStateParticle(const double mass, const double mt_min);
  FinalStateParticle(const double nonZeroMass);     // mt_min = mass
  const double mass() const;
  const double mt_min() const;
  void set(const double nonZeroMass);
private:
  double _mass;
  double _mt_min;
};

inline const double FinalStateParticle::mass() const { return _mass; }

inline const double FinalStateParticle::mt_min() const { return _mt_min; }

// --------------------------------------------------------------------

class TwoToJetsAndResiduum
{
public:
  void operator()(const vector<double>& randomNumber, const double E_CMS,
                  const vector<FinalStateParticle>& jet,
                  const FinalStateParticle& res);
  const double E_partonCMS() const;
  const FourVector in1() const;
  const double x1() const;
  const FourVector in2() const;
  const double x2() const;
  const FourVector out(const int i) const;
  const FourVector out_res() const;
  const double weight() const;
private:
  bool _allowed;
  double _E_partonCMS;
  FourVector _in1;
  double _x1;
  FourVector _in2;
  double _x2;
  vector<FourVector> _out;
  FourVector _out_res;
  double _weight;
};

inline const double TwoToJetsAndResiduum::E_partonCMS() const { assert(_allowed); return _E_partonCMS; }

inline const FourVector TwoToJetsAndResiduum::in1() const { assert(_allowed); return _in1; }

inline const double TwoToJetsAndResiduum::x1() const { assert(_allowed); return _x1; }

inline const FourVector TwoToJetsAndResiduum::in2() const { assert(_allowed); return _in2; }

inline const double TwoToJetsAndResiduum::x2() const { assert(_allowed); return _x2; }

inline const FourVector TwoToJetsAndResiduum::out(const int i) const { assert(_allowed); return _out[i]; }

inline const FourVector TwoToJetsAndResiduum::out_res() const { assert(_allowed); return _out_res; }

inline const double TwoToJetsAndResiduum::weight() const { return _weight; }

// --------------------------------------------------------------------

class TwoToResonanceAndTwoBodyDecay
{
public:
  void operator()(const vector<double>& randomNumber, const double E_CMS,
		  const Resonance& res, const FinalStateParticle& fsp1,
		  const FinalStateParticle& fsp2);
  const double E_partonCMS() const;
  const FourVector in1() const;
  const double x1() const;
  const FourVector in2() const;
  const double x2() const;
  const FourVector out1() const;
  const FourVector out2() const;
  const double weight() const;
private:
  bool _allowed;
  double _E_partonCMS;
  FourVector _in1;
  double _x1;
  FourVector _in2;
  double _x2;
  FourVector _out1;
  FourVector _out2;
  double _weight;
};

inline const double TwoToResonanceAndTwoBodyDecay::E_partonCMS() const { assert(_allowed); return _E_partonCMS; }

inline const FourVector TwoToResonanceAndTwoBodyDecay::in1() const { assert(_allowed); return _in1; }

inline const double TwoToResonanceAndTwoBodyDecay::x1() const { assert(_allowed); return _x1; }

inline const FourVector TwoToResonanceAndTwoBodyDecay::in2() const { assert(_allowed); return _in2; }

inline const double TwoToResonanceAndTwoBodyDecay::x2() const { assert(_allowed); return _x2; }

inline const FourVector TwoToResonanceAndTwoBodyDecay::out1() const { assert(_allowed); return _out1; }

inline const FourVector TwoToResonanceAndTwoBodyDecay::out2() const { assert(_allowed); return _out2; }

inline const double TwoToResonanceAndTwoBodyDecay::weight() const { return _weight; }

}     // MappingComponents

// --------------------------------------------------------------------

void test_kinematics();     // aborts if a test fails

#endif  /* KINEMATICS_H */

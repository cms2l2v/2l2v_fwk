#ifndef PI_H
#define PI_H

const double Pi = 3.141592653589793238462643383279502884197169399375105820974944592307816406286208998628034825342117068;
const double Pi2 = Pi*Pi;
const double TPi = 2.0*Pi;
const double FourPi = 4.0*Pi;

#endif  /* PI_H */


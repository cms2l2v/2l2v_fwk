#ifndef SMALL_POWERS_H
#define SMALL_POWERS_H

inline const double pow2(const double x)
{
  return x * x;
}

inline const double pow3(const double x)
{
  return x * x * x;
}

inline const double pow4(const double x)
{
  return x * x * x * x;
}

#endif  /* SMALL_POWERS_H */

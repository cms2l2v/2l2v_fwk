#ifndef CONSTVALUE_H
#define CONSTVALUE_H

#include <cassert>
/* assert macro */

template<typename T>
class ConstValue 
{
public:
  ConstValue();
  ConstValue(const T& value);
  const T& operator()() const;     // no typo!
  void set(const T& value);
  const bool isSet() const;
private:
  T _value;
  bool _isSet;
};

template<typename T>
inline const T& ConstValue<T>::operator()() const { assert(_isSet); return _value; }

template<typename T>
inline const bool ConstValue<T>::isSet() const { return _isSet; }

#endif  /* CONSTVALUE_H */

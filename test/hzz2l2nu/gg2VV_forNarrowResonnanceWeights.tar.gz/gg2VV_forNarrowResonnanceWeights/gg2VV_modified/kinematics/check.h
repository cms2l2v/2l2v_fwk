#ifndef CHECK_H
#define CHECK_H

#include <string>
using std::string;

void test_libkinematics();     // aborts if a test fails

// helper functions ---------------------------------------------------

#include "geometry.h"

void check(const bool equal, const string& test_id);

void check(const double actual, const double expected, const string& test_id,
           const double acceptable_relative_error = 1.e-10);

void check(const FourVector& actual, const FourVector& expected, const string& test_id,
           const double acceptable_relative_error = 1.e-10);

#endif  /* CHECK_H */

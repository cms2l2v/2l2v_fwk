#ifndef GIVEMASS_H
#define GIVEMASS_H

#include <cassert>
/* assert macro */

#include "geometry.h"

void repairNegativeMass(FourMomentum& p);
const FourMomentum getRepairNegativeMass(const FourMomentum& p);

class Givemass
{
public:
  void operator()(const FourMomentum& p1in, const double mass1, const FourMomentum& p2in, const double mass2);
  const bool isAllowed() const;
  const FourMomentum p1() const;
  const FourMomentum p2() const;
private:
  bool _allowed;
  FourMomentum _out1;
  FourMomentum _out2;
};

inline const bool Givemass::isAllowed() const { return _allowed; }

inline const FourMomentum Givemass::p1() const { assert(_allowed); return _out1; }

inline const FourMomentum Givemass::p2() const { assert(_allowed); return _out2; }

#endif  /* GIVEMASS_H */

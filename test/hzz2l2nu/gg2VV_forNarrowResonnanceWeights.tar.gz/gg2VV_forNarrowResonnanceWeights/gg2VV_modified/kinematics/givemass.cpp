#include <cmath>
using std::sqrt;
#include <cassert>
/* assert macro */
#include <iostream>
using std::cout;
#include <iomanip>
using std::endl;

#include "givemass.h"
#include "geometry.h"
#include "small_powers.h"
#include "check.h"

void repairNegativeMass(FourMomentum& p)
{
  // p^2 < 0 due to finite precision rounding errors
  assert(p.m2() < 0. && fabs(p.m2()) < 1.e-8);
  while (p.m2() < 0.) {
    p = FourMomentum(p.E()*1.000000000000001, p.fvec().vec());
  }
  assert(p.m() < 5.e-4);  
}

const FourMomentum getRepairNegativeMass(const FourMomentum& p)
{
  FourMomentum out(p);
  repairNegativeMass(out);
  return out;
}

void Givemass::operator()(const FourMomentum& p1in, const double mass1, const FourMomentum& p2in, const double mass2)
{
  const FourMomentum totin = p1in + p2in;

  assert(totin.m2() > 0.);     // timelike

  const double M = totin.m();
  if (M > mass1 + mass2) {
    _allowed = true;
  }
  else {
    _allowed = false;     // unphysical
    return;
  }

  // boost to totin rest frame
  const FourMomentum p1incms = boost(p1in, totin, true);
  const FourMomentum p2incms = boost(p2in, totin, true);
  const double pabscms = 0.5*(p1incms.pabs()+p2incms.pabs());

  const double M2 = totin.m2();
  const double m2_1 = pow2(mass1);
  const double m2_2 = pow2(mass2);

  const double poutcmsabs = sqrt((M2-pow2(mass1+mass2))*(M2-pow2(mass1-mass2)))/(2.*M);

  const double E1 = (M2 - m2_2 + m2_1)/(2.*M);
  const double p1x = p1incms.px()*poutcmsabs/pabscms;
  const double p1y = p1incms.py()*poutcmsabs/pabscms;
  const double p1z = p1incms.pz()*poutcmsabs/pabscms;

  const FourMomentum p1outcms(E1, p1x, p1y, p1z);

  const double E2 = (M2 - m2_1 + m2_2)/(2.*M);
  const double p2x = p2incms.px()*poutcmsabs/pabscms;
  const double p2y = p2incms.py()*poutcmsabs/pabscms;
  const double p2z = p2incms.pz()*poutcmsabs/pabscms;
  
  const FourMomentum p2outcms(E2, p2x, p2y, p2z);
  
  // boost back to original frame
  _out1 = boost(p1outcms, totin);
  _out2 = boost(p2outcms, totin);

  if (mass1 == 0. && _out1.m2() < 0.) {
    repairNegativeMass(_out1);
  }
  if (mass2 == 0. && _out2.m2() < 0.) {
    repairNegativeMass(_out2);
  }

  // CHECKS ----------------------------------------------------------------------  
  using ::check;
  const double err = 1.e-3;
  // 4-momentum conservation
  FourVector netMomentum;
  netMomentum += p1in.fvec();
  netMomentum += p2in.fvec();
  netMomentum -= _out1.fvec();
  netMomentum -= _out2.fvec();
  check(netMomentum, FourVector(0.,0.,0.,0.), "Givemass: 4-momentum not conserved", err);
  // on-shell conditions
  check(_out1.m(), mass1, "Givemass: _out1 off-shell", err);
  check(_out2.m(), mass2, "Givemass: _out2 off-shell", err);
  // -----------------------------------------------------------------------------
}

#include <vector>
using std::vector;
#include <algorithm>
using std::max;
#include <cmath>
using std::sqrt;
using std::tan;
using std::atan;
using std::pow;
using std::fabs;
#include <cassert>
/* assert macro */
#include <iostream>

#include "kinematics.h"
#include "pi.h"
#include "small_powers.h"
#include "rng.h"

namespace MappingComponents
{
const double bogusMass = -1.e50;

Resonance::Resonance(const double mass, const double width, const double minInvMass, const double maxInvMass)
{
  initialize(mass, width, minInvMass, maxInvMass);
}  

Resonance::Resonance(const double mass, const double width, const double maxInvMass)
{
  initialize(mass, width, 0., maxInvMass);
}

void Resonance::initialize(const double mass, const double width, const double minInvMass, const double maxInvMass)
{
  assert(mass > 0. && width > 0. && 0. <= minInvMass && minInvMass < maxInvMass);
  _M = mass;
  _M2 = pow2(mass);
  _minInvMass = minInvMass;
  _maxInvMass = maxInvMass;
  _MGamma = mass * width;
  _xmin = x(pow2(minInvMass));
}

const double Resonance::x(const double s) const {
  return atan((s - _M2)/_MGamma);
}

const double Resonance::s(const double x) const {
  return _MGamma * tan(x) + _M2;
}

const double Resonance::ds_over_dx(const double s) const {
  return pow2(s - _M2)/_MGamma + _MGamma;
}

const double Resonance::mappedFunction(const double s) const {
  return 1./(pow2(s - _M2) + pow2(_MGamma));
}

const double Resonance::f(const double s) const {
  return 1./pow2(mappedFunction(s));
}

void Resonance::operator()(const double randomNumber, double& weight, const bool nwa)     // default: false
{
  operator()(randomNumber, _maxInvMass, weight, nwa);
}

void Resonance::operator()(const double randomNumber, const double maxInvMass, double& weight, const bool nwa)     // default: false
{
  assert(_minInvMass < maxInvMass);
  if (nwa) {
    assert(_M < maxInvMass);
    _mass = _M;     // weight is unchanged    
    _mass_sqr = pow2(_M);
  }
  else {
    const double xmax = x(pow2(maxInvMass));
    const double xdelta = xmax - _xmin;
    _mass_sqr = s(_xmin + xdelta * randomNumber);
    if (_mass_sqr < 0.) {
      weight = 0.;
      _mass = bogusMass;
      _mass_sqr = bogusMass;
      return;
    }
    _mass = sqrt(_mass_sqr);
    if (!(_minInvMass < _mass && _mass < maxInvMass)) {
      weight = 0.;
      _mass = bogusMass;
      _mass_sqr = bogusMass;
      return;
    }
    weight /= TPi;     // weight includes constant in dq^2/TPi
    weight *= ds_over_dx(_mass_sqr);
    weight *= xdelta;     // Jacobian factor for randomNumber -> x mapping
  }
}

// --------------------------------------------------------------------

const double Massless::x(const double s)
{
  return -2./sqrt(s);
}
  
const double Massless::s(const double x)
{
  assert(x < 0.);
  return 4./pow2(x);
}

const double Massless::ds_over_dx(const double s)
{
  return pow(s, 1.5);
}

const double Massless::mappedFunction(const double s)
{
  return 1./pow(s, 1.5);
}

// --------------------------------------------------------------------

ResonancePlusMassless::ResonancePlusMassless(const double mass, const double width, const double minInvMass, const double maxInvMass)
  : _r(mass, width, minInvMass, maxInvMass)
{
  _minInvMass = minInvMass;
  _maxInvMass = maxInvMass;
  _mappingBoundInvMassEqualsMinInvMass = false;
  _mappingBoundInvMass = getMappingBoundInvMass(mass, width);
  if (_minInvMass >= _mappingBoundInvMass) {
    _mappingBoundInvMass = _minInvMass;   // only Resonance mapping is used
    _mappingBoundInvMassEqualsMinInvMass = true;
  }
  assert(_mappingBoundInvMass < mass);
}

const double ResonancePlusMassless::mappedFunction(const double s) const
{
  const double sBound = pow2(_mappingBoundInvMass);
  double mappedFunction = 0.;
  if (!_mappingBoundInvMassEqualsMinInvMass && s < sBound) {
    mappedFunction = Massless::mappedFunction(s);
  }
  else {
    mappedFunction = _r.mappedFunction(s);
  }
  return mappedFunction;
}

const double ResonancePlusMassless::f(const double s) const {
  const double val = _mappingBoundInvMassEqualsMinInvMass ? _r.mappedFunction(s) : (MappingComponents::Massless::mappedFunction(s)/MappingComponents::Massless::mappedFunction(_r.resonanceMass2()) * _r.mappedFunction(s));
  return 1./pow2(val);
}

const double ResonancePlusMassless::getMappingBoundInvMass(const double m, const double g)
{
  return 70.;
}

void ResonancePlusMassless::operator()(const double randomNumber, double& weight, const bool nwa)     // default: false
{
  operator()(randomNumber, _maxInvMass, weight, nwa);
}

void ResonancePlusMassless::operator()(const double randomNumber, const double maxInvMass, double& weight, const bool nwa)     // default: false
{
  assert(_minInvMass < maxInvMass);
  if (nwa) {
    const double M = _r.resonanceMass();
    assert(_minInvMass < M && M < maxInvMass);
    _mass = M;     // weight is unchanged    
    _mass_sqr = pow2(M);
  }
  else if (_mappingBoundInvMassEqualsMinInvMass) {
    _r(randomNumber, maxInvMass, weight);
    _mass_sqr = _r.m2();
    _mass = _r.m();
  }
  else {
    const double xmas_min = Massless::x(pow2(_minInvMass));
    if (maxInvMass > _mappingBoundInvMass) {
      if (randomNumber < 0.5) {
	const double xmas_max = Massless::x(pow2(_mappingBoundInvMass));
	const double xmas_delta = xmas_max - xmas_min;
	_mass_sqr = Massless::s(xmas_min + xmas_delta*2.*randomNumber);
	_mass = sqrt(_mass_sqr);
	weight *= Massless::ds_over_dx(_mass_sqr);
	weight *= xmas_delta*2.;     // Jacobian factor for randomNumber -> x mapping
      }
      else {   // 0.5 < randomNumber < 1
	const double xres_min = _r.x(pow2(_mappingBoundInvMass));
	const double xres_max = _r.x(pow2(maxInvMass));
	const double xres_delta = xres_max - xres_min;
	_mass_sqr = _r.s(xres_min + xres_delta*(2.*randomNumber-1.));
	_mass = sqrt(_mass_sqr);
	weight *= _r.ds_over_dx(_mass_sqr);
	weight *= xres_delta*2.;     // Jacobian factor for randomNumber -> x mapping
      }
    }
    else {
      const double xmas_max = Massless::x(pow2(maxInvMass));
      const double xmas_delta = xmas_max - xmas_min;
      _mass_sqr = Massless::s(xmas_min + xmas_delta * randomNumber);
      _mass = sqrt(_mass_sqr);
      weight *= Massless::ds_over_dx(_mass_sqr);
      weight *= xmas_delta;     // Jacobian factor for randomNumber -> x mapping
    }
    if (!(_minInvMass < _mass && _mass < maxInvMass)) {
      weight = 0.;
      _mass = bogusMass;
      _mass_sqr = bogusMass;
      return;
    }
    weight /= TPi;     // weight includes constant in dq^2/TPi
  }
}

// --------------------------------------------------------------------

void TwoBodyDecay::operator()(const double randomNumber1, const double randomNumber2,
  const FourMomentum& in, const double mass1, const double mass2, double& weight)
{
  assert(in.m2() >= 0.0);
  if (in.m() > mass1 + mass2) {
    _allowed = true;
  }
  else {
    _allowed = false;
    weight = 0.0;
    return;
  }
  // generate outgoing momenta in CMS and boost back
  const double out1_m2 = pow2(mass1);
  const double out2_m2 = pow2(mass2);
  const double out1_E = (in.m2() - out2_m2 + out1_m2)/(2.0 * in.m());
  const double out2_E = (in.m2() - out1_m2 + out2_m2)/(2.0 * in.m());
  const double nominator=sqrt((in.m2()-pow2(mass1+mass2))*(in.m2()-pow2(mass1-mass2)));
  const double pabs = nominator/(2.0 * in.m());      // = out1_pabs = out2_pabs
  const double cos_theta = 2 * randomNumber1 - 1;
  const double sin_theta = sqrt((1-cos_theta)*(1+cos_theta));
  const double phi = TPi * randomNumber2;
  const ThreeVector out1_vec = ThreeVector(pabs * sin_theta * cos(phi),
    pabs * sin_theta * sin(phi), pabs * cos_theta);
  _out1 = boost(FourVector(out1_E, out1_vec), in);
  _out2 = boost(FourVector(out2_E, -out1_vec), in);
  weight *= 2. * TPi;     // Jacobian factor
  weight *= nominator/(32*Pi2*in.m2());
}

// --------------------------------------------------------------------

FinalStateParticle::FinalStateParticle()
  : _mass(0.), _mt_min(0.)
{}

FinalStateParticle::FinalStateParticle(const double mass,
  const double mt_min)
  : _mass(mass), _mt_min(mt_min)
{
  assert(_mass >= 0.0 && _mt_min >= _mass);     // generally
  assert(_mt_min > 0.0);                        // for TwoToJetsAndResiduum generator
}

FinalStateParticle::FinalStateParticle(const double nonZeroMass)
  : _mass(nonZeroMass), _mt_min(nonZeroMass)
{
  assert(nonZeroMass > 0.0);
}

void FinalStateParticle::set(const double nonZeroMass)
{
  assert(nonZeroMass > 0.0);
  _mass = _mt_min = nonZeroMass;
}

// --------------------------------------------------------------------

#include "invhyp.h"

void TwoToJetsAndResiduum::operator()(const vector<double>& randomNumber,
  const double E_CMS, const vector<FinalStateParticle>& jet,
  const FinalStateParticle& res)
{
  assert(E_CMS > 0.0);
  assert(randomNumber.size() == 3*jet.size()+1);
  _allowed = true;
  _weight = 1.0;
  _out.clear();
  _out.reserve(jet.size());
  FourVector sumOfJets;
  for (int i = 0; i < jet.size(); ++i) {
    const FinalStateParticle& thisJet = jet[i];
    const double E_max = 0.5 * (E_CMS + pow2(thisJet.mass())/E_CMS);
    const double xmin = 1.0/E_max;
    const double xmax = 1.0/thisJet.mt_min();
    const double delx = xmax - xmin;
    const double x = delx * randomNumber[3*i+0] + xmin;
    const double mt = 1.0/x;
    const double ymax = arccosh(E_max/mt);
    const double y = ymax * (2*randomNumber[3*i+1]-1);     // y in (-ymax, ymax)
    const double phi = TPi * randomNumber[3*i+2];
    const double pt = sqrt(pow2(mt)-pow2(thisJet.mass()));
    _out.push_back(FourVector(mt*cosh(y), pt*cos(phi), pt*sin(phi), mt*sinh(y)));
    sumOfJets += _out.back();
    _weight *= pow3(mt) * delx * ymax * TPi;     // Jacobian factor
  }
  /*
    If sumOfJets = 1 massless jet, sumOfJets.sqr() = 0.  With finite num. precision: 
    -10^9 < sumOfJets.sqr() < 10^9, WARNING: eliminating the cases with
    sumOfJets.sqr() < 0 throws away legitimate phase space configurations (ca. 1/2)
  */
  const FourMomentum J = sumOfJets;
  const double J_m2 = max(J.m2(), 0.0);     // J is guaranteed to be non-space-like
  const double J_m = sqrt(J_m2);            // J is guaranteed to be non-space-like
  const double res_m = res.mass();
  if (J_m > E_CMS - res_m) {
    _allowed = false;
    _weight = 0.0;
    return;
  }
  const double s = pow2(E_CMS);
  const double delycm_arg = (s-pow2(res_m+J_m))*(1-pow2(res_m-J_m)/s) - 4*J.pt2();
  if (delycm_arg < 0.0) {
    _allowed = false;
    _weight = 0.0;
    return;
  }
  const double dely_cm = arcsinh(sqrt(delycm_arg)/(2*sqrt(J_m2+J.pt2())));
  const double y_cm = J.y() + dely_cm * (2*randomNumber[3*jet.size()]-1);
  _weight *= 2*dely_cm;     // Jacobian factor
  const double Jcm_pabs2 = J.pt2() + pow2(J.pz()*cosh(y_cm)-J.E()*sinh(y_cm));
  const double Jcm_E = sqrt(J_m2 + Jcm_pabs2);
  const double rescm_E = sqrt(pow2(res_m) + Jcm_pabs2);
  _E_partonCMS = rescm_E + Jcm_E;
  if (_E_partonCMS <= 0.0) {
    _allowed = false;
    _weight = 0.0;
    return;
  }
  const FourVector totMom(_E_partonCMS*cosh(y_cm), 0.0, 0.0, _E_partonCMS*sinh(y_cm));
  _out_res = totMom - J.fvec();
  _x1 = (totMom.t() + totMom.z())/E_CMS; 
  _x2 = (totMom.t() - totMom.z())/E_CMS;
  const double max_x = 0.99999999;
  if (_x1 > max_x || _x2 > max_x) {
    _allowed = false;
    _weight = 0.0;
    return;
  }
  const FourVector hadronMom(E_CMS/2, 0.0, 0.0, E_CMS/2);
  _in1 = _x1 * hadronMom;
  _in2 = _x2 * hadronMom.flip();
  const double s_hat = pow2(_E_partonCMS);
  const int n = jet.size()+1;
  _weight *= 1/(2*s_hat) * pow(TPi, 4-3*n)*_E_partonCMS/(s*rescm_E);
}

// --------------------------------------------------------------------

void TwoToResonanceAndTwoBodyDecay::operator()(const vector<double>& randomNumber,
  const double E_CMS, const Resonance& res,
  const FinalStateParticle& fsp1, const FinalStateParticle& fsp2)
{
  assert(E_CMS > 0.0);
  assert(res.m() > 0.0);     // res.operator() must have been called!
  assert(randomNumber.size() == 3);
  _allowed = true;
  _weight = 1.0;

  // Integration variable: d tau = 1/s ds_hat = 1/s dtotPartMom^2
  _weight *= TPi/pow2(E_CMS);     // Resonance provides dtotPartMom^2/TPi
  _E_partonCMS = res.m();
  if (_E_partonCMS <= fsp1.mt_min() + fsp2.mt_min()) {
    _allowed = false;
    _weight = 0.0;
    return;
  }
  const double tau = pow2(_E_partonCMS/E_CMS);     // tau = s_hat/s
  _x1 = tau + (1. - tau) * randomNumber[0];
  _x2 = tau/_x1;
  _weight *= (1. - tau);     // Jacobian factor
  _weight /= _x1;            // Jacobian factor from (x1, x2) -> (tau, x1)
  const FourVector hadronMom(E_CMS/2, 0.0, 0.0, E_CMS/2);
  _in1 = _x1 * hadronMom;
  _in2 = _x2 * hadronMom.flip();
  const double s_hat = pow2(_E_partonCMS);
  _weight *= 1/(2*s_hat);     // dsigma_hat = 1/(2 s_hat) * dPhi_2
  const FourMomentum totPartonMom = _in1 + _in2;
  static TwoBodyDecay decay;
  decay(randomNumber[1], randomNumber[2], totPartonMom, fsp1.mass(), fsp2.mass(), _weight);
  if (_weight == 0.) {
    _allowed = false;
    return;
  }
  _out1 = decay.p1();
  _out2 = decay.p2();
}

}     // MappingComponents

// --------------------------------------------------------------------

#include "check.h"

void test_kinematics()
{
  using namespace MappingComponents;

  Resonance res(175., 1.5, 175.+1.5*6500);
  double weight = 1.0;
  res(0.39, weight);
  check(res.m(), 174.7342019721594, "MappingComponents::Resonance: m");
  check(weight, 147.3065211171264, "MappingComponents::Resonance: weight");

  TwoBodyDecay tbd;
  weight = 1.0;
  FourMomentum in(1000., 30., -2., 8.);
  tbd(0.82, 0.11, in, 80., 5., weight);
  const FourVector p1_exp(514.0710225105504, 309.2342208201081, 242.1802187966279, 321.8570404425556);
  check(tbd.p1(), p1_exp, "MappingComponents::TwoBodyDecay: p1");
  const FourVector p2_exp(485.9289774894496, -279.2342208201082, -244.1802187966279, -313.8570404425556);
  check(tbd.p2(), p2_exp, "MappingComponents::TwoBodyDecay: p2");
  check(weight, 0.03953283260413583, "MappingComponents::TwoBodyDecay: weight");

  /*
  TwoToJetsAndResiduum tjr;
  vector<double> r(7);
  r[0] = 0.761324;
  r[1] = 0.635725;
  r[2] = 0.091234;
  r[3] = 0.048264;
  r[4] = 0.639620;
  r[5] = 0.033276;
  r[6] = 0.543222;
  vector<FinalStateParticle> jet;
  jet.reserve(2);
  jet.push_back(FinalStateParticle(0., 20.));
  jet.push_back(FinalStateParticle(5.));
  FinalStateParticle fsp_W(81.);
  tjr(r, 1800., jet, fsp_W);
  check(tjr.E_partonCMS(), 269.7115759083395, "MappingComponents::TwoToJetsAndResiduum: E_partonCMS");
  const FourVector in1_exp(417.4366996970907, 0, 0, 417.4366996970907);
  check(tjr.in1(), in1_exp, "MappingComponents::TwoToJetsAndResiduum: in1");
  check(tjr.x1(), 0.4638185552189896, "MappingComponents::TwoToJetsAndResiduum: x1");
  const FourVector in2_exp(43.56608692512316, 0, 0, -43.56608692512316);
  check(tjr.in2(), in2_exp, "MappingComponents::TwoToJetsAndResiduum: in2");
  check(tjr.x2(), 0.04840676325013684, "MappingComponents::TwoToJetsAndResiduum: x2");
  const FourVector out_0_exp(45.29938666635258, 21.91801445389801, 14.14916077658895, 37.03290866330482);
  check(tjr.out(0), out_0_exp, "MappingComponents::TwoToJetsAndResiduum: out_0");
  const FourVector out_1_exp(127.030705286636, 91.20388238144221, 19.3516469649596, 86.13457890949371);
  check(tjr.out(1), out_1_exp, "MappingComponents::TwoToJetsAndResiduum: out_1");
  const FourVector out_res_exp(288.6726946692252, -113.1218968353402, -33.50080774154855, 250.703125199169);
  check(tjr.out_res(), out_res_exp, "MappingComponents::TwoToJetsAndResiduum: out_res");
  check(tjr.weight(), 58415.05743581215, "MappingComponents::TwoToJetsAndResiduum: weight");
  */
}

#ifndef INVHYP_H
#define INVHYP_H

// inverse hyperbolic functions (for real argument x)

#include <cmath>
using std::log;
using std::sqrt;

inline const double arcsinh(const double x)
{
  return log(x + sqrt(x*x + 1.0));
}

// arccosh returns positive solution
inline const double arccosh(const double x)
{
  return log(x + sqrt(x*x - 1.0));
}

// arccosh_neg returns negative solution
inline const double arccosh_neg(const double x)
{
  return log(x - sqrt(x*x - 1.0));
}

inline const double arctanh(const double x)
{
  return 0.5*log((1.0+x)/(1.0-x));
}

#endif // INVHYP_H

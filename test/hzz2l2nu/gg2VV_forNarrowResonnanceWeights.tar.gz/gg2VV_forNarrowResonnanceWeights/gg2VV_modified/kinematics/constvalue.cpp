#include <vector>
using std::vector;
#include <cassert>
/* assert macro */

#include "constvalue.h"
#include "geometry.h"

template<typename T>
ConstValue<T>::ConstValue()
  : _value(), _isSet(false)
{}

template<typename T>
ConstValue<T>::ConstValue(const T& value)
  : _value(value), _isSet(true)
{}

template<typename T>
void ConstValue<T>::set(const T& value)
{
  assert(!_isSet);
  _value = value;
  _isSet = true;
}

template class ConstValue<double>;     // explicit instantiation
template class ConstValue<FourMomentum>;
template class ConstValue< vector<double> >;
template class ConstValue<int>;

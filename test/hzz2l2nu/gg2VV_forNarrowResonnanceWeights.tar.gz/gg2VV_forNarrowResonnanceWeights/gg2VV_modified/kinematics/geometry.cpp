#include <iostream>
#include <cmath>
using std::cos;
using std::sin;

#include "geometry.h"
#include "small_powers.h"

// class template Lazy_double -----------------------------------

template<class C>
Lazy_double<C>::Lazy_double(const C& c, const double (*compute_double)(const C& c))
  : _value_is_unknown(true), _c(&c), _compute_value(compute_double)
{}

template<class C>
Lazy_double<C>& Lazy_double<C>::operator=(const Lazy_double& ld)
{
  if (this != &ld) {
    _value_is_unknown = ld._value_is_unknown;
    if (!_value_is_unknown)
      _value = ld._value;
    // _c continues to point to parent class of type C;
    // _compute_value continues to point to static member function of parent class
  }
  return *this;
}

template<class C>
const double Lazy_double<C>::get_value()
{
  if (_value_is_unknown) {
    _value = (*_compute_value)(*_c);
    _value_is_unknown = false;
  }
  return _value;
}

// explicit instantiation

template class Lazy_double<ThreeVector>;
template class Lazy_double<FourVector>;
template class Lazy_double<FourMomentum>;
template class Lazy_double<FourMomentumPair>;

// class ThreeVector --------------------------------------------

ThreeVector::ThreeVector()
  : _x(0.), _y(0.), _z(0.), _sqr((*this), &ThreeVector::c_sqr),
    _abs((*this), &ThreeVector::c_abs)
{}

ThreeVector::ThreeVector(double x, double y, double z)
  : _x(x), _y(y), _z(z), _sqr((*this), &ThreeVector::c_sqr),
    _abs((*this), &ThreeVector::c_abs)
{}

ThreeVector::ThreeVector(const ThreeVector& tv)
  : _x(tv.x()), _y(tv.y()), _z(tv.z()), _sqr((*this), &ThreeVector::c_sqr),
    _abs((*this), &ThreeVector::c_abs)
{}

// assignment operator

ThreeVector& ThreeVector::operator=(const ThreeVector& tv)
{
  if (this != &tv) {
    _x = tv.x();
    _y = tv.y();
    _z = tv.z();
    reset_derived_variables();
  }
  return *this;
}

// operators

ThreeVector& ThreeVector::operator*=(double d)
{
  _x *= d;
  _y *= d;
  _z *= d;
  reset_derived_variables();
  return *this;
}

ThreeVector& ThreeVector::operator/=(double d)
{
  _x /= d;
  _y /= d;
  _z /= d;
  reset_derived_variables();
  return *this;
}

ThreeVector& ThreeVector::operator+=(const ThreeVector& tv)
{
  _x += tv.x();
  _y += tv.y();
  _z += tv.z();
  reset_derived_variables();
  return *this;
}

ThreeVector& ThreeVector::operator-=(const ThreeVector& tv)
{
  _x -= tv.x();
  _y -= tv.y();
  _z -= tv.z();
  reset_derived_variables();
  return *this;
}

// functions to compute derived variables

const double ThreeVector::c_sqr(const ThreeVector& tv)
{
  return tv * tv;
}

const double ThreeVector::c_abs(const ThreeVector& tv)
{
  return sqrt(tv.sqr());
}

// class FourVector ---------------------------------------------

FourVector::FourVector()
  : _t(0.), _vec(ThreeVector(0., 0., 0.)), _sqr((*this), &FourVector::c_sqr),
    _abs((*this), &FourVector::c_abs)
{}

FourVector::FourVector(double t, double x, double y, double z)
  : _t(t), _vec(ThreeVector(x, y, z)), _sqr((*this), &FourVector::c_sqr),
    _abs((*this), &FourVector::c_abs)
{}

FourVector::FourVector(const FourVector& fv)
  : _t(fv.t()), _vec(fv.vec()), _sqr((*this), &FourVector::c_sqr),
    _abs((*this), &FourVector::c_abs)
{}

FourVector::FourVector(double t, const ThreeVector& tv)
  : _t(t), _vec(tv), _sqr((*this), &FourVector::c_sqr),
    _abs((*this), &FourVector::c_abs)
{}

// assignment operator

FourVector& FourVector::operator=(const FourVector& fv)
{
  if (this != &fv) {
    _t = fv.t();
    _vec = fv.vec();
    reset_derived_variables();
  }
  return *this;
}

// operators

FourVector& FourVector::operator*=(double d)
{
  _t *= d;
  _vec *= d;
  reset_derived_variables();
  return *this;
}

FourVector& FourVector::operator/=(double d)
{
  _t /= d;
  _vec /= d;
  reset_derived_variables();
  return *this;
}

FourVector& FourVector::operator+=(const FourVector& fv)
{
  _t += fv.t();
  _vec += fv.vec();
  reset_derived_variables();
  return *this;
}

FourVector& FourVector::operator-=(const FourVector& fv)
{
  _t -= fv.t();
  _vec -= fv.vec();
  reset_derived_variables();
  return *this;
}

// functions to compute derived variables

const double FourVector::c_sqr(const FourVector& fv)
{
  return fv * fv;
}

const double FourVector::c_abs(const FourVector& fv)
{
  return sqrt(fv.sqr());
}

const FourVector boost(const FourVector& p, const FourVector& r, const bool reverse_r)
// default: false
{
  // p is assumed to be given in the rest frame of time-like r.
  // Returned vector is p boosted to the frame in which
  // r is given.  See Jackson, Eq. (11.19) with -beta, p. 525.

  ThreeVector beta = (!reverse_r) ? r.vec()/r.t() : -r.vec()/r.t();
  const double gamma = 1.0/sqrt(1.0 - beta.sqr());
  return FourVector(gamma * (p.t() + (beta*p.vec())),
                    p.vec() + beta *
                    ((beta*p.vec())*(gamma-1.0)/beta.sqr() + gamma*p.t()));

}

// class FourMomentum -------------------------------------------

FourMomentum::FourMomentum()
  : _fvec(FourVector()),
    _pt((*this), &FourMomentum::c_pt),
    _mt((*this), &FourMomentum::c_mt),
    _pt2((*this), &FourMomentum::c_pt2),
    _mt2((*this), &FourMomentum::c_mt2),
    _eta((*this), &FourMomentum::c_eta),
    _y((*this), &FourMomentum::c_y),
    _phi((*this), &FourMomentum::c_phi)
{}

FourMomentum::FourMomentum(double E, double px, double py, double pz)
  : _fvec(FourVector(E, px, py, pz)),
    _pt((*this), &FourMomentum::c_pt),
    _mt((*this), &FourMomentum::c_mt),
    _pt2((*this), &FourMomentum::c_pt2),
    _mt2((*this), &FourMomentum::c_mt2),
    _eta((*this), &FourMomentum::c_eta),
    _y((*this), &FourMomentum::c_y),
    _phi((*this), &FourMomentum::c_phi)
{}

FourMomentum::FourMomentum(const FourMomentum& fm)
  : _fvec(fm.fvec()),
    _pt((*this), &FourMomentum::c_pt),
    _mt((*this), &FourMomentum::c_mt),
    _pt2((*this), &FourMomentum::c_pt2),
    _mt2((*this), &FourMomentum::c_mt2),
    _eta((*this), &FourMomentum::c_eta),
    _y((*this), &FourMomentum::c_y),
    _phi((*this), &FourMomentum::c_phi)
{}
  
FourMomentum::FourMomentum(const FourVector& fv)
  : _fvec(fv),
    _pt((*this), &FourMomentum::c_pt),
    _mt((*this), &FourMomentum::c_mt),
    _pt2((*this), &FourMomentum::c_pt2),
    _mt2((*this), &FourMomentum::c_mt2),
    _eta((*this), &FourMomentum::c_eta),
    _y((*this), &FourMomentum::c_y),
    _phi((*this), &FourMomentum::c_phi)
{}
  
FourMomentum::FourMomentum(double E, const ThreeVector& pvec)
  : _fvec(FourVector(E, pvec)),
    _pt((*this), &FourMomentum::c_pt),
    _mt((*this), &FourMomentum::c_mt),
    _pt2((*this), &FourMomentum::c_pt2),
    _mt2((*this), &FourMomentum::c_mt2),
    _eta((*this), &FourMomentum::c_eta),
    _y((*this), &FourMomentum::c_y),
    _phi((*this), &FourMomentum::c_phi)
{}

// assignment operator

FourMomentum& FourMomentum::operator=(const FourMomentum& fm)
{
  if (this != &fm) {
    _fvec = fm.fvec();
    reset_derived_variables();
  }
  return *this;
}

// functions to compute derived variables

const double FourMomentum::c_pt(const FourMomentum& fm)
{
  return sqrt(fm.pt2());
}

const double FourMomentum::c_mt(const FourMomentum& fm)
{
  return sqrt(fm.mt2());
}

const double FourMomentum::c_pt2(const FourMomentum& fm)
{
  return pow2(fm.px()) + pow2(fm.py());
}

const double FourMomentum::c_mt2(const FourMomentum& fm)
{
  return fm.pt2() + fm.m2();
}

const double FourMomentum::c_eta(const FourMomentum& fm)
{
  return (fm.pabs() != fabs(fm.pz())) ?
    0.5*log((fm.pabs()+fm.pz())/(fm.pabs()-fm.pz())) : sign(fm.pz())*1000.;
}

const double FourMomentum::c_y(const FourMomentum& fm)
{
  return (fm.E() != fabs(fm.pz())) ?
    0.5*log((fm.E()+fm.pz())/(fm.E()-fm.pz())) : sign(fm.pz())*1000.;
}

const double FourMomentum::c_phi(const FourMomentum& fm)
{
  return (fm.px() != 0.0) ? atan2(fm.py(), fm.px()) : 0.0;
}

// operators

FourMomentum& FourMomentum::operator*=(double d)
{
  _fvec *= d;
  reset_derived_variables();
  return *this;
}

FourMomentum& FourMomentum::operator/=(double d)
{
  _fvec /= d;
  reset_derived_variables();
  return *this;
}

FourMomentum& FourMomentum::operator+=(const FourMomentum& fm)
{
  _fvec += fm.fvec();
  reset_derived_variables();
  return *this;
}

FourMomentum& FourMomentum::operator-=(const FourMomentum& fm)
{
  _fvec -= fm.fvec();
  reset_derived_variables();
  return *this;
}

ostream& operator<<(ostream& s, const FourMomentum& fm)
{
  return s << fm.E() << ", " << fm.px() << ", " << fm.py() << ", " << fm.pz();
}

// class FourMomentumPair ---------------------------------------

FourMomentumPair::FourMomentumPair(const ConstValue<FourMomentum>& p1,
                                   const ConstValue<FourMomentum>& p2)
  : _p1(p1), _p2(p2),
    _m((*this), &FourMomentumPair::c_m),
    _m2((*this), &FourMomentumPair::c_m2),
    _dot((*this), &FourMomentumPair::c_dot),
    _costh((*this), &FourMomentumPair::c_costh),
    _dot3((*this), &FourMomentumPair::c_dot3),
    _Deta((*this), &FourMomentumPair::c_Deta),
    _Dy((*this), &FourMomentumPair::c_Dy),
    _Dphi((*this), &FourMomentumPair::c_Dphi),
    _DR((*this), &FourMomentumPair::c_DR)
{}

// functions to compute derived variables

const double FourMomentumPair::c_m(const FourMomentumPair& fmp)
{
  return sqrt(fmp.m2());
}

const double FourMomentumPair::c_m2(const FourMomentumPair& fmp)
{
  assert(fmp._p1.isSet() && fmp._p2.isSet());
  return fmp._p1().m2() + fmp._p2().m2() + 2. * fmp.dot();
}

const double FourMomentumPair::c_dot(const FourMomentumPair& fmp)
{
  assert(fmp._p1.isSet() && fmp._p2.isSet());
  return fmp._p1().fvec() * fmp._p2().fvec();
}

const double FourMomentumPair::c_costh(const FourMomentumPair& fmp)
{
  assert(fmp._p1.isSet() && fmp._p2.isSet());
  return fmp.dot3() / (fmp._p1().pabs() * fmp._p2().pabs());
}

const double FourMomentumPair::c_dot3(const FourMomentumPair& fmp)
{
  assert(fmp._p1.isSet() && fmp._p2.isSet());
  return fmp._p1().fvec().vec() * fmp._p2().fvec().vec();
}

const double FourMomentumPair::c_Deta(const FourMomentumPair& fmp)
{
  assert(fmp._p1.isSet() && fmp._p2.isSet());
  return fmp._p1().eta() - fmp._p2().eta();
}

const double FourMomentumPair::c_Dy(const FourMomentumPair& fmp)
{
  assert(fmp._p1.isSet() && fmp._p2.isSet());
  return fmp._p1().y() - fmp._p2().y();
}

const double FourMomentumPair::c_Dphi(const FourMomentumPair& fmp)
{
  assert(fmp._p1.isSet() && fmp._p2.isSet());
  const double phi1 = fmp._p1().phi();
  const double phi2 = fmp._p2().phi();
  return min(fabs(phi1-phi2), TPi - fabs(phi1-phi2));
}

const double FourMomentumPair::c_DR(const FourMomentumPair& fmp)
{
  return sqrt(pow2(fmp.Deta()) + pow2(fmp.Dphi()));
}

// Tests --------------------------------------------------------

#include "check.h"

void test_geometry()
{
  const double t = 10.;
  const double x = 1.3;
  const double y = -2.1;
  const double z = 0.2;

  // class ThreeVector ------------------------------------------
  
  ThreeVector tv_default;
  check(tv_default.x() == 0., "ThreeVector(): x");
  check(tv_default.y() == 0., "ThreeVector(): y");
  check(tv_default.z() == 0., "ThreeVector(): z");

  ThreeVector tv(x, y, z);
  check(tv.x() == x, "ThreeVector(x,y,z): x");
  check(tv.y() == y, "ThreeVector(x,y,z): y");
  check(tv.z() == z, "ThreeVector(x,y,z): z");

  check(tv == ThreeVector(x,y,z), "ThreeVector::op==(ThreeVector, ThreeVector)");
  check(!(tv == ThreeVector(-x,y,z)), "ThreeVector::op==(ThreeVector, ThreeVector): x");
  check(!(tv == ThreeVector(x,-y,z)), "ThreeVector::op==(ThreeVector, ThreeVector): y");
  check(!(tv == ThreeVector(x,y,-z)), "ThreeVector::op==(ThreeVector, ThreeVector): z");
  check(!(tv != ThreeVector(x,y,z)), "ThreeVector::op!=(ThreeVector, ThreeVector)");
  check(tv != ThreeVector(-x,y,z), "ThreeVector::op!=(ThreeVector, ThreeVector): x");
  check(tv != ThreeVector(x,-y,z), "ThreeVector::op!=(ThreeVector, ThreeVector): y");
  check(tv != ThreeVector(x,y,-z), "ThreeVector::op!=(ThreeVector, ThreeVector): z");

  check(tv.sqr(), 6.14, "ThreeVector::sqr() 1st");
  check(tv.sqr(), 6.14, "ThreeVector::sqr() 2nd");
  check(tv.abs(), 2.4779023386727, "ThreeVector::abs() 1st");
  check(tv.abs(), 2.4779023386727, "ThreeVector::abs() 2nd");

  // copy constructor
  ThreeVector tv_copy = tv;
  check(tv_copy.x() == x, "ThreeVector(const ThreeVector&) unmod: x");
  check(tv_copy.y() == y, "ThreeVector(const ThreeVector&) unmod: y");
  check(tv_copy.z() == z, "ThreeVector(const ThreeVector&) unmod: z");
  check(tv_copy.sqr(), 6.14, "ThreeVector(const ThreeVector&) unmod: sqr() 1st");
  check(tv_copy.sqr(), 6.14, "ThreeVector(const ThreeVector&) unmod: sqr() 2nd");
  check(tv_copy.abs(), 2.4779023386727, "ThreeVector(const ThreeVector&) unmod: abs() 1st");
  check(tv_copy.abs(), 2.4779023386727, "ThreeVector(const ThreeVector&) unmod: abs() 2nd");
  tv_copy *= 2.;
  check(tv_copy.x() == x*2., "ThreeVector(const ThreeVector&) mod: x");
  check(tv_copy.y() == y*2., "ThreeVector(const ThreeVector&) mod: y");
  check(tv_copy.z() == z*2., "ThreeVector(const ThreeVector&) mod: z");
  check(tv_copy.sqr(), 24.56, "ThreeVector(const ThreeVector&) mod: sqr() 1st");
  check(tv_copy.sqr(), 24.56, "ThreeVector(const ThreeVector&) mod: sqr() 2nd");
  check(tv_copy.abs(), 4.955804677345546, "ThreeVector(const ThreeVector&) mod: abs() 1st");
  check(tv_copy.abs(), 4.955804677345546, "ThreeVector(const ThreeVector&) mod: abs() 2nd");
  
  ThreeVector tv1 = tv;
  const double d = 4.2;
  tv1 *= d;
  check(tv1 == ThreeVector(d*tv.x(), d*tv.y(), d*tv.z()), "ThreeVector::op*=(double)");
  ThreeVector tv2 = tv;
  tv2 /= d;
  check(tv2 == ThreeVector(tv.x()/d, tv.y()/d, tv.z()/d), "ThreeVector::op/=(double)");
  ThreeVector tv3 = tv;
  tv3 += ThreeVector(1., 1., 1.);
  check(tv3 == ThreeVector(tv.x()+1., tv.y()+1., tv.z()+1.), "ThreeVector::op+=(ThreeVector)");
  ThreeVector tv4 = tv;
  tv4 -= ThreeVector(1., 1., 1.);
  check(tv4 == ThreeVector(tv.x()-1., tv.y()-1., tv.z()-1.), "ThreeVector::op-=(ThreeVector)");

  ThreeVector tva(1., 2., 3.);
  ThreeVector tvb(10., 20., 30.);
  check(-tva == ThreeVector(-1., -2., -3.), "ThreeVector op-(ThreeVector)");
  check(tva*tvb, 140., "double op*(ThreeVector, ThreeVector)");
  check(2.*tva == ThreeVector(2., 4., 6.), "ThreeVector op*(double, ThreeVector)");
  check(tva*2. == ThreeVector(2., 4., 6.), "ThreeVector op*(ThreeVector, double)");
  check(tva/2. == ThreeVector(0.5, 1., 1.5), "ThreeVector op/(ThreeVector, double)");
  check(tva+tvb == ThreeVector(11., 22., 33.), "ThreeVector op+(ThreeVector, ThreeVector)");
  check(tva-tvb == ThreeVector(-9., -18., -27.), "ThreeVector op+(ThreeVector, ThreeVector)");

  // automatically generated assignment operator
  ThreeVector tv_assign = tvb;
  tv_assign = tv;
  check(tv_assign == tv, "ThreeVector& op=(const ThreeVector&): == to new");
  check(tv_assign != tvb, "ThreeVector& op=(const ThreeVector&): != with old");
  check(tv_assign.sqr(), 6.14, "ThreeVector& op=(const ThreeVector&) unmod: sqr() 1st");
  check(tv_assign.sqr(), 6.14, "ThreeVector& op=(const ThreeVector&) unmod: sqr() 2nd");
  check(tv_assign.abs(), 2.4779023386727, "ThreeVector& op=(const ThreeVector&) unmod: abs() 1st");
  check(tv_assign.abs(), 2.4779023386727, "ThreeVector& op=(const ThreeVector&) unmod: abs() 2nd");

  // class FourVector -------------------------------------------
  
  FourVector fv_default;
  check(fv_default.t() == 0., "FourVector(): t");
  check(fv_default.x() == 0., "FourVector(): x");
  check(fv_default.y() == 0., "FourVector(): y");
  check(fv_default.z() == 0., "FourVector(): z");

  FourVector fv(t, x, y, z);
  check(fv.t() == t, "FourVector(t,x,y,z): t");
  check(fv.x() == x, "FourVector(t,x,y,z): x");
  check(fv.y() == y, "FourVector(t,x,y,z): y");
  check(fv.z() == z, "FourVector(t,x,y,z): z");
  check(fv.flip() == FourVector(t,-x,-y,-z), "FourVector::flip()");
  check(fv.vec() == tv, "FourVector::vec()");

  check(fv == FourVector(t,x,y,z), "FourVector::op==(FourVector, FourVector)");
  check(!(fv == FourVector(-t,x,y,z)), "FourVector::op==(FourVector, FourVector): t");
  check(!(fv == FourVector(t,-x,y,z)), "FourVector::op==(FourVector, FourVector): x");
  check(!(fv == FourVector(t,x,-y,z)), "FourVector::op==(FourVector, FourVector): y");
  check(!(fv == FourVector(t,x,y,-z)), "FourVector::op==(FourVector, FourVector): z");
  check(!(fv != FourVector(t,x,y,z)), "FourVector::op!=(FourVector, FourVector)");
  check(fv != FourVector(-t,x,y,z), "FourVector::op!=(FourVector, FourVector): t");
  check(fv != FourVector(t,-x,y,z), "FourVector::op!=(FourVector, FourVector): x");
  check(fv != FourVector(t,x,-y,z), "FourVector::op!=(FourVector, FourVector): y");
  check(fv != FourVector(t,x,y,-z), "FourVector::op!=(FourVector, FourVector): z");

  // copy constructor
  FourVector fv_copy = fv;
  check(fv_copy.t() == t, "FourVector(const FourVector&) unmod: t");
  check(fv_copy.x() == x, "FourVector(const FourVector&) unmod: x");
  check(fv_copy.y() == y, "FourVector(const FourVector&) unmod: y");
  check(fv_copy.z() == z, "FourVector(const FourVector&) unmod: z");
  check(fv_copy.sqr(), 93.86, "FourVector(const FourVector&) unmod: sqr() 1st");
  check(fv_copy.sqr(), 93.86, "FourVector(const FourVector&) unmod: sqr() 2nd");
  check(fv_copy.abs(), 9.6881370758262, "FourVector(const FourVector&) unmod: abs() 1st");
  check(fv_copy.abs(), 9.6881370758262, "FourVector(const FourVector&) unmod: abs() 2nd");
  check(fv_copy.vec().sqr(), 6.14, "FourVector(const FourVector&) unmod: vec().sqr() 1st");
  check(fv_copy.vec().sqr(), 6.14, "FourVector(const FourVector&) unmod: vec().sqr() 2nd");
  check(fv_copy.vec().abs(), 2.4779023386727, "FourVector(const FourVector&) unmod: vec().abs() 1st");
  check(fv_copy.vec().abs(), 2.4779023386727, "FourVector(const FourVector&) unmod: vec().abs() 2nd");
  fv_copy *= 2.;
  check(fv_copy.t() == t*2., "FourVector(const FourVector&) mod: t");
  check(fv_copy.x() == x*2., "FourVector(const FourVector&) mod: x");
  check(fv_copy.y() == y*2., "FourVector(const FourVector&) mod: y");
  check(fv_copy.z() == z*2., "FourVector(const FourVector&) mod: z");
  check(fv_copy.sqr(), 375.44, "FourVector(const FourVector&) mod: sqr() 1st");
  check(fv_copy.sqr(), 375.44, "FourVector(const FourVector&) mod: sqr() 2nd");
  check(fv_copy.abs(), 19.3762741516524, "FourVector(const FourVector&) mod: abs() 1st");
  check(fv_copy.abs(), 19.3762741516524, "FourVector(const FourVector&) mod: abs() 2nd");
  check(fv_copy.vec().sqr(), 24.56, "FourVector(const FourVector&) mod: vec().sqr() 1st");
  check(fv_copy.vec().sqr(), 24.56, "FourVector(const FourVector&) mod: vec().sqr() 2nd");
  check(fv_copy.vec().abs(), 4.955804677345546, "FourVector(const FourVector&) mod: vec().abs() 1st");
  check(fv_copy.vec().abs(), 4.955804677345546, "FourVector(const FourVector&) mod: vec().abs() 2nd");

  FourVector fv_alt(t, tv);
  check(fv_alt == fv, "FourVector(double, ThreeVector)");

  check(fv.sqr(), 93.86, "FourVector::sqr() 1st");
  check(fv.sqr(), 93.86, "FourVector::sqr() 2nd");
  check(fv.abs(), 9.6881370758262, "FourVector::abs() 1st");
  check(fv.abs(), 9.6881370758262, "FourVector::abs() 2nd");

  FourVector fv1 = fv;
  const double df = 4.2;
  fv1 *= df;
  check(fv1 == FourVector(fv.t()*df, fv.vec()*df), "FourVector::op*=(double)");
  FourVector fv2 = fv;
  fv2 /= df;
  check(fv2 == FourVector(fv.t()/df, fv.vec()/df), "FourVector::op/=(double)");
  FourVector fv3 = fv;
  fv3 += FourVector(1., 1., 1., 1.);
  check(fv3 == FourVector(fv.t()+1., fv.x()+1., fv.y()+1., fv.z()+1.), "FourVector::op+=(FourVector)");
  FourVector fv4 = fv;
  fv4 -= FourVector(1., 1., 1., 1.);
  check(fv4 == FourVector(fv.t()-1., fv.x()-1., fv.y()-1., fv.z()-1.), "FourVector::op-=(FourVector)");

  FourVector fva(4., 1., 2., 3.);
  FourVector fvb(40., 10., 20., 30.);
  
  check(-fva == FourVector(-4., -1., -2., -3.), "FourVector op-(FourVector)");
  check(fva*fvb, 20., "double op*(FourVector, FourVector)");
  check(2.*fva == FourVector(8., 2., 4., 6.), "FourVector op*(double, FourVector)");
  check(fva*2. == FourVector(8., 2., 4., 6.), "FourVector op*(FourVector, double)");
  check(fva/2. == FourVector(2., 0.5, 1., 1.5), "FourVector op/(FourVector, double)");
  check(fva+fvb == FourVector(44., 11., 22., 33.), "FourVector op+(FourVector, FourVector)");
  check(fva-fvb == FourVector(-36., -9., -18., -27.), "FourVector op+(FourVector, FourVector)");

  // automatically generated assignment operator
  FourVector fv_assign = fvb;
  fv_assign = fv;
  check(fv_assign == fv, "FourVector& op=(const FourVector&): == to new");
  check(fv_assign != fvb, "FourVector& op=(const FourVector&): != with old");
  check(fv_assign.sqr(), 93.86, "FourVector& op=(const FourVector&) unmod: sqr() 1st");
  check(fv_assign.sqr(), 93.86, "FourVector& op=(const FourVector&) unmod: sqr() 2nd");
  check(fv_assign.abs(), 9.6881370758262, "FourVector& op=(const FourVector&) unmod: abs() 1st");
  check(fv_assign.abs(), 9.6881370758262, "FourVector& op=(const FourVector&) unmod: abs() 2nd");
  check(fv_assign.vec().sqr(), 6.14, "FourVector& op=(const FourVector&) unmod: vec().sqr() 1st");
  check(fv_assign.vec().sqr(), 6.14, "FourVector& op=(const FourVector&) unmod: vec().sqr() 2nd");
  check(fv_assign.vec().abs(), 2.4779023386727, "FourVector& op=(const FourVector&) unmod: vec().abs() 1st");
  check(fv_assign.vec().abs(), 2.4779023386727, "FourVector& op=(const FourVector&) unmod: vec().abs() 2nd");

  // boost()
  FourVector fv_shift(6., -2., 0.5, 1.3);
  FourVector fv_boosted = boost(fv, fv_shift);
  check(fv_boosted.t(), 10.325204612955, "fv boost: t");
  check(fv_boosted.x(), -2.2401437812233, "fv boost: x");
  check(fv_boosted.y(), -1.214964054694, "fv boost: y");
  check(fv_boosted.z(), 2.5010934577951, "fv boost: z");

  FourVector fv_rev_boosted = boost(fv, fv_shift.flip(), true);
  check(fv_rev_boosted.t(), 10.325204612955, "fv boost rev: t");
  check(fv_rev_boosted.x(), -2.2401437812233, "fv boost rev: x");
  check(fv_rev_boosted.y(), -1.214964054694, "fv boost rev: y");
  check(fv_rev_boosted.z(), 2.5010934577951, "fv boost rev: z");

  // class FourMomentum -----------------------------------------
  
  FourMomentum fm_default;
  check(fm_default.E() == 0., "FourMomentum(): E");
  check(fm_default.px() == 0., "FourMomentum(): px");
  check(fm_default.py() == 0., "FourMomentum(): py");
  check(fm_default.pz() == 0., "FourMomentum(): pz");

  FourMomentum fm(t, x, y, z);
  check(fm.E() == t, "FourMomentum(E,px,py,pz): E");
  check(fm.px() == x, "FourMomentum(E,px,py,pz): px");
  check(fm.py() == y, "FourMomentum(E,px,py,pz): py");
  check(fm.pz() == z, "FourMomentum(E,px,py,pz): pz");
  check(fm.flip() == FourMomentum(t,-x,-y,-z), "FourMomentum::flip()");
  check(fm.fvec() == fv, "FourMomentum::fvec()");
  check(FourVector(fm) == fv, "FourMomentum::operator FourVector()");

  check(fm == FourMomentum(t,x,y,z), "FourMomentum::op==(FourMomentum, FourMomentum)");
  check(!(fm == FourMomentum(-t,x,y,z)), "FourMomentum::op==(FourMomentum, FourMomentum): E");
  check(!(fm == FourMomentum(t,-x,y,z)), "FourMomentum::op==(FourMomentum, FourMomentum): px");
  check(!(fm == FourMomentum(t,x,-y,z)), "FourMomentum::op==(FourMomentum, FourMomentum): py");
  check(!(fm == FourMomentum(t,x,y,-z)), "FourMomentum::op==(FourMomentum, FourMomentum): pz");
  check(!(fm != FourMomentum(t,x,y,z)), "FourMomentum::op!=(FourMomentum, FourMomentum)");
  check(fm != FourMomentum(-t,x,y,z), "FourMomentum::op!=(FourMomentum, FourMomentum): E");
  check(fm != FourMomentum(t,-x,y,z), "FourMomentum::op!=(FourMomentum, FourMomentum): px");
  check(fm != FourMomentum(t,x,-y,z), "FourMomentum::op!=(FourMomentum, FourMomentum): py");
  check(fm != FourMomentum(t,x,y,-z), "FourMomentum::op!=(FourMomentum, FourMomentum): pz");
  
  // copy constructor
  FourMomentum fm_copy = fm;
  check(fm_copy.E() == t, "FourMomentum(const FourMomentum&) unmod: E");
  check(fm_copy.px() == x, "FourMomentum(const FourMomentum&) unmod: px");
  check(fm_copy.py() == y, "FourMomentum(const FourMomentum&) unmod: py");
  check(fm_copy.pz() == z, "FourMomentum(const FourMomentum&) unmod: pz");
  check(fm_copy.m2(), 93.86, "FourMomentum(const FourMomentum&) unmod: sqr() 1st");
  check(fm_copy.m2(), 93.86, "FourMomentum(const FourMomentum&) unmod: sqr() 2nd");
  check(fm_copy.m(), 9.6881370758262, "FourMomentum(const FourMomentum&) unmod: abs() 1st");
  check(fm_copy.m(), 9.6881370758262, "FourMomentum(const FourMomentum&) unmod: abs() 2nd");
  check(fm_copy.pabs2(), 6.14, "FourMomentum(const FourMomentum&) unmod: pabs2() 1st");
  check(fm_copy.pabs2(), 6.14, "FourMomentum(const FourMomentum&) unmod: pabs2() 2nd");
  check(fm_copy.pabs(), 2.4779023386727, "FourMomentum(const FourMomentum&) unmod: pabs() 1st");
  check(fm_copy.pabs(), 2.4779023386727, "FourMomentum(const FourMomentum&) unmod: pabs() 2nd");
  fm_copy *= 2.;
  check(fm_copy.E() == t*2., "FourMomentum(const FourMomentum&) mod: E");
  check(fm_copy.px() == x*2., "FourMomentum(const FourMomentum&) mod: px");
  check(fm_copy.py() == y*2., "FourMomentum(const FourMomentum&) mod: py");
  check(fm_copy.pz() == z*2., "FourMomentum(const FourMomentum&) mod: pz");
  check(fm_copy.m2(), 375.44, "FourMomentum(const FourMomentum&) mod: sqr() 1st");
  check(fm_copy.m2(), 375.44, "FourMomentum(const FourMomentum&) mod: sqr() 2nd");
  check(fm_copy.m(), 19.3762741516524, "FourMomentum(const FourMomentum&) mod: abs() 1st");
  check(fm_copy.m(), 19.3762741516524, "FourMomentum(const FourMomentum&) mod: abs() 2nd");
  check(fm_copy.pabs2(), 24.56, "FourMomentum(const FourMomentum&) mod: pabs2() 1st");
  check(fm_copy.pabs2(), 24.56, "FourMomentum(const FourMomentum&) mod: pabs2() 2nd");
  check(fm_copy.pabs(), 4.955804677345546, "FourMomentum(const FourMomentum&) mod: pabs() 1st");
  check(fm_copy.pabs(), 4.955804677345546, "FourMomentum(const FourMomentum&) mod: pabs() 2nd");

  FourMomentum fm_alt(fv);
  check(fm_alt == fm, "FourMomentum(FourVector)");

  FourMomentum fm_alt_alt(t, tv);
  check(fm_alt_alt == fm, "FourMomentum(double, ThreeVector)");

  check(fm.m(), 9.6881370758262, "FourMomentum::m() 1st");
  check(fm.m2(), 93.86, "FourMomentum::m2() 1st");
  check(fm.pt(), 2.4698178070456, "FourMomentum::pt() 1st");
  check(fm.pt2(), 6.1, "FourMomentum::pt2() 1st");
  check(fm.pabs(), 2.47790233867277, "FourMomentum::pabs() 1st");
  check(fm.pabs2(), 6.14, "FourMomentum::pabs2() 1st");
  check(fm.mt(), 9.99799979996, "FourMomentum::mt() 1st");
  check(fm.mt2(), 99.96, "FourMomentum::mt2() 1st");
  check(fm.eta(), 0.0808893930057, "FourMomentum::eta() 1st");
  check(fm.y(), 0.020002667306849, "FourMomentum::y() 1st");
  check(fm.phi(), -1.0164888305, "FourMomentum::phi() 1st");

  check(fm.m(), 9.6881370758262, "FourMomentum::m() 2nd");
  check(fm.m2(), 93.86, "FourMomentum::m2() 2nd");
  check(fm.pt(), 2.4698178070456, "FourMomentum::pt() 2nd");
  check(fm.pt2(), 6.1, "FourMomentum::pt2() 2nd");
  check(fm.pabs(), 2.47790233867277, "FourMomentum::pabs() 2nd");
  check(fm.pabs2(), 6.14, "FourMomentum::pabs2() 2nd");
  check(fm.mt(), 9.99799979996, "FourMomentum::mt() 2nd");
  check(fm.mt2(), 99.96, "FourMomentum::mt2() 2nd");
  check(fm.eta(), 0.0808893930057, "FourMomentum::eta() 2nd");
  check(fm.y(), 0.020002667306849, "FourMomentum::y() 2nd");
  check(fm.phi(), -1.0164888305, "FourMomentum::phi() 2nd");

  check(fm.m_greater(9.) == true, "FourMomentum::m_greater() true");
  check(fm.m_less(9.) == false, "FourMomentum::m_less() false");
  check(fm.m_less(10.) == true, "FourMomentum::m_less() true");
  check(fm.m_greater(10.) == false, "FourMomentum::m_greater() false");

  FourMomentum fm1 = fm;
  const double dfm = 4.2;
  check((fm1 *= dfm) == FourMomentum(fv*dfm), "FourMomentum::op*=(double)");
  FourMomentum fm2 = fm;
  check((fm2 /= dfm) == FourMomentum(fv/dfm), "FourMomentum::op/=(double)");
  FourMomentum fm3 = fm;
  check((fm3 += FourMomentum(1., 1., 1., 1.)) == FourMomentum(fm.E()+1., fm.px()+1., fm.py()+1., fm.pz()+1.), "FourMomentum::op+=(FourMomentum)");
  FourMomentum fm4 = fm;
  check((fm4 -= FourMomentum(1., 1., 1., 1.)) == FourMomentum(fm.E()-1., fm.px()-1., fm.py()-1., fm.pz()-1.), "FourMomentum::op-=(FourMomentum)");

  FourMomentum fma(4., 1., 2., 3.);
  FourMomentum fmb(40., 10., 20., 30.);
  
  check(FourMomentum(-fma) == FourMomentum(-4., -1., -2., -3.), "FourMomentum op-(FourMomentum)");
  check(fma*fmb, 20., "double op*(FourMomentum, FourMomentum)");
  check(FourMomentum(2.*fma) == FourMomentum(8., 2., 4., 6.), "FourMomentum op*(double, FourMomentum)");
  check(FourMomentum(fma*2.) == FourMomentum(8., 2., 4., 6.), "FourMomentum op*(FourMomentum, double)");
  check(FourMomentum(fma/2.) == FourMomentum(2., 0.5, 1., 1.5), "FourMomentum op/(FourMomentum, double)");
  check(FourMomentum(fma+fmb) == FourMomentum(44., 11., 22., 33.), "FourMomentum op+(FourMomentum, FourMomentum)");
  check(FourMomentum(fma-fmb) == FourMomentum(-36., -9., -18., -27.), "FourMomentum op+(FourMomentum, FourMomentum)");

  // automatically generated assignment operator
  FourMomentum fm_assign = fmb;
  fm_assign = fm;
  check(fm_assign == fm, "FourMomentum& op=(const FourMomentum&): == to new");
  check(fm_assign != fmb, "FourMomentum& op=(const FourMomentum&): != with old");
  check(fm_assign.m2(), 93.86, "FourMomentum& op=(const FourMomentum&) unmod: sqr() 1st");
  check(fm_assign.m2(), 93.86, "FourMomentum& op=(const FourMomentum&) unmod: sqr() 2nd");
  check(fm_assign.m(), 9.6881370758262, "FourMomentum& op=(const FourMomentum&) unmod: abs() 1st");
  check(fm_assign.m(), 9.6881370758262, "FourMomentum& op=(const FourMomentum&) unmod: abs() 2nd");
  check(fm_assign.pabs2(), 6.14, "FourMomentum& op=(const FourMomentum&) unmod: pabs2() 1st");
  check(fm_assign.pabs2(), 6.14, "FourMomentum& op=(const FourMomentum&) unmod: pabs2() 2nd");
  check(fm_assign.pabs(), 2.4779023386727, "FourMomentum& op=(const FourMomentum&) unmod: pabs() 1st");
  check(fm_assign.pabs(), 2.4779023386727, "FourMomentum& op=(const FourMomentum&) unmod: pabs() 2nd");

  // boost()
  FourMomentum fm_shift(6., -2., 0.5, 1.3);
  FourMomentum fm_boosted = boost(fm, fm_shift);
  check(fm_boosted.E(), 10.325204612955, "fm boost: E");
  check(fm_boosted.px(), -2.2401437812233, "fm boost: px");
  check(fm_boosted.py(), -1.214964054694, "fm boost: py");
  check(fm_boosted.pz(), 2.5010934577951, "fm boost: pz");

  FourMomentum fm_rev_boosted = boost(fm, fm_shift.flip(), true);
  check(fm_rev_boosted.E(), 10.325204612955, "fm boost rev: E");
  check(fm_rev_boosted.px(), -2.2401437812233, "fm boost rev: px");
  check(fm_rev_boosted.py(), -1.214964054694, "fm boost rev: py");
  check(fm_rev_boosted.pz(), 2.5010934577951, "fm boost rev: pz");

  // class FourMomentumPair -------------------------------------
  ConstValue<FourMomentum> cv_fm;
  ConstValue<FourMomentum> cv_fm_shift;
  FourMomentumPair fmp(cv_fm, cv_fm_shift);
  cv_fm.set(fm);
  cv_fm_shift.set(fm_shift);

  check(fmp.dot(), 63.39, "FourMomentumPair::dot() 1st");
  check(fmp.m2(), 250.7, "FourMomentumPair::m2() 1st");
  check(fmp.m(), 15.8335087709578, "FourMomentumPair::m() 1st");
  check(fmp.dot3(), -3.39, "FourMomentumPair::dot3() 1st");
  check(fmp.costh(), -0.561335217436, "FourMomentumPair::costh() 1st");
  check(fmp.Deta(), -0.51399086635186975, "FourMomentumPair::Deta() 1st");
  check(fmp.Dy(), -0.20015325241231724, "FourMomentumPair::Dy() 1st");
  check(fmp.Dphi(), 2.370082486216651, "FourMomentumPair::Dphi() 1st");
  check(fmp.DR(), 2.4251757878892084, "FourMomentumPair::DR() 1st");

  check(fmp.dot(), 63.39, "FourMomentumPair::dot() 2nd");
  check(fmp.m2(), 250.7, "FourMomentumPair::m2() 2nd");
  check(fmp.m(), 15.8335087709578, "FourMomentumPair::m() 2nd");
  check(fmp.dot3(), -3.39, "FourMomentumPair::dot3() 2nd");
  check(fmp.costh(), -0.561335217436, "FourMomentumPair::costh() 2nd");
  check(fmp.Deta(), -0.51399086635186975, "FourMomentumPair::Deta() 2nd");
  check(fmp.Dy(), -0.20015325241231724, "FourMomentumPair::Dy() 2nd");
  check(fmp.Dphi(), 2.370082486216651, "FourMomentumPair::Dphi() 2nd");
  check(fmp.DR(), 2.4251757878892084, "FourMomentumPair::DR() 2nd");

  // Helper functions -------------------------------------------
  
  check(deg(1.570796326794895), 90., "helper functions: deg");
  check(rad(90.), 1.570796326794895, "helper functions: rad");
  check(min(1., 2.), 1., "helper functions: min 2");
  check(min(2., 1.), 1., "helper functions: min 2");
  check(max(1., 2.), 2., "helper functions: max 2");
  check(max(2., 1.), 2., "helper functions: max 2");
  check(min(1., 2., 3.), 1., "helper functions: min 3");
  check(max(1., 2., 3.), 3, "helper functions: max 3");
  check(min(1., 2., 3., 4.), 1., "helper functions: min 4");
  check(max(1., 2., 3., 4.), 4., "helper functions: max 4");
  check(min(1., 2., 3., 4., 5., 6.), 1., "helper functions: min 6");
  check(non_neg(3.44), 3.44, "helper functions: non_neg pos");
  check(non_neg(-5.4), 0., "helper functions: non_neg neg");
  check(non_neg(0.), 0., "helper functions: non_neg zero");
  check(sign(4.7), 1., "helper functions: sign pos");
  check(sign(-8.2), -1., "helper functions: sign neg");
}
